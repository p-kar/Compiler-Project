#include "plugin_howto.h"

#include <QtPlugin>

void PluginHowtoAlgorithm::setAutomataCreator(const QSharedPointer<IAutomataCreator> &creator)
{
    m_creator = creator;
}

bool PluginHowtoAlgorithm::run(const IAutomaton::TAutomataList &input,
                          QSharedPointer<IAutomaton> &result, QString *report) const
{
    Q_UNUSED(input) Q_UNUSED(report)

    result = m_creator->createAutomaton
        (ITransition::TCharSet() << "p" << "l" << "u" << "g" << "i" << "n", "A", "\\varepsilon");

    result->createState("Q0", "", true, false);
    result->createState("Q1", "", false, false);
    result->createState("Q2", "", false, false);
    result->createState("Q3", "", false, false);
    result->createState("Q4", "", false, false);
    result->createState("Q5", "", false, false);
    result->createState("Q6", "", false, true);

    result->createTransition("Q0", "Q1", ITransition::TCharSet() << "p");
    result->createTransition("Q1", "Q2", ITransition::TCharSet() << "l");
    result->createTransition("Q2", "Q3", ITransition::TCharSet() << "u");
    result->createTransition("Q3", "Q4", ITransition::TCharSet() << "g");
    result->createTransition("Q4", "Q5", ITransition::TCharSet() << "i");
    result->createTransition("Q5", "Q6", ITransition::TCharSet() << "n");

    return true;
}



PluginHowtoHolder::PluginHowtoHolder()
{}

PluginHowtoHolder::~PluginHowtoHolder()
{}

IAlgorithm::TAlgorithmList PluginHowtoHolder::getAlgorithms() const
{
    IAlgorithm::TAlgorithmList algorithmList;

    algorithmList << QSharedPointer<IAlgorithm>(new PluginHowtoAlgorithm());

    return algorithmList;
}


Q_EXPORT_PLUGIN2(plugin_howto, PluginHowtoHolder)
