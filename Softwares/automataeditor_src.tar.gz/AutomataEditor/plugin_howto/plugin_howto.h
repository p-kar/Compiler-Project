#ifndef PLUGIN_HOWTO_H
#define PLUGIN_HOWTO_H

#include "interfaces/ialgorithm.h"
#include <QObject>

class PluginHowtoAlgorithm : public IAlgorithm
{
public:
    bool requireCreator() const { return true; }
    void setAutomataCreator(const QSharedPointer<IAutomataCreator> &creator);

    bool hasSettingsDialog() const { return false; }
    void runSettingsDialog(QWidget *) {}

    QString getName() const { return "Demo algorithm"; }
    int getInputCount() const { return 0; }

    bool run(const IAutomaton::TAutomataList &input,
             QSharedPointer<IAutomaton> &result,
             QString *report) const;

private:
    QSharedPointer<IAutomataCreator>    m_creator;
};

class PluginHowtoHolder : public QObject, public IAlgorithmHolder
{
    Q_OBJECT
    Q_INTERFACES(IAlgorithmHolder)
public:
    PluginHowtoHolder();
    ~PluginHowtoHolder();

    IAlgorithm::TAlgorithmList getAlgorithms() const;

    QString getVersion() const { return "2.0"; }

    QString getPluginName() const { return "Plugin howto"; }
};

#endif // PLUGIN_HOWTO_H
