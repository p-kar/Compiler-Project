/*********************************
 * AutomataEditor v 2.0          *
 * --------------------          *
 * Milan Kriz, FEL CTU in Prague *
 *  krizmil2@fel.cvut.cz         *
 *  milan.kriz@centrum.cz        *
 *                               *
 * README      Jicin, 2. 1. 2011 *
 *********************************/

Intro
-----
AutomataEditor is vector editor for drawing finite automata according to VauCanSon-G format (LaTeX package).
Editor supports export to several vector formats, e.g. EPS, VauCanSon-G, GraphML.
Then implements basic operations over finite automata, including simulation of DFA/NFA, basic algorithms
(determinization, minimalization, ...) and transition table export.

Subversion
----------
Curretly on webdev (contact zdarekj@fel.cvut.cz for access):
    https://webdev.felk.cvut.cz/~zdarekj/svn/Automata_editor
    
Project is planned to be moved to sourceforge:
    http://sourceforge.net/projects/automataeditor

Instalation
-----------
1) Install Qt 4.6.3 (supported and tested version)
    http://get.qt.nokia.com/qt/source/qt-everywhere-opensource-src-4.6.3.tar.gz
2) Check Automata_Editor.pro and the other subproject files (*.pro)
3) Run qmake in application directory (contains Automata_editor.pro)
4) Run make (nmake) in application directory

GraphViz wrapper
----------------
If don't wish to have GraphViz positioner, comment gvwrapper in Automata_editor.pro:
    SUBDIRS += gvwrapper

Windows: GraphViz version 2.26.3
Linux systems: GraphViz version 2.20.2-8

GraphViz version is checked in runtime and can be set globally in sources.pro:
    DEFINES += GRAPHVIZ_VERSION=\\\"2.26.3\\\"
    (escaping \\ and \" is required for make define's value a string)
or it's possible to change GraphViz supported libraries in constants.h:
    GRAPHVIZ_VERSION    "2.26.3"

For other versions of some modifications in gvwrapper will be probably needed,
because GraphViz interface was changed somewhere between 2.20.x and 2.26.x

Developement IDE
----------------
Possible to use QtCreator and load existing project Automata_editor.pro

    Eclipse
    ----------------------
    * Qt Eclipse Integration available - http://doc.qt.nokia.com/qt-eclipse-1.5/index.html

    Visual Studio
    -----------------------
    Qt Visual Studio Add-in available - http://doc.qt.nokia.com/vs-add-in-1.0/index.html
        
        Known issues:
        -------------
            a) First try to compile gvwrapper fails, but try it again should solve it

Plugin HOWTO
------------
Simple project which shows how to implement custom algorithm as external dynamically loaded plugin.
For build this project allow it in Automata_editor.pro:
    SUBDIRS += plugin_howto

Features settings
-----------------

    SVG support
    -----------
    If don't wish SVG support, comment usage of Qt SVG Module in core project sources.pro
        QT += svg

    OpenGL support (EXPERIMENTAL)
    ------------------------------
    It's possible to experimentally turn on OpenGL drawing by allowing it in sources.pro
        QT += opengl

