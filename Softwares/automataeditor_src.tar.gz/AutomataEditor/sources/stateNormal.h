#ifndef _STATENORMAL_H_412442362623_
#define _STATENORMAL_H_412442362623_

#include "state.h"

class StateNormal : public State
{
public:
    StateNormal(const QPoint &position, Editor *parent, const QString& label,
                const QString& name, bool dBorder, bool dim);

    virtual QString getTypeName() const;

    virtual int getWidth() const {return S_W;}
    virtual int getHeight() const {return S_H;}

    //! export support functions
    //virtual QString getEPS() const;

    //! implements QGraphicsItems functions
    virtual QPainterPath shape() const;
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);    

protected:
    void updateMyPolygon();
};

#endif //_STATENORMAL_H_412442362623_