#ifndef _TWOSTATESTRANSITION_H_4325239509045_
#define _TWOSTATESTRANSITION_H_4325239509045_

#include "transition.h"

class TwoStatesTransition : public Transition
{
public:
    TwoStatesTransition(Editor *parent, State *ss, State *es, 
                        bool left, bool dimmed)
    : Transition(parent, ss, es, dimmed), leftOriented(left)
    {}

    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

    virtual QString getTypeNameSuffix() const { return leftOriented ? "L" : "R"; }

    virtual void assign();
    virtual void unassign();

    bool isLeftOriented();
    void setLeftOriented(bool leftOriented);

protected:
    virtual void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

    bool leftOriented;
};

#endif
