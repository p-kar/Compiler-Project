#include "constants.h"

#include "commands.h"
#include "editor.h"
#include "state.h"
#include "transition.h"
#include "oneStateTransition.h"
#include "twoStatesTransition.h"
#include "label.h"

#include <QGraphicsScene>
#include <QGraphicsItem>
#include <QtDebug>
#include <QList>

QString createCommandString(State *state, const QPointF &pos)
{
    return QObject::tr("%1 at (%2, %3)")
        .arg(state->getName())
        .arg(pos.x())
        .arg(pos.y());
}

//<-- ShowGridFrameCommand --------------------------------------------------

ShowGridFrameCommand::ShowGridFrameCommand(Editor *editor, bool origGrid, bool grid,
                                                           bool origFrame, bool frame)
:   m_editor(editor),
    m_origGrid(origGrid), m_grid(grid),
    m_origFrame(origFrame), m_frame(frame)
{

}

void ShowGridFrameCommand::undo()
{
    m_editor->setShowGridFrame(m_origGrid, m_origFrame);

    setText(getMsg());
}

void ShowGridFrameCommand::redo()
{
    m_editor->setShowGridFrame(m_grid, m_frame);
    setText(getMsg());
}

QString ShowGridFrameCommand::getMsg() const
{
    QString msg = "";
    if (m_origGrid != m_grid)
    {
        msg += "Show Grid ";
        msg += m_grid ? "on" : "off";
    }
    if (m_origFrame != m_frame)
    {
        if (!msg.isEmpty()) msg += " / ";
        msg += "Show Frame ";
        msg += m_frame ? "on" : "off";
    }
    if (msg.isEmpty())
    {
        Q_ASSERT(0 && "nothing to be done!");
        msg = "Show Grid/Frame no action";
    }

    return msg;
}

//-------------------------------------------------- ShowGridFrameCommand -->



//<-- StateMoveCommand ------------------------------------------------------

StateMoveCommand::StateMoveCommand(State *state, const QPointF &oldPos, QUndoCommand *parent)
: QUndoCommand(parent), state(state), oldPos(oldPos)
{
    newPos = state->pos();
}

void StateMoveCommand::undo()
{
    state->setPos(oldPos);
    state->scene()->update();
    setText(QObject::tr("Move %1")
        .arg(createCommandString(state, newPos)));
}

void StateMoveCommand::redo()
{
    state->setPos(newPos);
    state->scene()->update();
    setText(QObject::tr("Move %1")
        .arg(createCommandString(state, newPos)));
}

//------------------------------------------------------ StateMoveCommand -->



//<-- StateAddCommand -------------------------------------------------------

StateAddCommand::StateAddCommand(Editor *editor, State *state, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), state(state)
{}

StateAddCommand::~StateAddCommand()
{
    if (wasUndo) delete state; // smazou se jen states ktere nejsou na scene!
}

void StateAddCommand::undo()
{
    wasUndo = true;
    editor->removeFromListsAndScene(state);
    setText(QObject::tr("Add State %1")
        .arg(createCommandString(state, state->pos())));
}

void StateAddCommand::redo()
{
    wasUndo = false;
    editor->addToListsAndScene(state);
    setText(QObject::tr("Add State %1")
        .arg(createCommandString(state, state->pos())));
}

//------------------------------------------------------- StateAddCommand -->



//<-- StateDeleteCommand ----------------------------------------------------

StateDeleteCommand::StateDeleteCommand(Editor *editor, State *state, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), state(state)
{
    transitionList = state->getTransitionList();
}

StateDeleteCommand::~StateDeleteCommand()
{
    if (!wasUndo) 
    {
        delete state;
        foreach (Transition *tr, transitionList)
        { // TODO: check all posibilities -> if transition is in ANY list everywhere
            delete tr;
        }
    }
}

void StateDeleteCommand::undo()
{
    wasUndo = true;
    editor->addToListsAndScene(state);
    for (int i=0; i<transitionList.size(); i++)
    {
        editor->addToListsAndScene(transitionList[i]);
    }
    setText(QObject::tr("Delete State %1")
        .arg(createCommandString(state, state->pos())));
}

void StateDeleteCommand::redo()
{
    wasUndo = false;
    editor->removeFromListsAndScene(state);
    for (int i=0; i<transitionList.size(); i++)
    {
        editor->removeFromListsAndScene(transitionList[i]);
    }
    setText(QObject::tr("Delete State %1")
        .arg(createCommandString(state, state->pos())));
}

//--------------------------------------------------- StateDeleteCommand -->



//<-- StateEditCommand -----------------------------------------------------

StateEditCommand::StateEditCommand(Editor *editor, State *state, QString label, QString name, bool db, bool dimmed,
                                   bool autoNammed, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), state(state), label_new(label), name_new(name), db_new(db),
  dimmed_new(dimmed), an_new(autoNammed)
{
  label_old = state->getLabel();
  name_old = state->getName();
  db_old = state->isDoubleBorder();
  dimmed_old = state->isDimmed();
  an_old = state->isAutoNammed();
}

void StateEditCommand::undo(){
    state->setLabel(label_old);
    editor->renameState(state, name_old);
    state->setDoubleBorder(db_old);
    state->setDimmed(dimmed_old);
    state->setAutoNammed(an_old);
    setText(QObject::tr("Edit State %1")
        .arg(createCommandString(state, state->pos())));
    state->update();
}

void StateEditCommand::redo(){
    state->setLabel(label_new);
    editor->renameState(state, name_new);
    state->setDoubleBorder(db_new);
    state->setDimmed(dimmed_new);
    state->setAutoNammed(an_new);
    setText(QObject::tr("Edit State %1")
        .arg(createCommandString(state, state->pos())));
    state->update();
}

//----------------------------------------------------- StateEditCommand -->



//<-- StateEditCommand -----------------------------------------------------

StateEditWithDelCommand::StateEditWithDelCommand(Editor *editor, State *state_backup, State *state_new,
                        QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), state_backup(state_backup), state_new(state_new)
{
    transitionList = state_backup->getTransitionList();
}

StateEditWithDelCommand::~StateEditWithDelCommand()
{
    if (wasUndo)
    {
        delete state_new;
    }
    else
    {
        delete state_backup;
    }
}

void StateEditWithDelCommand::undo()
{
    wasUndo = true;
    editor->removeFromListsAndScene(state_new);
    editor->addToListsAndScene(state_backup);
  
    state_backup->setTransitionList(transitionList); // move list of transitions
    state_new->clearTransitionList();
  
    for (int i=0; i<transitionList.size(); i++)
    {
        if (transitionList[i]->getStartState() == state_new)
            transitionList[i]->setStartState(state_backup);
        else
            transitionList[i]->setEndState(state_backup);
    }

    state_backup->adjustTransitions();
    setText(QObject::tr("EditWithDel State"));
}

void StateEditWithDelCommand::redo()
{
    wasUndo = false;
    editor->removeFromListsAndScene(state_backup);
    editor->addToListsAndScene(state_new);

    state_new->setTransitionList(transitionList); // move list of transitions
    state_backup->clearTransitionList();

    for (int i=0; i<transitionList.size(); i++){
        if (transitionList[i]->getStartState() == state_backup)
            transitionList[i]->setStartState(state_new);
        else
            transitionList[i]->setEndState(state_new);
    }

    copyExtendedParameters(state_new, state_backup);

    state_new->adjustTransitions();
    setText(QObject::tr("EditWithDel State"));
}

void StateEditWithDelCommand::copyExtendedParameters(State* s1, State* const s2)
{    
    s1->stateFillColor = s2->stateFillColor;
    s1->stateFillStatus = s2->stateFillStatus;    
    s1->stateLabelColor = s2->stateLabelColor;
    s1->setStateLabelScale(s2->stateLabelScale);
    s1->stateLineColor = s2->stateLineColor;
    s1->setStateLineDoubleCoef(s2->stateLineDoubleCoef);
    s1->setStateLineDoubleSep(s2->stateLineDoubleSep);
    s1->stateLineStyle = s2->stateLineStyle;
    s1->setStateLineWidth(s2->stateLineWidth);

    s1->dimStateFillColor = s2->dimStateFillColor;    
    s1->dimStateLabelColor = s2->dimStateLabelColor;
    s1->setDimStateLineCoef(s2->dimStateLineCoef);
    s1->dimStateLineColor = s2->dimStateLineColor;
    s1->dimStateLineStyle = s2->dimStateLineStyle;
}

//----------------------------------------------------- StateEditCommand -->



//<-- StateEditExtendedCommand ---------------------------------------------

StateEditExtendedCommand::StateEditExtendedCommand
(State *state, Qt::PenStyle lineS, float lineW, const QString &lineC,
 const QString &labelC, float labelS, Qt::BrushStyle fillS, 
 const QString &fillC, Qt::PenStyle dimLineS, const QString &dimLineC,
 float dimLineCoef, const QString &dimLabelC, const QString &dimFillC,
 float lineDC, float lineDS, QUndoCommand *parent)
: QUndoCommand(parent), state(state),
  lineStyle(lineS), lineWidth(lineW), lineColor(lineC),
  labelColor(labelC), labelScale(labelS), fillStatus(fillS), fillColor(fillC),
  dimLineStyle(dimLineS), dimLineColor(dimLineC), dimLineCoef(dimLineCoef),
  dimLabelColor(dimLabelC), dimFillColor(dimFillC), 
  lineDoubleCoef(lineDC), lineDoubleSep(lineDS)
{
  lineStyle_old = state->stateLineStyle;
  lineWidth_old = state->stateLineWidth;
  lineColor_old = state->stateLineColor;
  labelColor_old = state->stateLabelColor;
  labelScale_old = state->stateLabelScale;
  fillStatus_old = state->stateFillStatus;
  fillColor_old = state->stateFillColor;
  
  dimLineStyle_old = state->dimStateLineStyle;
  dimLineColor_old = state->dimStateLineColor;
  dimLineCoef_old = state->dimStateLineCoef;
  dimLabelColor_old = state->dimStateLabelColor;
  dimFillColor_old = state->dimStateFillColor;
  
  lineDoubleCoef_old = state->stateLineDoubleCoef;
  lineDoubleSep_old = state->stateLineDoubleSep;
}

void StateEditExtendedCommand::undo(){
  state->stateLineStyle = lineStyle_old;
  state->setStateLineWidth(lineWidth_old);
  state->stateLineColor = lineColor_old;
  state->stateLabelColor = labelColor_old;
  state->setStateLabelScale(labelScale_old);
  state->stateFillStatus = fillStatus_old;
  state->stateFillColor = fillColor_old;
  
  state->dimStateLineStyle = dimLineStyle_old;
  state->dimStateLineColor = dimLineColor_old;
  state->setDimStateLineCoef(dimLineCoef_old);
  state->dimStateLabelColor = dimLabelColor_old;
  state->dimStateFillColor = dimFillColor_old;
  
  state->setStateLineDoubleCoef(lineDoubleCoef_old);
  state->setStateLineDoubleSep(lineDoubleSep_old);
  
  state->update();
  state->adjustTransitions();
  
  setText(QObject::tr("Edit state %1 params")
    .arg(createCommandString(state, state->pos())));
}

void StateEditExtendedCommand::redo(){
  state->stateLineStyle = lineStyle;
  state->setStateLineWidth(lineWidth);
  state->stateLineColor = lineColor;
  state->stateLabelColor = labelColor;
  state->setStateLabelScale(labelScale);
  state->stateFillStatus = fillStatus;
  state->stateFillColor = fillColor;
  
  state->dimStateLineStyle = dimLineStyle;
  state->dimStateLineColor = dimLineColor;
  state->setDimStateLineCoef(dimLineCoef);
  state->dimStateLabelColor = dimLabelColor;
  state->dimStateFillColor = dimFillColor;
  
  state->setStateLineDoubleCoef(lineDoubleCoef);
  state->setStateLineDoubleSep(lineDoubleSep);
  
  state->update();
  state->adjustTransitions();
  
  setText(QObject::tr("Edit state %1 params")
    .arg(createCommandString(state, state->pos())));
}

//--------------------------------------------- StateEditExtendedCommand -->



//<-- TransitionAddCommand -------------------------------------------------

TransitionAddCommand::TransitionAddCommand(Editor *editor, Transition *transition, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), transition(transition)
{}

TransitionAddCommand::~TransitionAddCommand(){
  if (wasUndo) delete transition; // smazou se jen transitions ktere nejsou na scene!
}

void TransitionAddCommand::undo(){
  wasUndo = true;
  editor->removeFromListsAndScene(transition);
  setText(QObject::tr("Add Transition"));
}

void TransitionAddCommand::redo(){
  wasUndo = false;
  editor->addToListsAndScene(transition);  
  setText(QObject::tr("Add Transition"));
}

//------------------------------------------------- TransitionAddCommand -->



//<-- TransitionDeleteCommand ----------------------------------------------

TransitionDeleteCommand::TransitionDeleteCommand(Editor *editor, Transition *transition, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), transition(transition)
{}

TransitionDeleteCommand::~TransitionDeleteCommand(){
  if (!wasUndo){
    delete transition; // transition ktere jsem deletnul je treba vymazat fyzicky
  }
}

void TransitionDeleteCommand::undo(){
  wasUndo = true;
  editor->addToListsAndScene(transition);
  setText(QObject::tr("Del Transition"));
}

void TransitionDeleteCommand::redo(){
  wasUndo = false;
  editor->removeFromListsAndScene(transition);
  setText(QObject::tr("Del Transition"));
}

//---------------------------------------------- TransitionDeleteCommand -->



//<-- OneStateTransitionEditCommand ----------------------------------------

OneStateTransitionEditCommand::OneStateTransitionEditCommand
(OneStateTransition *transition, QString label, float labelPos, int direction, 
 bool dimmed, QUndoCommand *parent)
:   QUndoCommand(parent), tr(transition),
    lab_new(label), labelPos_new(labelPos), dir_new(direction), dimmed_new(dimmed)
{
  lab_old = tr->getLabelText();
  labelPos_old = tr->getLabelPos();
  dir_old = tr->getDirection();
  dimmed_old = tr->isDimmed();
}

void OneStateTransitionEditCommand::undo(){
  tr->setLabelText(lab_old);
  tr->setLabelPos(labelPos_old);
  tr->setDirection(dir_old);
  tr->setDimmed(dimmed_old);
  tr->adjust();
  setText(QObject::tr("Edit Transition"));
}

void OneStateTransitionEditCommand::redo(){
  tr->setLabelText(lab_new);
  tr->setLabelPos(labelPos_new);
  tr->setDirection(dir_new);
  tr->setDimmed(dimmed_new);
  tr->adjust();
  setText(QObject::tr("Edit Transition"));
}

//---------------------------------------- OneStateTransitionEditCommand -->


//<-- TwoStatesTransitionEditCommand ---------------------------------------

TwoStatesTransitionEditCommand::TwoStatesTransitionEditCommand
(TwoStatesTransition *tr, QString label, float labelPos, bool dimmed, bool leftOriented, 
 int arcAngle, int arcAngleB, float ncurv, QUndoCommand *parent)
: QUndoCommand(parent), tr(tr),
  lab_new(label), labelPos_new(labelPos), dimmed_new(dimmed), lo_new(leftOriented)
  , angle_new(arcAngle), angleB_new(arcAngleB), ncurv_new(ncurv)
{
  lab_old = tr->getLabelText();
  labelPos_old = tr->getLabelPos();
  dimmed_old = tr->isDimmed();
  lo_old = tr->isLeftOriented();  
  angle_old = tr->getArcAngle();
  angleB_old = tr->getArcAngleB();
  ncurv_old = tr->getNCurv();
}

void TwoStatesTransitionEditCommand::undo(){
  tr->setLabelText(lab_old);
  tr->setLabelPos(labelPos_old);
  tr->setLeftOriented(lo_old);
  tr->setDimmed(dimmed_old);
  tr->setArcAngle(angle_old);
  tr->setArcAngleB(angleB_old);
  tr->setNCurv(ncurv_old);
  tr->adjust();
  setText(QObject::tr("Edit Transition"));
}

void TwoStatesTransitionEditCommand::redo(){
  tr->setLabelText(lab_new);
  tr->setLabelPos(labelPos_new);
  tr->setLeftOriented(lo_new);
  tr->setDimmed(dimmed_new);
  tr->setArcAngle(angle_new);
  tr->setArcAngleB(angleB_new);
  tr->setNCurv(ncurv_new);
  tr->adjust();
  setText(QObject::tr("Edit Transition"));
}

//---------------------------------------------- TwoStatesTransitionEditCommand -->




//<-- TransitionEditWithDelCommand ------------------------------------------------

TransitionEditWithDelCommand::TransitionEditWithDelCommand
(Editor *editor, Transition *tr_backup, Transition *tr_new, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), tr_backup(tr_backup), tr_new(tr_new)
{}

TransitionEditWithDelCommand::~TransitionEditWithDelCommand(){
    if (wasUndo)
    {
        delete tr_new;
    }
    else
    {
        delete tr_backup;
    }
}

void TransitionEditWithDelCommand::undo()
{
    wasUndo = true;
    
    tr_backup->nextLabels = tr_new->nextLabels;
    
    editor->removeFromListsAndScene(tr_new);
    editor->addToListsAndScene(tr_backup);
    
    tr_new->nextLabels.clear();
    
    tr_backup->adjust();
    setText(QObject::tr("EditWithDel Transition"));
}

void TransitionEditWithDelCommand::redo()
{
    wasUndo = false;
    
    tr_new->nextLabels = tr_backup->nextLabels;

    editor->removeFromListsAndScene(tr_backup);
    editor->addToListsAndScene(tr_new);
    
    
    tr_backup->nextLabels.clear();

    copyExtendedParameters(tr_new, tr_backup);

    tr_new->adjust();
    setText(QObject::tr("EditWithDel Transition"));
}

void TransitionEditWithDelCommand::copyExtendedParameters(Transition *tr1, Transition* const tr2)
{    
    tr1->edgeLabelColor = tr2->edgeLabelColor;
    tr1->setEdgeLabelScale(tr2->edgeLabelScale);
    tr1->edgeLineBorderCoef = tr2->edgeLineBorderCoef;
    tr1->edgeLineBorderColor = tr2->edgeLineBorderColor;
    tr1->edgeLineColor = tr2->edgeLineColor;
    tr1->edgeLineDblCoef = tr2->edgeLineDblCoef;
    tr1->edgeLineDblSep = tr2->edgeLineDblSep;
    tr1->edgeLineDblStatus = tr2->edgeLineDblStatus;
    tr1->edgeLineStyle = tr2->edgeLineStyle;
    tr1->setEdgeLineWidth(tr2->edgeLineWidth);
    
    tr1->dimEdgeLabelColor = tr2->dimEdgeLabelColor;
    tr1->setDimEdgeLineCoef(tr2->dimEdgeLineCoef);
    tr1->dimEdgeLineColor = tr2->dimEdgeLineColor;
    tr1->dimEdgeLineStyle = tr2->dimEdgeLineStyle;
}

//------------------------------------------------ TransitionEditWithDelCommand -->



//<-- TransitionEditExtendedCommand -----------------------------------------------

TransitionEditExtendedCommand::TransitionEditExtendedCommand
(Transition *tr, Qt::PenStyle lineS, float lineW, const QString &lineC,
 const QString &labelC, float labelS, bool lineDoubleS, Qt::PenStyle dimLineS, 
 const QString &dimLineC, float dimLineCoef, const QString &dimLabelC,
 float borderCoef, const QString &borderColor,
 float lineDC, float lineDS, QUndoCommand *parent)
: QUndoCommand(parent), tr(tr),
  lineStyle(lineS), lineWidth(lineW), lineColor(lineC),
  labelColor(labelC), labelScale(labelS), lineDoubleStatus(lineDoubleS),
  dimLineStyle(dimLineS), dimLineColor(dimLineC), dimLineCoef(dimLineCoef),
  dimLabelColor(dimLabelC), borderCoef(borderCoef), borderColor(borderColor),
  lineDoubleCoef(lineDC), lineDoubleSep(lineDS)
{
  lineStyle_old = tr->edgeLineStyle;
  lineWidth_old = tr->edgeLineWidth;
  lineColor_old = tr->edgeLineColor;
  labelColor_old = tr->edgeLabelColor;
  labelScale_old = tr->edgeLabelScale;
  lineDoubleStatus_old = tr->edgeLineDblStatus;
  
  dimLineStyle_old = tr->dimEdgeLineStyle;
  dimLineColor_old = tr->dimEdgeLineColor;
  dimLineCoef_old = tr->dimEdgeLineCoef;
  dimLabelColor_old = tr->dimEdgeLabelColor;
  
  borderCoef_old = tr->edgeLineBorderCoef;
  borderColor_old = tr->edgeLineBorderColor;
  
  lineDoubleCoef_old = tr->edgeLineDblCoef;
  lineDoubleSep_old = tr->edgeLineDblSep;
}

void TransitionEditExtendedCommand::undo(){
  tr->edgeLineStyle = lineStyle_old;
  tr->setEdgeLineWidth(lineWidth_old);
  tr->edgeLineColor = lineColor_old;
  tr->edgeLabelColor = labelColor_old;
  tr->setEdgeLabelScale(labelScale_old);
  tr->edgeLineDblStatus = lineDoubleStatus_old;
  
  tr->dimEdgeLineStyle = dimLineStyle_old;
  tr->dimEdgeLineColor = dimLineColor_old;
  tr->setDimEdgeLineCoef(dimLineCoef_old);
  tr->dimEdgeLabelColor = dimLabelColor_old;
  
  tr->edgeLineBorderCoef = borderCoef_old;
  tr->edgeLineBorderColor = borderColor_old;
  
  tr->edgeLineDblCoef = lineDoubleCoef_old;
  tr->edgeLineDblSep = lineDoubleSep_old;
  
  tr->update();
  setText(QObject::tr("Transition params change"));
}

void TransitionEditExtendedCommand::redo(){
  tr->edgeLineStyle = lineStyle;
  tr->setEdgeLineWidth(lineWidth);
  tr->edgeLineColor = lineColor;
  tr->edgeLabelColor = labelColor;
  tr->setEdgeLabelScale(labelScale);
  tr->edgeLineDblStatus = lineDoubleStatus;
  
  tr->dimEdgeLineStyle = dimLineStyle;
  tr->dimEdgeLineColor = dimLineColor;
  tr->setDimEdgeLineCoef(dimLineCoef);
  tr->dimEdgeLabelColor = dimLabelColor;
  
  tr->edgeLineBorderCoef = borderCoef;
  tr->edgeLineBorderColor = borderColor;
  
  tr->edgeLineDblCoef = lineDoubleCoef;
  tr->edgeLineDblSep = lineDoubleSep;
  
  tr->update();
  setText(QObject::tr("Transition params change"));
}

//--------------------------------------------- TransitionEditExtendedCommand -->



//<-- NextLabelAddCommand --------------------------------------------------------

NextLabelAddCommand::NextLabelAddCommand(Editor *editor, LabelX *label, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), label(label)
{
}

NextLabelAddCommand::~NextLabelAddCommand()
{
  if (wasUndo)
  {
    delete label;
  }
}

void NextLabelAddCommand::undo()
{
    wasUndo = true;
    editor->removeFromListAndScene(label);
    setText(QObject::tr("NextLabel added"));
}

void NextLabelAddCommand::redo()
{    
    wasUndo = false;
    editor->addToListAndScene(label);
    label->getTransition()->adjust();
    setText(QObject::tr("NextLabel added"));
}

//--------------------------------------------------------- NextLabelAddCommand -->



//<-- NextLabelDeleteCommand ------------------------------------------------------

NextLabelDeleteCommand::NextLabelDeleteCommand(Editor *editor, LabelX *label, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), label(label)
{
}

NextLabelDeleteCommand::~NextLabelDeleteCommand()
{
  if (!wasUndo)
  {
    delete label;
  }
}

void NextLabelDeleteCommand::undo()
{
    wasUndo = true;
    editor->addToListAndScene(label);
    setText(QObject::tr("NextLabel delete"));
}

void NextLabelDeleteCommand::redo()
{
    wasUndo = false;
    editor->removeFromListAndScene(label);
    setText(QObject::tr("NextLabel delete"));
}

//------------------------------------------------------ NextLabelDeleteCommand -->



//<-- NextLabelEditCommand --------------------------------------------------------

NextLabelEditCommand::NextLabelEditCommand
(LabelX *label, const QString &labelText, float labelPos, bool isLeft, QUndoCommand *parent)
: QUndoCommand(parent), label(label), labelText_new(labelText), labelPos_new(labelPos), isLeft_new(isLeft)
{
    labelText_backup = label->text();
    labelPos_backup = label->posParam();
    isLeft_backup = label->left();
}

void NextLabelEditCommand::undo()
{
    label->setText(labelText_backup);
    label->setPosParam(labelPos_backup);
    label->setLeftOriented(isLeft_backup);
    label->getTransition()->adjust();
    setText(QObject::tr("NextLabel edit"));
}

void NextLabelEditCommand::redo()
{
    label->setText(labelText_new);
    label->setPosParam(labelPos_new);
    label->setLeftOriented(isLeft_new);   
    label->getTransition()->adjust();
    setText(QObject::tr("NextLabel edit"));
}

//-------------------------------------------------------- NextLabelEditCommand -->



//<-- EditorChangeGridRectCommand -------------------------------------------------

EditorChangeGridRectCommand::EditorChangeGridRectCommand
(Editor *editor, QRect gridRect, int border, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), gridRect_new(gridRect), border_new(border)
{
  gridRect_old = editor->getGridRect();
  border_old = editor->getBorder();
}

void EditorChangeGridRectCommand::undo()
{
  editor->setBorder(border_old); // has to be before setGridRect, because this method use border value!
  editor->setGridRect(gridRect_old);  
  setText(QObject::tr("Change GridRect"));
}

void EditorChangeGridRectCommand::redo()
{
  editor->setBorder(border_new); // has to be before setGridRect, because this method use border value!
  editor->setGridRect(gridRect_new);
  setText(QObject::tr("Change GridRect"));
}

//------------------------------------------------- EditorChangeGridRectCommand -->



//<-- StateStyleChangeCommand ---------------------------------------------

StateStyleChangeCommand::StateStyleChangeCommand
(Editor *editor, int changeT, Qt::PenStyle lineS, float lineW, const QString &lineC,
 const QString &labelC, float labelS, Qt::BrushStyle fillS, 
 const QString &fillC, Qt::PenStyle dimLineS, const QString &dimLineC,
 float dimLineCoef, const QString &dimLabelC, const QString &dimFillC,
 float lineDC, float lineDS, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), changeType(changeT),
  lineStyle(lineS), lineWidth(lineW), lineColor(lineC),
  labelColor(labelC), labelScale(labelS), fillStatus(fillS), fillColor(fillC),
  dimLineStyle(dimLineS), dimLineColor(dimLineC), dimLineCoef(dimLineCoef),
  dimLabelColor(dimLabelC), dimFillColor(dimFillC), 
  lineDoubleCoef(lineDC), lineDoubleSep(lineDS)
{
  lineStyle_old = editor->stateLineStyle;
  lineWidth_old = editor->stateLineWidth;
  lineColor_old = editor->stateLineColor;
  labelColor_old = editor->stateLabelColor;
  labelScale_old = editor->stateLabelScale;
  fillStatus_old = editor->stateFillStatus;
  fillColor_old = editor->stateFillColor;
  
  dimLineStyle_old = editor->dimStateLineStyle;
  dimLineColor_old = editor->dimStateLineColor;
  dimLineCoef_old = editor->dimStateLineCoef;
  dimLabelColor_old = editor->dimStateLabelColor;
  dimFillColor_old = editor->dimStateFillColor;
  
  lineDoubleCoef_old = editor->stateLineDoubleCoef;
  lineDoubleSep_old = editor->stateLineDoubleSep;
  
  changedStates.clear();
  if (changeType == 1)
  foreach(State *state, editor->getStateList()){
    if ((state->stateLineStyle == editor->stateLineStyle) && 
        (state->stateLineWidth == 1) &&
        (state->stateLineColor == editor->stateLineColor) &&
        (state->stateLabelColor == editor->stateLabelColor) &&
        (state->stateLabelScale == 1) &&
        (state->stateFillStatus == editor->stateFillStatus) &&
        (state->stateFillColor == editor->stateFillColor) &&
        (state->dimStateLineStyle == editor->dimStateLineStyle) &&
        (state->dimStateLineColor == editor->dimStateLineColor) &&
        (state->dimStateLineCoef == editor->dimStateLineCoef) &&
        (state->dimStateLabelColor == editor->dimStateLabelColor) &&
        (state->dimStateFillColor == editor->dimStateFillColor) &&
        (state->stateLineDoubleCoef == editor->stateLineDoubleCoef) &&
        (state->stateLineDoubleSep == editor->stateLineDoubleSep)){
      changedStates << state;
    }
  }
  else if (changeType == 2){
    changedStates = editor->getStateList();
    lineStyleMap.clear(); lineWidthMap.clear(); lineColorMap.clear();
    labelColorMap.clear(); labelScaleMap.clear(); fillStatusMap.clear();
    fillColorMap.clear();
    dimLineStyleMap.clear(); dimLineColorMap.clear(); dimLineCoefMap.clear();
    dimLabelColorMap.clear(); dimFillColorMap.clear();
    lineDoubleCoefMap.clear(); lineDoubleSepMap.clear();
    foreach (State *state, editor->getStateList())
    {
      lineStyleMap.insert(state, state->stateLineStyle);
      lineWidthMap.insert(state, state->stateLineWidth);
      lineColorMap.insert(state, state->stateLineColor);
      labelColorMap.insert(state, state->stateLabelColor);
      labelScaleMap.insert(state, state->stateLineWidth);
      fillStatusMap.insert(state, state->stateFillStatus);
      fillColorMap.insert(state, state->stateFillColor);
      dimLineStyleMap.insert(state, state->dimStateLineStyle);
      dimLineColorMap.insert(state, state->dimStateLineColor);
      dimLineCoefMap.insert(state, state->dimStateLineCoef);
      dimLabelColorMap.insert(state, state->dimStateLabelColor);
      dimFillColorMap.insert(state, state->dimStateFillColor);
      lineDoubleCoefMap.insert(state, state->stateLineDoubleCoef);
      lineDoubleSepMap.insert(state, state->stateLineDoubleSep);
    }
  }
}

void StateStyleChangeCommand::undo()
{
  editor->stateLineStyle = lineStyle_old;
  editor->stateLineWidth = lineWidth_old;
  editor->stateLineColor = lineColor_old;
  editor->stateLabelColor = labelColor_old;
  editor->stateLabelScale = labelScale_old;
  editor->stateFillStatus = fillStatus_old;
  editor->stateFillColor = fillColor_old;
  
  editor->dimStateLineStyle = dimLineStyle_old;
  editor->dimStateLineColor = dimLineColor_old;
  editor->dimStateLineCoef = dimLineCoef_old;
  editor->dimStateLabelColor = dimLabelColor_old;
  editor->dimStateFillColor = dimFillColor_old;
  
  editor->stateLineDoubleCoef = lineDoubleCoef_old;
  editor->stateLineDoubleSep = lineDoubleSep_old;

  if (changeType == 1){
    foreach (State *state, changedStates){
      state->stateLineStyle = lineStyle_old;
      //state->stateLineWidth = 1;
      state->stateLineColor = lineColor_old;
      state->stateLabelColor = labelColor_old;
      //state->stateLabelScale = 1;
      state->stateFillStatus = fillStatus_old;
      state->stateFillColor = fillColor_old;
      
      state->dimStateLineStyle = dimLineStyle_old;
      state->dimStateLineColor = dimLineColor_old;
      state->setDimStateLineCoef(dimLineCoef_old);
      state->dimStateLabelColor = dimLabelColor_old;
      state->dimStateFillColor = dimFillColor_old;
      
      state->setStateLineDoubleCoef(lineDoubleCoef_old);
      state->setStateLineDoubleSep(lineDoubleSep_old);
    }
  }
  else if (changeType == 2){
    foreach (State *state, changedStates){
      state->stateLineStyle = lineStyleMap.value(state);
      state->setStateLineWidth(lineWidthMap.value(state));
      state->stateLineColor = lineColorMap.value(state);
      state->stateLabelColor = labelColorMap.value(state);
      state->setStateLabelScale(labelScaleMap.value(state));
      state->stateFillStatus = fillStatusMap.value(state);
      state->stateFillColor = fillColorMap.value(state);
      
      state->dimStateLineStyle = dimLineStyleMap.value(state);
      state->dimStateLineColor = dimLineColorMap.value(state);
      state->setDimStateLineCoef(dimLineCoefMap.value(state));
      state->dimStateLabelColor = dimLabelColorMap.value(state);
      state->dimStateFillColor = dimFillColorMap.value(state);
      
      state->setStateLineDoubleCoef(lineDoubleCoefMap.value(state));
      state->setStateLineDoubleSep(lineDoubleSepMap.value(state));
    }
  }
  
  editor->update();
  
  QString s_arg = "";
  if (changeType == 1){
    s_arg = " - non changed states";
  }
  else if (changeType == 2){
    s_arg = " - to all states";
  }
  setText(QObject::tr("Change state style%1").arg(s_arg));
}

void StateStyleChangeCommand::redo(){
  editor->stateLineStyle = lineStyle;
  editor->stateLineWidth = lineWidth;
  editor->stateLineColor = lineColor;
  editor->stateLabelColor = labelColor;
  editor->stateLabelScale = labelScale;
  editor->stateFillStatus = fillStatus;
  editor->stateFillColor = fillColor;
  
  editor->dimStateLineStyle = dimLineStyle;
  editor->dimStateLineColor = dimLineColor;
  editor->dimStateLineCoef = dimLineCoef;
  editor->dimStateLabelColor = dimLabelColor;
  editor->dimStateFillColor = dimFillColor;
  
  editor->stateLineDoubleCoef = lineDoubleCoef;
  editor->stateLineDoubleSep = lineDoubleSep;
  
  if (changeType != 0){
    foreach(State *state, changedStates){
      state->stateLineStyle = lineStyle;
      state->setStateLineWidth(1);
      state->stateLineColor = lineColor;
      state->stateLabelColor = labelColor;
      state->setStateLabelScale(1);
      state->stateFillStatus = fillStatus;
      state->stateFillColor = fillColor;

      state->dimStateLineStyle = dimLineStyle;
      state->dimStateLineColor = dimLineColor;
      state->setDimStateLineCoef(dimLineCoef);
      state->dimStateLabelColor = dimLabelColor;
      state->dimStateFillColor = dimFillColor;

      state->setStateLineDoubleCoef(lineDoubleCoef);
      state->setStateLineDoubleSep(lineDoubleSep);
    }
  }
  
  editor->update();
  
  QString s_arg = "";
  if (changeType == 1){
    s_arg = " - non changed states";
  }
  else if (changeType == 2){
    s_arg = " - to all states";
  }
  setText(QObject::tr("Change state style%1").arg(s_arg));
}

//--------------------------------------------- StateStyleChangeCommand -->



//<-- TransitionStyleChangeCommand ---------------------------------------------

TransitionStyleChangeCommand::TransitionStyleChangeCommand
(Editor *editor, int changeT, Qt::PenStyle lineS, float lineW, const QString &lineC,
 const QString &labelC, float labelS, bool lineDoubleS, Qt::PenStyle dimLineS, 
 const QString &dimLineC, float dimLineCoef, const QString &dimLabelC,
 float borderCoef, const QString &borderColor,
 float lineDC, float lineDS, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), changeType(changeT),
  lineStyle(lineS), lineWidth(lineW), lineColor(lineC),
  labelColor(labelC), labelScale(labelS), lineDoubleStatus(lineDoubleS),
  dimLineStyle(dimLineS), dimLineColor(dimLineC), dimLineCoef(dimLineCoef),
  dimLabelColor(dimLabelC), borderCoef(borderCoef), borderColor(borderColor),
  lineDoubleCoef(lineDC), lineDoubleSep(lineDS)
{
  lineStyle_old = editor->edgeLineStyle;
  lineWidth_old = editor->edgeLineWidth;
  lineColor_old = editor->edgeLineColor;
  labelColor_old = editor->edgeLabelColor;
  labelScale_old = editor->edgeLabelScale;
  lineDoubleStatus_old = editor->edgeLineDblStatus;
  
  dimLineStyle_old = editor->dimEdgeLineStyle;
  dimLineColor_old = editor->dimEdgeLineColor;
  dimLineCoef_old = editor->dimEdgeLineCoef;
  dimLabelColor_old = editor->dimEdgeLabelColor;
  
  borderCoef_old = editor->edgeLineBorderCoef;
  borderColor_old = editor->edgeLineBorderColor;
  
  lineDoubleCoef_old = editor->edgeLineDblCoef;
  lineDoubleSep_old = editor->edgeLineDblSep;
  
  changedTransitions.clear();
  if (changeType == 1)
  foreach(Transition *tr, editor->getTransitionList())
  {
    if ((tr->edgeLineStyle == editor->edgeLineStyle) && 
        (tr->edgeLineWidth == 1) &&
        (tr->edgeLineColor == editor->edgeLineColor) &&
        (tr->edgeLabelColor == editor->edgeLabelColor) &&
        (tr->edgeLabelScale == 1) &&
        (tr->edgeLineDblStatus == editor->edgeLineDblStatus) &&
        (tr->dimEdgeLineStyle == editor->dimEdgeLineStyle) &&
        (tr->dimEdgeLineColor == editor->dimEdgeLineColor) &&
        (tr->dimEdgeLineCoef == editor->dimEdgeLineCoef) &&
        (tr->dimEdgeLabelColor == editor->dimEdgeLabelColor) &&
        (tr->edgeLineBorderCoef == editor->edgeLineBorderCoef) &&
        (tr->edgeLineBorderColor == editor->edgeLineBorderColor) &&
        (tr->edgeLineDblCoef == editor->edgeLineDblCoef) &&
        (tr->edgeLineDblSep == editor->edgeLineDblSep)){
      changedTransitions << tr;
    }
  }
  else if (changeType == 2)
  {
    changedTransitions = editor->getTransitionList();
    lineStyleMap.clear(); lineWidthMap.clear(); lineColorMap.clear();
    labelColorMap.clear(); labelScaleMap.clear(); lineDoubleStatusMap.clear();
    dimLineStyleMap.clear(); dimLineColorMap.clear(); dimLineCoefMap.clear();
    dimLabelColorMap.clear();
    lineBorderCoefMap.clear(); lineBorderColorMap.clear();
    lineDoubleCoefMap.clear(); lineDoubleSepMap.clear();
    foreach (Transition *tr, editor->getTransitionList())
    {
      lineStyleMap.insert(tr, tr->edgeLineStyle);
      lineWidthMap.insert(tr, tr->edgeLineWidth);
      lineColorMap.insert(tr, tr->edgeLineColor);
      labelColorMap.insert(tr, tr->edgeLabelColor);
      labelScaleMap.insert(tr, tr->edgeLabelScale);
      lineDoubleStatusMap.insert(tr, tr->edgeLineDblStatus);
      dimLineStyleMap.insert(tr, tr->dimEdgeLineStyle);
      dimLineColorMap.insert(tr, tr->dimEdgeLineColor);
      dimLineCoefMap.insert(tr, tr->dimEdgeLineCoef);
      dimLabelColorMap.insert(tr, tr->dimEdgeLabelColor);
      lineBorderCoefMap.insert(tr, tr->edgeLineBorderCoef);
      lineBorderColorMap.insert(tr, tr->edgeLineBorderColor);
      lineDoubleCoefMap.insert(tr, tr->edgeLineDblCoef);
      lineDoubleSepMap.insert(tr, tr->edgeLineDblSep);
    }
  }
}

void TransitionStyleChangeCommand::undo(){
  editor->edgeLineStyle = lineStyle_old;
  editor->edgeLineWidth = lineWidth_old;
  editor->edgeLineColor = lineColor_old;
  editor->edgeLabelColor = labelColor_old;
  editor->edgeLabelScale = labelScale_old;
  editor->edgeLineDblStatus = lineDoubleStatus_old;
  
  editor->dimEdgeLineStyle = dimLineStyle_old;
  editor->dimEdgeLineColor = dimLineColor_old;
  editor->dimEdgeLineCoef = dimLineCoef_old;
  editor->dimEdgeLabelColor = dimLabelColor_old;
  
  editor->edgeLineBorderCoef = borderCoef_old;
  editor->edgeLineBorderColor = borderColor_old;
  
  editor->edgeLineDblCoef = lineDoubleCoef_old;
  editor->edgeLineDblSep = lineDoubleSep_old;
  
  if (changeType == 1){
    foreach (Transition *tr, changedTransitions){
      tr->edgeLineStyle = lineStyle_old;
      tr->setEdgeLineWidth(lineWidth_old);
      tr->edgeLineColor = lineColor_old;
      tr->edgeLabelColor = labelColor_old;
      tr->setEdgeLabelScale(labelScale_old);
      tr->edgeLineDblStatus = lineDoubleStatus_old;
      
      tr->dimEdgeLineStyle = dimLineStyle_old;
      tr->dimEdgeLineColor = dimLineColor_old;
      tr->setDimEdgeLineCoef(dimLineCoef_old);
      tr->dimEdgeLabelColor = dimLabelColor_old;
      
      tr->edgeLineBorderCoef = borderCoef_old;
      tr->edgeLineBorderColor = borderColor_old;
      
      tr->edgeLineDblCoef = lineDoubleCoef_old;
      tr->edgeLineDblSep = lineDoubleSep_old;
    }
  }
  else if (changeType == 2){
    foreach (Transition *tr, changedTransitions){
      tr->edgeLineStyle = lineStyleMap.value(tr);
      tr->setEdgeLineWidth(lineWidthMap.value(tr));
      tr->edgeLineColor = lineColorMap.value(tr);
      tr->edgeLabelColor = labelColorMap.value(tr);
      tr->setEdgeLabelScale(labelScaleMap.value(tr));
      tr->edgeLineDblStatus = lineDoubleStatusMap.value(tr);
      
      tr->dimEdgeLineStyle = dimLineStyleMap.value(tr);
      tr->dimEdgeLineColor = dimLineColorMap.value(tr);
      tr->setDimEdgeLineCoef(dimLineCoefMap.value(tr));
      tr->dimEdgeLabelColor = dimLabelColorMap.value(tr);
      
      tr->edgeLineBorderCoef = lineBorderCoefMap.value(tr);
      tr->edgeLineBorderColor = lineBorderColorMap.value(tr);
      
      tr->edgeLineDblCoef = lineDoubleCoefMap.value(tr);
      tr->edgeLineDblSep = lineDoubleSepMap.value(tr);
    }
  }  
  
  editor->update();
  
  QString s_arg = "";
  if (changeType == 1){
    s_arg = " - non changed transitions";
  }
  else if (changeType == 2){
    s_arg = " - to all transitions";
  }
  setText(QObject::tr("Change transition style%1").arg(s_arg));
}

void TransitionStyleChangeCommand::redo(){
  editor->edgeLineStyle = lineStyle;
  editor->edgeLineWidth = lineWidth;
  editor->edgeLineColor = lineColor;
  editor->edgeLabelColor = labelColor;
  editor->edgeLabelScale = labelScale;
  editor->edgeLineDblStatus = lineDoubleStatus;
  
  editor->dimEdgeLineStyle = dimLineStyle;
  editor->dimEdgeLineColor = dimLineColor;
  editor->dimEdgeLineCoef = dimLineCoef;
  editor->dimEdgeLabelColor = dimLabelColor;
  
  editor->edgeLineBorderCoef = borderCoef;
  editor->edgeLineBorderColor = borderColor;
  
  editor->edgeLineDblCoef = lineDoubleCoef;
  editor->edgeLineDblSep = lineDoubleSep;
  
  if (changeType != 0){
    foreach(Transition *tr, changedTransitions){
      tr->edgeLineStyle = lineStyle;
      tr->setEdgeLineWidth(lineWidth);
      tr->edgeLineColor = lineColor;
      tr->edgeLabelColor = labelColor;
      tr->setEdgeLabelScale(labelScale);
      tr->edgeLineDblStatus = lineDoubleStatus;
      
      tr->dimEdgeLineStyle = dimLineStyle;
      tr->dimEdgeLineColor = dimLineColor;
      tr->setDimEdgeLineCoef(dimLineCoef);
      tr->dimEdgeLabelColor = dimLabelColor;
      
      tr->edgeLineBorderCoef = borderCoef;
      tr->edgeLineBorderColor = borderColor;
      
      tr->edgeLineDblCoef = lineDoubleCoef;
      tr->edgeLineDblSep = lineDoubleSep;
    }
  }
  
  editor->update();
  QString s_arg = "";
  if (changeType == 1){
    s_arg = " - non changed transitions";
  }
  else if (changeType == 2){
    s_arg = " - to all transitions";
  }
  setText(QObject::tr("Change transition style%1").arg(s_arg));
}

//--------------------------------------------- TransitionStyleChangeCommand -->



//<-- GeneratedGraphAddCommand -------------------------------------------------

GeneratedGraphAddCommand::GeneratedGraphAddCommand(Editor *editor, 
  const QList<State *> &stateList, QRect gr_new, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), stateList(stateList),
  gridRect_new(gr_new), wasUndo(false)
{
  gridRect_old = editor->getGridRect();
}

GeneratedGraphAddCommand::~GeneratedGraphAddCommand(){  
  if (wasUndo){ // delete all items if undo was used
    foreach(State *state, stateList){
      delete state;
    }  
  }
}

void GeneratedGraphAddCommand::undo(){
    if (gridRect_new != gridRect_old) 
        editor->setGridRect(gridRect_old);
  
    foreach(State *state, stateList)
    {
        foreach(Transition *tr, state->getTransitionList())
        {
            if (state == tr->getStartState()) // remove tr only once
                editor->removeFromListAndScene(tr);
        }
        editor->removeFromListsAndScene(state);
    }
  
    setText(QObject::tr("Generated graph add"));
    wasUndo = true;
}

void GeneratedGraphAddCommand::redo(){
  if (gridRect_new != gridRect_old) 
    editor->setGridRect(gridRect_new);
  if (wasUndo){ // no do at first
    foreach(State *state, stateList){
      editor->addToListsAndScene(state);
      foreach(Transition *tr, state->getTransitionList())
      {
          if (state == tr->getStartState()) // add tr only once
              editor->addToListAndScene(tr);
      }
    }
  }  
  
  setText(QObject::tr("Generated graph add"));
  wasUndo = false;
}

//------------------------------------------------- GeneratedGraphAddCommand -->



//<-- ItemsAddCommand ----------------------------------------------------------

ItemsAddCommand::ItemsAddCommand(Editor *editor, 
  const QList<State *> &stateList, QRect gr_new, QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), stateList(stateList),
  gridRect_new(gr_new), wasUndo(false)
{
    gridRect_old = editor->getGridRect();
}

ItemsAddCommand::~ItemsAddCommand()
{
    if (wasUndo)
    { // delete all items if undo was used -> 
      // transitions and labels are deleted through state's destructor
        foreach(State *state, stateList)
        {
            delete state;
        }
    }
}

void ItemsAddCommand::undo()
{
    if (gridRect_new != gridRect_old) 
        editor->setGridRect(gridRect_old);
  
    foreach(State *state, stateList)
    {
        foreach(Transition *tr, state->getTransitionList())
        {
            if (state == tr->getStartState()) // remove tr only once
                editor->removeFromListAndScene(tr);
        }
        editor->removeFromListsAndScene(state);
    }
  
    setText(QObject::tr("Items added"));
    wasUndo = true;
}

void ItemsAddCommand::redo()
{
    if (gridRect_new != gridRect_old) 
        editor->setGridRect(gridRect_new);    
    
    foreach(State *state, stateList)
    {
        editor->addToListsAndScene(state);
        foreach(Transition *tr, state->getTransitionList())
        {
            if (state == tr->getStartState()) // add tr only once
            {
                editor->addToListAndScene(tr);
            }
        }    
    }

    setText(QObject::tr("Items added"));
    wasUndo = false;
}

//---------------------------------------------------------- ItemsAddCommand -->



//<-- ItemsRemoveCommand -------------------------------------------------------

ItemsRemoveCommand::ItemsRemoveCommand(Editor *editor, const QList<State *> &stateList,
                                       const QList<Transition *> &transitionList,
                                       QUndoCommand *parent)
: QUndoCommand(parent), editor(editor), stateList(stateList),
  transitionList(transitionList), wasUndo(false)
{}

ItemsRemoveCommand::~ItemsRemoveCommand()
{
    if (!wasUndo)
    {
        foreach(State *state, stateList)
        {
            delete state;
        }

        foreach(Transition *transition, transitionList)
        {
            delete transition;
        }
    }
}

void ItemsRemoveCommand::undo()
{
    foreach(State *state, stateList)
    {
        editor->addToListsAndScene(state);
    }

    foreach(Transition *transition, transitionList)
    {
        editor->addToListsAndScene(transition);
    }

    wasUndo = true;
    setText(QObject::tr("Items removed"));
}

void ItemsRemoveCommand::redo()
{
    foreach(State *state, stateList)
    {
        editor->removeFromListsAndScene(state);
    }

    foreach(Transition *transition, transitionList)
    {
        editor->removeFromListsAndScene(transition);
    }

    wasUndo = false;
    setText(QObject::tr("Items removed"));
}

//------------------------------------------------------- ItemsRemoveCommand -->



//<-- StateSetMarkedCommand ----------------------------------------------------

StatesSetMarkedCommand::StatesSetMarkedCommand(QList<State*> states, bool marked, QUndoCommand *parent)
: QUndoCommand(parent), m_states(states), m_marked(marked)
{}

StatesSetMarkedCommand::~StatesSetMarkedCommand()
{}

void StatesSetMarkedCommand::undo()
{
    foreach(State *state, m_states)
    {
        state->setMarked(!m_marked);
    }
    setText(QObject::tr(m_marked ? "States mark" : "States unmark"));
}

void StatesSetMarkedCommand::redo()
{
    foreach(State *state, m_states)
    {
        state->setMarked(m_marked);
    }
    setText(QObject::tr(m_marked ? "States mark" : "States unmark"));
}

//---------------------------------------------------- StateSetMarkedCommand -->
