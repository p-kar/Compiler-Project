#include "constants.h"

#include "mainwindow.h"

#include <QtPlugin>
#include <QApplication>

/*! \mainpage AutomataEditor
 *
 * \section intro_sec Introduction
 *
 * AutomataEditor is vector editor for drawing finite automata according to VauCanSon-G format (LaTeX package).
 * Editor supports export to several vector formats, e.g. EPS, VauCanSon-G, GraphML.
 * Then implements basic operations over finite automata, including simulation of DFA/NFA, basic algorithms
 * (determinization, minimalization, ...) and transition table export.
 *
 * \section subversion Subversion
 * 
 * Curretly on webdev (contact zdarekj@fel.cvut.cz for access):
 *     https://webdev.felk.cvut.cz/~zdarekj/svn/Automata_editor
 *    
 * Project is planned to be moved to sourceforge:
 *     http://sourceforge.net/projects/automataeditor
 *
 * \section install_sec Installation
 *
 * \subsection step1 Step 1: Install Qt 4.6.3 (supported and tested version)
 * \subsection step2 Step 2: Check Automata_Editor.pro and the other subproject files (*.pro)
 * \subsection step3 Step 3: Run qmake in application directory (contains Automata_editor.pro)
 * \subsection step4 Step 4: Run make (nmake) in application directory
 *
 * \section wrapper GraphViz wrapper
 * If don't wish to have GraphViz positioner, comment gvwrapper in Automata_editor.pro:
 * \code SUBDIRS += gvwrapper \endcode
 *
 * Widows: GraphViz version 2.26.3
 * Linux systems: GraphViz version 2.20.2-8 (for other version modification of gvwrapper could be needed)
 *
 * GraphViz version is checked in runtime and can be set globally in sources.pro:
 * \code DEFINES += GRAPHVIZ_VERSION=\\\"2.26.3\\\" \endcode
 * \note escaping \\ and \" is required for make define's value a string
 * or it's possible to change GraphViz supported libraries in constants.h:
 * \code GRAPHVIZ_VERSION    "2.26.3" \endcode
 *
 *
 * For other versions of some modifications in gvwrapper will be probably needed,
 * because GraphViz interface was changed somewhere between 2.20.x and 2.26.x
 *
 * It's possible to change GraphViz supported libraries in constants.h:
 * \code GRAPHVIZ_VERSION    "2.26.3"    // this is version which is required in runtime \endcode
 *
 * \section devel Developement IDE
 *
 * Possible to use QtCreator and load existing project Automata_editor.pro
 *
 * \subsection eclipse Eclipse
 *
 * Qt Eclipse Integration available - http://doc.qt.nokia.com/qt-eclipse-1.5/index.html
 *
 * \subsection visualstudio Visual Studio project
 *
 * Qt Visual Studio Add-in available - http://doc.qt.nokia.com/vs-add-in-1.0/index.html
 *
 * \subsubsection vs_issues Known issues
 * \li First try to compile gvwrapper fails, but try it again should solve it
 *
 * \section plugin Plugin HOWTO subproject
 *
 * Simple project which shows how to implement custom algorithm as external dynamically loaded plugin.
 * For build this project allow it in Automata_editor.pro:
 * \code SUBDIRS += plugin_howto \endcode
 *
 * \section features Features settings
 *
 * \subsection svg SVG support
 *
 * If don't wish SVG support, comment usage of Qt SVG Module in core project sources.pro
 * \code QT += svg \endcode
 *
 * \subsection opengl OpenGL support
 *
 * It's possible to experimentally turn on OpenGL drawing by allowing it in sources.pro
 * \code QT += opengl \endcode
 */


// on windows release turn on logging to file
#if defined(QT_NO_DEBUG) && defined(_WINDOWS)
#   define LOGGING_ENABLED
#endif

#ifdef LOGGING_ENABLED
    #include <QFile>
    #include <QTextStream>
    #include <stdlib.h>

    QFile gLogFile("automataLog.txt");

void automataMsgHandler(QtMsgType type, const char *msg)
{
    gLogFile.open(QIODevice::Append);
    QTextStream log(&gLogFile);
    switch (type) 
    {                       
        case QtDebugMsg:
            log << "Debug: " << msg << endl;
            fprintf(stdout, "Debug: %s\n", msg);            
            break;
        case QtWarningMsg:
            log << "Warning: " << msg << endl;            
            fprintf(stderr, "Warning: %s\n", msg);
            break;
        case QtCriticalMsg:
            log << "Critical: " << msg << endl;            
            fprintf(stderr, "Critical: %s\n", msg);
            break;
        case QtFatalMsg:            
            log << "Fatal: " << msg << endl;            
            fprintf(stderr, "Fatal: %s\n", msg);
            abort();
    }
    gLogFile.close();
}

#endif

void printHelp()
{
    QTextStream out(stdout);

    if (out.status() == QTextStream::Ok)
    {
        out << "AutomataEditor v 2.0" << endl
            << "Usage:" << endl
            << "\tAutomataEditor filename" << endl
            << "\tAutomataEditor [opions] -f|--file filename" << endl
            << "Options:" << endl
            << "-h,--help\t\tthis help message" << endl
            << "-f,--file\t\topen specified file" << endl
            << endl
            << "Homepage: http://sourceforge.net/projects/automataeditor" << endl
            << "Milan Kriz" << endl
            << "\tmilan.kriz@centrum.cz" << endl
            << "\tkrizmil2@fel.cvut.cz" << endl
            << "Jan Zdarek" << endl
            << "\tzdarekj@fel.cvut.cz" << endl;
    }
    else
    {
        RELLOG("Cannot output standard output!!! (" << out.status() << ")");
    }
}

Q_IMPORT_PLUGIN(algorithms)

int main(int argc, char **argv)
{
    Q_INIT_RESOURCE(application);
    #ifdef LOGGING_ENABLED
        gLogFile.open(QIODevice::WriteOnly); // erase old log file
        gLogFile.close();
        qInstallMsgHandler(automataMsgHandler);
    #endif

    QString fileName;
    if (argc > 1)
    {
        QStringList args;
        for(int i=1; i<argc; ++i)
        {
            args << argv[i];
        }

        if (args.contains("-h") || args.contains("--help"))
        {
            printHelp();
            return 0;
        }

        if (args.count() == 1)
        {
            fileName = args[0];
        }
        else if (args.contains("-f") && args.length() > args.indexOf("-f"))
        {
            fileName = args[args.indexOf("-f")+1];
        }
        else if (args.contains("-file") && args.length() > args.indexOf("-file"))
        {
            fileName = args[args.indexOf("-file")+1];
        }
        else if(!args.isEmpty())
        {
            printHelp();
            return 1;
        }
    }

    QApplication app(argc, argv);

    MainWindow window(fileName);
    window.show();
    return app.exec();
}
