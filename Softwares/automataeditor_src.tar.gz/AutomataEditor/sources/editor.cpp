#include "constants.h"

#include "editor.h"
#include "transforms.h"
#include "mainwindow.h"
#include "parser.h"
#include "commands.h"
#include "state.h"
#include "stateDialogs.h"
#include "stateManager.h"
#include "transition.h"
#include "transitionDialogs.h"
#include "transitionManager.h"
#include "oneStateTransition.h"
#include "twoStatesTransition.h"
#include "dialogs.h"
#include "label.h"
#include "serializers.h" // objects for serializing items to QDataStream e.g. for clipboard, QVariant, ...
#include "automataWorkSimulator.h"
#include "drawAlgorithm.h"
#include "automataCreator.h"
#include "utils.h"
#include "dbglog.h"

#include "ialgorithm.h"
#include "istate.h"
#include "itransition.h"
#include "iautomaton.h"

#include "igraphviz.h"

#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsItem>
#include <QGraphicsLineItem>
#include <QGraphicsSimpleTextItem>
#include <QMessageBox>
#include <QMenu>
#include <QResizeEvent>
#include <QGraphicsSceneMouseEvent>
#include <QFontMetrics>
#include <QMouseEvent>
#include <QScrollBar>
#include <QRubberBand>
#include <QList>
#include <QQueue>
#include <QCursor>
#include <QRectF>
#include <QSharedPointer>

#ifndef DONT_USE_SVG_MODULE
#   include <QSvgGenerator>
#endif

#ifndef DONT_USE_OPENGL_RENDERING
#   include <QGLWidget>
#endif

// export
#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QPrinter>
#include <QImage>
#include <QDate>

// import
#include <QRegExpValidator>
#include <QRegExp>

#include <QUndoStack>
#include <QDir>
#include <QShortcut>


#include <math.h>

// copy/paste
#include <QApplication>
#include <QMimeData>
#include <QDataStream>
#include <QClipboard>

#ifdef PERFORMANCE_MEASUREMENT
#   include <QTime>
#endif

#include <QObject>


/*!
 * Reimplementation of painting QRubberBand to give only dashed line around selection rect.
 */
class DashedRubberBand : public QRubberBand
{
public:
    DashedRubberBand(Shape s, QWidget *p = 0)
    : QRubberBand(s, p)
    {
    }

protected:
    void paintEvent(QPaintEvent *event)
    {
        QPainter painter(this);
        
        painter.setPen(QPen(
            QColor(SelectedColor::r, SelectedColor::g,
                   SelectedColor::b, SelectedColor::a),
            2, Qt::DashLine));
                
        painter.setBrush(Qt::NoBrush);
        painter.drawRect(event->rect());
    }

    friend class Editor;
};



//<-- Editor -----------------------------------------------------------------

Editor::Editor(MainWindow *parent)
:   QGraphicsView((QWidget*) parent), mw(parent), sceneBorder(SCENE_BORDER),
    startState(NULL), selectedState(NULL), selectedTransition(NULL),
    snapToGrid(SNAP_TO_GRID), showGrid(SHOW_GRID), showFrame(SHOW_FRAME),
    antial(INIT_ANTIALIASING), saved(false), addition(false), //changed(false),
    m_stateIsMoving(false), m_simulationIsRun(false)
{
    // 120.0 is delta for most mice, ZOOM_DIVIDER should be in multiples of 120.0
    m_zoomInFactor = pow(2.0, 120.0 / ZOOM_DIVIDER);

    // state parameters adjustable
    stateLineStyle = DEF_LINE_STYLE;
    stateLineWidth = DEF_STATE_LINE_WIDTH;
    stateLineColor = DEF_COLOR;
    stateLabelColor = DEF_COLOR;
    stateLabelScale = DEF_LABEL_SCALE;
    stateFillStatus = DEF_FILL_STATUS;
    stateFillColor = DEF_FILL_COLOR;
    // state parameters preset
    dimStateLineStyle = DEF_DIM_LINE_STYLE;
    dimStateLineColor = DEF_DIM_COLOR;
    dimStateLineCoef = DEF_DIM_STATE_LINE_COEF;
    dimStateLabelColor = DEF_DIM_COLOR;
    dimStateFillColor = DEF_DIM_FILL_COLOR;
    // state parameters double
    stateLineDoubleCoef = DEF_STATE_LINE_DBL_COEF;
    stateLineDoubleSep = DEF_STATE_LINE_DBL_SEP;

    // edge parameters adjustable
    edgeLineStyle = DEF_LINE_STYLE;
    edgeLineWidth = DEF_EDGE_LINE_WIDTH;
    edgeLineColor = DEF_COLOR;
    edgeLabelColor = DEF_COLOR;
    edgeLabelScale = DEF_LABEL_SCALE;
    edgeLineDblStatus = DEF_EDGE_LINE_DBL_STATUS;
    // transition parameters dimmed
    dimEdgeLineStyle = DEF_DIM_LINE_STYLE;
    dimEdgeLineColor = DEF_DIM_COLOR;
    dimEdgeLineCoef = DEF_DIM_EDGE_LINE_COEF;
    dimEdgeLabelColor = DEF_DIM_COLOR; 
    // transition parameters border
    edgeLineBorderCoef = DEF_EDGE_LINE_BORDER_COEF;
    edgeLineBorderColor = DEF_EDGE_LINE_BORDER_COLOR;
    // transition parameters double
    edgeLineDblCoef = DEF_EDGE_LINE_DBL_COEF;
    edgeLineDblSep = DEF_EDGE_LINE_DBL_SEP;
    
    setScene(new QGraphicsScene(this));

    m_undoStack = new QUndoStack();
    m_undoStack->setUndoLimit(UNDO_LIMIT);
    connect(m_undoStack, SIGNAL(canUndoChanged(bool)), this, SLOT(canUndoChangedSlot(bool)));
    connect(m_undoStack, SIGNAL(canRedoChanged(bool)), this, SLOT(canRedoChangedSlot(bool)));
    connect(m_undoStack, SIGNAL(cleanChanged(bool)), this, SLOT(setClean(bool)));

    createUndoView();
    connect(m_undoView, SIGNAL(closed()), this, SIGNAL(undoViewClosed()));

    connect(scene(), SIGNAL(changed(const QList<QRectF> &)), this, SLOT(sceneChanged(const QList<QRectF> &)));
    
    if (!antial)
        setRenderHint(QPainter::SmoothPixmapTransform); // nicier lines and still good performance
    else
        setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform);

    setCacheMode(QGraphicsView::CacheNone);

    newStateNumber = 0; // first state is Q0

    // popup menus
    popup = new QMenu(this);
    popup->addAction(QString("Edit state style parameters"), this, SLOT(editStateStyleParams()));
    popup->addAction(QString("Edit transition style parameters"), this, SLOT(editTransitionStyleParams()));
    popup->addAction(QString("Set grid rect"), this, SLOT(showGridRectDialog()));
    popup->addSeparator();
    popupPasteHere = popup->addAction(tr("Paste here"), this, SLOT(pasteOnPos()));

    popupSelection = new QMenu(this);
    popupSelection->addAction(tr("Cut"), this, SLOT(cutSelection()));
    popupSelection->addAction(tr("Copy"), this, SLOT(copySelection()));
    popupSelection->addAction(tr("Remove"), this, SLOT(removeSelection()));
    
    popupState = new QMenu(this);
    popupStateLabel = new QAction("State", this);
    popupState->addAction(popupStateLabel);
    popupState->addSeparator();
    popupState->addAction(QString("Edit"),this,SLOT(editState()));
    popupState->addAction(QString("Edit extended"), this, SLOT(editStateParams()));
    popupState->addAction(QString("Move"), this, SLOT(moveState()));
    popupState->addSeparator();
    popupState->addAction(QString("Cut"), this, SLOT(cutState()));
    popupState->addAction(QString("Copy"), this, SLOT(copyState()));
    popupState->addSeparator();
    popupState->addAction(QString("Remove"),this,SLOT(removeState()));

    //! right action will be selected when used according to transition type
    popupTransitionLabel = new QAction("Transition", this);
    popupOneStateTransitionEdit = new QAction("Edit", this);
    connect(popupOneStateTransitionEdit, SIGNAL(triggered()), this, SLOT(editOneStateTransition()));
    popupTwoStatesTransitionEdit = new QAction("Edit", this);
    connect(popupTwoStatesTransitionEdit, SIGNAL(triggered()), this, SLOT(editTwoStatesTransition()));
    
    popupTransition = new QMenu(this);
    popupTransition->addAction(popupTransitionLabel);
    popupTransition->addSeparator();
    popupTransition->addAction(popupOneStateTransitionEdit);
    popupTransitionEdit = popupOneStateTransitionEdit;
    popupTransition->addAction(QString("Edit next labels"), this, SLOT(editNextLabels()));
    popupTransition->addAction(QString("Edit extended"), this, SLOT(editTransitionParams()));
    popupTransition->addSeparator();
    popupTransition->addAction(QString("Remove"),this,SLOT(removeTransition()));

    setGridRect(QRect(LLX, LLY, URX - LLX, URY - LLY));

    fileName = QString(NEW_FILENAME); // new file

    QFont::insertSubstitution("Arial", "Helvetica");

    //! needed because editor propagates mouse click to main window
    setAttribute(Qt::WA_NoMousePropagation);

    // TODO: how to grap bitmap when OpenGL is enabled? .. this has no effect :(
    DBGLOG(DBGPAR(testAttribute(Qt::WA_NoBackground)));
    DBGLOG(DBGPAR(testAttribute(Qt::WA_NoSystemBackground)));
    DBGLOG(DBGPAR(testAttribute(Qt::WA_OpaquePaintEvent)));
    DBGLOG(DBGPAR(testAttribute(Qt::WA_TranslucentBackground)));
    setAttribute(Qt::WA_NoBackground, false);
    setAttribute(Qt::WA_NoSystemBackground, true);
    setAttribute(Qt::WA_OpaquePaintEvent, false);
    setAttribute(Qt::WA_TranslucentBackground, false);

    setTransformationAnchor(QGraphicsView::AnchorUnderMouse);    
    setOptimizationFlags(QGraphicsView::DontSavePainterState);

#ifndef DONT_USE_OPENGL_RENDERING
    setViewport(new QGLWidget(QGLFormat(QGL::SampleBuffers)));    
#endif
    
    // TODO: try to set QGraphicsView::SmartViewportUpdate, currently redrawing
    //       is incorrect when SmartViewportUpdate is set
    setViewportUpdateMode(QGraphicsView::FullViewportUpdate);
    
    // required Rectangle due to OpenGL!!! (other rubber band is opaque) // TODO: not functional on Windows Qt 4.6.2
    m_rubberBand = new DashedRubberBand(QRubberBand::Rectangle, this); // implemented here in Editor.cpp (on top)
    setRubberBandSelectionMode(Qt::IntersectsItemShape);

    m_drawAlgorithmList << QSharedPointer<IDrawAlgorithm>(new NaiveDrawAlgorithm());
    m_drawAlgorithmList << QSharedPointer<IDrawAlgorithm>(new FarthestFinalDrawAlgorithm());
    m_currentDrawAlgorithm = m_drawAlgorithmList.count()-1;

    qRegisterMetaTypeStreamOperators<StateSerializer>("StateSerializer");
    qRegisterMetaTypeStreamOperators<SelectionSerializer>("SelectionSerializer");
    qRegisterMetaTypeStreamOperators<TransitionSerializer>("TransitionSerializer");

#ifdef STRING_PROCESSOR_TEST
    StringProcessor::runTest();
#endif
}

Editor::~Editor()
{ // probably scene do this, but rather ...
    m_undoStack->clear();
    delete m_undoStack;
    
    QList<State*> stateList = getStateList();
  
    while ( !stateList.isEmpty() )
        delete stateList.takeFirst(); // transitions are deleted in state's destructor

    Q_ASSERT(StateManager::getInstance());
    Q_ASSERT(TransitionManager::getInstance());
    delete StateManager::getInstance();
    delete TransitionManager::getInstance();    

    DBGLOG("deleted");
}

void Editor::createUndoView()
{
    m_undoView = new UndoView(m_undoStack, this);
    m_undoView->setWindowTitle(tr("Undo stack"));
    m_undoView->setAttribute(Qt::WA_QuitOnClose, false);
    m_undoView->setWindowFlags(Qt::Tool);
} 

void Editor::setGridRect(QRect gridRect)
{
    int dllx,dury;
    dllx = this->gridRect.x();
    dury = this->gridRect.y() + this->gridRect.height();
  
    if (!(gridRect.width() > 0 && gridRect.height() > 0))
    {
        QMessageBox::warning(this,
                tr("Bad coordinate?"),
                tr("GridRect will not be changed!"),tr("&Ok"));
        return;
    }
  
    this->gridRect = gridRect;
    br = QPoint(gridRect.width() * GRID_STEP + GRID_STEP/2 + 2,
                gridRect.height() * GRID_STEP + GRID_STEP/2 + 2);
  
    scene()->setSceneRect(0,0,br.x(),br.y());
    setSceneRect(-sceneBorder, -sceneBorder, br.x() + sceneBorder*2, br.y() + sceneBorder*2);
    centerOn(scene()->width() / 2,scene()->height() / 2);
  
    dllx = gridRect.x() - dllx;
    dury = gridRect.y() + gridRect.height() - dury;
  
    // if scene is changed, change positions of states too
    if (dllx != 0 || dury != 0)
    {
        QList<State*> stateList = getStateList();
        foreach (State *state, stateList)
        {
            state->setPos(state->x() - dllx * GRID_STEP, state->y() + dury * GRID_STEP);
        }
    }
}

QRect Editor::getGridRect()
{
    return gridRect;
}

void Editor::setAction(EAction action)
{
    m_selectedAction = action;

    setActionCursor(action);

    if (action != eSelection)
        scene()->clearSelection();

    if (startState)
    {
        startState->setChecked(false);
        startState = NULL;
    }
    selectedState = NULL;
}

void Editor::setActionCursor(EAction action)
{
    switch(action)
    {
    case eSelection:
        DBGLOG_ME("cursor=ArrowCursor");
        setCursor(Qt::ArrowCursor);
        break;
    case eInsertState:
        DBGLOG_ME("cursor=CrossCursor");
        setCursor(Qt::CrossCursor);
        break;
    case eInsertTransition:
        DBGLOG_ME("cursor=UpArrowCursor");
        setCursor(Qt::UpArrowCursor);
        break;
    default:
        Q_ASSERT(0 && "Unexpected state");
    }
}

void Editor::setActionInternal(EAction action)
{
    setAction(action);
    emit actionChanged(action); // mainwindow changes it's tools toolbar menu
}

void Editor::setSelectedState(State *state)
{
    if (state) selectedState = state;
    else selectedState = NULL;
}

void Editor::update()
{
    QGraphicsView::update();
}

void Editor::canUndoChangedSlot(bool can)
{
    if (m_simulationIsRun) return;
    emit canUndoChanged(can);
}

void Editor::canRedoChangedSlot(bool can)
{
    if (m_simulationIsRun) return;
    emit canRedoChanged(can);
}

void Editor::slotSnapToGrid()
{
    QString s;
  
    if (snapToGrid == true)
    {
        snapToGrid = false;
        s = "Snap to grid set off";
    }
    else
    {
        snapToGrid = true;
        s = "Snap to grid set on";
    }

    mw->setStatusBar(s);
}

void Editor::slotAlignToGrid()
{
    QList<State*> stateList = getStateList();
    QVector<QPointF> origPositions(stateList.size());    

    int i = 0;    
    foreach(QGraphicsItem *item, stateList)
    {
        origPositions[i] = item->pos();
        ++i;
    }
    
    if (itemsAlignToGrid(stateList))
    {
        m_undoStack->push
        (
            createMoveItemsCommand(stateList, origPositions)
        );
        
        mw->setStatusBar( QString("States aligned to grid") );
    }
    else
    {
        DBGLOG("nothing to be aligned");
    }
}

void Editor::setShowGridFrame(bool grid, bool frame)
{
    resetCachedContent();
    scene()->update();

    showGrid = grid;
    showFrame = frame;

    emit showChanged(showGrid, showFrame);
}

void Editor::slotShowGrid(bool show)
{
    m_undoStack->push(
        new ShowGridFrameCommand(this, showGrid, show, showFrame, showFrame)
    );

    QString s("Grid set ");
    s += (showGrid) ? "on" : "off";
    mw->setStatusBar(s);
}

void Editor::slotShowFrame(bool show)
{
    m_undoStack->push(
        new ShowGridFrameCommand(this, showGrid, showGrid, showFrame, show)
    );

    QString s("Frame set ");
    s += (showFrame) ? "on" : "off";
    mw->setStatusBar(s);
}

bool Editor::testStateName(const QString &s)
{
    return testStateName(s, m_stateMap);
}

bool Editor::testStateName(const QString &s, const TStateMap &stateMap)
{
    return stateMap.contains(s);
}

bool Editor::isChanged() const
{
    return !m_undoStack->isClean();
}

void Editor::setClean(bool clean)
{
    QString file = fileName.right(fileName.length() - fileName.lastIndexOf('/') - 1);
    if (clean)
        mw->setWindowTitle(QString("%1 - %2").arg(PROGRAM_NAME).arg(file));
    else
        mw->setWindowTitle(QString("%1 - %2*").arg(PROGRAM_NAME).arg(file));

    if (!saved && clean && m_undoStack->index() == 0)
    {
        emit isChanged(true);
        return;
    }

    emit isChanged(!clean);
}

void Editor::newFile()
{
    m_undoStack->clear();

    QList<State*> stateList = getStateList();
    while ( !stateList.isEmpty() )
        delete stateList.takeFirst();
    
    m_stateMap.clear();
    
    // deleted from state, here only removed from editor's list
    m_transitionList.clear();

    scene()->update();
    setFileName(NEW_FILENAME);
    
    saved = false;
    setClean(true);

    newStateNumber = 0; // first added state will be Q0 again
}

void Editor::openFile(const QString& fn)
{
    DBGLOG("opening" << fn);

    newFile();
    
    QList<State *>  parsedStates;
    QRect           newGridRect;
    
    bool wasFrame = showFrame;
    bool wasGrid = showGrid;

    Parser p(this, true);
#ifdef MEASURE_PARSER_RUN
    QTime timer;
    timer.start();
#endif
    bool ret = p.run(fn, parsedStates, newGridRect);
#ifdef MEASURE_PARSER_RUN
    RELLOG("Parsing have taken " << timer.elapsed() << "ms");
#endif
    if (ret || !parsedStates.empty())
    {
        ItemsAddCommand command(this, parsedStates, newGridRect);
        command.redo();
        
        QMessageBox::information(this, "Loading report", p.getReport() , QMessageBox::Ok);
        mw->setStatusBar(QString("File %1 was loaded sucessfully!").arg(fn));

        if (!ret)
        {
            ReportDialog prd(p.getReport(), this);
            prd.exec();

            mw->setStatusBar(QString("Loading file %1 wasn't totally successfull! See report!").arg(fn));
        }

        update();

        setFileName(fn);
        saved = true;
        setClean(true);
    }
    else
    {
        showFrame = wasFrame;
        showGrid = wasGrid;

        ReportDialog prd(p.getReport(), this);
        prd.exec();
        
        mw->setStatusBar(QString("Loading file %1 was totally unsuccessfull! See report!").arg(fn));
    }
}

QPointF Editor::mapToGrid(const QPointF& scenePos)
{
    return QPointF((float)(scenePos.x() - GRID_STEP/2) / GRID_STEP + gridRect.x(),
                   gridRect.height()-((float)(scenePos.y() - GRID_STEP/2) / GRID_STEP - gridRect.y()));
}

void Editor::setStatePrevParamsDef(StatePrevParams &prevParams)
{
    prevParams.stateLineStyle = stateLineStyle; // default is editor
    prevParams.stateLineWidth = 1;
    prevParams.stateLineColor = stateLineColor;
    prevParams.stateLabelColor = stateLabelColor;
    prevParams.stateLabelScale = 1;
    prevParams.stateFillStatus = stateFillStatus;
    prevParams.stateFillColor = stateFillColor;
}

void Editor::setTrPrevParamsDef(EdgePrevParams &prevTrParams)
{
    prevTrParams.edgeLineStyle = edgeLineStyle; // default is editor
    prevTrParams.edgeLineWidth = 1;
    prevTrParams.edgeLineColor = edgeLineColor;
    prevTrParams.edgeLabelColor = edgeLabelColor;
    prevTrParams.edgeLabelScale = 1;
    prevTrParams.edgeLineDblStatus = edgeLineDblStatus;
}

void Editor::setFileName(const QString &fn)
{
    QString file = fn.right(fn.length() - fn.lastIndexOf(QRegExp("[/\\\\]")) - 1);
    fileName = fn;
    DBGLOG(DBGPAR(fileName));
    mw->setWindowTitle(QString("%1 - %2")
        .arg(PROGRAM_NAME)
        .arg(file));
}

void Editor::exportToVaucanson(const QString& fn, bool additionals)
{   // TODO: remove exportToVaucanson -> replace by saveToFile only
    saveToFile(fn, additionals);
}

void Editor::saveLaTeXHeader(QTextStream &out)
{
    // LaTeX header
    out << "\\documentclass[11pt]{article}" << endl;
    out << "\\usepackage{vaucanson-g}" << endl;
    out << "\\begin{document}" << endl;   
}

void Editor::saveLaTeXFooter(QTextStream &out)
{
    out << "\\end{document}" << endl;
}

void Editor::saveHeader(QTextStream &out)
{
    if (showGrid) out << "\\ShowGrid" << endl;
    if (showFrame) out << "\\ShowFrame" << endl;
  
    // VCPicture with gridRect size
    out << "\\begin{VCPicture}"
        << "{(" 
        << gridRect.x() << "," << gridRect.y()
        << ")("
        << gridRect.x() + gridRect.width() << "," << gridRect.y() + gridRect.height()
        << ")}"
        << endl;
}

void Editor::saveVCSettings(QTextStream &out)
{
    if(stateLineStyle != DEF_LINE_STYLE)
        out << "\\SetStateLineStyle{" << trLineStyle(stateLineStyle) << "}" << endl;
    if(stateLineWidth != (float) DEF_STATE_LINE_WIDTH)
        out << "\\SetStateLineWidth{" << stateLineWidth << "pt}" << endl;
    if(stateLineColor != DEF_COLOR)
        out << "\\SetStateLineColor{" << stateLineColor << "}" << endl;
    if(stateLabelScale != (float) DEF_LABEL_SCALE)
        out << "\\SetStateLabelScale{" << stateLabelScale << "}" << endl;
    if(stateFillStatus != DEF_FILL_STATUS)
        out << "\\SetStateFillStatus{" << trFillStatus(stateFillStatus) << "}" << endl;
    if(stateFillColor != DEF_FILL_COLOR)
        out << "\\SetStateFillColor{" << stateFillColor << "}" << endl;
    
    if(edgeLineStyle != DEF_LINE_STYLE)
        out << "\\SetEdgeLineStyle{" << trLineStyle(edgeLineStyle) << "}" << endl;
    if(edgeLineWidth != (float) DEF_EDGE_LINE_WIDTH)
        out << "\\SetEdgeLineWidth{" << edgeLineWidth << "pt}" << endl;
    if(edgeLineColor != DEF_COLOR)
        out << "\\SetEdgeLineColor{" << edgeLineColor << "}" << endl;
    if(edgeLabelColor != DEF_COLOR)
        out << "\\SetEdgeLabelColor{" << edgeLabelColor << "}" << endl;
    if(edgeLabelScale != (float) DEF_LABEL_SCALE)
        out << "\\SetEdgeLabelScale{" << edgeLabelScale << "}" << endl;
    if(edgeLineDblStatus != DEF_EDGE_LINE_DBL_STATUS)
        out << "\\EdgeLineDouble" << endl;
}

void Editor::saveFooter(QTextStream &out)
{
    out << "\\end{VCPicture}" << endl;
}

void Editor::saveGraph(QTextStream &out)
{
    out << "%" << m_stateMap.count() << " states";
    bool first = true;
  
    // TODO: implement memory optimalization -> group states with same switches
    int sbs = 0; // how many states is written side-by-side
    bool prevDimmed = false;
  
    StatePrevParams prevParams;
    prevParams.stateLineStyle = stateLineStyle;
    prevParams.stateLineWidth = 1;
    prevParams.stateLineColor = stateLineColor;
    prevParams.stateLabelColor = stateLabelColor;
    prevParams.stateLabelScale = 1;
    prevParams.stateFillStatus = stateFillStatus;
    prevParams.stateFillColor = stateFillColor;
    prevParams.stateLineDoubleCoef = DEF_STATE_LINE_DBL_COEF;
    prevParams.stateLineDoubleSep = DEF_STATE_LINE_DBL_SEP;
    prevParams.dimStateLineStyle = DEF_DIM_LINE_STYLE;
    prevParams.dimStateLineColor = DEF_DIM_COLOR;
    prevParams.dimStateLineCoef = DEF_DIM_STATE_LINE_COEF;
    prevParams.dimStateLabelColor = DEF_DIM_COLOR;
    prevParams.dimStateFillColor = DEF_DIM_FILL_COLOR;
  
    QPointF s_pos;
    QList<State*> stateList = getStateList();
    foreach(State *state, stateList)
    {
        if (prevDimmed)
        {
            if (!state->isDimmed())
            {
                out << " \\RstState";
                setStatePrevParamsDef(prevParams);
                sbs = 0;
                prevDimmed = false;
                first = false;
            }
            if(state->getVCParams(out, prevParams)) {sbs = SBS_STATES;}
            else if (first) sbs = 0; 
        }
        else
        {
            if(state->getVCParams(out, prevParams)) {sbs = SBS_STATES;}
            else if (first) sbs = 0;
            if (state->isDimmed())
            {
                if (sbs != SBS_STATES || first)
                {
                    out << endl;
                    sbs = SBS_STATES;
                }
                out << "\\DimState ";
                prevDimmed = true;
                first = false;
            }
        }
    
        if (!sbs || first) out << endl;
        sbs = sbs ? sbs : SBS_STATES;
        first = false; 
        if (sbs != SBS_STATES) out << " ";
        out << state->getVCCommand();
        sbs--;
    }
    out << endl;
  
    // trasition printout
    QList<Transition *> trList;
    QList<Transition *> trIFList; // initial -- final
      
    foreach(Transition *tr, m_transitionList)
    {
        // only due to convention that IF transitions are first
        if (tr->getTypeName() == "Initial" ||
            tr->getTypeName() == "Final")
        {
            trIFList << tr;
        }
        else
        {
            trList << tr;
        }
    }
  
    // default parameters
    EdgePrevParams prevTrParams;
    prevTrParams.edgeLineStyle = edgeLineStyle; // default is editor
    prevTrParams.edgeLineWidth = 1;
    prevTrParams.edgeLineColor = edgeLineColor;
    prevTrParams.edgeLabelColor = edgeLabelColor;
    prevTrParams.edgeLabelScale = 1;
    prevTrParams.edgeLineDblStatus = edgeLineDblStatus;
    prevTrParams.edgeLineBorderCoef = DEF_EDGE_LINE_BORDER_COEF;
    prevTrParams.edgeLineBorderColor = DEF_EDGE_LINE_BORDER_COLOR;
    prevTrParams.edgeLineDblCoef = DEF_EDGE_LINE_DBL_COEF;
    prevTrParams.edgeLineDblSep = DEF_EDGE_LINE_DBL_SEP;
    prevTrParams.dimEdgeLineStyle = DEF_DIM_LINE_STYLE;
    prevTrParams.dimEdgeLineColor = DEF_DIM_COLOR;
    prevTrParams.dimEdgeLineCoef = DEF_DIM_EDGE_LINE_COEF;
    prevTrParams.dimEdgeLabelColor = DEF_DIM_COLOR;
   
    out << "%" << trIFList.size() << " initial-final";
    first = true;
  
    sbs = SBS_IF;
    prevDimmed = false;
    foreach(Transition *tr, trIFList)
    {
        if (prevDimmed)
        {
            if (!tr->isDimmed())
            {
                out << " \\RstEdge";
                setTrPrevParamsDef(prevTrParams);
                sbs = 0;
                prevDimmed = false;
                first = false;
            }
            if(tr->getVCParams(out, prevTrParams)) {sbs = SBS_IF;}
            else if (first) sbs = 0;
        }
        else
        {
            if(tr->getVCParams(out, prevTrParams)) {sbs = SBS_IF;}
            else if (first) sbs = 0;
            if (tr->isDimmed())
            {
                if (sbs != SBS_IF || first)
                {
                    out << endl;
                    sbs = SBS_IF;
                }
                out << "\\DimEdge ";
                prevDimmed = true;
                first = false;
            }
        }
    
        if (!sbs || first) out << endl;
        sbs = sbs ? sbs : SBS_IF;
        first = false; 
        if (sbs != SBS_IF) out << " ";
        out << tr->getVCCommand();
        sbs--;
    }
    // if (prevDimmed) out << " \\RstEdge"; - tohle ne, jsou to take Transitions!
    out << endl; 
    
    out << "%" << trList.size() << " transitions";
    first = true;
  
    sbs = SBS_TRAN;
    // prevDimmed = false; - tohle ne, Initial a Final jsou take Transitions!
    foreach(Transition *tr, trList)
    {
        if (prevDimmed)
        {
            if (!tr->isDimmed())
            {
                if (!first) out << " ";
                out << "\\RstEdge";
                setTrPrevParamsDef(prevTrParams);
                sbs = 0;
                prevDimmed = false;
                first = false;
            }
            if(tr->getVCParams(out, prevTrParams)) { sbs = SBS_TRAN; }
            else if (first) sbs = 0;
        }
        else
        {
            if(tr->getVCParams(out, prevTrParams)) { sbs = SBS_TRAN; }
            else if (first) sbs = 0;
            if (tr->isDimmed()) 
            {
                if (sbs != SBS_TRAN || first) 
                {
                    out << endl;
                    sbs = SBS_TRAN;
                }   
                out << "\\DimEdge ";
                prevDimmed = true;
                first = false;
            }
        }
                  
        if (!sbs || first) out << endl;
        sbs = sbs ? sbs : SBS_TRAN;
        first = false;  
        if (sbs != SBS_TRAN) out << " ";
        out << tr->getVCCommand();
        sbs--;
    }

    out << endl;
}

void Editor::saveToFile(const QString &filename, bool latexHeader)
{    
    // only to keep consistency with exportTo*
    scene()->clearSelection();

    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly))
    {
        QString s;
        s = "Filename " + filename + " cannot be saved!";
        mw->setStatusBar(s);
        
        RELLOG("Unable to save file " << filename << ".");
        return;
    }
    QTextStream out(&file);
    
       
    if (latexHeader) saveLaTeXHeader(out);
    
    saveHeader(out);
    saveVCSettings(out);
    saveGraph(out);
    saveFooter(out);
    
    if (latexHeader) saveLaTeXFooter(out);
    
    out.setDevice(0);
    file.close();
        
    addition = latexHeader; // for save
    saved = true;
    m_undoStack->setClean();
    
    QString s;
    s = "Filename " + filename + " saved as Vaucanson-G format";
    mw->setStatusBar(s);
}

void Editor::exportToGraphML(const QString& fn)
{
    // only to keep consistency with exportTo*
    scene()->clearSelection();

    QFile file(fn);
    file.open(QIODevice::WriteOnly);
    QTextStream out(&file);
 
    out << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" << endl;
    out << "<graphml xmlns=\"http://graphml.graphdrawing.org/xmlns\">" << endl;
    out << "  <key id=\"d000\" for=\"node\" attr.name=\"type\" attr.type=\"string\" />" << endl
        << "  <key id=\"d001\" for=\"node\" attr.name=\"label\" attr.type=\"string\" />" << endl
        << "  <key id=\"d010\" for=\"node\" attr.name=\"x-coordinate\" attr.type=\"float\" />" << endl
        << "  <key id=\"d011\" for=\"node\" attr.name=\"y-coordinate\" attr.type=\"float\" />" << endl        
        << "  <key id=\"d02\" for=\"node\" attr.name=\"final\" attr.type=\"boolean\" />" << endl
        << "  <key id=\"d03\" for=\"node\" attr.name=\"dimmed\" attr.type=\"boolean\" />" << endl
        << "  <key id=\"d040\" for=\"node\" attr.name=\"lineStyle\" attr.type=\"string\">" << endl
        << "    <default>" << trLineStyle(stateLineStyle) << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d041\" for=\"node\" attr.name=\"lineWidth\" attr.type=\"float\">" << endl
        << "    <default>" << stateLineWidth << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d042\" for=\"node\" attr.name=\"lineColor\" attr.type=\"string\">" << endl
        << "    <default>" << stateLineColor << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d043\" for=\"node\" attr.name=\"labelColor\" attr.type=\"string\">" << endl
        << "    <default>" << stateLabelColor << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d044\" for=\"node\" attr.name=\"labelScale\" attr.type=\"float\">" << endl
        << "    <default>" << stateLabelScale << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d045\" for=\"node\" attr.name=\"fillStatus\" attr.type=\"string\">" << endl
        << "    <default>" << trFillStatus(stateFillStatus) << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d046\" for=\"node\" attr.name=\"fillColor\" attr.type=\"string\">" << endl
        << "    <default>" << stateFillColor << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d050\" for=\"node\" attr.name=\"dimLineStyle\" attr.type=\"string\">" << endl
        << "    <default>" << dimStateLineStyle << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d051\" for=\"node\" attr.name=\"dimLineColor\" attr.type=\"string\">" << endl
        << "    <default>" << dimStateLineColor << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d052\" for=\"node\" attr.name=\"dimLineCoef\" attr.type=\"float\">" << endl
        << "    <default>" << dimStateLineCoef << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d053\" for=\"node\" attr.name=\"dimLabelColor\" attr.type=\"string\">" << endl
        << "    <default>" << dimStateLabelColor << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d054\" for=\"node\" attr.name=\"dimFillColor\" attr.type=\"string\">" << endl
        << "    <default>" << dimStateFillColor << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d060\" for=\"node\" attr.name=\"lineDoubleCoef\" attr.type=\"float\">" << endl
        << "    <default>" << stateLineDoubleCoef << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d061\" for=\"node\" attr.name=\"lineDoubleSep\" attr.type=\"float\">" << endl
        << "    <default>" << stateLineDoubleSep << "</default>" << endl
        << "  </key>" << endl
        << endl
        << "  <key id=\"d10\" for=\"edge\" attr.name=\"type\" attr.type=\"string\" />" << endl
        << "  <key id=\"d11\" for=\"edge\" attr.name=\"label\" attr.type=\"string\" />" << endl
        << "  <key id=\"d12\" for=\"edge\" attr.name=\"dimmed\" attr.type=\"boolean\" />" << endl
        << "  <key id=\"d130\" for=\"edge\" attr.name=\"angle\" attr.type=\"integer\">" << endl
        << "    <default>" << DEF_ARC_ANGLE << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d131\" for=\"edge\" attr.name=\"arcangleA\" attr.type=\"integer\">" << endl
        << "    <default>" << DEF_VCURV_ANGLE << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d132\" for=\"edge\" attr.name=\"arcangleB\" attr.type=\"integer\">" << endl
        << "    <default>" << DEF_VCURV_ANGLE_B << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d133\" for=\"edge\" attr.name=\"ncurv\" attr.type=\"float\">" << endl
        << "    <default>" << DEF_ARC_CURV << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d140\" for=\"edge\" attr.name=\"lineStyle\" attr.type=\"string\">" << endl
        << "    <default>" << edgeLineStyle << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d141\" for=\"edge\" attr.name=\"lineWidth\" attr.type=\"float\">" << endl
        << "    <default>" << edgeLineWidth << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d142\" for=\"edge\" attr.name=\"lineColor\" attr.type=\"string\">" << endl
        << "    <default>" << edgeLineColor << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d143\" for=\"edge\" attr.name=\"labelColor\" attr.type=\"string\">" << endl
        << "    <default>" << edgeLabelColor << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d144\" for=\"edge\" attr.name=\"labelScale\" attr.type=\"float\">" << endl
        << "    <default>" << edgeLabelScale << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d145\" for=\"edge\" attr.name=\"lineDblStatus\" attr.type=\"boolean\">" << endl
        << "    <default>" << trBool(edgeLineDblStatus) << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d150\" for=\"edge\" attr.name=\"dimLineStyle\" attr.type=\"string\">" << endl
        << "    <default>" << dimEdgeLineStyle << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d151\" for=\"edge\" attr.name=\"dimLineColor\" attr.type=\"string\">" << endl
        << "    <default>" << dimEdgeLineColor << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d152\" for=\"edge\" attr.name=\"dimLineCoef\" attr.type=\"float\">" << endl
        << "    <default>" << dimEdgeLineCoef << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d153\" for=\"edge\" attr.name=\"dimLabelColor\" attr.type=\"string\">" << endl
        << "    <default>" << dimEdgeLabelColor << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d160\" for=\"edge\" attr.name=\"lineBorderCoef\" attr.type=\"float\">" << endl
        << "    <default>" << edgeLineBorderCoef << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d161\" for=\"edge\" attr.name=\"lineBorderColor\" attr.type=\"string\">" << endl
        << "    <default>" << edgeLineBorderColor << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d170\" for=\"edge\" attr.name=\"lineDblCoef\" attr.type=\"float\">" << endl
        << "    <default>" << edgeLineDblCoef << "</default>" << endl
        << "  </key>" << endl
        << "  <key id=\"d171\" for=\"edge\" attr.name=\"lineDblSep\" attr.type=\"float\">" << endl
        << "    <default>" << edgeLineDblSep << "</default>" << endl
        << "  </key>" << endl
        << endl 
        << "  <graph id=\"G\" edgedefualt=\"directed\">" << endl;
    
    QPointF pos;
    QList<State*> stateList = getStateList();
    foreach (State *state, stateList)
    {
        out << "    <node id=\"n" << state->getName() << "\">" << endl;
      
        out << "    <data key=\"d000\">" << state->getTypeName() << "</data>" << endl;

        if (state->getLabel() != "")
        out << "      <data key=\"d001\">" << state->getLabel() << "</data>" << endl;
      
        pos = mapToGrid(state->pos());
        out << "      <data key=\"d010\">" << pos.x() << "</data>" << endl;
        out << "      <data key=\"d011\">" << pos.y() << "</data>" << endl;
      
        out << "      <data key=\"d02\">" << trBool(state->isDoubleBorder()) << "</data>" << endl;
      
        out << "      <data key=\"d03\">" << trBool(state->isDimmed()) << "</data>" << endl;
      
        if (state->stateLineStyle != stateLineStyle)
        out << "      <data key=\"d040\">" << trLineStyle(state->stateLineStyle) << "</data>" << endl;
        if (state->stateLineWidth != 1)
        out << "      <data key=\"d041\">" << state->stateLineWidth * stateLineWidth << "</data>" << endl;
        if (state->stateLineColor != stateLineColor)
        out << "      <data key=\"d042\">" << state->stateLineColor << "</data>" << endl;
        if (state->stateLabelColor != stateLabelColor)
        out << "      <data key=\"d043\">" << state->stateLabelColor << "</data>" << endl;
        if (state->stateLabelScale != 1)
        out << "      <data key=\"d044\">" << state->stateLabelScale * stateLabelScale << "</data>" << endl;
        if (state->stateFillStatus != stateFillStatus)
        out << "      <data key=\"d046\">" << trFillStatus(state->stateFillStatus) << "</data>" << endl;
        if (state->stateFillColor != stateFillColor)
        out << "      <data key=\"d047\">" << state->stateFillColor << "</data>" << endl;
    
        if (state->dimStateLineStyle != dimStateLineStyle)
        out << "      <data key=\"d050\">" << trLineStyle(state->dimStateLineStyle) << "</data>" << endl;
        if (state->dimStateLineColor != dimStateLineColor)
        out << "      <data key=\"d051\">" << state->dimStateLineColor << "</data>" << endl;
        if (state->dimStateLineCoef != dimStateLineCoef)
        out << "      <data key=\"d052\">" << state->dimStateLineCoef << "</data>" << endl;
        if (state->dimStateLabelColor != dimStateLabelColor)
        out << "      <data key=\"d053\">" << state->dimStateLabelColor << "</data>" << endl;
        if (state->dimStateFillColor != dimStateFillColor)
        out << "      <data key=\"d054\">" << state->dimStateFillColor << "</data>" << endl;
      
        if (state->stateLineDoubleCoef != stateLineDoubleCoef)
        out << "      <data key=\"d060\">" << state->stateLineDoubleCoef << "</data>" << endl;
        if (state->stateLineDoubleSep != stateLineDoubleSep)
        out << "      <data key=\"d061\">" << state->stateLineDoubleSep << "</data>" << endl;
      
        out << "    </node>" << endl;
    }
    out << endl;
    
    foreach (Transition *tr, m_transitionList)
    {
        out << "    <edge source=\"n" << tr->getStartState()->getName() << "\"";
        if (tr->hasEndState())
            out << " target=\"n" << tr->getEndState()->getName() << "\">" << endl;
        else
            out << ">" << endl;
      
        out << "      <data key=\"d10\">" << tr->getTypeName() << tr->getTypeNameSuffix() << "</data>" << endl;
        if (tr->getLabelText() != "")
        out << "      <data key=\"d11\">" << tr->getLabelText() << "</data>" << endl;
        out << "      <data key=\"d12\">" << trBool(tr->isDimmed()) << "</data>" << endl;
        
        out << tr->getGraphMLParams();

        /*if (tr->getType() == TR_VARC)
        {
            if (tr->getArcAngle() != DEF_ARC_ANGLE)
        out << "      <data key=\"d130\">" << tr->getArcAngle() << "</data>" << endl;
            if (tr->getNCurv() != DEF_ARC_CURV)
        out << "      <data key=\"d133\">" << tr->getNCurv() << "</data>" << endl;
        }
        else if(tr->getType() == TR_VCURVE)
        {
        out << "      <data key=\"d131\">" << tr->getArcAngle() << "</data>" << endl;
        out << "      <data key=\"d132\">" << tr->getArcAngle() << "</data>" << endl;
        out << "      <data key=\"d133\">" << tr->getNCurv() << "</data>" << endl;
        } // if*/
      
        if (tr->edgeLineStyle != edgeLineStyle)
        out << "      <data key=\"d140\">" << trLineStyle(tr->edgeLineStyle) << "</data>" << endl;
        if (tr->edgeLineWidth != 1)
        out << "      <data key=\"d141\">" << tr->edgeLineWidth * edgeLineWidth << "</data>" << endl;
        if (tr->edgeLineColor != edgeLineColor)
        out << "      <data key=\"d142\">" << tr->edgeLineColor << "</data>" << endl;
        if (tr->edgeLabelColor != edgeLabelColor)
        out << "      <data key=\"d143\">" << tr->edgeLabelColor << "</data>" << endl;
        if (tr->edgeLabelScale != 1)
        out << "      <data key=\"d144\">" << tr->edgeLabelScale * edgeLabelScale << "</data>" << endl;
        if (tr->edgeLineDblStatus != edgeLineDblStatus)
        out << "      <data key=\"d145\">" << trBool(tr->edgeLineDblStatus) << "</data>" << endl;
      
        if (tr->dimEdgeLineStyle != dimEdgeLineStyle)
        out << "      <data key=\"d150\">" << trLineStyle(tr->dimEdgeLineStyle) << "</data>" << endl;
        if (tr->dimEdgeLineColor != dimEdgeLineColor)
        out << "      <data key=\"d151\">" << tr->dimEdgeLineColor << "</data>" << endl;
        if (tr->dimEdgeLineCoef != dimEdgeLineCoef)
        out << "      <data key=\"d152\">" << tr->dimEdgeLineCoef << "</data>" << endl;
        if (tr->dimEdgeLabelColor != dimEdgeLabelColor)
        out << "      <data key=\"d153\">" << tr->dimEdgeLabelColor << "</data>" << endl;
      
        if (tr->edgeLineBorderCoef != edgeLineBorderCoef)
        out << "      <data key=\"d160\">" << tr->edgeLineBorderCoef << "</data>" << endl;
        if (tr->edgeLineBorderColor != edgeLineBorderColor)
        out << "      <data key=\"d161\">" << tr->edgeLineBorderColor << "</data>" << endl;
      
        if (tr->edgeLineDblCoef != edgeLineDblCoef)
        out << "      <data key=\"d170\">" << tr->edgeLineDblCoef << "</data>" << endl;
        if (tr->edgeLineDblSep != edgeLineDblSep)
        out << "      <data key=\"d171\">" << tr->edgeLineDblSep << "</data>" << endl;
      
        out << "    </edge>" << endl;
    }
    
    out << "  </graph>" << endl
        << "</graphml>" << endl;    
  
    out.setDevice(0);
    file.close();
  
    QString s;
    s = "Filename " + fn + " saved as GraphML format";
    mw->setStatusBar(s);
}

/*void Editor::exportToEPS(const QString& fn)
{
  QFile file(fn);
  file.open(QIODevice::WriteOnly);
  QTextStream out(&file);
  
  QRectF boundingBox = scene()->itemsBoundingRect();  
  boundingBox = boundingBox.united(scene()->sceneRect());
  // in EPS 0,0 is left bottom corner but in editor it is left top corner
  int height = scene()->height() - boundingBox.top(); // top is negative number or 0
  int bottom = scene()->height() - boundingBox.height(); // should be 0 or negative number

  QDateTime dt = QDateTime().currentDateTime();
  out << "%!PS-Adobe-3.0 EPSF-3.0" << endl
        << "%%Creator: Automata editor by krizm7@fel.cvut.cz" << endl
        << "%%CreationDate: " << QDateTime().currentDateTime().toString("d.M.yyyy hh:mm:ss") << endl
        << "%%Title: " << fn << endl                
        << "%%BoundingBox: " << (int)boundingBox.left()   << " "
                             << (int)bottom               << " "
                             << (int)boundingBox.width()  << " "
                             << (int)height               << endl
        << "%%EndComments" << endl;
  out << endl
      << "/bdef { bind def } bind def" << endl
      << "%line types: " << endl
      << "/solid { [] 0 setdash } bdef" << endl
      << "/dashed { [6 2] 0 setdash } bdef" << endl
      << "/dotted { [1 2] 0 setdash } bdef" << endl
      << "/dotdashed { [1 2 6 2] 0 setdash } bdef" << endl
      << "/none { [0 20] 0 setdash } bdef" << endl // TODO: make "none" better
      << endl
      << "% x y radius width r g b x y radius r g b sCircle" << endl
         << "/sCircle {" << endl
      //<< "  gsave" << endl
      << "  setrgbcolor" << endl
      << "  newpath" << endl
      << "  0 360 arc" << endl
      << "  fill" << endl
      << "  setrgbcolor" << endl
      << "  setlinewidth" << endl
      << "  newpath" << endl
      << "  0 360 arc" << endl
      << "  stroke" << endl
      //<< "  grestore" << endl
      << "} def" << endl
      << endl
      << "% x y radius x y radius width r g b x y radius r g b sDbCircle" << endl
      << "/sDbCircle {" << endl
      << "  gsave" << endl
      << "  setrgbcolor" << endl
      << "  newpath" << endl
      << "  0 360 arc" << endl
      << "  fill" << endl
      << "  setrgbcolor" << endl
      << "  setlinewidth" << endl
      << "  newpath" << endl
      << "  0 360 arc" << endl
      << "  stroke" << endl
      << "  newpath" << endl
      << "  0 360 arc" << endl      
      << "  stroke" << endl
      << "  grestore" << endl
      << "} def" << endl
      << endl
      << "% x y width height radius linewidth r g b rfill gfill bfill sBubble" << endl
      << "% x,y is center of bubble" << endl
      << "/sBubble {" << endl
      << "  setrgbcolor" << endl
      << "  /bval exch def" << endl
      << "  /gval exch def" << endl
      << "  /rval exch def" << endl
      << "  setlinewidth" << endl
      << "  /radval exch def" << endl
      << "  2 div" << endl
      << "  /hval exch def" << endl
      << "  2 div" << endl
      << "  /wval exch def" << endl
      << "  /yval exch def" << endl
      << "  /xval exch def" << endl
      << "  newpath" << endl
      << "  % from top to left" << endl
      << "  xval yval hval add moveto" << endl
      << "  xval wval sub" << endl
      << "  yval hval add" << endl
      << "  xval wval sub" << endl
      << "  yval radval arct" << endl
      << "  xval wval sub yval lineto     % to half of bubble (according to arct reference)" << endl
      << "  % from left to bottom" << endl
      << "  % xval wval sub yval moveto" << endl
      << "  xval wval sub" << endl
      << "  yval hval sub" << endl
      << "  xval yval hval sub radval arct" << endl
      << "  xval yval hval sub lineto" << endl
      << "  % from bottom to right" << endl
      << "  % xval yval hval sub moveto" << endl
      << "  xval wval add" << endl
      << "  yval hval sub" << endl
      << "  xval wval add yval radval arct" << endl
      << "  xval wval add yval lineto" << endl
      << "  % from right to top" << endl
      << "  % xval wval add yval moveto" << endl
      << "  xval wval add" << endl
      << "  yval hval add" << endl
      << "  xval yval hval add radval arct" << endl
      << "  xval yval hval add lineto" << endl
      << "  gsave" << endl
      << "  fill" << endl      
      << "  grestore" << endl
      << "  rval gval bval setrgbcolor" << endl
      << "  stroke" << endl
      << "} def" << endl
      << endl      
      << "% r g b lx1 ly lx ly lx ly mx my trArrow" << endl
      << "/trArrow {" << endl
      << "  newpath" << endl
      << "  moveto" << endl
      << "  lineto" << endl
      << "  lineto" << endl
      << "  lineto" << endl
      << "  closepath" << endl
      << "  setrgbcolor" << endl
      << "  fill" << endl
      << "} def" << endl
      << endl
      << "% r g b width lx ly mx my trLine" << endl
      << "/trLine {" << endl
      << "  newpath" << endl
      << "  moveto" << endl
      << "  lineto" << endl
      << "  setlinewidth" << endl
      << "  setrgbcolor" << endl
      << "  stroke" << endl
      << "} def" << endl
      << endl
      << "% r g b width cx cy cx cy cx cy mx my trLoop" << endl
      << "/trLoop {" << endl
      << "  newpath" << endl
      << "  moveto" << endl
      << "  curveto" << endl
      << "  setlinewidth" << endl
      << "  setrgbcolor" << endl
      << "  stroke" << endl
      << "} def" << endl
      //<< endl
      //<< "% r g b width x y radius angle1 angle2 trArc" << endl
      //<< "/trArc {" << endl
      //<< "  newpath" << endl
      //<< "  arc" << endl
      //<< "  setlinewidth" << endl
      //<< "  setrgbcolor" << endl
      //<< "  stroke" << endl
      //<< "} def" << endl
      // now Arc has same style of painting as VArc
      << endl      
      << "% r g b width x0 y0 x1 y1 x2 y2 x y trArc" << endl
      << "/trArc {" << endl
      << "  newpath" << endl
      << "  moveto" << endl
      << "  curveto" << endl
      << "  setlinewidth" << endl
      << "  setrgbcolor" << endl
      << "  stroke" << endl
      << "} def" << endl
      << endl      
      << "% r g b width x0 y0 x1 y1 x2 y2 x y trVArc" << endl
      << "/trVArc {" << endl
      << "  newpath" << endl
      << "  moveto" << endl
      << "  curveto" << endl
      << "  setlinewidth" << endl
      << "  setrgbcolor" << endl
      << "  stroke" << endl
      << "} def" << endl
      << endl
      // VCurve has the same style of painting as VArc, VArc has both angles same
      << "% r g b width x0 y0 x1 y1 x2 y2 x y trVCurve" << endl
      << "/trVCurve {" << endl
      << "  newpath" << endl
      << "  moveto" << endl
      << "  curveto" << endl
      << "  setlinewidth" << endl
      << "  setrgbcolor" << endl
      << "  stroke" << endl
      << "} def" << endl
      << endl
      << "% (text) r g b x y iLabel" << endl
      << "/iLabel {" << endl
      << "  newpath" << endl
      << "  moveto" << endl
      << "  setrgbcolor" << endl
      << "  show" << endl
      << "} def" << endl            
      << endl
      << "% default font" << endl
      << "/Arial findfont 30 scalefont setfont" << endl
      << endl;
      
  
    out << "%transitions" << endl;
    foreach (Transition *tr, m_transitionList){
        out << tr->getEPS();
    }

    out << endl;

    out << "%states" << endl;
    QList<State*> stateList = getStateList();
    foreach (State *state, stateList){
        out << state->getEPS();
    }

    out.setDevice(0);
    file.close();

    QString s = "Filename " + fn + " saved as Encapsulated PostScript format";
    mw->setStatusBar(s);
}*/

QRectF Editor::getPrintRect()
{
    QRectF boundingBox = scene()->itemsBoundingRect();
    // TODO: what if showFrame == fasle? .. too much space on top and on left sides
    const QRectF sceneRect = showFrame ? scene()->sceneRect().adjusted(0,0,2,4) // adjusted due to grid numbers
                                       : scene()->sceneRect();
    boundingBox = boundingBox.united(sceneRect);
    return boundingBox;
}

void Editor::exportToEPS(const QString& fn)
{
    // selection area marker shouldn't be exported
    scene()->clearSelection();
    
    QRectF boundingBox = getPrintRect();
    
    QPrinter printer(QPrinter::PrinterResolution);
    printer.setOutputFileName(fn);
    printer.setOutputFormat(QPrinter::PostScriptFormat);        
    DBGLOG("Paper size: " << boundingBox.size().toSize());
    printer.setPaperSize(boundingBox.size().toSize(), QPrinter::Point);

    QPainter painter(&printer);
    render(&painter, QRectF(), mapFromScene(boundingBox).boundingRect());
    painter.end();

    QString s = "Filename " + fn + " saved as Encapsulated PostScript format";
    mw->setStatusBar(s);
}

#ifndef DONT_USE_SVG_MODULE
void Editor::exportToSVG(const QString& fn)
{
    // selection area marker shouldn't be exported
    scene()->clearSelection();

    QRectF boundingBox = getPrintRect();
    // needs to be from point 0,0 for generator, so translate to it
    QRectF translatedBB = QRectF(0, 0, boundingBox.width(), boundingBox.height());

    QSvgGenerator generator;
    generator.setFileName(fn);
    generator.setSize(boundingBox.size().toSize());
    generator.setViewBox(translatedBB);
    generator.setTitle(tr("AutomataEditor"));
    generator.setDescription(tr("SVG graph exported by AutomataEditor"));

    QPainter painter;
    painter.begin(&generator);

    // background HACK? - maybe could be used even for OpenGL rendering of pixmap (bug)?
    painter.setPen(Qt::NoPen);
    painter.setBrush(Qt::white);
    painter.drawRect(translatedBB);

    render(&painter, QRectF(), mapFromScene(boundingBox).boundingRect());
    painter.end();
}
#endif

void Editor::exportToPixmap(const QString& fn, Format f)
{
    // selection area marker shouldn't be exported
    scene()->clearSelection();

    QString format;
    
    switch (f) {
        case png : format = "PNG"; break;
        case bmp : format = "BMP"; break;
        case xpm : format = "XPM"; break;
        default : return; break;
    }

    if (QPixmap::grabWidget(this,
        mapFromScene(getPrintRect()).boundingRect())
        .save(fn, format.toAscii())){
        mw->setStatusBar( QString("Filename \'%1\' saved").arg(fn) );
    } else {
        mw->setStatusBar( QString("Failed to save filename \'%1\'").arg(fn) );
    }
}

void Editor::setRightSceneRect()
{
    // This is quite alogical, this method pass to QGraphicView another sceneRect than it realy is (in QGraphicsScene).
    // One should pressupose that it only sets new sceneRect to scene (as scene()->setSceneRect()).
    // Therefore it is very useful if one want to set BORDER around real scene ;-).
    QRectF newRect(-sceneBorder, -sceneBorder, br.x() + sceneBorder*2, br.y() + sceneBorder*2);
    newRect |= scene()->itemsBoundingRect();

    setSceneRect(newRect);
}

void Editor::sceneChanged(const QList<QRectF> &)
{
    m_sceneChanged = true;
}

void Editor::resizeEvent(QResizeEvent* )
{  
    setRightSceneRect();
}

void Editor::wheelEvent(QWheelEvent *event)
{
    if (event->modifiers() == Qt::CTRL)
    {
        scaleView(pow(2., event->delta() / ZOOM_DIVIDER));
        return;
    }
    QGraphicsView::wheelEvent(event); // original behavior
}

void Editor::scaleView(qreal scaleFactor)
{
    // TODO: try to use setMatrix instead of scale! (maybe faster)
    qreal factor = matrix().scale(scaleFactor, scaleFactor).mapRect(QRectF(0, 0, 1, 1)).width();
    if (factor < 0.07)
    {
        emit canZoomOut(false);
        return;
    }
    else if(factor > 100)
    {
        emit canZoomIn(false);
        return;
    }

    emit canZoomIn(true);
    emit canZoomOut(true);

    scale(scaleFactor, scaleFactor);
}

void Editor::moveState()
{
    m_stateIsMoving = true;
    m_itemsMoved = false;

    m_origPos = selectedState->pos();
    m_origPositions.resize(1);
    m_origPositions[0] = selectedState->pos();
    
    // TODO: why this is not fuctional under Ubutnu/Linux?
    QCursor::setPos(mapToGlobal(mapFromScene(m_origPos.toPoint())));
    
    DBGLOG_ME("cursor=ClosedHandCursor");
    setCursor(Qt::ClosedHandCursor);
}

void Editor::cutSelection()
{
    copySelection();
    removeSelection();
}

void Editor::removeSelection()
{
    QList<State *> selectedStates;
    
    QSet<Transition *> transitionSet;
    transitionSet.reserve(m_transitionList.count());

    QList<State*> stateList = getStateList();
    foreach(State *state, stateList)
    {
        if (state->isSelected())
        {
            selectedStates << state;
            foreach(Transition *tr, state->getTransitionList())
            {
                transitionSet << tr;
            }
        }
    }

    foreach(Transition *tr, m_transitionList)
    {
        if (tr->isSelected())
        {
            transitionSet << tr;
        }
    }

    m_undoStack->push(
        new ItemsRemoveCommand(this, selectedStates, transitionSet.toList())
    );
}

bool Editor::isSomethingSelected()
{
    return !(scene()->selectedItems().empty());
}

bool Editor::isPastePossible()
{
    if (m_simulationIsRun) return false;

    DBGLOG(QApplication::clipboard()->mimeData()->formats());
    if (QApplication::clipboard()->mimeData()->hasFormat(CLIPBOARD_FORMAT_STATE) ||
        QApplication::clipboard()->mimeData()->hasFormat(CLIPBOARD_FORMAT))
    {
        return true;
    }
    return false;
}

void Editor::cutState()
{
    copyState();
    removeState();
}

void Editor::copyState()
{
    QByteArray itemData;
    QDataStream dataStream(&itemData, QIODevice::WriteOnly);
    
    Q_ASSERT(selectedState != NULL && 
        "Pointer is NULL but should be filled in Editor::popupState!");

    dataStream << StateSerializer(*selectedState);

    QMimeData *mimeData = new QMimeData();
    mimeData->setData(CLIPBOARD_FORMAT_STATE, itemData);

    QApplication::clipboard()->setMimeData(mimeData);
}

void Editor::copySelection()
{
    // TODO: make selection copyable only when some state is selected!
    //       or think up some way how to add copyied transiton -> 
    //       e.g. some dialog with existing state's selection
    
    QByteArray itemsData;
    QDataStream dataStream(&itemsData, QIODevice::WriteOnly);

    dataStream << SelectionSerializer(scene()->selectedItems());

    QMimeData *mimeData = new QMimeData();
    mimeData->setData(CLIPBOARD_FORMAT, itemsData);

    QApplication::clipboard()->setMimeData(mimeData);
}

void Editor::paste(const QPoint& insertPoint)
{
    // TODO: paste data from clipboard with some offset (for each pasting other offset)
    try
    {
        QClipboard *clipboard = QApplication::clipboard();
        const QMimeData *mimeData = clipboard->mimeData();

        if (mimeData->hasFormat(CLIPBOARD_FORMAT_STATE)) // state is in clipboard
        {
            setActionInternal(eSelection);

            QByteArray itemData = mimeData->data(CLIPBOARD_FORMAT_STATE);

            QDataStream dataStream(&itemData, QIODevice::ReadOnly);
        
            StateSerializer stateSerializer;
            dataStream >> stateSerializer;

            DBGLOG_SER("stateSerializer ->" << stateSerializer.m_typeName);            

            State *state = stateSerializer.createState(this, insertPoint);
            state->setAutoNammed(true);
            m_undoStack->push(
                new StateAddCommand(this, state)
            );

            scene()->clearSelection();
            state->setSelected(true);
        }
        else if (mimeData->hasFormat(CLIPBOARD_FORMAT)) // selection is in clipboard
        {
            setActionInternal(eSelection);

            QByteArray itemData = mimeData->data(CLIPBOARD_FORMAT);

            QDataStream dataStream(&itemData, QIODevice::ReadOnly);

            SelectionSerializer serializer;
            dataStream >> serializer;

            DBGLOG_SER("selectionSerializer ->" << "hotSpot=" << serializer.m_hotSpot << " "
                                                << "state count=" << serializer.m_serializedStates.count());

            SelectionSerializer::TItemsPair items = serializer.createItems(this, insertPoint);
            QList<State*> states = items.first;
            QList<Transition*> transitions = items.second;

            m_undoStack->push(
                new ItemsAddCommand(this, states, gridRect)
            );

            scene()->clearSelection();

            foreach(State* state, states)
            {
                state->setSelected(true);
            }
            foreach(Transition *transition, transitions)
            {
                transition->setSelected(true);
            }
        }
        else
        {
            Q_ASSERT(0 && "This shouldn't be possible call this method when incorrect data is in clipboard");
            RELLOG("Incorrect data in clipboard, but paste called!");
        }
    }
    catch(...)
    {
        QMessageBox::critical(this, PROGRAM_NAME,
            tr("Invalid clipboard! \n"
               "Data from clipboard couldn't be pasted!"), "OK");
    }
}

void Editor::paste()
{
    paste(QPoint(scene()->width()/2, scene()->height()/2));
}

//! private only for pasting form popup
void Editor::pasteOnPos()
{
    paste(mapToScene(m_popupPoint).toPoint());
}

void Editor::itemsInvertSelection(QList<QGraphicsItem *> items)
{
    foreach(QGraphicsItem *item, items)
    {
        item->setSelected(!item->isSelected());
    }
}

bool Editor::itemAlignToGrid(QGraphicsItem *item)
{
    if (!(item->flags() & QGraphicsItem::ItemIsMovable))
    {
        return false;
    }

    QPoint pos(item->pos().toPoint());
    
    QPoint newPos;
    newPos.setX(pos.x() / GRID_STEP * GRID_STEP + (pos.x() > 0 ? GRID_STEP/2 : - GRID_STEP/2));
    newPos.setY(pos.y() / GRID_STEP * GRID_STEP + (pos.y() > 0 ? GRID_STEP/2 : - GRID_STEP/2));

    if (pos != newPos)
    {
        item->setPos(newPos.x(), newPos.y());
        return true;
    }

    return false;
}

void Editor::mousePressEvent(QMouseEvent *event)
{
    DBGLOG_ME("accepted=" << event->isAccepted());

    if (m_simulationIsRun) return;

    if (m_stateIsMoving)
    {
        m_stateIsMoving = false;
        
        if (m_itemsMoved)
        {
            stateMoved(selectedState, m_origPositions[0]);
        }

        selectedState->setChecked(false);
        selectedState = NULL;

        return;
    }

    m_currentMouseAction = eNoMouseAction;
    QList<QGraphicsItem *> itemsOnPos(items(event->pos()));

    // remove nonselectable items due to controlling if clicked item is selected
    while(!itemsOnPos.isEmpty())
    {        
        if (itemsOnPos.first()->flags() & QGraphicsItem::ItemIsSelectable)
            break; // we need to be sure that first item in list selectable, no all of them
        else
            itemsOnPos.removeFirst();
    }

    if (m_selectedAction == eSelection)
    {
        switch (event->button())
        {
        case Qt::LeftButton:        
            if (event->modifiers() == Qt::ShiftModifier)
            {            
                if (itemsOnPos.empty())
                { // no item -> start rubberBand, don't clear previous selection
                    m_currentMouseAction = eSelectMultipleItems;
                    m_rubberBandOrigin = event->pos();
                    m_rubberBand->setGeometry(QRect(m_rubberBandOrigin, QSize()));
                    m_rubberBand->show();
                    return;
                }
                else
                { // item (selected or not) -> invert
                    itemsInvertSelection(itemsOnPos);                
                }
            }
            else // w/o SHIFT
            {                        
                if (itemsOnPos.empty())
                { // no item -> clear selection, start rubberBand                    
                    m_currentMouseAction = eSelectMultipleItems;
                    scene()->clearSelection();
                    m_rubberBandOrigin = event->pos();
                    m_rubberBand->setGeometry(QRect(m_rubberBandOrigin, QSize()));
                    m_rubberBand->show();
                    QGraphicsView::mousePressEvent(event);
                }
                else if (itemsOnPos[0]->isSelected() &&
                         scene()->selectedItems().count() > 1) // only when more items are selected
                { // selected item -> move with selected items -> store original pos
                    // moving is possible only with movable items -> currently only on states
                    m_currentMouseAction = eMoveMultItem;                    
                    DBGLOG_ME("cursor=ClosedHandCursor");
                    setCursor(Qt::ClosedHandCursor); // TODO: why cursor isn't changed after popup menu is closed?                    

                    m_itemsMoved = false;
                    m_origPos = mapToScene(event->pos());
                    
                    m_origPositions.resize(scene()->selectedItems().size());

                    int i = 0;
                    foreach(QGraphicsItem *item, scene()->selectedItems())
                    {
                        m_origPositions[i] = item->pos();
                        ++i;
                    }
                }
                else
                { // no selected item -> clear selection and propagate to item
                    m_currentMouseAction = eMoveItem;
                    scene()->clearSelection();                    

                    QGraphicsView::mousePressEvent(event);
                }
            }
            break; // Qt::LeftButton
        case Qt::RightButton:
            if (itemsOnPos.empty())
            { // no item -> show popup (paste)
                scene()->clearSelection();
                m_currentMouseAction = eShowPopup;
            }
            else if (itemsOnPos[0]->isSelected() &&
                     scene()->selectedItems().count() > 1) // only when more items are selected
            { // selected item -> show popup (copy, remove)
                m_currentMouseAction = eShowSelectionPopup;
            }
            else
            { // no selected item (or just one) -> propagate (item will invoke popup)
                scene()->clearSelection();
                QGraphicsView::mousePressEvent(event);
            }
            break; // Qt::RightButton
        case Qt::MidButton:
            scene()->clearSelection();
            QGraphicsView::mousePressEvent(event);
            break;
        default:;
        }
    } // if(m_selectedAction == eSelection)
    else if(m_selectedAction == eInsertState)
    {
        switch(event->button())
        {
        case Qt::LeftButton:
            m_currentMouseAction = eInsertItem;            
            break;
        case Qt::RightButton:            
            if (itemsOnPos.empty())
            { // no item -> show popup (insert state, paste)
                m_currentMouseAction = eShowPopup;
            }
            else if (itemsOnPos[0]->isSelected())
            { // selected item -> show popup (cut, copy, remove
                m_currentMouseAction = eShowSelectionPopup;
            }
            else
            { // item -> propagate (item will invoke popup)
                QGraphicsView::mousePressEvent(event);
            }
            break;
        case Qt::MidButton:
            scene()->clearSelection();
            QGraphicsView::mousePressEvent(event);
            break;
        default:;
        }
    } // if(m_selectedAction == eInsertState)
    else if(m_selectedAction == eInsertTransition)
    {
        switch(event->button())
        {
        case Qt::LeftButton:
            m_currentMouseAction = eInsertItem;
            selectedState = NULL;
            QGraphicsView::mousePressEvent(event);
            break;
        case Qt::RightButton:
            if (itemsOnPos.empty())
            { // no item -> show popup (insert state, paste)
                m_currentMouseAction = eShowPopup;         
            }            
            /*else if (itemsOnPos[0]->isSelected())
            { // selected item -> show popup (cut, copy, remove
                m_currentMouseAction = eShowSelectionPopup;
            }*/
            else
            { // item -> propagate (item will invoke popup)                
                QGraphicsView::mousePressEvent(event);
            }
            break;
        default:;
        }
    }
    else
    {
        RELLOG("Unexpected situation -> unknown editor action selected!!!");
        Q_ASSERT(0 && "Unexpected situation!");
    }

    DBGLOG_ME(trMouseAction(m_currentMouseAction));
}

void Editor::mouseMoveEvent(QMouseEvent *event)
{
    // show cursor position in scene coordinates
    QPoint p = mapToScene(event->pos()).toPoint();

    if (snapToGrid)
    {
        mw->setStatusBar( QString("Cursor position: %1 , %2")
            .arg(p.x() / GRID_STEP + gridRect.x())
            .arg(gridRect.height()-(p.y() / GRID_STEP - gridRect.y())));
    }
    else 
    {
        QPointF ePoint = mapToGrid(mapToScene(event->pos()));
        mw->setStatusBar( QString("Cursor position: %1 , %2")
            .arg(ePoint.x())
            .arg(ePoint.y()));
    }
    
    if (m_stateIsMoving)
    {
        bool itemsMoved = false;
        QPointF movePoint(0,0);
        QPointF changePoint = mapToScene(event->pos()) - m_origPos;

        if (snapped())
        {
            itemsMoved |= itemAlignToGrid(selectedState);
            
            if (changePoint.x() > (GRID_STEP / 2))
            {
                movePoint = QPoint(GRID_STEP, 0);
            } 
            else if (changePoint.x() < (-GRID_STEP / 2))
            {
                movePoint = QPoint(-GRID_STEP, 0);
            }
            if(changePoint.y() > (GRID_STEP / 2))
            {
                movePoint = QPoint(0, GRID_STEP);
            }
            else if(changePoint.y() < (-GRID_STEP / 2))
            {
                movePoint = QPoint(0,-GRID_STEP);
            }
        }
        else
        {
            movePoint = changePoint;
        }
        
        if (movePoint != QPointF(0,0)) 
        {
            itemsMoved = true;
            selectedState->moveBy(movePoint.x(), movePoint.y());
        }

        if (itemsMoved)
        {
            m_origPos += movePoint;
        }
        
        m_itemsMoved |= itemsMoved;

        return;
    }

    if (m_rubberBand->isVisible())
        m_rubberBand->setGeometry(QRect(m_rubberBandOrigin, event->pos()).normalized());

    if (m_selectedAction == eSelection && m_currentMouseAction == eMoveMultItem)
    {
        bool itemsMoved = false;
        QPointF movePoint(0,0);
        QPointF changePoint = mapToScene(event->pos()) - m_origPos;        

        if (snapped())
        {
            m_itemsMoved |= itemsAlignToGrid(scene()->selectedItems());
            
            if (changePoint.x() > (GRID_STEP / 2))
            {
                movePoint = QPoint(GRID_STEP, 0);
            } 
            else if (changePoint.x() < (-GRID_STEP / 2))
            {
                movePoint = QPoint(-GRID_STEP, 0);
            }
            if(changePoint.y() > (GRID_STEP / 2))
            {
                movePoint = QPoint(0, GRID_STEP);
            }
            else if(changePoint.y() < (-GRID_STEP / 2))
            {
                movePoint = QPoint(0,-GRID_STEP);
            }
        }
        else
        {
            movePoint = changePoint;
        }
        
        foreach(QGraphicsItem *item, scene()->selectedItems())
        {
            if(item->flags() & QGraphicsItem::ItemIsMovable)
            {
                if (movePoint != QPointF(0,0))
                {
                    itemsMoved = true;
                    item->moveBy(movePoint.x(), movePoint.y());
                }
            }
        }

        if (itemsMoved)
        {
            m_origPos += movePoint;
        }

        m_itemsMoved |= itemsMoved;

        return;
    }

    QGraphicsView::mouseMoveEvent(event); // opriginal implementation
}

void Editor::mouseReleaseEvent(QMouseEvent *event)
{
    DBGLOG_ME("called");
    if (m_rubberBand->isVisible())
    {        
        itemsInvertSelection(items(m_rubberBand->geometry()));        
        m_rubberBand->hide();   
    }

    if ((m_selectedAction == eInsertState && m_currentMouseAction == eInsertItem) ||
        (m_selectedAction == eSelection && m_currentMouseAction == eInsertItem))
    {
        QPoint p = mapToScene(event->pos()).toPoint();

        if (snapped())
        { // if should be snapped, do it
            p.setX(p.x() / GRID_STEP * GRID_STEP + GRID_STEP/2);
            p.setY(p.y() / GRID_STEP * GRID_STEP + GRID_STEP/2);
        }

        insertState(p);
    }
    else if(m_selectedAction == eSelection && m_currentMouseAction == eMoveMultItem)
    {
        if (m_itemsMoved)
        {
            m_undoStack->push
            (
                createMoveItemsCommand(scene()->selectedItems(), m_origPositions)
            );

            update();
        }
    }
    else if(m_currentMouseAction == eShowPopup)
    {
        popupPasteHere->setVisible(isPastePossible());
        m_popupPoint = event->pos();
        popup->exec(mapToGlobal(m_popupPoint));
    }
    else if(m_currentMouseAction == eShowSelectionPopup)
    {
        popupSelection->exec(mapToGlobal(event->pos()));
    }
    else
    {
        QGraphicsView::mouseReleaseEvent(event);
    }

    if (!m_stateIsMoving)
        setActionCursor(m_selectedAction);

    if (m_sceneChanged)
    {
        setRightSceneRect();
        m_sceneChanged = false;
    }

    m_currentMouseAction = eNoMouseAction;
}

void Editor::mouseDoubleClickEvent(QMouseEvent *event)
{
    if (m_simulationIsRun) return;

    DBGLOG_ME("called");
    // double click on empty scene means state inserting
    if (event->button() == Qt::LeftButton)
    {
        QList<QGraphicsItem *> itemsOnPos(items(event->pos()));

        if (itemsOnPos.empty())
        {
            m_currentMouseAction = eInsertItem;
        }
        else
            QGraphicsView::mouseDoubleClickEvent(event); // orign behavior
    }
}

bool Editor::showPopup(State *state)
{
    popupStateLabel->setText("State: \"" + state->getLabel() + "\" / " + state->getName());
    selectedState = state;
    if (startState != NULL)
    {
        startState->setChecked(false);
        startState = NULL;
    }
    // mapovani nejprve ze sceny - potom na globalni souradnice
    popupState->exec(mapToGlobal(mapFromScene(state->pos())));
    if (!selectedState) return false;
    if (!m_stateIsMoving)
    {   
        selectedState->setChecked(false);
        selectedState = NULL;
    }
    return  true;
}

void Editor::showPopup(OneStateTransition *transition,const QPointF &point)
{
    popupTransitionLabel->setText(transition->getTypeName() + 
                                  transition->getTypeNameSuffix() +
                                  " \"" + transition->getLabelText() + "\"");    
    // switch Edit action if necessary -> handle diferent transtitions types
    if (popupTransitionEdit != popupOneStateTransitionEdit)
    {
        QList<QAction *> actions = popupTransition->actions();
        int i = actions.lastIndexOf(popupTransitionEdit);
        popupTransition->removeAction(popupTransitionEdit);
        popupTransition->insertAction(actions.value(i+1), popupOneStateTransitionEdit);
        popupTransitionEdit = popupOneStateTransitionEdit;
    }

    selectedTransition = transition;

    popupTransition->exec(mapToGlobal(mapFromScene(point.toPoint())));
    if(selectedTransition) // transition could be deleted
    {
        selectedTransition->setChecked(false);
        selectedTransition->update();
        selectedTransition = NULL;
    }    
}

void Editor::showPopup(TwoStatesTransition *transition, const QPointF &point)
{
    popupTransitionLabel->setText(transition->getTypeName() + 
                                  transition->getTypeNameSuffix() +
                                  " \"" + transition->getLabelText() + "\"");    
    // switch Edit action if necessary -> handle diferent transtitions types
    if (popupTransitionEdit != popupTwoStatesTransitionEdit)
    {
        QList<QAction *> actions = popupTransition->actions();
        int i = actions.lastIndexOf(popupTransitionEdit);        
        popupTransition->removeAction(popupTransitionEdit);
        popupTransition->insertAction(actions.value(i+1), popupTwoStatesTransitionEdit);
        popupTransitionEdit = popupTwoStatesTransitionEdit;
    }
    
    selectedTransition = transition;
    popupTransition->exec(mapToGlobal(mapFromScene(point.toPoint())));
    if(selectedTransition) // transition could be deleted
    {
        selectedTransition->setChecked(false);
        selectedTransition->update();
        selectedTransition = NULL;
    }
}

// slots

void Editor::editState()
{
    StateManager *stateManager = StateManager::getInstance();
    StateDialog sd(this, stateManager->getTypeNameList(), StateDialog::eEdit, selectedState->isInitial(), this);

    sd.setLabel(selectedState->getLabel());
    sd.setName(selectedState->getName()); // i vygenerovane jmeno se zobrazi
    int typeID = stateManager->getTypeNameId(selectedState->getTypeName());
    sd.setType(typeID);
    sd.setDimmed(selectedState->isDimmed());
    sd.setAutoNammed(selectedState->isAutoNammed());
        
    int ret = sd.exec();

    selectedState->setChecked(false);

    if (ret == QDialog::Rejected)
    {
        return;
    }
        
    QUndoCommand *command = sd.quickInitial() ?
            new QUndoCommand(QString("Edit state (%1) + quick initial add").arg(selectedState->getName())) : NULL;

    QUndoCommand *tmpCommand = NULL;
    if (typeID == sd.getType())
    { // not changed
        tmpCommand =
                new StateEditCommand(this, selectedState, sd.getLabel(), sd.getName(), (bool)(sd.getType() & 1),
                                     sd.isDimmed(), sd.isAutoNammed(), command);
    }
    else
    { // changed state Type        
        QPoint point = selectedState->pos().toPoint();        
        State *newState = stateManager->createState(this, point, sd);

        Q_ASSERT(newState != NULL);

        tmpCommand = new StateEditWithDelCommand(this, selectedState, newState, command);
        selectedState = newState;
    }

    Q_ASSERT(tmpCommand);

    if (sd.quickInitial()) // add initial transition quickly
    {
        Q_ASSERT(command && "shoul be parent command!");
        Transition *initial = TransitionManager::getInstance()->createOneStateTransition("Initial", this, selectedState, "", WEST, false);
        new TransitionAddCommand(this, initial, command);
    }
    else
    {
        Q_ASSERT(!command && "should be NULL!");
        command = tmpCommand;
    }

    m_undoStack->push(command);

    mw->setStatusBar("Selected state edited", 2000);
    update();
}

void Editor::editStateParams()
{
    StateExtendedDialog sed(this);
  
    sed.setParams(selectedState);
    if (sed.exec() == QDialog::Rejected) return;
    
    m_undoStack->push(
        new StateEditExtendedCommand(selectedState, sed.getLineStyle(), sed.getLineWidth(),
            sed.getLineColor(), sed.getLabelColor(), sed.getLabelScale(), sed.getFillStatus(),
            sed.getFillColor(), sed.getDimLineStyle(), sed.getDimLineColor(),
            sed.getDimLineCoef(), sed.getDimLabelColor(), sed.getDimFillColor(), 
            sed.getLineDblCoef(), sed.getLineDblSep())
    );
  
    mw->setStatusBar("Selected state's parameters edited", 2000);
    update();
}

void Editor::editStateStyleParams()
{
    StateStyleDialog ssd(this); // postara se o vsecho sam ...
    ssd.exec();
}

void Editor::editState(State *state)
{
    selectedState = state;
    editState();    
}

void Editor::removeState()
{   
    m_undoStack->push(
        new StateDeleteCommand(this, selectedState)
    );
}

void Editor::editOneStateTransition()
{
    editTransition(static_cast<OneStateTransition *>(selectedTransition));
}

void Editor::editTwoStatesTransition()
{
    editTransition(static_cast<TwoStatesTransition *>(selectedTransition));
}

void Editor::editTransition(OneStateTransition *selectedTr)
{
    DBGLOG("ok" << selectedTr);

    TransitionManager *transitionManager = TransitionManager::getInstance();

    TransitionLoopSEDialog td(TransitionLoopSEDialog::eEdit, this);
    
    int typeId = transitionManager->getTypeNameId(selectedTr->getTypeName());

    td.setLabel(selectedTr->getLabelText());
    td.setLabelPos(selectedTr->getLabelPos());
    td.setDimmed(selectedTr->isDimmed());
    td.setType(typeId);
    td.setDirection(selectedTr->getDirection());

    int ret = td.exec();
 
    selectedTr->setChecked(false);

    if (ret == QDialog::Rejected)
    {
        return;
    }

    if (td.getType() == typeId)
    { // type of transition not changed
        m_undoStack->push(
            new OneStateTransitionEditCommand
            (selectedTr, td.getLabel(), td.getLabelPos(),
             td.getDirection(), td.isDimmed())
        );
    }
    else
    {
        State *s1 = selectedTr->getStartState();

        Transition *tr = transitionManager->createOneStateTransition
            (this, s1, td);
        tr->setLabelPos(td.getLabelPos());

        m_undoStack->push(new TransitionEditWithDelCommand(this, selectedTr, tr));
        selectedTransition = tr;
        tr->adjust();
    }
}

void Editor::editTransition(TwoStatesTransition *selectedTr)
{
    DBGLOG("ok" << selectedTr);
    
    TransitionManager *transitionManager = TransitionManager::getInstance();

    int typeId = transitionManager->getTypeNameId(selectedTr->getTypeName());

    TransitionDialog td(TransitionDialog::eEdit, this);
    td.setName(selectedTr->getLabelText());
    td.setTrOrientation(selectedTr->isLeftOriented());    
    td.setType(typeId);
    td.setLabelPos(selectedTr->getLabelPos());        
    // used only for some types of transition!
    td.setArcAngle(selectedTr->getArcAngle());
    td.setArcAngleB(selectedTr->getArcAngleB());
    td.setNCurv(selectedTr->getNCurv());

    td.setDimmed(selectedTr->isDimmed());

    int ret = td.exec();
    
    selectedTr->setChecked(false);

    if (ret == QDialog::Rejected) 
    {    
        return;
    }    

    if (typeId == td.getType())
    { // transition type preserved
        m_undoStack->push(
            new TwoStatesTransitionEditCommand
                (selectedTr, td.getLabel(), td.getLabelPos(), td.isDimmed(), 
                td.isLeftOriented(), td.getArcAngle(),
                td.getArcAngleB(), td.getNCurv())
            );
        selectedTr->adjust();
    }
    else
    { // transition type changed
        State *s1, *s2;
        Transition *tr;
        s1 = selectedTr->getStartState();
        s2 = selectedTr->getEndState();

        tr = transitionManager->createTwoStatesTransition
            (this, s1, s2, td);
        tr->setLabelPos(td.getLabelPos());
        tr->setArcAngle(td.getArcAngle());
        tr->setArcAngleB(td.getArcAngleB());
        tr->setNCurv(td.getNCurv());

        mw->setStatusBar(tr->getTypeName() +
                         tr->getTypeNameSuffix() +
                         " inserted", 2000);
        m_undoStack->push(new TransitionEditWithDelCommand(this,selectedTr,tr));
        selectedTransition = tr;
        tr->adjust();
    }
    update();
}

void Editor::editNextLabels()
{
    NextLabelsDialog nld(this, selectedTransition, this);
    nld.exec();
    selectedTransition->adjust();
}

void Editor::editTransitionParams()
{
  TransitionExtendedDialog ted(this);
  
  ted.setParams(selectedTransition);
  
  if (ted.exec() == QDialog::Rejected) return;
  
  m_undoStack->push(
    new TransitionEditExtendedCommand(selectedTransition, ted.getLineStyle(), ted.getLineWidth(),
        ted.getLineColor(), ted.getLabelColor(), ted.getLabelScale(), ted.getDblStatus(),
        ted.getDimLineStyle(), ted.getDimLineColor(), ted.getDimLineCoef(),
        ted.getDimLabelColor(), ted.getLineBorderCoef(), ted.getLineBorderColor(),
        ted.getLineDblCoef(), ted.getLineDblSep())
  );
  
  mw->setStatusBar("Selected transition's parameters edited", 2000);
}

void Editor::editTransitionStyleParams(){
    TransitionStyleDialog tsd(this);
    tsd.exec();
}

void Editor::removeTransition()
{
    m_undoStack->push(new TransitionDeleteCommand(this,selectedTransition));
}

// private members
void Editor::insertState(const QPoint& point)
{
    StateManager *stateManager = StateManager::getInstance();
    StateDialog sd(this, stateManager->getTypeNameList(), StateDialog::eAdd, false, this);
  
    QString stateName = getUniqueAutoName();

    sd.setName(stateName, false);
    sd.setAutoNammed(true);
    if (sd.exec() == QDialog::Rejected) return;

    State *newState;
      
    newState = stateManager->createState(this, point, sd);
    newState->setAutoNammed(sd.isAutoNammed());

    QUndoCommand *command;
    if (sd.quickInitial()) // add initial transition quickly
    {
        command = new QUndoCommand(QString("Insert state (%1) + quick initial add").arg(newState->getName()));
        new StateAddCommand(this, newState, command);
        TransitionManager *trManager = TransitionManager::getInstance();
        Transition *initial = trManager->createOneStateTransition("Initial", this, newState, "", WEST, false);
        new TransitionAddCommand(this, initial, command);
    }
    else
    {
        command = new StateAddCommand(this, newState);
    }

    m_undoStack->push(
        command
    );
 
    mw->setStatusBar("New state inserted", 2000);
}

QPoint Editor::toScenePos(const QPointF &gridPos)
{
    return QPoint((int)((gridPos.x() - gridRect.x()) * GRID_STEP + GRID_STEP / 2),
                  (int)(scene()->height()-2 - (gridPos.y()-gridRect.y()) * GRID_STEP));         
}
    
// for parser ..
State* Editor::insertState(State *state)
{
    QRegExp rx("^Q[0-9]{1,10}$"); // check if name is autoNammed
    QRegExpValidator v(rx,this);
    int pos = 0; QString tested = state->getName();
    
    state->setAutoNammed(v.validate(tested,pos) == QValidator::Acceptable);
   
    addToListsAndScene(state);
   
    return state;
};

void Editor::insertTransition()
{
    DBGLOG_ADD("called");
    if (selectedState)
    {        
        if (startState == NULL)
        { // first state inserted
            startState = selectedState;
            mw->setStatusBar("First state selected; Select second state", 2000);
        }
        else
        { // maybe new transiton            
            TransitionManager *transitionManager = TransitionManager::getInstance();
            Transition *tr = NULL;
            if (startState==selectedState)
            { // one state transition
                TransitionLoopSEDialog td(TransitionLoopSEDialog::eAdd, this);
                if (!(td.exec() == QDialog::Rejected))
                {
                    tr = transitionManager->createOneStateTransition
                            (this, startState, td);
                    tr->setLabelPos(td.getLabelPos());
                    mw->setStatusBar(tr->getTypeName() +
                                     tr->getTypeNameSuffix() +
                                     " inserted", 2000);
                    m_undoStack->push(new TransitionAddCommand(this, tr));
                }
            }
            else
            {
                // two states transition
                TransitionDialog td(TransitionDialog::eAdd, this);
                if (!(td.exec() == QDialog::Rejected))
                {
                    tr = transitionManager->createTwoStatesTransition
                            (this, startState, selectedState, td);                 
                    
                    tr->setLabelPos(td.getLabelPos());
                    tr->setArcAngle(td.getArcAngle());
                    tr->setArcAngleB(td.getArcAngleB());
                    tr->setNCurv(td.getNCurv());

                    mw->setStatusBar(tr->getTypeName() +
                                     tr->getTypeNameSuffix() +
                                     " inserted", 2000);
                    m_undoStack->push(new TransitionAddCommand(this, tr));
                }
            }      
            if (selectedState != startState)
            { // only two states transition
                startState->setChecked(false); 
                startState->update();
                startState = NULL;
            }
            else
            {
                startState = NULL;
            }
            selectedState->setChecked(false);
            selectedState = NULL;            
            if (tr) tr->adjust();
        }
    }
}

QString Editor::getUniqueAutoName()
{
    return getUniqueAutoName(m_stateMap);
}

QString Editor::getUniqueAutoName(const TStateMap &stateMap)
{
    QString autoName;
    bool ok;
    do
    {
        ok = true; // osetreni proti dvojimu pouziti tehoz jmena
        autoName = QString("Q%1").arg(getNewStateNumber());
        if(testStateName(autoName, stateMap))
        {
            increaseNewStateNumber();
            ok = false;
        } 
    }
    while(!ok);
    
    return autoName;
}

State* Editor::getStateByName(const TStateMap &stateMap, const QString &name) const
{    
    if (stateMap.contains(name))
        return stateMap[name];

    return 0; // state not founded!
}

void Editor::drawBackground(QPainter *painter, const QRectF &)
{
    int fontHeight = 12;
    int fontWidth;
    QFont font;
    font.setPixelSize(fontHeight);
    painter->setFont(font);
    QFontMetrics fm(font);
    if (showGrid || showFrame)
    {
        int pop = gridRect.x(); //lowerLeftX
        for (int x = GRID_STEP / 2; x < scene()->width();x += GRID_STEP)
        {
            if (showGrid) // create lines
            {
                if (pop)
                    painter->setPen(QPen(Qt::lightGray, 1, Qt::DotLine));
                else // bold x-axis
                    painter->setPen(QPen(Qt::darkGray, 1, Qt::DotLine));
                
                painter->drawLine(x, GRID_STEP/2, x, (int)scene()->height());       
            }
            if (showFrame) // create numbers
            {
                painter->setPen(QPen(Qt::lightGray));
                QString s = QString("%1").arg(pop);
                fontWidth = fm.width(s, s.length());
                painter->drawText(x-fontWidth/2,fontHeight,s);        
            }
            pop++;
        }
        pop = gridRect.y() + gridRect.height(); //upperRightY - from up
        for (int y = GRID_STEP/2; y < scene()->height(); y+=GRID_STEP)
        {
            if (showGrid) // create lines
            {
                if (pop)
                    painter->setPen(QPen(Qt::lightGray, 1, Qt::DotLine));
                else // bold y-axis
                    painter->setPen(QPen(Qt::darkGray, 1, Qt::DotLine));
                
                painter->drawLine(GRID_STEP/2, y, (int)scene()->width(), y);
            }
            if (showFrame) // create numbers
            {
                painter->setPen(QPen(Qt::lightGray));
                painter->drawText(2, y + fontHeight/2,QString("%1").arg(pop));
            }
            pop--; // to lower
        }
    }
}

void Editor::setStatusBar(const QString &text, int ms)
{
    mw->setStatusBar(text, ms); // hlavne kvuli commandum
}

// public slots:

void Editor::showGridRectDialog()
{
    GridRectDialog grd(this);
    grd.setLowerLeftX(gridRect.x());
    grd.setLowerLeftY(gridRect.y());
    grd.setUpperRightX(gridRect.x() + gridRect.width());
    grd.setUpperRightY(gridRect.y() + gridRect.height());
    grd.setBorder(sceneBorder);
  
    if (grd.exec() == QDialog::Rejected) 
    {
        return;
    }
    
    QRect gridRect_new = QRect(grd.getLowerLeftX(), grd.getLowerLeftY(),
                               grd.getUpperRightX() - grd.getLowerLeftX(),
                               grd.getUpperRightY() - grd.getLowerLeftY());
    
    m_undoStack->push(
        new EditorChangeGridRectCommand(this, gridRect_new, grd.getBorder())
    );
}

void Editor::undo()
{
    startState = NULL;
    scene()->clearSelection();
    m_undoStack->undo();
}

void Editor::redo()
{
    startState = NULL; // to avoid problem with transition adding to NULL state
    scene()->clearSelection();
    m_undoStack->redo();
}


void Editor::showUndoView(bool show)
{
    if (show)
        m_undoView->show();
    else
        m_undoView->hide();
}

void Editor::zoomIn()
{
    scaleView(m_zoomInFactor);
}

void Editor::zoomOut()
{
    scaleView(1/m_zoomInFactor);
}

void Editor::resetZoom()
{
    // TODO: check if this is true even if other transformations are done!
    scaleView(1/transform().m11()); // m11 is x scale value 
}

void Editor::stateMoved(State *state, const QPointF &oldPos)
{
    m_undoStack->push(new StateMoveCommand(state, oldPos));
    update();
}

void Editor::removeFromListsAndScene(Transition *transition)
{
    removeFromListAndScene(transition);
  
    transition->unassign();
}

void Editor::removeFromListsAndScene(State *state)
{
    if (state == selectedState) selectedState = NULL;
    
    DBGLOG_ADD("state ->" << (void*)state << DBGPAR(state->getName()));
    
    int count = m_stateMap.remove(state->getName());
    Q_UNUSED(count);
    Q_ASSERT(count == 1);

    scene()->removeItem(state);
}

void Editor::removeFromListAndScene(Transition *transition)
{
    DBGLOG_ADD("transition ->" << (void*)transition);
    int i = m_transitionList.indexOf(transition);
    if (i != -1) m_transitionList.removeAt(i);
  
    scene()->removeItem(transition);
    
    if (transition->getLabel())
    {
        DBGLOG_ADD("transition -> label" << (void*)(transition->getLabel()));
        scene()->removeItem(transition->getLabel());
    }

    const Transition::TLabelXList& labelList = transition->getNextLabels();
    for (Transition::TLabelXList::ConstIterator labelIt = labelList.begin();
         labelIt != labelList.end();
         ++labelIt)
    {
        DBGLOG_ADD("transition -> label" << (void*)(*labelIt));
        scene()->removeItem(*labelIt);
    }
}

void Editor::removeFromListAndScene(LabelX *pLabel)
{
    DBGLOG_ADD("label" << (void*)(pLabel));
    scene()->removeItem(pLabel);
    pLabel->getTransition()->removeNextLabel(pLabel);
}

void Editor::addToListAndScene(Transition *transition)
{
    DBGLOG_ADD("transition ->" << (void*)transition);
    m_transitionList << transition;
    scene()->addItem(transition);
    
    if (transition->getLabel() != NULL)
    {
        DBGLOG_ADD("transition -> label" << (void*)(transition->getLabel()));
        scene()->addItem(transition->getLabel());  
    }

    const Transition::TLabelXList& labelList = transition->getNextLabels();
    for (Transition::TLabelXList::ConstIterator labelIt = labelList.begin();
         labelIt != labelList.end();
         ++labelIt)
    {
        DBGLOG_ADD("transition -> label" << (void*)(*labelIt));
        scene()->addItem(*labelIt);
    }
}

void Editor::addToListAndScene(LabelX *pLabel)
{    
    DBGLOG_ADD("label" << (void*)(pLabel));
    scene()->addItem(pLabel);
    pLabel->getTransition()->addNextLabel(pLabel);
}

void Editor::addToListsAndScene(Transition *transition)
{
    addToListAndScene(transition);
  
    transition->assign();
}

void Editor::addToListsAndScene(State *state)
{
    DBGLOG_ADD("state ->" << (void*)state << DBGPAR(state->getName()));
    
    Q_ASSERT(!m_stateMap.contains(state->getName()));
    m_stateMap[state->getName()] = state;
    
    scene()->addItem(state);
}

void Editor::renameState(State *state, const QString &name)
{
    if (state->getName() == name) return;
    
    if (m_stateMap.contains(state->getName()))
    {
        int count = m_stateMap.remove(state->getName());
        Q_UNUSED(count);
        Q_ASSERT(count == 1);
        Q_ASSERT(!m_stateMap.contains(state->getName()));
        m_stateMap[name] = state;
    }
    state->setName(name);
}

void Editor::switchAntialiasing()
{
    antial = !antial;
    DBGLOG(DBGPAR(antial));
    if (antial)
    {
        setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform); // nicier        
    }
    else
    {
        setRenderHint(QPainter::Antialiasing, false);
        setRenderHint(QPainter::SmoothPixmapTransform,true); // for slower engines
    }
}

void Editor::generateGraph()
{
  GraphGenerationDialog ggd(this);
  if (ggd.exec() == QDialog::Rejected) {
    return; 
  }
  
  int type = ggd.getType();
  QString string = ggd.getString();
  int len = string.length();
  QPoint startPoint = ggd.getStartPoint();
  int distance = ggd.getDistance();
  
  if (distance > len-1) distance = len-1;
  
  QList<State *> sList;
  
  switch (type)
  {
    case 0: // EXACT MATCHING
      sList = generateExactMatching(string,ggd.getStartPoint());
      break;
    case 1: // HAMMING DISTANCE
      sList = generateDistance(1,string, distance, startPoint);
      break;
    case 2: // LEVENSTHEIN DISTANCE
      sList = generateDistance(2,string, distance, startPoint);
      break;
    default:;
  }
  
  QRect gridRect_new = gridRect;
  
  if (ggd.isExpandRequired())
  {
    int llx, lly, urx, ury, lly_new, urx_new;
    llx = gridRect.x();
    lly = gridRect.y();
    urx = gridRect.x() + gridRect.width();
    ury = gridRect.y() + gridRect.height();
  
    if (startPoint.x() < llx) llx = startPoint.x();
    if (startPoint.y() > ury) ury = startPoint.y();
    if (startPoint.x() > urx) urx = startPoint.x();
    if (startPoint.y() < lly) lly = startPoint.y();
    
    if (type == 0) // EXACT MATCHING
    {
      urx_new = startPoint.x() + len * EXACT_HSPACE + 1; // 1 is because not margins set
      lly_new = startPoint.y();
    }
    else
    {
      urx_new = startPoint.x() + len * (type == 1 ? HAMMING_HSPACE : LEVEN_VSPACE) + 1;
      lly_new = startPoint.y() - distance * (type == 1 ? HAMMING_VSPACE : LEVEN_VSPACE) - 1;
    } // if

    if (urx < urx_new) urx = urx_new;
    if (lly > lly_new) lly = lly_new;

    DBGLOG(llx << lly << urx << ury << lly_new << urx_new);
    
    gridRect_new = QRect(llx, lly, urx - llx, ury - lly);
  }
  
    m_undoStack->push(
        new ItemsAddCommand(this, sList, gridRect_new)
    );

    setActionInternal(eSelection);

    foreach(State *state, sList)
    {
        state->setSelected(true);
        foreach(Transition *tr, state->getTransitionList())
        {
            tr->setSelected(true);
        }
    }
}

// generating

QList<State *> Editor::generateExactMatching(QString string, QPoint startPoint)
{
    QString stateType, newName;
    Transition *tr;
    StateManager *stateManager = StateManager::getInstance();
    TransitionManager *transitionManager = TransitionManager::getInstance();
    QList<State *> sList;
    State *s1 = NULL, *s2 = NULL;

    TStateMap stateMapCopy = m_stateMap;

    for (int i = 0; i <= string.length(); i++)
    {
        newName = getUniqueAutoName(stateMapCopy);
        stateMapCopy[newName] = NULL;

        stateType = i == string.length() ? "FinalState" : "State";
        s2 = stateManager->createState(stateType, this, toScenePos(startPoint + i*QPoint(EXACT_HSPACE, 0)),
                                   QString("%1").arg(i), newName, false);
        sList << s2;
    
        if (i > 0)
        { // paint transitions
            tr = transitionManager->createTwoStatesTransition("Edge",this, s1, s2, QString(string[i-1]),true, false);
            tr->assign();
        } 
        else
        {
            tr = transitionManager->createOneStateTransition("Initial", this, s2, "", WEST, false);      
            tr->assign();
            tr = transitionManager->createOneStateTransition("Loop", this, s2, "A", NORTH, false);
            tr->assign();
        }
        s1 = s2;
    }
  
    return sList;
}

QList<State *> Editor::generateDistance(int typ, QString string, int distance, QPoint startPoint)
{
    QString stateType, newName;
    int len = string.length();
  
    int labNumb = -1;
  
    QList<State *> sList;
    State *s1 = NULL, *s2 = NULL;
    StateManager *stateManager = StateManager::getInstance();
    Transition *tr;
    TransitionManager *transitionManager = TransitionManager::getInstance();
  
    TStateMap stateMapCopy = m_stateMap;
  
    for (int j = 0; j <= distance; j++)
    {
        for (int i = j; i <= len; i++)
        {
            newName = getUniqueAutoName(stateMapCopy);
            stateMapCopy[newName] = NULL;
      
            stateType = (i == string.length()) ? "FinalState" : "State";
            s2 = stateManager->
                createState(stateType, this,
                            toScenePos(
                                startPoint + 
                                    QPoint((typ==1 ? HAMMING_HSPACE : LEVEN_HSPACE) * i,
                                    (typ==1 ? -HAMMING_VSPACE : -LEVEN_VSPACE) * j)
                            ),
                            QString("%1").arg(++labNumb),
                            newName,
                            false);
        
            sList << s2;
      
            if (i != j)
            { // paint transitions
                tr = transitionManager->createTwoStatesTransition
                    ("Edge", this, s1, s2, QString(string[i-1]), true, false);

                tr->assign();
            } 
            else if (j == 0)
            {
                tr = transitionManager->createOneStateTransition
                    ("Initial", this, s2, "", WEST, false);                
                tr->assign();
                tr = transitionManager->createOneStateTransition
                    ("Loop", this, s2, "A", NORTH, false);                
                tr->assign();
            }
      
            if (j > 0)
            { // transitions diagonal, horizontal, curved
              // (max_i + 1)*j + i - (j + j^2)/2  -- cislo stavu v sListu
        
                s1 = sList[(len+1)*(j-1) + (i-1) - (j-1)*(1+(j-1))/2]; // diag and curved line
                if (s1)
                {    
                    tr = transitionManager->createTwoStatesTransition
                        ("Edge", this, s1, s2, "A", typ == 1, false);
                    tr->assign();
        
                    if (typ == 2)
                    {
                        tr = transitionManager->createTwoStatesTransition
                            ("Arc", this, s1, s2, "\\varepsilon", false, false);
                        tr->assign();
                        tr->adjust();
            
                        if (i != len)
                        {
                            s1 = sList[(len+1)*(j-1) + (i) - (j-1)*(1+(j-1))/2]; // horizontal
                            if (s1)
                            {
                                tr = transitionManager->createTwoStatesTransition
                                    ("Edge", this, s1, s2, "A", true, false);                                
                                tr->assign();
                            }
                        }
                    }
                }
            }
      
            s1 = s2;
        }   
    }
    return sList;
}

void Editor::createLaTeXTable()
{
    QSharedPointer<IAutomaton> automaton = loadAutomaton("LaTeX table");
    
    if (!automaton)
    {
        RELLOG("no automaton detected!");
        return;
    }
    
    LaTeXTableDialog ltd(this, automaton->getTransitionTable());

    ltd.exec();
}

void Editor::addToUndoStack(QUndoCommand *command)
{
    m_undoStack->push(command);
}

int Editor::addAlgorithm(const QSharedPointer<IAlgorithm> &algorithm)
{
    if (algorithm->requireCreator())
        algorithm->setAutomataCreator(getAutomataCreator());

    m_algorithmList << algorithm;
    return m_algorithmList.count()-1;
}

void Editor::addGraphVizDrawAlgorithm(IGraphViz *graphVizWrapper)
{
    DBGLOG("GraphViz version: " << graphVizWrapper->getGraphVizVersion());
    if (graphVizWrapper->getGraphVizVersion() != QString(GRAPHVIZ_VERSION))
    {
        RELLOG("Cannot be used with GraphViz version " << graphVizWrapper->getGraphVizVersion() <<
               ", required version is " << GRAPHVIZ_VERSION << "!!!");
        return;
    }
    m_drawAlgorithmList << QSharedPointer<IDrawAlgorithm>(new GraphVizDrawAlgorithm(graphVizWrapper));
    m_currentDrawAlgorithm = m_drawAlgorithmList.count()-1;
}

QStringList Editor::getDrawAlgorithms() const
{
    QStringList result;
    foreach(const QSharedPointer<IDrawAlgorithm> &drawAlg, m_drawAlgorithmList)
    {
        result << drawAlg->getName();
    }
    Q_ASSERT(!result.empty() && "no drawing algorithm was set!");
    return result;
}

QSharedPointer<AutomatonImpl> Editor::loadAutomaton(const QString &dialogTitle)
{    
    LoadAutomataDialog lad(this, dialogTitle, 0, QStringList(), true, NULL); // use only current automaton (0)
    if (!lad.exec())
        return QSharedPointer<AutomatonImpl>();
    
    ITransition::TCharSet   alphabet;
    QString                 alphabetSymbol;
    QString                 epsilonSymbol;
    
    if (lad.alphabetIsSet())
        alphabet = lad.getAlphabet();
    if (lad.alphabetSymbolIsSet())
        alphabetSymbol = lad.getAlphabetSymbol();
    if (lad.epsilonSymbolIsSet())
        epsilonSymbol = lad.getEpsilonSymbol();
    
    if (m_stateMap.empty())
    {
        QMessageBox::information(this, "No automaton", 
                                 "There is no automaton on scene!" , QMessageBox::Ok);
        return QSharedPointer<AutomatonImpl>();
    }

    return getAutomaton(getStateList(), alphabet, alphabetSymbol, epsilonSymbol);
}

IAutomaton::TAutomataList Editor::loadAutomata(const QString &dialogTitle, int count,
                                               QStringList &fileNames, IAlgorithm *algorithm)
{
    LoadAutomataDialog lad(this, dialogTitle, count, getDrawAlgorithms(), !m_stateMap.empty(), algorithm);
    
    Q_ASSERT(m_currentDrawAlgorithm < m_drawAlgorithmList.count());
    lad.setDrawAlgorithmIndex(m_currentDrawAlgorithm);

    if (QDialog::Rejected == lad.exec())
        return IAutomaton::TAutomataList();
    
    fileNames = lad.getFileNames();
    
    DBGLOG_AI(DBGPAR(fileNames));
    
    IAutomaton::TAutomataList automata;
    QSharedPointer<IAutomaton> automaton;
    Parser parser(this, false);
    bool okParse = true;
    bool okAutomata = true;
    QStringList invalidFiles;
    
    QList<State *>  parsedStates;
    QRect           newGridRect;
    QString         report;
    
    ITransition::TCharSet alphabet;
    if (lad.alphabetIsSet()) alphabet = lad.getAlphabet();
    QString alphabetSymbol;
    if (lad.alphabetSymbolIsSet()) alphabetSymbol = lad.getAlphabetSymbol();
    QString epsilonSymbol;
    if (lad.epsilonSymbolIsSet()) epsilonSymbol = lad.getEpsilonSymbol();
    
    if (lad.useCurrentAutomaton())
    {
#ifdef MEASURE_AUTOMATA_RECOGNIZATION 
        QTime timer;
        timer.start();
#endif
        ITransition::TCharSet alphabetTmp = alphabet;
        QString alphabetSymbTmp = alphabetSymbol;
        QString epsilonSymbTmp = epsilonSymbol;
        automaton = getAutomaton(getStateList(), alphabetTmp, alphabetSymbTmp, epsilonSymbTmp);
#ifdef MEASURE_AUTOMATA_RECOGNIZATION
        RELLOG("Calling getAutomaton() have taken" << timer.elapsed() << "ms");
#endif
        if (automaton)
        {
            automata << automaton;
        }
        else
        {
            okAutomata &= false;
            invalidFiles << "Current file";
        }
    }
    
    int i = lad.useCurrentAutomaton() ? 1 : 0;
    for (; i<count; ++i)
    {
        if (!parser.run(fileNames[i], parsedStates, newGridRect))        
        {
            report += fileNames[i] + "<br>" + parser.getReport() + "<br><br>";
            okParse &= false;
        }
        
        if (!parsedStates.empty())
        {
#ifdef MEASURE_AUTOMATA_RECOGNIZATION 
            QTime timer;
            timer.start();
#endif
            ITransition::TCharSet alphabetTmp = alphabet;
            QString alphabetSymbTmp = alphabetSymbol;
            QString epsilonSymbTmp = epsilonSymbol;
            automaton = getAutomaton(parsedStates, alphabetTmp, alphabetSymbTmp, epsilonSymbTmp);
#ifdef MEASURE_AUTOMATA_RECOGNIZATION
            RELLOG("Calling getAutomaton() have taken" << timer.elapsed() << "ms");
#endif
            if (automaton)
            {
                automata << automaton;
            }
            else
            {
                okAutomata &= false;
                invalidFiles << fileNames[i];
            }   
        }        
        parsedStates.clear();
        automaton.clear();
    }
    
    if (!okParse)
    {
        ReportDialog prd(report, this);
        prd.exec();
    }
    
    if (!okAutomata)
    {
        report = "Some automata are defined incorrectly! Please check it!<br>"
                 "Incorrectly defined files:<br>"
                 "--------------------------------<br>";
        for (int idx=0; idx<invalidFiles.count(); ++idx)
        {
            report += invalidFiles.join("<br>");
        }
        ReportDialog prd(report, this);
        prd.exec();
    }
    
    m_currentDrawAlgorithm = lad.getDrawAlgorithmIndex();
    return automata;
}

QList<State*> Editor::createGraphicsItems(const QSharedPointer<IAutomaton> &automaton)
{
    QList<State*> result;
    
    if (!automaton->hasPositions()) return result;
    
    // TODO: implement this
    
    return result;
}

void Editor::expandGrid(int bound)
{    
    m_undoStack->push(
        new EditorChangeGridRectCommand(this, getExpandedGridRect(m_stateMap.values(), bound), getBorder())
    );
}

QRect Editor::getExpandedGridRect(const TStateList &states, int bound)
{
    Q_ASSERT(bound >= 0);
    
    QRectF bb;
    foreach(State* state, states)
    {
        bb |= state->boundingRect().translated(state->pos());
        TTransitionList transitions = state->getOutgoingTransitions();
        foreach(Transition* transition, transitions)
        {
            bb |= transition->boundingRect().translated(transition->pos());
        }
    }

    QPointF topLeft = mapToGrid(bb.topLeft());
    QPointF bottomRight = mapToGrid(bb.bottomRight());
    
    QRectF newGridRect(topLeft.x(), bottomRight.y(),
                       bottomRight.x()-topLeft.x(), topLeft.y()-bottomRight.y());
    
    DBGLOG(DBGPAR(newGridRect));

    return newGridRect.toAlignedRect().adjusted(-bound,-bound,bound,bound);
}

void Editor::runAlgorithm()
{
    DBGLOG_AI("called");
    
    QAction *action = qobject_cast<QAction*>(sender());
    bool ok;
    int algIndex = action->data().toInt(&ok);

    if (!ok)
    {
        Q_ASSERT(0 && "incorrect action!!!");
        RELLOG("incorrect action!!!");
        return;
    }    

    if (! (algIndex < m_algorithmList.count()))
    {
        Q_ASSERT(0 && "bad algorithm index given from action!!!");
        RELLOG("bad algorithm index given from action!!!");
        return;
    }

    QSharedPointer<IAlgorithm> algorithm = m_algorithmList[algIndex];
    IAutomaton::TAutomataList automata;
    QStringList fileNames;

    if (algorithm->getInputCount())
        automata = loadAutomata(algorithm->getName(), algorithm->getInputCount(), fileNames, algorithm.data());
    
    if (automata.size() != algorithm->getInputCount())
    {
        return;
    }

    QSharedPointer<IAutomaton> resultAutomaton;
    QString report;
    if (algorithm->run(automata, resultAutomaton, &report))
    {
        QUndoCommand *command = new QUndoCommand(QString("RunAlgorith -> %1").arg(algorithm->getName()));
        new ItemsRemoveCommand(this, getStateList(), m_transitionList, command);
        
        QList<State *> newStates;
        
        newStates = createGraphicsItems(resultAutomaton);
        
        if (newStates.isEmpty())
        {
            Q_ASSERT(m_drawAlgorithmList.size() > m_currentDrawAlgorithm && "inconsistency with LoadAutomataDialog!");
            newStates = m_drawAlgorithmList[m_currentDrawAlgorithm]->drawAutomaton(this, resultAutomaton);
        }
        
        new ItemsAddCommand(this, newStates, gridRect, command);

        new EditorChangeGridRectCommand(this, getExpandedGridRect(newStates, 0), getBorder(), command);

        m_undoStack->push(command);
        
        DBGLOG("Algorithm '" << algorithm->getName() << "' successfull." << endl 
               << "Report: " << report << ".");
    }
    else
    {
        DBGLOG("Algorithm '" << algorithm->getName() << "' failed.");
        ReportDialog rd(report, this);
        rd.exec();
    }
}

void Editor::simulateAutomatonWork()
{
    QSharedPointer<AutomatonImpl> automaton = loadAutomaton("Simulation");
    if (!automaton) return;
    
    Q_ASSERT(automaton);
        
    AutomataWorkSimulator *aws = new AutomataWorkSimulator(this, *m_undoStack, automaton);
    connect(aws, SIGNAL(finished()), this, SLOT(simulationFinished()));
    connect(aws, SIGNAL(setStatesMarked(QList<State*>, bool)), this, SLOT(setStatesMarked(QList<State*>, bool)));
    
    m_simulationIsRun = true;
    updateMenuState();
    aws->run();
}

void Editor::simulationFinished()
{
    m_simulationIsRun = false;
    updateMenuState();
    
    AutomataWorkSimulator *simulator = qobject_cast<AutomataWorkSimulator*>(sender());
    simulator->disconnect();
    Q_ASSERT(simulator);
    delete simulator;
}

void Editor::setStatesMarked(QList<State*> states, bool marked)
{
    m_undoStack->push(
        new StatesSetMarkedCommand(states, marked)
    );
}

void Editor::updateMenuState()
{
    // TODO: check all possiblities - is this sufficient?
    emit canNewFile(!m_simulationIsRun);
    emit canOpenFile(!m_simulationIsRun);
    emit canSaveFile(!m_simulationIsRun);
    
    emit itemsAvailable(!m_simulationIsRun);
    emit toolsAvailable(!m_simulationIsRun);
    emit utilsAvailable(!m_simulationIsRun);
    
#ifndef ALLOW_UNDO_VIEW_WHILE_SIMULATION_RUNNING
    m_undoView->close();
    emit showUndoStackAvailable(!m_simulationIsRun);
#endif
    emit canUndoChanged(!m_simulationIsRun && m_undoStack->canUndo());
    emit canRedoChanged(!m_simulationIsRun && m_undoStack->canRedo());       
}

QSharedPointer<AutomatonImpl> Editor::getAutomaton(const TStateList &stateList,
                                                   ITransition::TCharSet &alphabet,
                                                   QString &alphabetSymbol,
                                                   QString &epsilonSymbol)
{
    // TODO: make error reporting better
    if (getInitialStates(stateList).isEmpty())
    {
        QMessageBox::information(this, "No initial state",
                                 "There is no initial state on scene!\nSuch automaton has no sense" , QMessageBox::Ok);
        return QSharedPointer<AutomatonImpl>(NULL);
    }

    if (alphabet.isEmpty() || alphabetSymbol == "" || epsilonSymbol == "")
    {
        bool ok = detectAutomataSettings(stateList, alphabet, alphabetSymbol, epsilonSymbol);

        if (!ok) return QSharedPointer<AutomatonImpl>(NULL);
    }

    if (alphabetSymbol == "") alphabetSymbol = AutomataCreator::defaultAlphabetSymbList[0];
    if (epsilonSymbol == "") epsilonSymbol = AutomataCreator::defaultEpsilonSymbList[0];

    DBGLOG("Automata settings:"     << endl <<
           DBGPAR(alphabet)         << endl <<
           DBGPAR(alphabetSymbol)   << endl <<
           DBGPAR(epsilonSymbol));

    QScopedPointer<AutomataCreator> creator(new AutomataCreator());
    QSharedPointer<AutomatonImpl> automaton = creator->createPrivateAutomaton(alphabet, alphabetSymbol, epsilonSymbol);
    for (TStateList::ConstIterator stateIt = stateList.begin();
         stateIt != stateList.end();
         ++stateIt)
    {
        State* state = (*stateIt);
        bool ok = automaton->addState(
            creator->createPrivateState(state->getName(), state->getLabel(), state->isInitial(), state->isFinal(), state)
        );

        Q_UNUSED(ok);
        Q_ASSERT(ok && "some problem when adding state!");
    }

    for (TStateList::ConstIterator stateIt = stateList.begin();
         stateIt != stateList.end();
         ++stateIt)
    {
        TTransitionList trList = (*stateIt)->getOutgoingTransitions();
        for (TTransitionList::ConstIterator trIt = trList.begin();
             trIt != trList.end();
             ++trIt)
        {
            Transition* transition = (*trIt);
            Q_ASSERT(transition->getTypeName() != "Initial" && transition->getTypeName() != "Final");

            ITransition::TCharSet characters;
            bool ok = transition->getCharacters(characters, alphabet, alphabetSymbol, epsilonSymbol);

            if (!ok)
            {
                return QSharedPointer<AutomatonImpl>(NULL); // report already showen in Transition::getCharacters
            }

            automaton->createAndAddPrivateTransition(transition->getStartStateName(), transition->getEndStateName(),
                                                     characters, transition);
        }
    }

    DBGLOG("automaton created, consists of:" << endl
                   << automaton->getStates().count() << "states" << endl
                   << automaton->getInitialStates().count() << "initial states" << endl
                   << automaton->getFinalStates().count() << "final states" << endl
                   << "alphabet:" << automaton->getAlphabet() << endl
                   << "alphabetSymb:" << automaton->getAlphabetSymbol() << endl
                   << "epsilonSymb:" << automaton->getEpsilonSymbol());

    return automaton;
}

bool Editor::detectAutomataSettings(const QList<State *> &stateList,
                                    ITransition::TCharSet &alphabet,
                                    QString &alphabetSymbol,
                                    QString &epsilonSymbol)
{
    QString report = "";

    ITransition::TCharSet a;
    foreach (State *state, stateList)
    {        
        foreach(Transition *transition, state->getOutgoingTransitions())
        {
            transition->getCharactersOccurences(a);
        }
    }
    
    DBGLOG_AI("Character occurences: " << a);
    
    // if alphabet is set manually, only alphabetSymbol or epsilonSymbol can be in rest of occurences
    if (!alphabet.isEmpty())
    {
        a -= alphabet;
        DBGLOG_AI("Adepts to alphabet or epsilon symbol: " << a);
    }
    
    // detect alphabet symbol
    if (!a.isEmpty() && alphabetSymbol == "")
    {
        QString aSymb = "";
        foreach(const QString &symb, AutomataCreator::defaultAlphabetSymbList)
        {
            if (a.contains(symb))
            {
                if (aSymb == "")
                {
                    aSymb = symb;
                    a -= symb;
                }
                else if (aSymb != symb)
                {
                    report += "Mismatch in alphabet symbol usage - " + aSymb + ", " + symb + "\n"
                           +  "Please set alphabet symbol manually.\n";
                    break;
                }
            }
        }
        alphabetSymbol = aSymb;
    }
    if (alphabetSymbol == "")
    {
        alphabetSymbol = AutomataCreator::defaultAlphabetSymbList.first();
    }    
    a -= alphabetSymbol; // remove from alphabet (or rest of characters)
    
    DBGLOG_AI("Adepts to epsilon symbol: " << a);
    // detect epsilon symbol
    if (!a.isEmpty() && epsilonSymbol == "")
    {
        QString eSymb = "";
        foreach(const QString &symb, AutomataCreator::defaultEpsilonSymbList)
        {
            if (a.contains(symb))
            {
                if (eSymb == "")
                {
                    eSymb = symb;
                    a -= symb;
                }
                else if (eSymb != symb)
                {
                    report += "Mismatch in epsilon symbol usage - " + eSymb + ", " + symb + "\n"
                           +  "Please set epsilon symbol manually.\n";
                    break;
                }
            }
        }
        epsilonSymbol = eSymb;
    }
    if (epsilonSymbol == "")
    {
        epsilonSymbol = AutomataCreator::defaultEpsilonSymbList.first();
    }
    a -= epsilonSymbol; // remove from alphabet (or rest of characters)
    
    if (alphabet.isEmpty())
    {
        if (a.isEmpty())
        {
            report += "Alphabet detection failed! No symbols found.\n";
        }
        else
        {
            alphabet = a;
        }
    }
    else
    {        
        if (!a.isEmpty())
        {
            RELLOG("Found characters which are unexpected: " << a);
            report += "Unexpected characters found: ";
            int count = 0;
            foreach(const QString &character, a)
            {                
                if (count != 0) report += ", ";
                if (count % 10 == 0)
                {
                    report += "\n\t";
                }
                ++count;
                report += character;
            }
            report += "\n";
        }
    }
    
    // check logic errors
    if (alphabetSymbol == epsilonSymbol ||
        alphabet.contains(alphabetSymbol) ||
        alphabet.contains(epsilonSymbol))
    {
        report += "Automaton settings couldn't be detected correctly, please set it manually.\n";
    }
        
    if (report != "")
    {
        ReportDialog rd(report, this);
        rd.exec();
        return false;
    }    
    
    Q_ASSERT(!alphabet.isEmpty() && alphabetSymbol != "" && epsilonSymbol != ""
             && "Settings detection failed!!!");
    
    return true;
}

#if 0
// TODO: not actual, now each file contains single automaton - this code is depraceted, possible to reuse
//       it when it will be required to detect more automata from single file (single scene)

AutomatonImpl::TAutomatonList Editor::getAutomata(const QList<State*> &stateList,
                                                  ITransition::TCharSet &alphabet,
                                                  QString &alphabetSymbol,
                                                  QString &epsilonSymbol)
{
    // TODO: maybe not written so effective as could be possible, so check performance enhancement
    QScopedPointer<AutomataCreator> creator(new AutomataCreator);
    
    if (alphabet.isEmpty() || alphabetSymbol == "" || epsilonSymbol == "")
    {        
        bool ok = detectAutomataSettings(stateList, alphabet, alphabetSymbol, epsilonSymbol);
    
        if (!ok) return AutomatonImpl::TAutomatonList();
    }
    
    Q_ASSERT(!alphabet.isEmpty());
    if (alphabetSymbol == "") alphabetSymbol = AutomataCreator::defaultAlphabetSymbList[0];
    if (epsilonSymbol == "") epsilonSymbol = AutomataCreator::defaultEpsilonSymbList[0];

    DBGLOG("Automata settings:"     << endl <<
           DBGPAR(alphabet)         << endl <<
           DBGPAR(alphabetSymbol)   << endl <<
           DBGPAR(epsilonSymbol));

// start looking for automata --->
    
    AutomatonImpl::TAutomatonList automataList;
    
    // all inital state in editor
    QList<State*> allInitialStates = getInitialStates(stateList);
    
    QList<State*> currentInitialStates;
    QList<State*> currentFinalStates;
    QList<State*> currentStates;
    QSet<Transition*> currentTransitions;

    QSharedPointer<AutomatonImpl> automaton;
    // starts looking from first inital states, when some other inital state is reached,
    // remove it form allInitialStates (foreclose looking same automaton again)
    while (!allInitialStates.empty())
    {
        State *currentState = allInitialStates.takeFirst();
        currentStates << currentState;
        currentInitialStates << currentState;

        // BFS implementation
        QQueue<State*> openedStates;
        openedStates.enqueue(currentState);        

        while(!openedStates.empty())
        {
            currentState = openedStates.dequeue();
            foreach(Transition *tr, currentState->getOutgoingTransitions())
            {
                currentTransitions << tr;
            }

            foreach(State *newState, currentState->getAccessibleStates())
            {
                if (newState->isInitial()) allInitialStates.removeAll(newState); // belongs to current automaton

                if (currentStates.contains(newState)) continue;
                currentStates << newState;
                
                foreach(Transition *tr, newState->getOutgoingTransitions())
                {
                    currentTransitions << tr;
                }
                
                if (newState->isInitial())
                    currentInitialStates << newState;
                if (newState->isFinal())
                    currentFinalStates << newState;

                if (openedStates.contains(newState)) continue;
                openedStates.enqueue(newState);
            }
        }

        automaton = creator->createPrivateAutomaton(alphabet, alphabetSymbol, epsilonSymbol);
        
        foreach(State *state, currentStates)
        {
            bool ok;
            ok = automaton->addState(
                creator->createPrivateState(state->getName(), state->getLabel(), state->isInitial(), state->isFinal(), state)
            );

            Q_ASSERT(ok && "some problem when adding state!");
        }

        foreach(Transition *transition, currentTransitions)
        {
            bool ok;
            ITransition::TCharSet characters;
            ok = transition->getCharacters(characters, alphabet, alphabetSymbol, epsilonSymbol);

            if (!ok)
            {                
                return AutomatonImpl::TAutomatonList();
            }
            
            ok = automaton->addTransition(
                creator->createPrivateTransition(transition->getStartStateName(),
                                                 transition->getEndStateName(),
                                                 characters,
                                                 transition)
            );

            Q_ASSERT(ok && "some problem when adding transition!");
        }

        DBGLOG("automaton added, consists of:" << endl
               << currentStates.count() << "states" << endl
               << currentInitialStates.count() << "initial states" << endl
               << currentFinalStates.count() << "final states" << endl
               << "alphabet:" << automaton->getAlphabet() << endl
               << "alphabetSymb:" << automaton->getAlphabetSymbol() << endl
               << "epsilonSymb:" << automaton->getEpsilonSymbol());

        automataList << automaton;
        automaton.clear();

        currentInitialStates.clear();
        currentFinalStates.clear();
        currentStates.clear();
        currentTransitions.clear();
    }
    
    return automataList;
}

// TODO: remove or rename to joinAutomata or something similar
QSharedPointer<AutomatonImpl> Editor::getAutomaton(const QList<State*> &stateList,
                                                   ITransition::TCharSet &alphabet,
                                                   QString &alphabetSymbol,
                                                   QString &epsilonSymbol)
{
    AutomatonImpl::TAutomatonList automataList =
        getAutomata(stateList, alphabet, alphabetSymbol, epsilonSymbol);

    if (automataList.empty())
    {
        RELLOG("No automaton found using given states!!!");
        return QSharedPointer<AutomatonImpl>(NULL);
    }

    Q_ASSERT(!alphabet.isEmpty());
    Q_ASSERT(alphabetSymbol != "");
    Q_ASSERT(epsilonSymbol != "");

    if (automataList.count() == 1)
        return automataList[0];

    QScopedPointer<AutomataCreator> creator(new AutomataCreator);

    StateImpl::TStateList states;
    TransitionImpl::TTransitionList transitions;

    foreach(const QSharedPointer<AutomatonImpl> &automaton, automataList)
    {
        states << automaton->getPrivateStates();
        transitions << automaton->getPrivateTransitions();

        // should be set and checked in getAutomata()
        Q_ASSERT(alphabet == automaton->getAlphabet());
        Q_ASSERT(alphabetSymbol == automaton->getAlphabetSymbol());
        Q_ASSERT(epsilonSymbol == automaton->getEpsilonSymbol());
    }

    QSharedPointer<AutomatonImpl> automaton =
        creator->createPrivateAutomaton(alphabet, alphabetSymbol, epsilonSymbol);
    automaton->addLists(states, transitions);

    return automaton;
}

#endif


QSharedPointer<IAutomataCreator> Editor::getAutomataCreator()
{
    return QSharedPointer<IAutomataCreator>(new AutomataCreator());
}

QList<State*> Editor::getInitialStates(const QList<State*> &stateList)
{
    QList<State*> initialStates;
    foreach(State *state, stateList)
    {
        if (state->isInitial())
        {
            initialStates << state;
        }
    }
    return initialStates;
}

QList<State*> Editor::getFinalStates(const QList<State*> &stateList)
{
    QList<State*> finalStates;
    foreach(State *state, stateList)
    {
        if (state->isFinal())
        {
            finalStates << state;
        }
    }
    return finalStates;
}

// TODO: is this good place for such methods?
ITransition::TCharSet Editor::parseCharSet(const QString &text)
{
    StringProcessor::TCharacterList charList = StringProcessor::computeCharacterList(text);
    
    ITransition::TCharSet result;
    
    StringProcessor::TCharacterList::const_iterator charIt = charList.begin();
    while(charIt != charList.end())
    {
        result << charIt->character;
        
        if (++charIt == charList.end()) break;

        if (charIt->character != ",") return ITransition::TCharSet();
        ++charIt;
    }
    
    return result;
}

QString Editor::parseCharacter(const QString &text)
{
    StringProcessor::TCharacterList charList = StringProcessor::computeCharacterList(text);
    if (charList.count() != 1) return QString("");
    
    return charList[0].character;
}

//---------------------------------------------------------------- Editor -->


//<-- UndoView --------------------------------------------------------------

UndoView::UndoView(QUndoStack *stack, QWidget *parent)
: QUndoView(stack, parent)
{
  setMaximumSize(200,600);
  
  QShortcut *closeShortcut = new QShortcut(tr("Ctrl+W"), this);
  connect(closeShortcut, SIGNAL(activated()), this, SLOT(close()));
}

void UndoView::closeEvent(QCloseEvent *event)
{
    if (event->type() == QEvent::Close) emit closed();
}

//-------------------------------------------------------------- UndoView -->
