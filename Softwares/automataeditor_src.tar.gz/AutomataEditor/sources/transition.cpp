#include "constants.h"

#include "mainwindow.h"
#include "editor.h"
#include "transition.h"
#include "state.h"
#include "label.h"
#include "commands.h"
#include "dialogs.h"
#include "transforms.h"
#include "stringProcessor.h"
#include "automataCreator.h"

#include <QGraphicsScene>
#include <QEvent>
#include <QGraphicsSceneMouseEvent>
#include <QFontMetrics>
#include <QLineF>
#include <QPolygonF>
#include <QPointF>
#include <QPainterPath>

#include <QTextStream>

#include <math.h>

#include <QtDebug>

#ifdef PERFORMANCE_MEASUREMENT
#   include <QTime>
float       g_TimeSum = 0;
int         g_TimeIterations = 0;
const int   g_TimeIterationsCount = 100;
#endif

//<-- Transition -------------------------------------------------------------

Transition::Transition(Editor *parent, State *ss, State *es,
                       bool d)
:   editor(parent), startState(ss), endState(es), startPoint(ss->pos()),
    dimmed(d), checked(false),
    checkedColor(QColor(CheckedColor::r, CheckedColor::g, 
                        CheckedColor::b, CheckedColor::a))
{
    setFlag(QGraphicsItem::ItemIsMovable, false);
    setFlag(QGraphicsItem::ItemIsSelectable, true);

    if (endState) // initial/final arrow or transition // TODO: implement this better
    {        
        endPoint = endState->pos();
    }

    // edge adjustable parameters - editor
    edgeLineStyle = editor->edgeLineStyle;
    edgeLineWidth = 1;
    edgeLineColor = editor->edgeLineColor;
    edgeLabelColor = editor->edgeLabelColor;
    edgeLabelScale = 1;
    edgeLineDblStatus = editor->edgeLineDblStatus;

    // transition parametres preset
    edgeLineBorderCoef = editor->edgeLineBorderCoef; //DEF_EDGE_LINE_BORDER_COEF;
    edgeLineBorderColor = editor->edgeLineBorderColor; //DEF_EDGE_LINE_BORDER_COLOR;

    edgeLineDblCoef = editor->edgeLineDblCoef; //DEF_EDGE_LINE_DBL_COEF;
    edgeLineDblSep = editor->edgeLineDblSep; //DEF_EDGE_LINE_DBL_SEP;

    // transition parametres dimmed
    dimEdgeLineStyle = editor->dimEdgeLineStyle; //DEF_DIM_LINE_STYLE;
    dimEdgeLineColor = editor->dimEdgeLineColor; //DEF_DIM_COLOR;
    dimEdgeLineCoef = editor->dimEdgeLineCoef; //DEF_DIM_EDGE_LINE_COEF;
    dimEdgeLabelColor = editor->dimEdgeLabelColor; //DEF_DIM_COLOR;
    
    m_labelFontSize = (int) (EDGE_LABEL_SIZE * edgeLabelScale * editor->edgeLabelScale);
    m_lineWidth = editor->edgeLineWidth * TR_LINE_VIEW_COEF;
    if (dimmed)
        m_lineWidth *= dimEdgeLineCoef;
    else
        m_lineWidth *= edgeLineWidth;

    // set default arrow polygon
    m_arrowPoints << QPointF(0,0); // center

    QLineF arrowLine(QPointF(0,0), QPointF(ARROW_LEN, 0)); // line in arrow direction
    QLineF normArrowLine = arrowLine.normalVector(); // width vector of arrow
    normArrowLine.translate(ARROW_LEN,0); // move width part to end of arrow

    normArrowLine.setLength(ARROW_WIDTH/2);
    m_arrowPoints << normArrowLine.p2(); // top point of arrow

    arrowLine.setLength(ARROW_LEN - 2);
    m_arrowPoints << arrowLine.p2(); // middle point of arrow

    normArrowLine.setLength(-ARROW_WIDTH/2);    
    m_arrowPoints << normArrowLine.p2(); // bottom point of arrow
}

Transition::~Transition()
{
    if (label) delete label;
        
    qDeleteAll(nextLabels.begin(), nextLabels.end());
    nextLabels.clear();

    DBGLOG("Transition::~Transition");
}

QString Transition::getStartStateName() const
{
    Q_ASSERT(startState && "invalid startState!");
    return startState->getName(); 
}
 
QString Transition::getEndStateName() const
{
    Q_ASSERT(getEndState() && "invalid endState!");
    return getEndState()->getName(); // note that trLoop implements own getEndState
}

LabelX *Transition::getLabel() const
{
    return (label) ? label : NULL;
}

QString Transition::getLabelText() const
{
    if (label)
        return label->text();
    else
        return QString("");
}

void Transition::setLabelText(const QString &labelText)
{    
    prepareGeometryChange();
    if (!label) 
    {
        RELLOG("trying to set label text to nonexistent label");
        return;
    }
    
    label->setText(labelText);
    setLabelPosition();    
}

void Transition::setLabelPosition(LabelX *pLabel, float pos, bool isLeft, int width, int height)
{
    Q_ASSERT(pLabel);

    prepareGeometryChange();
    // vector for label position
    QLineF text_v = QLineF(mapToScene(p.pointAtPercent(pos)),mapToScene(p.pointAtPercent(pos+0.1)));
    text_v = text_v.normalVector(); // normal vector to curve
  
    text_v.setLength(isLeft ? TEXT_DISTANCE : -TEXT_DISTANCE); // because of unstable loop orientation    
    
    float label_x, label_y;
    float correct_x, correct_y;
    correct_x = -width/2 + 
                (text_v.x2() - text_v.x1()) / TEXT_DISTANCE * // cos alfa
                width/2;
    correct_y = -height/2 + 
                (text_v.y2() - text_v.y1()) / TEXT_DISTANCE * // sin alfa
                height/2;
    label_x = text_v.x2() + correct_x;
    label_y = text_v.y2() + correct_y;
  
    pLabel->setPos(label_x, label_y);
}

void Transition::setLabelPosition()
{
    for (TLabelXList::Iterator labelIt = nextLabels.begin();
         labelIt != nextLabels.end();
         ++labelIt)
    {
        setLabelPosition(*labelIt, (*labelIt)->posParam(), (*labelIt)->left(),
            (*labelIt)->getWidth(), (*labelIt)->getHeight());
    }
}

void Transition::setLabelPos(float pos)
{
    if (label) label->setPosParam(pos);
}

float Transition::getLabelPos() const
{
    if (label) return label->posParam();
    else return DEF_EDGE_LAB_POS;
}

void Transition::addNextLabel(LabelX *pLabel)
{    
    if (dimmed)
        pLabel->setColor(QColor(dimEdgeLabelColor));
    else
        pLabel->setColor(QColor(edgeLabelColor));
    nextLabels << pLabel;
}

void Transition::removeNextLabel(LabelX *pLabel)
{
    if (!nextLabels.removeOne(pLabel))
        RELLOG("required label was not found!");
}

QPainterPath Transition::createShape(const QPainterPath &path, int bounds) const
{
    QPainterPathStroker pathStroker;
    pathStroker.setWidth(bounds);
    
    QPainterPath strokePath = pathStroker.createStroke(path);    

    strokePath.addPolygon(pa);
    strokePath.closeSubpath();

    if (label && label->text() != "")
    {
        strokePath.addPolygon(mapFromItem(label, label->boundingRect()));
        strokePath.closeSubpath();
    }

    for (TLabelXList::ConstIterator labelIt = nextLabels.begin();
         labelIt != nextLabels.end();
         ++labelIt)
    {
        if ((*labelIt)->text() == "") continue;
        strokePath.addPolygon(mapFromItem((*labelIt), (*labelIt)->boundingRect()));
        strokePath.closeSubpath();
    }

    strokePath.setFillRule(Qt::WindingFill);

    return strokePath;
}

QPainterPath Transition::shape() const
{    
    return getClickPath();
}

QRectF Transition::boundingRect() const
{
    QRectF rect = getClickPath().boundingRect();

    if (label)
        rect |= (mapFromItem(label, label->boundingRect())).boundingRect(); // rect over pathRect and labelRect

    for (TLabelXList::ConstIterator labelIt = nextLabels.begin();
         labelIt != nextLabels.end();
         ++labelIt)
    {
        rect |= (mapFromItem((*labelIt), (*labelIt)->boundingRect())).boundingRect();
    }

    rect |= pa.boundingRect();

    return rect.adjusted(-5,-5,5,5); // rather adjusted for different widths of lines
}

void Transition::paintSelectionDecoration(QPainter *painter)
{
    if (isSelected())
    {
        const QColor selectedColor(SelectedColor::r,SelectedColor::g,
                                   SelectedColor::b, SelectedColor::a);
        painter->setPen(QPen(selectedColor,1,Qt::DashLine));

        painter->strokePath(getSelectionPath(), painter->pen());
    }
}

void Transition::paint (QPainter *painter, const QStyleOptionGraphicsItem * /*option*/, QWidget * /*widget*/)
{
    QColor lineC;
    Qt::PenStyle lineS;

    if (dimmed)
    {
        lineS = dimEdgeLineStyle;
        lineC = dimEdgeLineColor;
    }
    else
    {
        lineS = edgeLineStyle;
        lineC = edgeLineColor;
    }

    if (checked)
    {
        painter->setPen(QPen(checkedColor, m_lineWidth, lineS));
    }
    else
    {
        painter->setPen(QPen(lineC, m_lineWidth, lineS));
    }

    painter->setBrush(Qt::NoBrush);
    painter->strokePath(p, painter->pen());

    // draw arrow
    if (checked)
        painter->setBrush(checkedColor);
    else
        painter->setBrush(lineC);

    painter->drawPolygon(pa); // computed in adjust

    paintSelectionDecoration(painter);

#ifdef TESTING_PAINTING
#   ifdef TESTING_BOUNDING_RECT_PAINTING
        painter->setBrush(QBrush(QColor(50,255,0,100)));
        painter->fillRect(boundingRect(), painter->brush());
#   endif

    painter->setBrush(QBrush(QColor(0,0,255,150)));
    painter->fillPath(shape(), painter->brush());
#endif
}

void Transition::setDimmed(bool dim)
{
    if (dimmed == dim) return; // not necessary

    dimmed = dim;

    if (dimmed)
        m_lineWidth = m_lineWidth * dimEdgeLineCoef/edgeLineWidth;
    else
        m_lineWidth = m_lineWidth * edgeLineWidth/dimEdgeLineCoef;
    
    QColor color = QColor(dimmed ? dimEdgeLabelColor : edgeLabelColor);

    if (label) label->setColor(color);

    for (TLabelXList::ConstIterator labelIt = nextLabels.begin();
         labelIt != nextLabels.end();
         ++labelIt)
    {
        (*labelIt)->setColor(color);
    }

    createStrokes(p);
}

bool Transition::isDimmed()
{
    return dimmed;
}

void Transition::setChecked(bool ch)
{
    checked = ch;    

    QColor color = (ch) ? checkedColor :
        dimmed ? QColor(dimEdgeLabelColor) : QColor(edgeLabelColor);
        
    if (label) label->setColor(color);

    for (TLabelXList::ConstIterator labelIt = nextLabels.begin();
         labelIt != nextLabels.end();
         ++labelIt)
    {
        (*labelIt)->setColor(color);
    }

    update();
}

void Transition::setSelected(bool sel)
{
    if (label && label->text() != "")
    {
        label->setSelected(sel);
    }

    foreach(LabelX *label, nextLabels)
    {
        label->setSelected(sel);
    }

    QGraphicsItem::setSelected(sel);
}

void Transition::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    DBGLOG_ME("called");
    m_lastMouseClickType = eMouseNoClick;
    setChecked();
    if (event->button() == Qt::RightButton)
    {
        m_lastMouseClickType = eMouseRightClick;
    }
}

void Transition::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event)
{
    DBGLOG_ME("Transition::mouseDoubleClickEvent");
    if (event->button() == Qt::LeftButton && editor->getAction() == Editor::eSelection)
    {        
        m_lastMouseClickType = eMouseDoubleClick;
        setChecked();
    }
}

void Transition::setStartState(State *state)
{
    startState = state;
    adjust(); // redraw
}

void Transition::setEndState(State *state)
{
    if (endState)
        endState = state;
    else RELLOG("No endState available!");
    adjust(); // redraw
}

// saving
bool Transition::getVCParams(QTextStream &out, EdgePrevParams &prevParams) const
{
  bool stChanged = false;
  if (!dimmed){
    if (edgeLineStyle != prevParams.edgeLineStyle){
      prevParams.edgeLineStyle = edgeLineStyle;
      stChanged = true;
      if (edgeLineStyle != editor->edgeLineStyle){
        out << endl << "\\ChgEdgeLineStyle{";
        out << trLineStyle(edgeLineStyle);
        out << "}" << endl;
        }
      else{
        out << endl << "\\RstEdgeLineStyle";
      } // if != editor
    } // if
    
    if (edgeLineWidth != prevParams.edgeLineWidth){
      stChanged = true;
      prevParams.edgeLineWidth = edgeLineWidth;
      if (edgeLineWidth != 1)
        out << endl << "\\ChgEdgeLineWidth{" << edgeLineWidth << "}"; 
      else
        out << endl << "\\RstEdgeLineWidth";
    } // if
    
    if (edgeLineColor != prevParams.edgeLineColor){
      stChanged = true;
      prevParams.edgeLineColor = edgeLineColor;
      if (edgeLineColor != editor->edgeLineColor)
        out << endl << "\\ChgEdgeLineColor{" << edgeLineColor.toLower() << "}"; 
      else
        out << endl << "\\RstEdgeLineColor";
    } // if
    
    if (edgeLabelColor != prevParams.edgeLabelColor){
      stChanged = true;
      prevParams.edgeLabelColor = edgeLabelColor;
      if (edgeLabelColor != editor->edgeLabelColor)
        out << endl << "\\ChgEdgeLabelColor{" << edgeLabelColor.toLower() << "}"; 
      else
        out << endl << "\\RstEdgeLabelColor";
    } // if
    
    if (edgeLabelScale != prevParams.edgeLabelScale){
      stChanged = true;
      prevParams.edgeLabelScale = edgeLabelScale;
      if (edgeLabelScale != 1)
        out << endl << "\\ChgEdgeLabelScale{" << edgeLabelScale << "}";
      else
        out << endl << "\\RstEdgeLabelScale";
    } // if
    
    if (edgeLineDblStatus != prevParams.edgeLineDblStatus){
      stChanged = true;
      prevParams.edgeLineDblStatus = edgeLineDblStatus;
      out << endl << (edgeLineDblStatus ? "\\EdgeLineDouble" : "\\EdgeLineSimple"); 
    } // if
  } // if (!dimmed)
  else{
    if (dimEdgeLineStyle != prevParams.dimEdgeLineStyle ||
        dimEdgeLineColor != prevParams.dimEdgeLineColor ||
        dimEdgeLineCoef != prevParams.dimEdgeLineCoef ||
        dimEdgeLabelColor != prevParams.dimEdgeLabelColor ){
      stChanged = true;
      prevParams.dimEdgeLineStyle = dimEdgeLineStyle;
      prevParams.dimEdgeLineColor = dimEdgeLineColor;
      prevParams.dimEdgeLineCoef = dimEdgeLineCoef;
      prevParams.dimEdgeLabelColor = dimEdgeLabelColor;
      out << endl <<"\\FixDimEdge{" << trLineStyle(dimEdgeLineStyle) << "}"
                                 "{" << dimEdgeLineCoef << "}" // TODO: compare with manual (probably bad there)!
                                 "{" << dimEdgeLineColor.toLower() << "}"
                                 "{" << dimEdgeLabelColor.toLower() << "}";
    } // if
  } // if dimmed
  if (edgeLineDblStatus){
    if (edgeLineBorderCoef != prevParams.edgeLineBorderCoef ||
        edgeLineBorderColor != prevParams.edgeLineBorderColor){
      stChanged = true;
      prevParams.edgeLineBorderCoef = edgeLineBorderCoef;
      prevParams.edgeLineBorderColor = edgeLineBorderColor;
      out << endl << "\\FixEdgeBorder{" << edgeLineBorderCoef << "}"
                                    "{" << edgeLineBorderColor.toLower() << "}"; 
    } // if
    
    if (edgeLineDblCoef != prevParams.edgeLineDblCoef ||
        edgeLineDblSep != prevParams.edgeLineDblSep){
      stChanged = true;
      prevParams.edgeLineDblCoef = edgeLineDblCoef;
      prevParams.edgeLineDblSep = edgeLineDblSep;
      out << endl << "\\FixEdgeLineDouble{" << edgeLineDblCoef << "}"
                                        "{" << edgeLineDblSep << "}"; 
    } // if
  } // if edgeLineDblStatus
  
  if (stChanged) out << endl;
  
  return stChanged;
}

QString Transition::getNextLabelsVCCommand() const
{
    QString command = "";

    // if some next labels, store them
    int sbs_counter = 0;
    for(TLabelXList::ConstIterator labelIt = nextLabels.begin();
        labelIt != nextLabels.end();
        ++labelIt)
    {      
        command += (sbs_counter % SBS_LABELS) ? " " : "\n";
        command += "\\Label";
        command += (*labelIt)->left() ? "L" : "R";
      
        if ((*labelIt)->posParam() != DEF_EDGE_LAB_POS) 
            command += "[" + QString("%1").arg((*labelIt)->posParam()) + "]";
      
        command += "{" + (*labelIt)->text() + "}";
        sbs_counter++;
    }
    if (!nextLabels.isEmpty()) command += "\n";
    return command;
}

// not necessary more -> QPainterPathStroker used instead
/*void Transition::makeAreas(const QPainterPath &p)
{   
#if QT_VERSION < 0x040600
    // insert increased area for clicking
    QPolygonF pf1, pf2;

    if (p.elementCount() < 2) return;

    QPointF startP = p.pointAtPercent(0);
    QPointF endP = p.pointAtPercent(1);

    QLineF angleLine(startP, endP);
    qreal angle = angleLine.angle() * M_PI/180;

    // make polygon form path   
    pf1 = p.toFillPolygon();
    pf2 = p.toReversed().toFillPolygon();
    

    QPolygonF selPol1(pf1);
    selPol1.translate(-SELECTION_BOUNDS*sin(angle),-SELECTION_BOUNDS*cos(angle));
    QPolygonF selPol2(pf2);
    selPol2.translate(SELECTION_BOUNDS*sin(angle),SELECTION_BOUNDS*cos(angle));

    pf1.translate(-CLICK_BOUNDS*sin(angle),-CLICK_BOUNDS*cos(angle)); // increase area
    pf2.translate(CLICK_BOUNDS*sin(angle),CLICK_BOUNDS*cos(angle));        

    Q_ASSERT(!selPol1.empty());
    Q_ASSERT(!selPol2.empty());

    Q_ASSERT(!pf1.empty());
    Q_ASSERT(!pf2.empty());

    selPol1.pop_back();
    selPol2.pop_back();
    selPol1 << selPol2;

    m_selectionArea = selPol1;

    pf1.pop_back(); // last point is automaticly joined to first point, so erase
    pf2.pop_back();
    pf1 << pf2;
         
    m_clickArea = pf1;
#else
    if (p.elementCount() < 2)
        return;   
    
    QPointF startP = p.pointAtPercent(0);
    QPointF endP = p.pointAtPercent(1);

    QLineF angleLine(startP, endP);
    qreal angle = angleLine.angle() * M_PI/180;    

    //! create paths translated according to angle, distance between original and 
    //! translated path is CLICK_BOUNDS
    QPainterPath pClick1(p.translated(CLICK_BOUNDS*sin(angle), CLICK_BOUNDS*cos(angle)));
    QPainterPath pClick2(p.translated(-CLICK_BOUNDS*sin(angle), -CLICK_BOUNDS*cos(angle)));
    
    QPainterPath pSel1(p.translated(SELECTION_BOUNDS*sin(angle), SELECTION_BOUNDS*cos(angle)));
    QPainterPath pSel2(p.translated(-SELECTION_BOUNDS*sin(angle), -SELECTION_BOUNDS*cos(angle)));    

    //! create one closed path
    pClick1.connectPath(pClick2.toReversed());
    m_clickArea = pClick1.toFillPolygon();
    
    pSel1.connectPath(pSel2.toReversed());
    m_selectionArea = pSel1.toFillPolygon();
#endif
}*/

void Transition::createStrokes(const QPainterPath &path)
{
#ifdef MEASURE_CREATE_STROKES 
    QTime timer;
    timer.start();
#endif

#if 1
    m_clickPath = createShape(path, ((int)m_lineWidth < CLICK_BOUNDS*2) ? CLICK_BOUNDS*2 : (int)m_lineWidth);
    m_selectionPath = createShape(path, (int) m_lineWidth + SELECTION_BOUNDS);
#else
    if (p.elementCount() < 2)
        return;   
    
    QPointF startP = p.pointAtPercent(0);
    QPointF endP = p.pointAtPercent(1);

    QLineF angleLine(startP, endP);
    qreal angle = angleLine.angle() * M_PI/180;    

    //! create paths translated according to angle, distance between original and 
    //! translated path is CLICK_BOUNDS
    QPainterPath pClick1(p.translated(CLICK_BOUNDS*sin(angle), CLICK_BOUNDS*cos(angle)));
    QPainterPath pClick2(p.translated(-CLICK_BOUNDS*sin(angle), -CLICK_BOUNDS*cos(angle)));
    
    QPainterPath pSel1(p.translated(SELECTION_BOUNDS*sin(angle), SELECTION_BOUNDS*cos(angle)));
    QPainterPath pSel2(p.translated(-SELECTION_BOUNDS*sin(angle), -SELECTION_BOUNDS*cos(angle)));    

    //! create one closed path
    pClick1.connectPath(pClick2.toReversed());
    m_clickPath = pClick1;
    
    pSel1.connectPath(pSel2.toReversed());
    m_selectionPath = pSel1;
#endif

#ifdef MEASURE_CREATE_STROKES
    g_TimeSum += timer.elapsed();
    g_TimeIterations++;
    if (g_TimeIterations == g_TimeIterationsCount)
    {
        RELLOG("PM:" << "takes" << g_TimeSum << "ms on" << g_TimeIterationsCount << "iterations");
        g_TimeIterations = 0;
        g_TimeSum = 0;
    }
#endif
}

const QPainterPath& Transition::getClickPath() const
{
    return m_clickPath;
}

const QPainterPath& Transition::getSelectionPath() const
{
    return m_selectionPath;
}

QPolygonF Transition::getArrowPolygon(const QPainterPath &path)
{
    QPointF p1 = path.pointAtPercent(1);
    QPointF p2 = path.pointAtPercent(path.percentAtLength(path.length()-ARROW_LEN));
    QLineF arrowAngleLine(p1, p2);
    qreal angle = arrowAngleLine.angle();

    QMatrix matrix;
    matrix.rotate(-angle); 
    QPolygonF arrowPoints = matrix.map(m_arrowPoints); // rotate default arrowPoints to right angle

    arrowPoints.translate(path.pointAtPercent(1)); // move arrow to right position

    return arrowPoints;
}

QPolygonF Transition::findIntersectedPoints(const QPolygonF &curve, const QPolygonF &polygon, 
                                             const Transition::EIntersectionFindMethod method)
{
    QPolygonF intersectedPoints;

    if (curve.size() < 2 || polygon.size() < 2)
    {
        Q_ASSERT(0 && "bad polygon given");
        RELLOG("bad polygons given (small size) !!!");
        return intersectedPoints;
    }

    QLineF curveLine, polyLine;
    QPointF intersectedPoint, tmpPoint;
    QPolygonF::ConstIterator curveIt1 = curve.end()-1; 
    QPolygonF::ConstIterator curveIt2 = curve.end()-2; // from endState
    QPolygonF::ConstIterator polyIt;

    int found = 0;       

    while (curveIt2 >= curve.begin())
    {        
        curveLine.setPoints(*curveIt1, *curveIt2);

        polyIt = polygon.begin();
        polyLine.setP2(*polyIt++);
        
        while (polyIt < polygon.end())
        {
            polyLine.setP1(polyLine.p2());
            polyLine.setP2(*polyIt++);

            if (polyLine.intersect(curveLine, &intersectedPoint) == QLineF::BoundedIntersection)
            {
                tmpPoint = intersectedPoint;
                curveIt1--;
                
                while (curveIt1 > curveIt2) // find more exact point
                {
                    curveLine.setPoints(*curveIt1--, *curveIt2);
                    if (polyLine.intersect(curveLine, &intersectedPoint) == QLineF::BoundedIntersection)
                    {
                        tmpPoint = intersectedPoint;
                    }
                }
                
                // add only new point!
                if (intersectedPoints.empty() || intersectedPoints.last() != tmpPoint)
                {
                    intersectedPoints << tmpPoint;
                    found++;
                    
                    if (method == eFIND_FIRST ||
                        (method == eFIND_TWO && found == 2))
                        break;
                }
            }
        }

        if ((method == eFIND_FIRST && found == 1) ||
            (method == eFIND_TWO && found == 2))        
            break;

        curveIt2--;
    }

    if (found == 0)
        DBGLOG("no intersected point found");

#ifdef TESTING_ARROW_POINTS
    DBGLOG(DBGPAR(intersectedPoints));
#endif

    return intersectedPoints;
}

void Transition::setEdgeLabelScale(float labelScale)
{
    if (edgeLabelScale == labelScale) return;

    prepareGeometryChange();

    m_labelFontSize = (int) (m_labelFontSize * labelScale/edgeLabelScale);
    edgeLabelScale = labelScale;
    if (label)
    {
        label->setFontSize(m_labelFontSize);
    }
    for (TLabelXList::Iterator labelIt = nextLabels.begin();
         labelIt != nextLabels.end();
         ++labelIt)
    {
        (*labelIt)->setFontSize(m_labelFontSize);
    }

    setLabelPosition(); // virtual method -> right one should be called
}

void Transition::setEdgeLineWidth(float lineWidth)
{
    if (edgeLineWidth == lineWidth) return;

    prepareGeometryChange();

    if (!dimmed)
        m_lineWidth = m_lineWidth * lineWidth/edgeLineWidth;
    edgeLineWidth = lineWidth;
    
    if (!dimmed)
        createStrokes(p);
    // TODO: set label position according to line width
}

void Transition::setDimEdgeLineCoef(float lineCoef)
{
    if (dimEdgeLineCoef == lineCoef) return;

    prepareGeometryChange();
    
    if (dimmed)
        m_lineWidth = m_lineWidth * lineCoef/dimEdgeLineCoef;
    dimEdgeLineCoef = lineCoef;

    if (dimmed)
        createStrokes(p);
}

// ITransition support implementation -->

QString Transition::getSourceState() const
{
    return getStartStateName();
}

QString Transition::getDestinationState() const
{
    // note that this method should be never called on Initial or Final transition
    return getEndStateName();
}

void Transition::showErrorReport(const QString &reportText) const
{
    QString report = "Incorrect transition definition (transition between states \""
                   + getSourceState() + "\" and \"" + getDestinationState() + "\")<br>"
                   + reportText;
    ReportDialog rd(report, editor);
    rd.exec();
}

bool Transition::getCharacters(ITransition::TCharSet &characters,
                               const ITransition::TCharSet &alphabet,
                               const QString &alphabetSymbol,
                               const QString &epsilonSymbol) const
{
    LabelSyntaxChecker syntaxChecker(alphabet, alphabetSymbol, epsilonSymbol);
    bool empty = true;
    
    if (label)
    {
        if (!syntaxChecker.checkSyntax(label->getCharacterList()))
        {
            showErrorReport(syntaxChecker.getReport());
            return false;
        }
        
        characters |= syntaxChecker.getCharacters();
        empty = empty && (syntaxChecker.getPattern() == LabelSyntaxChecker::eEmptyPattern);
    }
    
    for(TLabelXList::ConstIterator labelIt = nextLabels.begin();
        labelIt != nextLabels.end();
        ++labelIt)
    {
        if (!syntaxChecker.checkSyntax((*labelIt)->getCharacterList()))
        {
            showErrorReport(syntaxChecker.getReport());
            return false;
        }
        
        characters |= syntaxChecker.getCharacters();
        empty = empty || (syntaxChecker.getPattern() == LabelSyntaxChecker::eEmptyPattern);
    }
    
    if (empty) // all labels are EMPTY
    {
        showErrorReport("No symbols for transition.");
        return false;
    }
    
    return true;
}

void Transition::getCharactersOccurences(ITransition::TCharSet &characters) const
{
    QStringList occurences;
    
    if (label)
    {
        occurences = label->getCharacters(); 
        dismemberCharacters(occurences, characters);                             
    }
    
    for(TLabelXList::ConstIterator labelIt = nextLabels.begin();
        labelIt != nextLabels.end();
        ++labelIt)
    {
        occurences = (*labelIt)->getCharacters();
        dismemberCharacters(occurences, characters);
    }
}

void Transition::dismemberCharacters(const QStringList &occurences,
                                     ITransition::TCharSet &characters) const
{
    foreach(const QString &character, occurences)
    {
        // special symbols // TODO: solve better
        if (character == "," || character == "-" || character == "\\{" || character == "\\}") continue;
        
        characters << character;
    }
}


