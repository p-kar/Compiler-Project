#ifndef EDITOR_H_1321657634484
#define EDITOR_H_1321657634484

#include <QList>
#include <QVector>
#include <QGraphicsView>
#include <QUndoView>

#include "iautomaton.h"
#include "automataCreator.h"

class IAlgorithm;

class QGraphicsScene;
class MainWindow;
class QGraphicsLineItem;
class QGraphicsSimpleTextItem;
class QMenu;
class State;
class Transition;
class LabelX;
class QUndoStack;
class QUndoCommand;
class UndoView;
class QSpinBox;
class QComboBox;
class QLineEdit;
class QCheckBox;
class QRubberBand; //!< used for selection implementation

class OneStateTransition;
class TwoStatesTransition;
class TranstionSerializer;

struct StatePrevParams;
struct EdgePrevParams;

class IDrawAlgorithm;
class IGraphViz;

// logging enabled/disabled
#ifdef TESTING_ADDING
#   define DBGLOG_ADD(x) DBGLOG_("ADDING", x)
#else
#   define DBGLOG_ADD(x)
#endif

#ifdef TESTING_MOUSE_EVENTS
#   define DBGLOG_ME(x) DBGLOG_("MOUSEEVENTS", x)
#else
#   define DBGLOG_ME(x)
#endif

enum EMouseClick {eMouseNoClick, eMouseLeftClick, eMouseRightClick, eMouseDoubleClick, eMouseMiddleClick, 
                  eMouseLeftShiftClick, eMouseMove};

class Editor : public QGraphicsView
{
  Q_OBJECT
public:
//types
    typedef QMap<QString, State*>   TStateMap;
    typedef QList<State*>           TStateList;
    typedef QList<Transition*>      TTransitionList;

    enum Format {vcg, tex, gml, eps, svg, png, bmp, xpm};

    Editor(MainWindow *parent = 0);
    ~Editor();

    friend class Parser;
    friend class StateStyleDialog;
    friend class StateStyleChangeCommand;
    friend class TransitionStyleDialog;
    friend class TransitionStyleChangeCommand;
    friend class NextLabelsDialog;
    friend struct StateSerializer;
    friend struct TransitionSerializer;

    QRect getGridRect();                        //!< grid coordinates
    void setGridRect(QRect gridRect);           //!< sets new grid rect coordinates
    QPointF mapToGrid(const QPointF& scenePos); //!< maps scene positon to grid position

    int getBorder() { return sceneBorder; }
    void setBorder(int b) { sceneBorder = b; }

    //! determinec selected action in editor,
    //! possible to do all actions in eSelection mode (eSelection is default mode)
    enum EAction {eSelection, eInsertState, eInsertTransition};
    //! holds current mouse aciton, affected by accelerators (CTRL, SHIFT) and by which mouse button is pressed
    enum EMouseAction {eNoMouseAction, eMoveItem, eMoveMultItem,
                       eInsertItem, eSelectItem, eSelectMultipleItems, 
                       eShowPopup, eShowSelectionPopup};

    void setAction(EAction action);
    EAction getAction() {return m_selectedAction;}
    void setSelectedState(State *state);
    void setSelectedTransition(Transition *transition) {selectedTransition = transition;}

    bool snapped() {return snapToGrid;} //!< \retval true if automatic snapping is used

    //! \retval false if element was deleted!
    bool showPopup(State *state);
    void showPopup(OneStateTransition *transition, const QPointF &point);
    void showPopup(TwoStatesTransition *transition, const QPointF &point);
    void insertTransition();

    void slotSnapToGrid();
    void slotAlignToGrid();

    void setShowGridFrame(bool grid, bool frame);
 
    void newFile();
    void openFile(const QString &fn);
    //! \name Exporting methods
    //! \{
    void exportToVaucanson(const QString &fn, bool additionals = 0);
    void exportToGraphML(const QString &fn = 0);
    void exportToEPS(const QString &fn);
#ifndef DONT_USE_SVG_MODULE
    void exportToSVG(const QString& fn);
#endif
    //void exportToEPS2(const QString &fn);
    void exportToPixmap(const QString &fn, Format f);

    void saveToFile(const QString &fn, bool latexHeader = false);
    void saveLaTeXHeader(QTextStream &out);
    void saveHeader(QTextStream &out);
    void saveVCSettings(QTextStream &out);
    void saveGraph(QTextStream &out);
    void saveFooter(QTextStream &out);
    void saveLaTeXFooter(QTextStream &out);
    //! \}

    IAutomaton::TAutomataList loadAutomata(const QString &dialogTitle, int count,
                                           QStringList &fileNames,
                                           IAlgorithm *algorithm = NULL);

    void setStatePrevParamsDef(StatePrevParams &prevParams);
    void setTrPrevParamsDef(EdgePrevParams &prevTrParams);

    void removeFromListsAndScene(Transition *transition);
    void removeFromListsAndScene(State *state);
    void removeFromListAndScene(Transition *transition);
    void removeFromListAndScene(LabelX *pLabel);
    void addToListsAndScene(Transition *transition);
    void addToListsAndScene(State *state);
    void addToListAndScene(Transition *transition);
    void addToListAndScene(LabelX *pLabel);

    void renameState(State *state, const QString &name);

    void setStatusBar(const QString &text, int ms);

    void update();
    void removeTransition(Transition *transition); // for undo and redo

    void setFileName(const QString &fn);
    inline QString getFileName() const { return fileName; }
    inline bool isAddition() const { return addition; }
    inline bool isSaved() const { return saved; }

    bool isChanged() const; //!< returns m_undoStack's clean state

    bool isSomethingSelected();
    bool isPastePossible();

    template<typename T>
    bool itemsAlignToGrid(QList<T*> items)
    {
        bool ret = false;
        foreach(T *item, items)
        {
            ret |= itemAlignToGrid(item);
        }
        return ret;
    }
    
    bool itemAlignToGrid(QGraphicsItem* item);

    QString getUniqueAutoName();
    bool testStateName(const QString &s);

    //! returns algorithm index
    int addAlgorithm(const QSharedPointer<IAlgorithm> &algorithm);

    //! add GraphVizDrawAlgorithm which uses given GraphViz Wrapper plugin
    void addGraphVizDrawAlgorithm(IGraphViz *graphVizWrapper);

    QList<State*> getStateList()
    {
        // TODO: return states in the same order as were loaded?
        return m_stateMap.values();
    }
    
    QList<Transition*> getTransitionList()
    {
        return m_transitionList;
    }

    //! converts \param gridPoc to scene position
    QPoint toScenePos(const QPointF &gridPos);

    //! returns state instance from \param stateMap accorgin to given \param name
    //! \retval NULL if no state has \param name
    State* getStateByName(const TStateMap &stateMap, const QString &name) const;

    //! \name state parameters adjustable
    //! \{
    Qt::PenStyle stateLineStyle;
    float stateLineWidth;
    QString stateLineColor;
    QString stateLabelColor;
    float stateLabelScale;
    Qt::BrushStyle stateFillStatus;
    QString stateFillColor;
    //! \}
    //! \name state parameters preset
    //! \{
    Qt::PenStyle dimStateLineStyle;
    QString dimStateLineColor;
    float dimStateLineCoef;
    QString dimStateLabelColor;
    QString dimStateFillColor;
    //! \}
    //! \name state parameters double
    //! \{
    float stateLineDoubleCoef;
    float stateLineDoubleSep;
    //! \}

    //! \name edge parameters adjustable
    //! \{
    Qt::PenStyle edgeLineStyle;
    float edgeLineWidth;
    QString edgeLineColor;
    QString edgeLabelColor;
    float edgeLabelScale;
    bool edgeLineDblStatus;
    //! \}
    //! \name transition parameters dimmed
    //! \{
    Qt::PenStyle dimEdgeLineStyle;
    QString dimEdgeLineColor;
    float dimEdgeLineCoef;
    QString dimEdgeLabelColor;
    //! \}
    //! \name transition parameters border
    //! \{
    float edgeLineBorderCoef;
    QString edgeLineBorderColor;
    //! \}
    //! \name transition parameters double
    //! \{
    float edgeLineDblCoef;
    float edgeLineDblSep;
    //! \}

public slots:
    void showGridRectDialog();
    void stateMoved(State *state, const QPointF &oldPos); // pro undo a redo na move
    void undo();
    void redo();
    void showUndoView(bool show);
    void zoomIn();
    void zoomOut();
    void resetZoom();

    void moveState();
    void cutState();
    void copyState();
    void copySelection();

    void paste();
    void paste(const QPoint &insertPoint);

    void cutSelection();
    void removeSelection();

    //! \name editing methods
    //! \{
    void editState(State *state);
    void editTransition(OneStateTransition *tr);
    void editTransition(TwoStatesTransition *tr);
    void editStateStyleParams();
    void editTransitionStyleParams();
    //! \}

    //! \name extra functions
    //! \{
    void switchAntialiasing();
    void generateGraph();
    void createLaTeXTable();
    //! \}

    //! expands grid according to items bounding box
    //! \param bound keeps free space around items
    void expandGrid(int bound = 0);

    //! sender() is QAction and its data is set as index to algorithmList
    void runAlgorithm();
    
    //! runs SimulationDialog
    void simulateAutomatonWork();    

    void canUndoChangedSlot(bool can);    
    void canRedoChangedSlot(bool can);

    void slotShowGrid(bool show);
    void slotShowFrame(bool show);

signals:
    bool canUndoChanged(bool can);
    bool canRedoChanged(bool can);
    bool canOpenFile(bool can);
    bool canNewFile(bool can);
    bool canSaveFile(bool can);
    
    bool itemsAvailable(bool available);
    bool toolsAvailable(bool available);
    bool utilsAvailable(bool available);
    bool showUndoStackAvailable(bool available);
    
    void isChanged(bool changed);

    void undoViewClosed();
    void showChanged(bool showG, bool showF);
    bool canZoomIn(bool can);
    bool canZoomOut(bool can);
    void actionChanged(int action);
  
protected:
    void setRightSceneRect();
    void resizeEvent(QResizeEvent *event);          //!< holds background large enought (according to scene)
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    
    void mouseDoubleClickEvent(QMouseEvent *event);

    void setActionCursor(EAction action);
    void setActionInternal(EAction action);

    void wheelEvent(QWheelEvent *event);
    void scaleView(qreal scaleFactor);

    //! retunrs expanded gridRect in a way that all states will be in grid with given boundary (int grid coordinates)
    QRect getExpandedGridRect(const TStateList &states, int bound);

    //! sets metu items enabled/disabled as necessary
    void updateMenuState();

    //! paints grid and labels, if required
    void drawBackground(QPainter *painter, const QRectF &rect);

    QList<State *> generateExactMatching(QString string, QPoint startPoint);
    QList<State *> generateDistance(int typ, QString string, int distance, QPoint startPoint);

    void addToUndoStack(QUndoCommand *command);

    QRectF getPrintRect();
    
    int getNewStateNumber() { return newStateNumber; }  // autonaming functions
    void increaseNewStateNumber() { newStateNumber++; }

    void itemsInvertSelection(QList<QGraphicsItem* > items);

    QString getUniqueAutoName(const TStateMap &stateMap);
    bool testStateName(const QString &s, const TStateMap &stateMap);

    // interface support
    QList<State *> getInitialStates(const QList<State*> &stateList);
    QList<State *> getFinalStates(const QList<State*> &stateList);

    //! loads single automaton from current file for actions with automaton
    //! (use when don't want to modify automaton)
    QSharedPointer<AutomatonImpl> loadAutomaton(const QString &dialogTitle);

    QStringList getDrawAlgorithms() const;

private slots:
    void setClean(bool clean); //!< sets mainwindow head according to m_undoStack clean state

    void removeTransition();
    void editState();
    void removeState();
    void editOneStateTransition();
    void editTwoStatesTransition();
    void editStateParams();
    void editTransitionParams();
    void editNextLabels();
    void pasteOnPos();
    
    void simulationFinished();
    void setStatesMarked(QList<State*> states, bool marked);

    /*!
     * due to performance -> only sets up internal flag m_sceneChanged
     * when scene signal changed() is emited -> don't forget connect it!
     */
    void sceneChanged(const QList<QRectF> &rects);

protected:
    MainWindow *mw;         //!< parent window, for display messages with statusBar()
    int sceneBorder;

    QPoint br;              //!< bottomRight -> scene usage
    QRect gridRect;         //!< VauCanSon-G grid metrics

    State *startState;              //!< for inserting transitions
    State *selectedState;           //!< for operations on states
    Transition *selectedTransition; //!< for operations on transitions

    void insertState(const QPoint &point);    
    State* getStateByName(const QString &name) const
    {
        return getStateByName(m_stateMap, name);
    }

    //! used by parser
    State* insertState(State *state);

    EAction         m_selectedAction;       //!< holds selected editor tool
    EMouseAction    m_currentMouseAction;   //!< holds current mouse action

    int newStateNumber;                     //!< automatic naming as Q1, Q2, ...

    TStateMap           m_stateMap;
    TTransitionList     m_transitionList;

    bool snapToGrid;
    bool showGrid;
    bool showFrame;

    QUndoStack      *m_undoStack;           //!< undo, redo functionality \sa Qt Undo Framework
    UndoView        *m_undoView;            //!< allows to show m_undoStack and operate on it
    void createUndoView();

    //! \name popup menu
    //! \{
    QMenu   *popup;
    QAction *popupPasteHere;

    QMenu   *popupSelection;

    QMenu   *popupState;
    QAction *popupStateLabel;
    
    QMenu   *popupTransition;
    QAction *popupTransitionLabel;
    
    QAction *popupTransitionEdit;
    QAction *popupOneStateTransitionEdit;
    QAction *popupTwoStatesTransitionEdit;

    QPoint  m_popupPoint;
    //! \}

    bool antial;    //!< true if scene is rendered in anialiasing mode

    //! \name save
    //! \{
    QString fileName;
    bool saved;
    bool addition;
    //! \}
    
    QRubberBand         *m_rubberBand;      //!< determines current selection
    QPoint              m_rubberBandOrigin; //!< rubberBand origin point (stored on press event)

    EMouseClick         m_lastMouseAction;  //!< remembers last mouse action
    QPointF             m_origPos;          //!< original mouse position for moving with multiple states
    QVector<QPointF>    m_origPositions;    //!< original positions of selected items before moving them
    bool                m_itemsMoved;       //!< for performance -> no undo command needed if nothing is moved

    //! special selected state of editor, state is moved by mouse move, click to release this mode
    bool                m_stateIsMoving;

    //! performance flag for better handling mouse release event -> if scene has been changed,
    //! view's sceneRect should be updated
    bool                m_sceneChanged;
    
    bool                m_simulationIsRun; //!< if simulation is running, no operations with object on scene are available

    qreal m_zoomInFactor; //!< zoomOutFactor = 1/m_zoomInFactor;

    typedef QList<QSharedPointer<IAlgorithm> >      TAlgorithmList;
    TAlgorithmList  m_algorithmList;            //!< holds list of available algorithms

    typedef QList<QSharedPointer<IDrawAlgorithm> >  TDrawAlgorithmList;
    TDrawAlgorithmList  m_drawAlgorithmList;    //!< holds drawing algorithms
    int                 m_currentDrawAlgorithm; //!< index of lastly used drawing algorithm
    
public:	
    QSharedPointer<IAutomataCreator>    getAutomataCreator();           //!< returns public automata creator
        
    static ITransition::TCharSet   parseCharSet(const QString &text);   //!< primarilly used for parse alphabet
    static QString                 parseCharacter(const QString &text); //!< ensures that given text contains just one symbol
        
protected:

    //! Parse one automaton from whole scene.
    //! Uses getAutomata() and then join parsed automata.
    //! Can detect automata setting if needed.
    QSharedPointer<AutomatonImpl> getAutomaton(const TStateList &stateList,
                                               ITransition::TCharSet &alphabet,
                                               QString &alphabetSymbol,
                                               QString &epsilonSymbol);

#if 0
    //! Parse automata on scene, each subgraph as automaton.
    //! Can detect automata setting if needed.
    AutomatonImpl::TAutomatonList getAutomata(const QList<State*> &stateList,
                                              ITransition::TCharSet &alphabet,
                                              QString &alphabetSymbol,
                                              QString &epsilonSymbol);
                                              
    IAutomaton::TAutomataList getIAutomata(const QList<State*> &stateList,
                                           ITransition::TCharSet &alphabet,
                                           QString &alphabetSymbol,
                                           QString &epsilonSymbol);
#endif

    //! Detects parameters of automata on scene.
    //! \sa Transition::getCharactersOccureces().
    bool detectAutomataSettings(const QList<State *> &stateList, // in
                                ITransition::TCharSet &alphabet, // out
                                QString &alphabetSymbol, // out
                                QString &epsilonSymbol); // out    
    
    //! Should be used only if algorithm does positioning
    //! \sa IAutomaton::hasPositions()
    QList<State*> createGraphicsItems(const QSharedPointer<IAutomaton> &automaton);
};


/*!
 * Allows to show undo stack and provides operations on it.
 */
class UndoView : public QUndoView
{
    Q_OBJECT
public:
    UndoView(QUndoStack *stack, QWidget *parent = 0);

protected:
    void closeEvent(QCloseEvent *event);
    
signals:
    void closed();
};

#endif
