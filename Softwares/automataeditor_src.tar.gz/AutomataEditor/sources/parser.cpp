#include "constants.h"

#include "parser.h"
#include "editor.h"
#include "dialogs.h"
#include "state.h"
#include "stateManager.h"
#include "label.h"
#include "transition.h"
#include "oneStateTransition.h"
#include "twoStatesTransition.h"
#include "transitionManager.h"
#include "transforms.h"

#include <QFile>
#include <QMessageBox>
#include <QApplication>
#include <QRect>

#include <QTextEdit> // due to report dialog
#include <QVBoxLayout>
#include <QPushButton>

#include <QtDebug>

// exceptions
enum Exceptions{U_EOI, U_TOKEN, NO_STATE, STATE_EXIST, BAD_STATE_NAME, BAD_GRID, U_ERR};

// TODO: check situation when something as "\textstyle aaa" is in label field, 
//       it seems that space between is currently dropped!!!

using namespace VaucansonKeywords;

//<-- LexAn ---------------------------------------------------------------------------

#define ADD_KEYWORD(keyword, token) keywordMap[keyword] = token

LexAn::TKeywordMap LexAn::keywordMap;

void LexAn::initialize()
{
    if (keywordMap.contains("begin"))
        return;
    
    ADD_KEYWORD("VCPut", kwVCPut);
    ADD_KEYWORD("begin", kwBegin);
    ADD_KEYWORD("end",kwEnd);
    ADD_KEYWORD("State",kwState);
    ADD_KEYWORD("FinalState",kwFinalState);
    ADD_KEYWORD("StateVar", kwStateVar);
    ADD_KEYWORD("FinalStateVar", kwFinalStateVar);
    ADD_KEYWORD("Initial", kwInitial);
    ADD_KEYWORD("Final", kwFinal);
    ADD_KEYWORD("LoopN", kwLoopN);
    ADD_KEYWORD("LoopS", kwLoopS);
    ADD_KEYWORD("LoopE", kwLoopE);
    ADD_KEYWORD("LoopW", kwLoopW);
    ADD_KEYWORD("LoopNE", kwLoopNE);
    ADD_KEYWORD("LoopNW", kwLoopNW);
    ADD_KEYWORD("LoopSE", kwLoopSE);
    ADD_KEYWORD("LoopSW", kwLoopSW);
    ADD_KEYWORD("CLoopN", kwCLoopN);
    ADD_KEYWORD("CLoopS", kwCLoopS);
    ADD_KEYWORD("CLoopE", kwCLoopE);
    ADD_KEYWORD("CLoopW", kwCLoopW);
    ADD_KEYWORD("CLoopNE", kwCLoopNE);
    ADD_KEYWORD("CLoopNW", kwCLoopNW);
    ADD_KEYWORD("CLoopSE", kwCLoopSE);
    ADD_KEYWORD("CLoopSW", kwCLoopSW);
    ADD_KEYWORD("LoopVarN", kwLoopVarN);
    ADD_KEYWORD("LoopVarS", kwLoopVarS);
    ADD_KEYWORD("VarLoopOn", kwVarLoopOn);
    ADD_KEYWORD("VarLoopOff", kwVarLoopOff);
    ADD_KEYWORD("EdgeL", kwEdgeL);
    ADD_KEYWORD("EdgeR", kwEdgeR);
    ADD_KEYWORD("ArcL", kwArcL);
    ADD_KEYWORD("ArcR", kwArcR);
    ADD_KEYWORD("LArcL", kwLArcL);
    ADD_KEYWORD("LArcR", kwLArcR);
    ADD_KEYWORD("VArcL", kwVArcL);
    ADD_KEYWORD("VArcR", kwVArcR);
    ADD_KEYWORD("VCurveL", kwVCurveL);
    ADD_KEYWORD("VCurveR", kwVCurveR);
    ADD_KEYWORD("LabelL", kwLabelL);
    ADD_KEYWORD("LabelR", kwLabelR);
    ADD_KEYWORD("DimState", kwDimState);
    ADD_KEYWORD("RstState", kwRstState);
    ADD_KEYWORD("DimEdge", kwDimEdge);
    ADD_KEYWORD("RstEdge", kwRstEdge);
    ADD_KEYWORD("ShowGrid", kwShowGrid);
    ADD_KEYWORD("ShowFrame", kwShowFrame);
    ADD_KEYWORD("HideGrid", kwHideGrid);
    ADD_KEYWORD("HideFrame", kwHideFrame);
    ADD_KEYWORD("StateLineDouble", kwStateLineDouble);
    ADD_KEYWORD("StateLineSimple", kwStateLineSimple);
    ADD_KEYWORD("EdgeLineDouble", kwEdgeLineDouble);
    ADD_KEYWORD("EdgeLineSimple", kwEdgeLineSimple);
    ADD_KEYWORD("EdgeBorder", kwEdgeBorder);
    ADD_KEYWORD("EdgeBorderOff", kwEdgeBorderOff);
    ADD_KEYWORD("SetStateLineStyle", setStateLineStyle);
    ADD_KEYWORD("SetStateLineWidth", setStateLineWidth);
    ADD_KEYWORD("SetStateLineColor", setStateLineColor);
    ADD_KEYWORD("SetStateLabelColor", setStateLabelColor);
    ADD_KEYWORD("SetStateLabelScale", setStateLabelScale);
    ADD_KEYWORD("SetStateFillStatus", setStateFillStatus);
    ADD_KEYWORD("SetStateFillColor", setStateFillColor);
    ADD_KEYWORD("SetEdgeLineStyle", setEdgeLineStyle);
    ADD_KEYWORD("SetEdgeLineWidth", setEdgeLineWidth);
    ADD_KEYWORD("SetEdgeLineColor", setEdgeLineColor);
    ADD_KEYWORD("SetEdgeLabelColor", setEdgeLabelColor);
    ADD_KEYWORD("SetEdgeLabelScale", setEdgeLabelScale);
    ADD_KEYWORD("ChgStateLineStyle", chgStateLineStyle);
    ADD_KEYWORD("ChgStateLineWidth", chgStateLineWidth);
    ADD_KEYWORD("ChgStateLineColor", chgStateLineColor);
    ADD_KEYWORD("ChgStateLabelColor", chgStateLabelColor);
    ADD_KEYWORD("ChgStateLabelScale", chgStateLabelScale);
    ADD_KEYWORD("ChgStateFillStatus", chgStateFillStatus);
    ADD_KEYWORD("ChgStateFillColor", chgStateFillColor);
    ADD_KEYWORD("ChgEdgeLineStyle", chgEdgeLineStyle);
    ADD_KEYWORD("ChgEdgeLineWidth", chgEdgeLineWidth);
    ADD_KEYWORD("ChgEdgeLineColor", chgEdgeLineColor);
    ADD_KEYWORD("ChgEdgeLabelColor", chgEdgeLabelColor);
    ADD_KEYWORD("ChgEdgeLabelScale", chgEdgeLabelScale);
    ADD_KEYWORD("RstStateLineStyle", rstStateLineStyle);
    ADD_KEYWORD("RstStateLineWidth", rstStateLineWidth);
    ADD_KEYWORD("RstStateLineColor", rstStateLineColor);
    ADD_KEYWORD("RstStateLabelColor", rstStateLabelColor);
    ADD_KEYWORD("RstStateLabelScale", rstStateLabelScale);
    ADD_KEYWORD("RstStateFillStatus", rstStateFillStatus);
    ADD_KEYWORD("RstStateFillColor", rstStateFillColor);
    ADD_KEYWORD("RstEdgeLineStyle", rstEdgeLineStyle);
    ADD_KEYWORD("RstEdgeLineWidth", rstEdgeLineWidth);
    ADD_KEYWORD("RstEdgeLineColor", rstEdgeLineColor);
    ADD_KEYWORD("RstEdgeLabelColor", rstEdgeLabelColor);
    ADD_KEYWORD("RstEdgeLabelScale", rstEdgeLabelScale);
    ADD_KEYWORD("FixDimState", fixDimState);
    ADD_KEYWORD("FixStateLineDouble", fixStateLineDouble);
    ADD_KEYWORD("FixDimEdge", fixDimEdge);
    ADD_KEYWORD("FixEdgeBorder", fixEdgeBorder);
    ADD_KEYWORD("FixEdgeLineDouble", fixEdgeLineDouble);
}

LexAn::LexAn() : fileOpened(false), input('w'), lineNumber(1), lineIndex(0), lineLength(0)
{
    initialize();
}

LexAn::~LexAn()
{
    if (inFile)
    {
        inFile->close();
        delete inFile;
    }
}

bool LexAn::openFile(const QString &fn)
{
    inFile = new QFile(fn);
    if (!inFile->open(QIODevice::ReadOnly))
    {
        DBGLOG_LEX("file couldn't be opened!");
        return false;
    }
    fileOpened = true;

    DBGLOG_LEX("file is opened");
    return true;
}

char LexAn::readChar()
{
    if (lineIndex >= lineLength) // necessary to read next line
    {
        lineIndex = 0;
        lineLength = inFile->readLine(line, sizeof(line));        
        if (lineLength == -1)
        {
            input = 'e';
            return input;
        }
    }
    character = line[lineIndex++];
    if((character >= 'A' && character <= 'Z') || (character >= 'a' && character <= 'z'))
    {
        input = 'c';
    }
    else if(character >= '0' && character <= '9')
    {
        input = 'n';
    }
    else if (character == '\n')
    {   //end of line
        lineNumber++;        
        input = 'l';
    }
    else if(character <= ' ')
    {
        input = 'w';
    }
    else
    {
        input = character;
    }
    return input;
}

QString LexAn::readStringBetween(const QChar &opening, const QChar &closing, bool allowMatching)
{
    Token returnToken = EOI;
    switch(closing.toAscii())
    {
    case '}':
        returnToken = RBRACE;
        break;
    case ']':
        returnToken = RBRACKET;
        break;
    default:
        Q_ASSERT(0 && "unexpected closing character!!!");
        break;
    }

    QString str;
    int balance = 1;
    while (input != 'e')
    {
        if (opening == character) balance++;
        else if (closing == character)
        {
            balance--;
            if (balance == 0 || !allowMatching)
            {
                token = returnToken;
                tokenData = closing;
                readChar();
                return str;
            }
        }

        str += character;
        readChar();
    }
    RELLOG("Unbalanced " << opening << " and " << closing << " pair!");
    token = EOI;
    return str;
}

Token LexAn::readToken()
{
  if (!fileOpened) return EOI;
  bool readed = false; 
  while(input == 'w' || input == 'l') readChar();

  DBGLOG_LEX("next token input: " << input);
  while (!readed){
    tokenData = "";
    switch(input){
    case 'e': // end of file 
      token = EOI;
      readed = true;
      DBGLOG_LEX("EOI");
      break;
    case '%': // comment
      while (readChar() != 'l' && input != 'e') { // while not end of line, read a store comment
        tokenData += character;
      }

      DBGLOG_LEX("COMMENT: " << tokenData);
      token = COMMENT;
      readed = true;
      break;
    case 'l': // discard whitespaces
    case 'w':
      while(readChar() == 'w' || input == 'l'){}
      break;
    case '\\': // should be keyword
      while (readChar() == 'c'){ // while input is char
        tokenData += character;
      } 
      token = keyWordTest(tokenData); // control if keyword
      if (token == ERR) {

    DBGLOG_LEX("not keyword" << tokenData);
    tokenData = "\\" + tokenData; // special symbol (e.g. greek symbol)
    token = SPECIAL; // strings as \sigma, \varepsilon
      }
      if (token == kwBegin){ // looking for kwBeginVCPicture 
        if (input == '{'){
          tokenData = "";
          while (readChar() == 'c'){
            tokenData += character;
          }
          if (tokenData == "VCPicture" && input == '}'){
            readChar(); // '}' is too part of kwBeginVCPicture
            token = kwBeginVCPicture;

            DBGLOG_LEX("VCPicture founded!");
          }
          else {
            token = ERR;
          }
        } // if {
      } // if kwBegin
      readed = true;
      break;
    case '{': // LBRACE
      token = LBRACE;
      readChar();
      readed = true;
      break;
    case '}': // RBRACE
      token = RBRACE;
      readChar();
      readed = true;
      break;
    case '[': //LBRACKET
      token = LBRACKET;
      readChar();
      readed = true;
      break;
    case ']': //RBRACKET
      token = RBRACKET;
      readChar();
      readed = true;
      break;
    case '(': //LPAR
      token = LPAR;
      readChar();
      readed = true;
      break;
    case ')': //RPAR
      token = RPAR;
      readChar();
      readed = true;
      break;
    case ',': // COMMA
      token = COMMA;  
      readChar();
      readed = true;
      break;
    case '-':
      token = MINUS;  
      readChar();
      readed = true;
      break;
    case '=':
      token = EQUAL;  
      readChar();
      readed = true;
      break;
    case '_':
      token = UNDERLINE;
      readChar();
      readed = true;
      break;
    case '.':
      tokenData += character;
      if (readChar() == 'n'){
        tokenData += character;
        while (readChar() == 'n'){
          tokenData += character;
        }
        token = FLOAT;
        readed = true;
        break;
      }
      token = DOT;
      readed = true;
      break;
    case 'n': // number or float
      tokenData = character;
      while (readChar() == 'n'){
        tokenData += character;
      }
      if (input == '.'){
        tokenData += character;
        while (readChar() == 'n')
          tokenData += character;
        token = FLOAT;

        DBGLOG_LEX("FLOAT" << tokenData);
      }
      else{
        token = NUMB;

        DBGLOG_LEX("NUMB" << tokenData);
      }      
      readed = true;
      break;
    case 'c': // ident - label, name, or constant symbol (as arcangle, angleA, ...)
      tokenData = character;
      while (readChar() == 'c' || input == 'n'){
        tokenData += character;
      }
      token = IDENT;

      DBGLOG_LEX("IDENT" << tokenData);
      readed = true;
      break;
    default:
      // return the other character
      tokenData = character;
      token = OTHER;
      readed = true;
      readChar();
    }
  }
  return token;
}

Token LexAn::keyWordTest(const QString &tokenData)
{
    if (keywordMap.contains(tokenData))
    {
        DBGLOG_LEX(keywordMap[tokenData]);
        return keywordMap[tokenData];
    }
    return ERR; // unknown keyword
}

QString LexAn::getTokenData()
{
    return tokenData;
}

Token LexAn::getToken()
{
    return token;
}

int LexAn::getLineNumber()
{
    return lineNumber;
}

//--------------------------------------------------------------------------- LexAn -->



//<-- Parser --------------------------------------------------------------------------

#define IF_CAN_CHANGE_EDITOR(x) if (m_canChangeEditor) {x}

Parser::Parser(Editor *editor, bool canChangeEditor)
: editor(editor), lexan(NULL), m_canChangeEditor(canChangeEditor), lastTr(NULL), err_count(0), war_count(0),
  dimState(false), dimEdge(false), edgeBorder(false), stateLineDouble(false), varLoop(false)
{
    resetParams();
    
    // default in Vaucanson-G
    IF_CAN_CHANGE_EDITOR
    (
        editor->showGrid = false;
        editor->showFrame = false;  
        emit editor->showChanged(false, false);
    )
}

void Parser::resetParams()
{
    // all parameters - to save
    stateLineStyle = DEF_LINE_STYLE;
    stateLineWidth = 1;
    stateLineColor = DEF_COLOR;
    stateLabelColor = DEF_COLOR;
    stateLabelScale = 1;
    stateFillStatus = DEF_FILL_STATUS;
    stateFillColor = DEF_FILL_COLOR;
    // state parametres preset
    stateLineDoubleCoef = DEF_STATE_LINE_DBL_COEF;
    stateLineDoubleSep = DEF_STATE_LINE_DBL_SEP;
    // state parametres dimmed
    dimStateLineStyle = DEF_DIM_LINE_STYLE;
    dimStateLineColor = DEF_DIM_COLOR;
    dimStateLineCoef = DEF_DIM_STATE_LINE_COEF;
    dimStateLabelColor = DEF_DIM_COLOR;
    dimStateFillColor = DEF_DIM_FILL_COLOR;
    // transition parameters
    edgeLineStyle = DEF_LINE_STYLE;
    edgeLineWidth = 1;
    edgeLineColor = DEF_COLOR;
    edgeLabelColor = DEF_COLOR;
    edgeLabelScale = 1;
    edgeLineDblStatus = DEF_EDGE_LINE_DBL_STATUS;
    // transition parameters preset
    edgeLineBorderCoef = DEF_EDGE_LINE_BORDER_COEF;
    edgeLineBorderColor = DEF_EDGE_LINE_BORDER_COLOR;
    edgeLineDblCoef = DEF_EDGE_LINE_DBL_COEF;
    edgeLineDblSep = DEF_EDGE_LINE_DBL_SEP;
    // transition parameters dimmed
    dimEdgeLineStyle = DEF_DIM_LINE_STYLE;
    dimEdgeLineColor = DEF_DIM_COLOR;
    dimEdgeLineCoef = DEF_DIM_EDGE_LINE_COEF;
    dimEdgeLabelColor = DEF_DIM_COLOR;
}

Parser::~Parser()
{
    if (lexan) delete lexan; // close file - this shouldn't be never done, only for sure
}

void Parser::matching(Token token, bool end)
{
    if (lexan->getToken() != token)
    {
        errorReportUTOKEN();
        throw U_TOKEN;
    }
    if (lexan->readToken() == EOI && !end)
    {
        DBGLOG_PAR("End");
        throw U_EOI;
    }
}

void Parser::checkTrParam(Transition *tr){
  if (edgeLineStyle != editor->edgeLineStyle) tr->edgeLineStyle = edgeLineStyle;
  if (edgeLineWidth != 1) tr->setEdgeLineWidth(edgeLineWidth);
  if (edgeLineColor != editor->edgeLineColor) tr->edgeLineColor = edgeLineColor;
  if (edgeLabelColor != editor->edgeLabelColor) tr->edgeLabelColor = edgeLabelColor;
  if (edgeLabelScale != 1) {
    tr->setEdgeLabelScale(edgeLabelScale);
  }
  if (edgeLineDblStatus != editor->edgeLineDblStatus) tr->edgeLineDblStatus = edgeLineDblStatus;
  
  if (edgeLineDblCoef != DEF_EDGE_LINE_DBL_COEF) tr->edgeLineDblCoef = edgeLineDblCoef;
  if (edgeLineDblSep != DEF_EDGE_LINE_DBL_SEP) tr->edgeLineDblSep = edgeLineDblSep;
  if (edgeLineBorderCoef != DEF_EDGE_LINE_BORDER_COEF) tr->edgeLineBorderCoef = edgeLineBorderCoef;
  if (edgeLineBorderColor != DEF_EDGE_LINE_BORDER_COLOR) tr->edgeLineBorderColor = edgeLineBorderColor;
  
  if (dimEdgeLineStyle != DEF_DIM_LINE_STYLE) tr->dimEdgeLineStyle = dimEdgeLineStyle;
  if (dimEdgeLineCoef != DEF_DIM_EDGE_LINE_COEF) tr->setDimEdgeLineCoef(dimEdgeLineCoef);
  if (dimEdgeLineColor != DEF_DIM_COLOR) tr->dimEdgeLineColor = dimEdgeLineColor;
  if (dimEdgeLabelColor != DEF_DIM_COLOR) tr->dimEdgeLabelColor = dimEdgeLabelColor;
  tr->adjust();
}

bool Parser::kwTest(Token token)
{
    return (eFirstKw <= token && token <= eLastKw);
}

void Parser::resetStateParams(){
  stateLineStyle = DEF_LINE_STYLE;
  stateLineWidth = 1;
  stateLineColor = DEF_COLOR;
  stateLabelColor = DEF_COLOR;
  stateLabelScale = 1;
  stateFillStatus = DEF_FILL_STATUS;
  stateFillColor = DEF_FILL_COLOR;
}

void Parser::resetTrParams()
{
    edgeLineStyle = DEF_LINE_STYLE;
    edgeLineWidth = 1;
    edgeLineColor = DEF_COLOR;
    edgeLabelColor = DEF_COLOR;
    edgeLabelScale = 1;
    edgeLineDblStatus = DEF_EDGE_LINE_DBL_STATUS;
}



// static methods

bool Parser::checkNameCorrectness(const QString &name, QString *error)
{
    // TODO: fix this method to check all possible problems, but which are they? :)
    if (name.contains(QRegExp("(?:\\[|\\]|,)")))
    {
        if (error) *error = "Characters '[', ']' and ',' are not allowed in state name due to VauCanSon-G format!";
        return false;
    }

    return true;
}



// recursive descent

bool Parser::run(const QString &filename, QList<State*> &stateList, QRect &gridRect)
{
    // reset info
    lexan = new LexAn();
    report.clear();
    err_count = 0;
    war_count = 0;

    if(lexan->openFile(filename))
    {
        try
        {
            lexan->readToken(); // read first token
            File();
        }  
        catch (Exceptions v)
        {
            switch (v)
            {
            case U_EOI: 
                report << QString("%1: Error %2 - Unexpected end of file!").arg(lexan->getLineNumber()).arg(++err_count);
                break;
            case BAD_GRID:
                report << QString("%1: Error %2 - Invalid GridRect proportion!").arg(lexan->getLineNumber()).arg(++err_count);
                break;
            case U_TOKEN:
                // message is added to report list in Parser::matching
                break; 
            default:
                report << QString("%1: Error %2 - Unknown error").arg(lexan->getLineNumber()).arg(++err_count);
            }
        }
    }  
    else report << QString("File %1 couldn't be opened!").arg(filename);

    stateList = m_stateMap.values();
    gridRect = m_gridRect;

    m_stateMap.clear();
    m_gridRect = QRect();

    delete lexan; lexan = NULL;

    if (report.isEmpty() && !err_count && !war_count)
    {
        report << "VCPicture loaded sucessfully!"
               << "-------------------------"
               << "<b>Errors: 0, Warnings: 0</b>";
        return true;
    }
    else
    {
        report         << "------------------------------"; // for html coding, must be join("<br>"), no "\n"!    
        report << QString("<b>Errors: %1, Warnings: %2</b>").arg(err_count).arg(war_count);        
        return false;
    }
}

void Parser::File()
{
    Predeclaration();
    DBGLOG_PAR("predeclaration ok ...");
    VCPicture();
}

void Parser::Predeclaration()
{
  while (!kwTest(lexan->getToken()) && lexan->getToken() != EOI)
  {
    lexan->readToken();
    IF_CAN_CHANGE_EDITOR
    (
    editor->addition = true;
    )
  } // accept only key word or EOI!
  switch (lexan->getToken()){
  case kwShowGrid:
    IF_CAN_CHANGE_EDITOR
    (
    editor->showGrid = true;
    emit editor->showChanged(editor->showGrid, editor->showFrame);
    )
    lexan->readToken();
    break;
  case kwShowFrame:
    IF_CAN_CHANGE_EDITOR
    (
    editor->showFrame = true;
    emit editor->showChanged(editor->showGrid, editor->showFrame);
    )
    lexan->readToken();
    break;
  case kwHideGrid:
    IF_CAN_CHANGE_EDITOR
    (
    editor->showGrid = false;
    emit editor->showChanged(editor->showGrid, editor->showFrame);
    )
    lexan->readToken();
    break;
  case kwHideFrame:
    IF_CAN_CHANGE_EDITOR
    (
    editor->showFrame = false;
    emit editor->showChanged(editor->showGrid, editor->showFrame);
    )
    lexan->readToken();
    break;
  case kwBeginVCPicture:
    return;
  case EOI:
    throw U_EOI;
    break;
  default:
    try{
      ChgParam(); // most keywords
    }
    catch (Exceptions v)
    {
        if (v != U_TOKEN) throw;    // if U_TOKEN, it's ok, whatever should be in .tex file
        lexan->readToken();
    }
  }
  Predeclaration();
}

void Parser::VCPicture()
{
    int lx, ly, rx, ry;
    DBGLOG_PAR("VCPicture loading");
    matching(kwBeginVCPicture);
    matching(LBRACE);
    matching(LPAR);
    lx = Numb();
    matching(COMMA);
    ly = Numb();
    matching(RPAR);
    matching(LPAR);
    rx = Numb();
    matching(COMMA);
    ry = Numb();
    matching(RPAR);
    matching(RBRACE);
    if (lx < rx && ly < ry)
    {
      // set grid rect
      m_gridRect = QRect(lx,ly,rx-lx,ry-ly);
      IF_CAN_CHANGE_EDITOR(editor->setGridRect(m_gridRect);)
    }
    else
    {
      throw BAD_GRID;
    }
    DBGLOG_PAR("entering to main part - Element");
    while (Element()){}; // main part of parsing
    matching(kwEnd);
    matching(LBRACE);
    if (lexan->getToken() == IDENT)
    {
        if (lexan->getTokenData() != "VCPicture")
        {
            errorReportUTOKEN();
            throw U_TOKEN;
        }
    }
    matching(IDENT);
    matching(RBRACE, true);
}

void Parser::VCPut()
{
    matching(kwVCPut);

    if (lexan->getToken() == LBRACKET)
    {
        matching(LBRACKET);
        Number();
        matching(RBRACKET);
    }

    matching(LBRACE);
    matching(LPAR);
    Number();
    matching(COMMA);
    Number();
    matching(RPAR);
    matching(RBRACE);
    param = lexan->readStringBetween('{', '}');
    RELLOG("VCPut ignored content: " << param);
    matching(RBRACE);

    report << QString("%1: Warning %2 - VCPut is unsupported element, will be ignored (with all its content)!")
                  .arg(lexan->getLineNumber())
                  .arg(++war_count);
}

bool Parser::Element()
{
    try
    {
        switch (lexan->getToken())
        {
            case kwVCPut:
                VCPut();
                break;
            case kwDimState:
            case kwDimEdge:
            case kwRstState:
            case kwRstEdge:  
            case kwStateLineDouble:
            case kwStateLineSimple:
            case kwEdgeLineDouble:
            case kwEdgeLineSimple:  
                Switch();
                break;
            case kwEdgeBorder:
            case kwEdgeBorderOff:
                report << QString("%1: Warning %2 - EdgeBorder is not yet supported -> so ignored")
                    .arg(lexan->getLineNumber())      
                    .arg(++war_count);
                Switch();
                break;
            case kwVarLoopOn:
            case kwVarLoopOff:      
                Switch();
                break;
            case kwState:
            case kwFinalState:
            case kwStateVar:
            case kwFinalStateVar:
                DBGLOG_PAR("found State");
                State_r();
                break;
            case kwInitial:
            case kwFinal:
            case kwLoopN:
            case kwLoopS:
            case kwLoopE:
            case kwLoopW:
            case kwLoopNE:
            case kwLoopNW:
            case kwLoopSE:
            case kwLoopSW:
            case kwCLoopN:
            case kwCLoopS:
            case kwCLoopE:
            case kwCLoopW:
            case kwCLoopNE:
            case kwCLoopNW:
            case kwCLoopSE:
            case kwCLoopSW:
            case kwLoopVarN:
            case kwLoopVarS:
            case kwEdgeL:
            case kwEdgeR:
            case kwArcL:
            case kwArcR:
            case kwLArcL:
            case kwLArcR:
            case kwVArcL:
            case kwVArcR:
            case kwVCurveL:
            case kwVCurveR:
                DBGLOG_PAR("founded Transition");
                Transition_r();
                break;  
            case kwLabelL:
            case kwLabelR:
                DBGLOG_PAR("founded Label");
                Label_r();
                break;
            case COMMENT:
                matching(COMMENT); // TODO: maybe inflictable?
                break; 
            case kwEnd: // end of picture
                DBGLOG_PAR("end");
                return false;
            default:
                ChgParam(); // the longest list of keywords
        }
    }//try
    catch (Exceptions v)
    {
        switch (v)
        {
            case STATE_EXIST:
                report << QString("%1: Error%2 - State with same name already exists. Skipping to next element ...")
                    .arg(lexan->getLineNumber()).arg(++err_count);
                break;
            case NO_STATE:
                report << QString("%1: Error%2 - Required state doesn't exist. Skipping to next element ...")
                    .arg(lexan->getLineNumber()).arg(++err_count);
                break;
            case U_TOKEN:
                errorReportUTOKEN();
                break;
            default:
                throw;
                break;
        }
        while (!kwTest(lexan->readToken()) && lexan->getToken() != EOI){}
        if (lexan->getToken() == EOI) throw EOI;
    }
    return true;
}

void Parser::Switch()
{
  switch (lexan->getToken()){
  case kwDimState: dimState = true; matching(kwDimState);
    break;
  case kwRstState: dimState = false; matching(kwRstState);
    resetStateParams();
    break;
  case kwDimEdge: dimEdge = true; matching(kwDimEdge);
    break;
  case kwRstEdge: dimEdge = false; matching(kwRstEdge);
    resetTrParams();
    break;
  case kwEdgeBorder: edgeBorder = true; matching(kwEdgeBorder);
    break;
  case kwEdgeBorderOff: edgeBorder = false; matching(kwEdgeBorderOff);
    break;
  case kwStateLineDouble: stateLineDouble = true; matching(kwStateLineDouble);
    break;
  case kwStateLineSimple: stateLineDouble = false; matching(kwStateLineSimple);
    break;
  case kwEdgeLineDouble: edgeLineDblStatus = true; matching(kwEdgeLineDouble);
    break;
  case kwEdgeLineSimple: edgeLineDblStatus = false; matching(kwEdgeLineSimple);
    break;
  case kwVarLoopOn: varLoop = true; matching(kwVarLoopOn);
      break;
  case kwVarLoopOff: varLoop = false; matching(kwVarLoopOff);
      break;
  default:
      report << QString("%1: Error %2 - Unexpected token '%3', expected Switch")
          .arg(lexan->getLineNumber())    
          .arg(++err_count)
          .arg(lexan->getTokenData());
    throw U_TOKEN;
  }
}

void Parser::ChgParam(){
  float number, number2;
  switch (lexan->getToken()){
  case setStateLineStyle:
    matching(setStateLineStyle);
    matching(LBRACE);
    stateLineStyle = LineStyle();
    IF_CAN_CHANGE_EDITOR(editor->stateLineStyle = stateLineStyle;)
    matching(RBRACE);
    break;
  case setStateLineWidth:
    matching(setStateLineWidth);
    matching(LBRACE);
    number = Number();
    if (lexan->getToken() == IDENT){
      if (lexan->getTokenData() != "pt"){
          report << QString("%1: Warning %2 - Unexpected IDENT '%3' -> expected 'pt' -> substituted to 'pt'")
            .arg(lexan->getLineNumber())      
            .arg(++war_count)
            .arg(lexan->getTokenData());
      }
      matching(IDENT);
    }
    else{
        report << QString("%1: Warning %2 - Missing IDENT -> expected 'pt' -> inserted 'pt'")
            .arg(lexan->getLineNumber())    
            .arg(++war_count);
    }
    IF_CAN_CHANGE_EDITOR(editor->stateLineWidth = number;)
    stateLineWidth = 1; // change to default
    matching(RBRACE);
    break;
  case setStateLineColor:
    matching(setStateLineColor);
    matching(LBRACE);
    stateLineColor = Color();
    IF_CAN_CHANGE_EDITOR(editor->stateLineColor = stateLineColor;)
    matching(RBRACE);
    break;
  case setStateLabelColor:
    matching(setStateLabelColor);
    matching(LBRACE);
    stateLabelColor = Color();
    IF_CAN_CHANGE_EDITOR(editor->stateLabelColor = stateLabelColor;)
    matching(RBRACE);
    break;
  case setStateLabelScale:
    matching(setStateLabelScale);
    matching(LBRACE);
    number = Number();
    stateLabelScale = number;
    IF_CAN_CHANGE_EDITOR(editor->stateLabelScale = stateLabelScale;)
    matching(RBRACE);
    break;
  case setStateFillStatus:
    matching(setStateFillStatus);
    matching(LBRACE);
    stateFillStatus = FillStatus();
    IF_CAN_CHANGE_EDITOR(editor->stateFillStatus = stateFillStatus;)
    matching(RBRACE);
    break;
  case setStateFillColor:
    matching(setStateFillColor);
    matching(LBRACE);
    stateFillColor = Color();
    IF_CAN_CHANGE_EDITOR(editor->stateFillColor = stateFillColor;)
    matching(RBRACE);
    break;
  case setEdgeLineStyle:
    matching(setEdgeLineStyle);
    matching(LBRACE);
    edgeLineStyle = LineStyle();
    IF_CAN_CHANGE_EDITOR(editor->edgeLineStyle = edgeLineStyle;)
    matching(RBRACE);
    break;
  case setEdgeLineWidth:
    matching(setEdgeLineWidth);
    matching(LBRACE);
    number = Number();
    if (lexan->getToken() == IDENT){
      if (lexan->getTokenData() != "pt"){
        report << QString("%1: Warning %2 - Unexpected IDENT '%3'  -> expected 'pt' -> substituted to 'pt'")
            .arg(lexan->getLineNumber())      
            .arg(++war_count)
            .arg(lexan->getTokenData());
      }
      matching(IDENT);
    }
    else{
      report << QString("%1: Warning %2 - Missing IDENT -> expected 'pt' -> inserted 'pt'")
            .arg(lexan->getLineNumber())    
            .arg(++war_count);
    }
    edgeLineWidth = number;
    IF_CAN_CHANGE_EDITOR(editor->edgeLineWidth = edgeLineWidth;)
    matching(RBRACE);
    break;
  case setEdgeLineColor:
    matching(setEdgeLineColor);
    matching(LBRACE);
    edgeLineColor = Color();
    IF_CAN_CHANGE_EDITOR(editor->edgeLineColor = edgeLineColor;)
    matching(RBRACE);
    break;
  case setEdgeLabelColor:
    matching(setEdgeLineStyle);
    matching(LBRACE);
    edgeLabelColor = Color();
    IF_CAN_CHANGE_EDITOR(editor->edgeLabelColor = edgeLabelColor;)
    matching(RBRACE);
    break;
  case setEdgeLabelScale:
    matching(setEdgeLabelScale);
    matching(LBRACE);
    number = Number();
    edgeLabelScale = number;
    IF_CAN_CHANGE_EDITOR(editor->edgeLabelScale = edgeLabelScale;)
    matching(RBRACE);
    break;
  /*case setEdgeLineDblStatus:
    matching(setEdgeLineDblStatus);
    matching(LBRACE);
    if (lexan->getToken() == IDENT){
    if (lexan->getTokenData() == "true"){
      editor->edgeLineDblStatus = true;
      edgeLineDblStatus = true;
    }
    else if (lexan->getTokenData() == "false"){
      editor->edgeLineDblStatus = false;
      edgeLineDblStatus = false;
    }
    matching(RBRACE);
    break;
    } // if IDENT
    report << QString("Error %1: Unexpected token in line %2, expected bool")
              .arg(++err_count)
              .arg(lexan->getLineNumber());
    throw U_TOKEN;
    break;*/
  case chgStateLineStyle:
    DBGLOG_PAR(lexan->getTokenData());
    matching(chgStateLineStyle);
    DBGLOG_PAR(lexan->getTokenData());
    matching(LBRACE);
    stateLineStyle = LineStyle();
    matching(RBRACE);
    break;
  case chgStateLineWidth:
    matching(chgStateLineWidth);
    matching(LBRACE);
    number = Number(); // radsi pres promennou
    stateLineWidth = number;
    matching(RBRACE);
    break;
  case chgStateLineColor:
    matching(chgStateLineColor);
    matching(LBRACE);
    stateLineColor = Color();
    matching(RBRACE);
    break;
  case chgStateLabelColor:
    matching(chgStateLabelColor);
    matching(LBRACE);
    stateLabelColor = Color();
    matching(RBRACE);
    break;
  case chgStateLabelScale:
    matching(chgStateLabelScale);
    matching(LBRACE);
    number = Number();
    stateLabelScale = number;
    matching(RBRACE);
    break;
  case chgStateFillStatus:
    matching(chgStateFillStatus);
    matching(LBRACE);
    stateFillStatus = FillStatus();
    matching(RBRACE);
    break;
  case chgStateFillColor:
    matching(chgStateFillColor);
    matching(LBRACE);
    stateFillColor = Color();
    matching(RBRACE);
    break;
  case chgEdgeLineStyle:
    matching(chgEdgeLineStyle);
    matching(LBRACE);
    edgeLineStyle = LineStyle();
    matching(RBRACE);
    break;
  case chgEdgeLineWidth:
    matching(chgEdgeLineWidth);
    matching(LBRACE);
    number = Number();
    edgeLineWidth = number;
    matching(RBRACE);
    break;
  case chgEdgeLineColor:
    matching(chgEdgeLineColor);
    matching(LBRACE);
    edgeLineColor = Color();
    matching(RBRACE);
    break;
  case chgEdgeLabelColor:
    matching(chgEdgeLabelColor);
    matching(LBRACE);
    edgeLabelColor = Color();
    matching(RBRACE);
    break;
  case chgEdgeLabelScale:
    matching(chgEdgeLabelScale);
    matching(LBRACE);
    number = Number();
    edgeLabelScale = number;
    matching(RBRACE);
    break;
  /*case chgEdgeLineDblStatus:
    matching(setEdgeLineDblStatus);
    matching(LBRACE);
    if (lexan->getToken() == IDENT){
    if (lexan->getTokenData() == "true"){
      edgeLineDblStatus = true;  
    }
    else if(lexan->getTokenData() == "false"){
      edgeLineDblStatus = false;
    }
    matching(RBRACE);
    break;
    } // if IDENT
    report << QString("Error %1: Unexpected token in line %2, expected bool")
              .arg(++err_count)
              .arg(lexan->getLineNumber());
    throw U_TOKEN;
    break;*/
  case rstStateLineStyle:
    matching(rstStateLineStyle);
    stateLineStyle = editor->stateLineStyle;
    break;
  case rstStateLineWidth:
    matching(rstStateLineWidth);
    stateLineWidth = 1; // it's only coeficient, no value!
    break;
  case rstStateLineColor:
    matching(rstStateLineColor);
    stateLineColor = editor->stateLineColor;
    break;
  case rstStateLabelColor:
    matching(rstStateLabelColor);
    stateLabelColor = editor->stateLabelColor;
    break;
  case rstStateLabelScale:
    matching(rstStateLabelScale);
    stateLabelScale = 1;
    break;
  case rstStateFillStatus:
    matching(rstStateFillStatus);
    stateFillStatus = editor->stateFillStatus;
    break;
  case rstStateFillColor:
    matching(rstStateFillColor);
    stateFillColor = editor->stateFillColor;
    break;
  case rstEdgeLineStyle:
    matching(rstEdgeLineStyle);
    edgeLineStyle = editor->edgeLineStyle;
    break;
  case rstEdgeLineWidth:
    matching(rstEdgeLineWidth);
    edgeLineWidth = 1;
    break;
  case rstEdgeLineColor:
    matching(rstEdgeLineColor);
    edgeLineColor = editor->edgeLineColor;
    break;
  case rstEdgeLabelColor:
    matching(rstStateLabelColor);
    stateLabelColor = editor->stateLabelColor;
    break;
  case rstEdgeLabelScale:
    matching(rstEdgeLabelScale);
    edgeLabelScale = 1;
    break;
  /*case rstEdgeLineDblStatus:
    matching(rstEdgeLineDblStatus);
    edgeLineDblStatus = editor->edgeLineDblStatus;
    break;*/
  case fixDimState:
    matching(fixDimState);
    matching(LBRACE);
      dimStateLineStyle = LineStyle();
    matching(RBRACE);
    matching(LBRACE);
      dimStateLineColor = Color();
    matching(RBRACE);
    matching(LBRACE);
      dimStateLineCoef = Number();
    matching(RBRACE);
    matching(LBRACE);
      dimStateLabelColor = Color();
    matching(RBRACE);
    matching(LBRACE);
      dimStateFillColor = Color();
    matching(RBRACE);
    break;
  case fixStateLineDouble:
    matching(fixStateLineDouble);
    matching(LBRACE);
      number = Number();
    matching(RBRACE);
    matching(LBRACE);
      number2 = Number();
    matching(RBRACE);
      stateLineDoubleCoef = number;
      stateLineDoubleSep = number2;
    break;
  case fixDimEdge:
    matching(fixDimEdge);
    matching(LBRACE);
      dimEdgeLineStyle = LineStyle();
    matching(RBRACE);
    matching(LBRACE);
      number = Number();
      dimEdgeLineCoef = number;
    matching(RBRACE);
    matching(LBRACE);
      dimEdgeLineColor = Color();
    matching(RBRACE);
    matching(LBRACE);
      dimEdgeLabelColor = Color();
    matching(RBRACE);
    break;
  case fixEdgeBorder:
    matching(fixEdgeBorder);
    matching(LBRACE);
      number = Number();
      edgeLineBorderCoef = number;
    matching(RBRACE);
    matching(LBRACE);
      edgeLineBorderColor = Color();
    matching(RBRACE);
    break;
  case fixEdgeLineDouble:
    matching(fixEdgeLineDouble);
    matching(LBRACE);
      number = Number();
    matching(RBRACE);
    matching(LBRACE);
      number2 = Number();
    matching(RBRACE);
      edgeLineDblCoef = number;
      edgeLineDblSep = number2;
    break;
  default:
    throw U_TOKEN;
  } // switch
}

Qt::BrushStyle Parser::FillStatus(){
  QString s;
  if (lexan->getToken() == IDENT){
    s = lexan->getTokenData();
    matching(IDENT);
    if(s == "vlines"){ 
      return Qt::FDiagPattern;
    }
    else if(s == "hlines"){
      return Qt::BDiagPattern;
    }
    else if(s == "crosshatch"){
      return Qt::DiagCrossPattern;
    }
    else if(s == "none"){
      return Qt::NoBrush;
    }
    else if(s == "solid"){
      return Qt::SolidPattern;
    }
    report << QString("%1: Warning %2 - Bad fill status '%3', substituted by none!")
        .arg(lexan->getLineNumber())    
        .arg(++war_count)
        .arg(s);
    return Qt::NoBrush;
  } // if IDENT
  
  errorReportUTOKEN();
  throw U_TOKEN;
}

Qt::PenStyle Parser::LineStyle(){
  QString s;
  if (lexan->getToken() == IDENT){
    s = lexan->getTokenData();
    matching(IDENT);
    if (s == "dashed"){
      return Qt::DashLine;
    }
    else if (s == "dotted"){
      return Qt::DotLine;
    }
    else if (s == "solid"){
      return Qt::SolidLine;
    }
    else if (s == "none"){
      return Qt::NoPen;
    }
    report << QString("%1: Warning %2 - Bad line style '%3', substituted by solid!")
        .arg(lexan->getLineNumber())      
        .arg(++war_count)
        .arg(s);
    return Qt::SolidLine;
  } // if IDENT
  
  errorReportUTOKEN();
  throw U_TOKEN;  
}

QString Parser::Color(){
    QString s;
        if (lexan->getToken() == IDENT)
        {
            s = lexan->getTokenData();
            matching(IDENT);
            return s; // TODO: checking color string!
        } // if IDENT
    errorReportUTOKEN();
    throw U_TOKEN;  
}

void Parser::State_r(){
  param = lexan->getTokenData();
  switch (lexan->getToken())
  {
  case kwState:         
    matching(kwState);
    StateDeclaration(param);
    break;
  case kwFinalState:
    matching(kwFinalState);
    StateDeclaration(param);
    break;
  case kwStateVar:
    matching(kwStateVar);
    StateDeclaration(param);
    break;
  case kwFinalStateVar:
    matching(kwFinalStateVar);
    StateDeclaration(param);
    break;
  default:
      errorReportUTOKEN();
    throw U_TOKEN;
  }
  
}

void Parser::StateDeclaration(const QString& typeN){
    QString typeName = typeN;
    QString label, name;
    float x, y;
    switch (lexan->getToken())
    {
    case LBRACKET: // [ 
        //matching(LBRACKET);
        StateLabel(); label = param;
        matching(RBRACKET);
        break;
    case LBRACE: // {
        break;
    default:
        errorReportUTOKEN();
        throw U_TOKEN;
    }
    matching(LBRACE);
    matching(LPAR);
    x = Number();
    matching(COMMA);
    y = Number();
    matching(RPAR);
    matching(RBRACE);
    matching(LBRACE);
    Name();
    name = param;
    matching(RBRACE);

    if (m_stateMap.contains(name))
    {
        report << QString("%1: Error %2 - State name '%3' already exists (state names conflict)!")
            .arg(lexan->getLineNumber())    
            .arg(++err_count)
            .arg(name);
        throw STATE_EXIST;
    }
    
    DBGLOG_PAR(typeName << QString("[%1]{(%2,%3)}{%4}")
                                .arg(label)
                                .arg(x)
                                .arg(y)
                                .arg(name));
  
    if (stateLineDouble) typeName = "Final" + typeName;

    QPoint pos = editor->toScenePos(QPointF(x,y));
    
    StateManager *stateManager = StateManager::getInstance();
    State *state = stateManager->createState(typeName, editor, pos, label, name, dimState);
    Q_ASSERT(state != NULL);

#ifdef MEASURE_PARSER_RUN
    static int s_stateCount = 0;
    s_stateCount++;
    if (s_stateCount % 1000 == 0)
        RELLOG(DBGPAR(s_stateCount));
#endif

    // parameters setting
    if (stateLineStyle != editor->stateLineStyle) state->stateLineStyle = stateLineStyle;
    if (stateLineWidth != 1) state->setStateLineWidth(stateLineWidth);
    if (stateLineColor != editor->stateLineColor) state->stateLineColor = stateLineColor;
    if (stateLabelColor != editor->stateLabelColor) state->stateLabelColor = stateLabelColor;
    if (stateLabelScale != 1) state->setStateLabelScale(stateLabelScale);
    if (stateFillStatus != editor->stateFillStatus) state->stateFillStatus = stateFillStatus;
    if (stateFillColor != editor->stateFillColor) state->stateFillColor = stateFillColor;

    if (stateLineDoubleCoef != (float) DEF_STATE_LINE_DBL_COEF)
    state->setStateLineDoubleCoef(stateLineDoubleCoef);
    if (stateLineDoubleSep != (float) DEF_STATE_LINE_DBL_SEP)
    state->setStateLineDoubleSep(stateLineDoubleSep);

    if (dimStateLineStyle != DEF_DIM_LINE_STYLE) state->dimStateLineStyle = dimStateLineStyle;
    if (dimStateLineColor != DEF_DIM_COLOR) state->dimStateLineColor = dimStateLineColor;
    if (dimStateLineCoef != (float) DEF_DIM_STATE_LINE_COEF) state->setDimStateLineCoef(dimStateLineCoef);
    if (dimStateLabelColor != DEF_DIM_COLOR) state->dimStateLabelColor = dimStateLabelColor;
    if (dimStateFillColor != DEF_DIM_FILL_COLOR) state->dimStateFillColor = dimStateFillColor;
    
    m_stateMap.insert(name, state);
}

void Parser::StateLabel()
{
    param = lexan->readStringBetween('[', ']', false);
}

void Parser::Transition_r(){
  switch (lexan->getToken()){
  case kwInitial:
  case kwFinal:
  case kwLoopN:
  case kwLoopS:
  case kwLoopE:
  case kwLoopW:
  case kwLoopNE:
  case kwLoopNW:
  case kwLoopSE:
  case kwLoopSW:
  case kwCLoopN:
  case kwCLoopS:
  case kwCLoopE:
  case kwCLoopW:
  case kwCLoopNE:
  case kwCLoopNW:
  case kwCLoopSE:
  case kwCLoopSW:
  case kwLoopVarN:
  case kwLoopVarS:
    OneStateTransition();
    break;
  default: // solved by Element
    TwoStateTransition();
  }
}

void Parser::Label_r()
{
    bool left = false;
    switch (lexan->getToken()){
        case kwLabelL:
            matching(kwLabelL);
            left = true;
            break;
        case kwLabelR:
            matching(kwLabelR);
            left = false;
            break;
        default:
            RELLOG("Unexpected parser state!!!");
            left = true;
    }

    float pos_param = 0; bool isParam = false;
    pos_param = PosParam(isParam);
    if(!isParam) pos_param = DEF_EDGE_LAB_POS;
    TransitionLabel();
    matching(RBRACE);

    DBGLOG_PAR(isParam << pos_param << "Label" << (left ? "L" : "R") 
        << "[" << pos_param<< "]" << "{" << param << "}");

    if (lastTr == NULL)
    {
        report << QString("%1: Error %2 - Trying to add LabelX and no transition exist!")
            .arg(lexan->getLineNumber())    
            .arg(++err_count);
        throw U_ERR;
    }
    LabelX *pLabel = new LabelX(lastTr, param, left, lastTr->m_labelFontSize, 
        lastTr->getLabelColor(), pos_param);    
    
    lastTr->addNextLabel(pLabel);
    
    lastTr->setLabelPosition(); // TODO: check if this should be removed (maybe it is aplied later again -> so performance can be better)
}

void Parser::OneStateTransition()
{
#ifdef MEASURE_PARSER_RUN
    static int s_oneTrCount = 0;
#endif
    param = "";
    Transition *tr; State *state;
    TransitionManager *transitionManager = TransitionManager::getInstance();
    QString stateName, typeName, label;
    int dir;
    float pos_param; bool isParam;
    typeName = lexan->getTokenData(); // type name -> VauCanSon-G keyword
    switch (lexan->getToken())
    {
    case kwInitial:
        matching(kwInitial);        
    break;
    case kwFinal:
        matching(kwFinal);        
        break;
    default:
        dir = Loop();
        pos_param = PosParam(isParam);
        matching(LBRACE);
        Name();
        stateName = param; param = "";
        matching(RBRACE);        
        TransitionLabel(); label = param;
                    
        dir = trLoopDirection(dir);
    
        if (varLoop) // switch is set, so this will be LoopVar
        {                     
            typeName = "LoopVar";
        }
        else if (typeName.startsWith("LoopVar"))
            typeName = "LoopVar";
        else if (typeName.startsWith("CLoop"))
            typeName = "CLoop";
        else if (typeName.startsWith("Loop"))
            typeName = "Loop";
        else
        {
            RELLOG("Parser::OneStateTransition -> Unexpected loop type!!!");
            report << QString("%1: Warning %2 - Loop type name '%3' isn't supported, Loop used!")
                .arg(lexan->getLineNumber())
                .arg(++war_count)
                .arg(typeName);
            typeName = "Loop";
        }

        DBGLOG_PAR(isParam << pos_param
            << typeName << " " << dir << "{" << param << "}" << "{" << stateName << "}");

        // insert loop
        if (!m_stateMap.contains(stateName))
        {
            report << QString("%1: Error %2 - State name '%3' doesn't exist!")
                .arg(lexan->getLineNumber())
                .arg(++err_count)
                .arg(stateName);
            throw NO_STATE;
        }
        
        state = m_stateMap[stateName];
            
        tr = transitionManager->createOneStateTransition(typeName, editor, state, label, dir, dimEdge);        

        if (isParam) tr->setLabelPos(pos_param);
        checkTrParam(tr);
        tr->assign();
        
        lastTr = tr;
        
#ifdef MEASURE_PARSER_RUN
    s_oneTrCount++;
    if (s_oneTrCount % 1000 == 0)
        RELLOG(DBGPAR(s_oneTrCount));
#endif
        
        matching(RBRACE);
        return;
    }
    
    dir = DirParam(isParam);
    matching(LBRACE);
    Name(); stateName = param;
  
    DBGLOG_PAR(typeName << "{" << stateName << "}");

    if (!m_stateMap.contains(stateName))
    {
        report << QString("%1: Error %2 - State name '%3' doesn't exist!")
            .arg(lexan->getLineNumber())    
            .arg(++err_count)
            .arg(stateName);
        throw NO_STATE;
    }
    
    state = m_stateMap[stateName];

    if (!isParam)
    {
        if (typeName == "Initial")
            dir = DEF_TR_S_DIR;
        else
            dir = DEF_TR_E_DIR;
    }

    tr = transitionManager->createOneStateTransition(typeName, editor, state, "", dir, dimEdge);
    tr->assign();
    checkTrParam(tr);
    
    lastTr = tr;

#ifdef MEASURE_PARSER_RUN
    s_oneTrCount++;
    if (s_oneTrCount % 1000 == 0)
        RELLOG(DBGPAR(s_oneTrCount));
#endif

    matching(RBRACE);
}

int Parser::Loop()
{
  switch (lexan->getToken()){
  case kwLoopN:
    matching(kwLoopN);
    return NORTH;
  case kwLoopS:
    matching(kwLoopS);
    return SOUTH;
  case kwLoopE:
    matching(kwLoopE);
    return EAST;
  case kwLoopW:
    matching(kwLoopW);
    return WEST;
  case kwLoopNE:
    matching(kwLoopNE);
    return NORTH_EAST;
  case kwLoopNW:
    matching(kwLoopNW);
    return NORTH_WEST;
  case kwLoopSE:
    matching(kwLoopSE);
    return SOUTH_EAST;
  case kwLoopSW:
    matching(kwLoopSW);
    return SOUTH_WEST;
  // CLoop has direction increased with num of directions (first is SOUTH_WEST+1)
  case kwCLoopN:
    matching(kwCLoopN);
    return trCLoopDirection(NORTH);
  case kwCLoopS:
    matching(kwCLoopS);
    return trCLoopDirection(SOUTH);
  case kwCLoopE:
    matching(kwCLoopE);
    return trCLoopDirection(EAST);
  case kwCLoopW:
    matching(kwCLoopW);
    return trCLoopDirection(WEST);
  case kwCLoopNE:
    matching(kwCLoopNE);
    return trCLoopDirection(NORTH_EAST);
  case kwCLoopNW:
    matching(kwCLoopNW);
    return trCLoopDirection(NORTH_WEST);
  case kwCLoopSE:
    matching(kwCLoopSE);
    return trCLoopDirection(SOUTH_EAST);
  case kwCLoopSW:
    matching(kwCLoopSW);
    return trCLoopDirection(SOUTH_WEST);
  case kwLoopVarN:    
    matching(kwLoopVarN);
    return trLoopVarDirection(NORTH);
  case kwLoopVarS:    
    matching(kwLoopVarS);
    return trLoopVarDirection(SOUTH);
  default:
    return 0;
  }
}

void Parser::TwoStateTransition()
{
    DBGLOG_PAR(""); // only info about function
    param = ""; // QString as class var
    QString typeName;
    bool left = false; float pos = 0; bool isPosParam = false;
    bool small = false; //for Arc :+(
  
    switch (lexan->getToken())
    {
    case kwEdgeL:
    case kwEdgeR:
        left = Edge();
        typeName = "Edge";
        pos = PosParam(isPosParam);
        break;
    case kwArcL:
    case kwArcR:
    case kwLArcL:
    case kwLArcR:
        left = Arc(small);
        if (small)
            typeName = "Arc";
        else
            typeName = "LArc";
        pos = PosParam(isPosParam);
        break;
    case kwVArcL:
    case kwVArcR:
        left = VArc();
        typeName = "VArc";
        pos = PosParam(isPosParam);
        matching(LBRACE);
        VArcParam();
        matching(RBRACE);
        break;
    case kwVCurveL:
    case kwVCurveR:
        left = VCurve();
        typeName = "VCurve";
        pos = PosParam(isPosParam);
        matching(LBRACE);
        VCurveParam();
        matching(RBRACE);
    default:; // tohle nenastane, hlida to Element
    }  
    EndTransitionDeclaration(typeName ,left, pos, isPosParam);
}

bool Parser::Edge(){
    if (lexan->getToken() == kwEdgeL)
    {
        matching(kwEdgeL);
        return true;
    }
    matching(kwEdgeR);
    return false;
}

bool Parser::Arc(bool &small){
  switch (lexan->getToken()){
  case kwArcL:
    small = true;
    matching(kwArcL);
    return true;
  case kwArcR:
    small = true;
    matching(kwArcR);
    return false;
  case kwLArcL:
    small = false;
    matching(kwLArcL);
    return true;
  case kwLArcR:
    small = false;
    matching(kwLArcR);
    return false;
  default:
    return 0;
  }
}

bool Parser::VArc()
{
  if (lexan->getToken() == kwVArcL){
    matching(kwVArcL);
    return true;
  }
  matching(kwVArcR);
  return false;
}

bool Parser::VCurve()
{
  if (lexan->getToken() == kwVCurveL){
    matching(kwVCurveL);
    return true;
  }
  matching(kwVCurveR);
  return false;
}

void Parser::VArcParam()
{
  cParam.isAngleA = false; // vynuluju co budu potrebovat
  cParam.isNCurv = false;
  if (lexan->getToken() != RBRACE){
    VArcParamIdent();
    VArcParamNext();
  }
}

void Parser::VArcParamNext()
{
  if (lexan->getToken() != RBRACE){
    matching(COMMA);
    VArcParamIdent();
    VArcParamNext();
  }
}

void Parser::VArcParamIdent()
{
  switch(lexan->getToken()){
  case IDENT:
    if (lexan->getTokenData() == "arcangle"){
      matching(IDENT);
      matching(EQUAL);
      cParam.angleA = Numb(); cParam.isAngleA = true; 
    }
    else if (lexan->getTokenData() == "ncurv"){
      matching(IDENT);
      matching(EQUAL);
      cParam.ncurv = Number(); cParam.isNCurv = true;
    }
    else{
      // TODO: jump to next IDENT or "}"
      errorReportUTOKEN();
      throw U_TOKEN;
    }
    break;
  default:;
  }
}

void Parser::VCurveParam(){
  cParam.isAngleA = false; // vynuluju co budu potrebovat
  cParam.isAngleB = false;
  cParam.isNCurv = false;
  if (lexan->getToken() != RBRACE){
    VCurveParamIdent();
    VCurveParamNext();
  }
}

void Parser::VCurveParamNext(){
  if (lexan->getToken() != RBRACE){
    matching(COMMA);
    VCurveParamIdent();
    VCurveParamNext();
  }
}

void Parser::VCurveParamIdent(){
 switch(lexan->getToken()){
  case IDENT:
    if (lexan->getTokenData() == "angleA"){
      matching(IDENT);
      matching(EQUAL);
      cParam.angleA = Numb(); cParam.isAngleA = true; 
    }
    else if (lexan->getTokenData() == "angleB"){
      matching(IDENT);
      matching(EQUAL);
      cParam.angleB = Numb(); cParam.isAngleB = true; 
    }
    else if (lexan->getTokenData() == "ncurv"){
      matching(IDENT);
      matching(EQUAL);
      cParam.ncurv = Number(); cParam.isNCurv = true;
    }
    else{
      // TODO: jump to next IDENT or "}"
        errorReportUTOKEN();
      throw U_TOKEN;
    }
    break;
  default:;
  }
}

void Parser::EndTransitionDeclaration(const QString &typeName, bool left, float pos, bool isPosParam)
{
    QString s1, s2, label;
    Transition *tr; State *state1, *state2; // for save to scene
    TransitionManager *transitionManager = TransitionManager::getInstance();
    matching(LBRACE);
    param = "";
    Name();
    s1 = param;
    matching(RBRACE);
    matching(LBRACE);
    param = "";
    Name();
    s2 = param;
    matching(RBRACE);
    //matching(LBRACE);
    TransitionLabel(); 
    label = param;
  
    // place transition to graph
    DBGLOG_PAR(typeName << left << pos << isPosParam
        << "{" << s1 << "}" << "{" << s2 << "}" << "{" << label << "}");
  
    if (!m_stateMap.contains(s1) ||
        !m_stateMap.contains(s2))
    {
        report << QString("%1: Error %2 - State name '%3' or '%4' doesn't exist!")
            .arg(lexan->getLineNumber())
            .arg(++err_count)
            .arg(s1)
            .arg(s2);
        throw NO_STATE;
    }
  
    state1 = m_stateMap[s1];
    state2 = m_stateMap[s2];
  
    tr = transitionManager->createTwoStatesTransition(typeName, editor, state1, state2, label, left, dimEdge);
    tr->assign();
    
    if (cParam.isAngleA) tr->setArcAngle(cParam.angleA);
    else if (!left) tr->setArcAngle(-DEF_ARC_ANGLE);

    if (cParam.isAngleB) tr->setArcAngleB(cParam.angleB);
    if (cParam.isNCurv) tr->setNCurv(cParam.ncurv);
  
    if (isPosParam)
        tr->setLabelPos(pos);
  
    checkTrParam(tr);
    
    lastTr = tr;
    
#ifdef MEASURE_PARSER_RUN
    static int s_twoTrCount = 0;
    s_twoTrCount++;
    if (s_twoTrCount % 1000 == 0)
        RELLOG(DBGPAR(s_twoTrCount));
#endif
    
    matching(RBRACE);
}

void Parser::TransitionLabel()
{
    param = lexan->readStringBetween('{', '}');
}

float Parser::PosParam(bool &isParam){
  float pos = 0;
  switch (lexan->getToken()){
  case LBRACKET:
    matching(LBRACKET);
    pos = Pos(isParam);
    matching(RBRACKET);
    break;
  default:
    isParam = false;
  }
  return pos;
}

float Parser::Pos(bool &isParam){
  float pos = 0;
  switch (lexan->getToken()){
  case MINUS:
  case NUMB:
  case FLOAT:
    pos = Number();
    isParam = true;
    break;
  case RBRACKET:
    pos = 0.5; // IMHO this do VauCanSon-G too! (or Latex do it)
    isParam = true;
    break;
  default:
    isParam = false;
  }
  return pos;
}

int Parser::DirParam(bool &isParam){
  int dir = NORTH;
  switch (lexan->getToken()){
  case LBRACKET:
    matching(LBRACKET);
    dir = Dir(isParam);
    matching(RBRACKET);
    break;
  default:
    isParam = false;
  }
  return dir;
}

int Parser::Dir(bool &isParam){
  int dir = NORTH; QString dir_s;
  switch(lexan->getToken()){
  case IDENT:
    dir_s = lexan->getTokenData();
    if (dir_s == "n"){
      dir = NORTH;
    }
    else if (dir_s == "s"){
      dir = SOUTH;
    }
    else if (dir_s == "e"){
      dir = EAST;
    }
    else if (dir_s == "w"){
      dir = WEST;
    }
    else if (dir_s == "ne"){
      dir = NORTH_EAST;
    }
    else if (dir_s == "nw"){
      dir = NORTH_WEST;
    }
    else if (dir_s == "se"){
      dir = SOUTH_EAST;
    }
    else if (dir_s == "sw"){
      dir = SOUTH_WEST;
    }
    else {
      errorReportUTOKEN();
      throw U_TOKEN;
    }
    matching(IDENT);
    isParam = true;
    break;
  default:
    isParam = false;
  }
  return dir;
}

float Parser::Number(){
  float number = Sign() ? -1 : 1;
  number = number * NumberNextPart();  
  DBGLOG_PAR(number);
  return number;
}

float Parser::NumberNextPart(){
    float number=0;
    if (lexan->getToken() == NUMB)
    {
        number = lexan->getTokenData().toInt();
        matching(NUMB);
    }
    else if(lexan->getToken() == FLOAT)
    {
        number = lexan->getTokenData().toFloat();
        matching(FLOAT);
    }
    else if(lexan->getToken() == IDENT)
    {}// it can be pt
    else
    {
      report << QString("%1: Warning %2 - No NUMB or FLOAT token, substituted by 0")
          .arg(lexan->getLineNumber())    
          .arg(++war_count);
      throw U_TOKEN;
    }
    return number;
}

int Parser::Numb(){
  int numb = Sign() ? -1 : 1;
  
  if (lexan->getToken() == NUMB) {
    numb = numb * lexan->getTokenData().toInt();
    matching(NUMB);
  }
  else {
    numb = 0;
    report << QString("%1: Warning %2 - No NUMB token, substituted by 0")
        .arg(lexan->getLineNumber())
        .arg(++war_count); 
    if (lexan->getToken() == IDENT || lexan->getToken() == FLOAT) lexan->readToken();
    else throw U_TOKEN;
  }
  
  DBGLOG_PAR(numb);
  return numb;
}

bool Parser::Sign(){
  if (lexan->getToken() == MINUS){
    matching(MINUS);
    return true;
  }
  else
    return false;
}

void Parser::Name()
{
    param="";
    while (NoBracesToken()){}

    QString errorMsg;
    if (!checkNameCorrectness(param, &errorMsg))
    {
        report << QString("%1: Error %2 - %3 (%4)!")
            .arg(lexan->getLineNumber())
            .arg(++err_count)
            .arg(errorMsg)
            .arg(param);
        throw BAD_STATE_NAME;
    }
}

// TODO: delete this, not used anymore, see NameAllowedToken, checkNameCorrectness
void Parser::NameNextPart(){ 
  if (lexan->getToken() == RBRACE){
    return;
  }
  NameAllowedToken();
  NameNextPart();
}

// Now exchanged for NoBracesToken, due to more than only these character can be used for Name
// But no all combinations are allowed!
// TODO: fix this and use it again
void Parser::NameAllowedToken(){
  switch (lexan->getToken()){
  case IDENT:
    param += lexan->getTokenData();
    matching(IDENT);
    break;
  case NUMB:
    param += lexan->getTokenData();
    matching(NUMB);
    break;
  case FLOAT:
    param += lexan->getTokenData();
    matching(FLOAT);
    break;  
  case DOT:
    param += ".";
    matching(DOT);
    break;
  default:
      errorReportUTOKEN();
    throw U_TOKEN;
  }
}

bool Parser::NoBracesToken()
{
  int brace_count = 0;
  do { // pairing loop
  switch (lexan->getToken()){
  case LPAR: // ( 
    param += "(";
    matching(LPAR);
    break;
  case RPAR:
    param += ")";
    matching(RPAR);
    break;
  case COMMA:
    param += ",";
    matching(COMMA);
    break;
  case DOT:
    param += ".";
    matching(DOT);
    break;
  case EQUAL:
    param += "=";
    matching(EQUAL);
    break;
  case MINUS:
    param += "-";
    matching(MINUS);
    break;
  case UNDERLINE:
    param += "_";
    matching(UNDERLINE);
    break;
  case IDENT:
    param += lexan->getTokenData();
    matching(IDENT);
    break;
  case NUMB:
    param += lexan->getTokenData();
    matching(NUMB);
    break;  
  case FLOAT:
    param += lexan->getTokenData();
    matching(FLOAT);
    break;
  case OTHER:
    param += lexan->getTokenData();
    DBGLOG_PAR("OTHER" << lexan->getTokenData());
    matching(OTHER);
    break;
  case SPECIAL:
    param += lexan->getTokenData();
    DBGLOG_PAR("SPECIAL" << lexan->getTokenData());
    matching(SPECIAL);
    break;
  case LBRACE:
    brace_count++;
    param += "{";
    DBGLOG_PAR("{" << brace_count);
    matching(LBRACE);
    break;
  case RBRACE:
    if (brace_count) {
      brace_count--;
      param += "}";
      matching(RBRACE);
      DBGLOG_PAR("}" << brace_count);
    }
    else {
      DBGLOG_PAR("}" << brace_count);
      return false;
    }
    break;
  case LBRACKET:
    param += "[";
    matching(LBRACKET);
    break;
  case RBRACKET:
    param += "]";
    matching(RBRACKET);
    break;
  default:
      errorReportUTOKEN();
    throw U_TOKEN;
  }
  }while (brace_count);
  return true;
}

// TODO: is this used anymore?
bool Parser::NoBracketsToken()
{
  int brace_count = 0;
  int bracket_count = 0;
  do{ // due to pairing of parentheses
  switch (lexan->getToken()){
  case LPAR: // ( 
    param += "(";
    matching(LPAR);
    break;
  case RPAR:
    param += ")";
    matching(RPAR);
    break;
  case COMMA:
    param += ",";
    matching(COMMA);
    break;
  case DOT:
    param += ".";
    matching(DOT);
    break;
  case EQUAL:
    param += "=";
    matching(EQUAL);
    break;
  case MINUS:
    param += "-";
    matching(MINUS);
    break;
  case UNDERLINE:
    param += "_";
    matching(UNDERLINE);
    break;
  case IDENT:
    param += lexan->getTokenData();
    matching(IDENT);
    break;
  case NUMB:
    param += lexan->getTokenData();
    matching(NUMB);
    break;  
  case FLOAT:
    param += lexan->getTokenData();
    matching(FLOAT);
    break;
  case OTHER:
    param += lexan->getTokenData();
    DBGLOG_PAR("OTHER" << lexan->getTokenData());
    matching(OTHER);
    break;
  case SPECIAL:
    param += lexan->getTokenData();
    DBGLOG_PAR("SPECIAL" << lexan->getTokenData());
    matching(SPECIAL);
    break;
  case LBRACE: // {
    brace_count++;
    param += "{";
    DBGLOG_PAR("{" << brace_count);
    matching(LBRACE);
    break;
  case RBRACE: // }
    if (brace_count) brace_count--;
    else throw U_TOKEN;
    param += "}";
    matching(RBRACE);
    DBGLOG_PAR("}" << brace_count);
    break;
  case LBRACKET: // [
    bracket_count++;
    param += "[";
    DBGLOG_PAR("[" << bracket_count);
    matching(LBRACKET);
    break;
  case RBRACKET: // ]
    if (bracket_count) {
      bracket_count--;
      param += "]";
      matching(RBRACKET);
      DBGLOG_PAR("]" << bracket_count);
    }
    else{
      if (brace_count == 0)
        return false; // end
      else
        throw U_TOKEN; // not balanced '{' and '}' !!!
    }
    break;
  default:
      errorReportUTOKEN();
      throw U_TOKEN;
      break;
  }
  } while (bracket_count || brace_count);
  
  return true;
}

//-------------------------------------------------------------------------- Parser -->
