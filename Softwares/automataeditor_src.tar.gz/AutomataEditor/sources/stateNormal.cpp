#include "constants.h"

#include "stateNormal.h"
#include "transforms.h"

#include <QtDebug>

StateNormal::StateNormal(const QPoint &position, Editor *parent, const QString& label, 
                         const QString &name, bool dBorder, bool dim)
: State(position, parent, label, name, dBorder, dim)
{
    updateMyPolygon();
}

QString StateNormal::getTypeName() const
{
    return doubleBorder ? "FinalState" : "State";
}

void StateNormal::updateMyPolygon()
{
    QPainterPath path;
    QRectF ellipseRect(S_LX,S_LY,S_W,S_H);

    float adjust;

    if (doubleBorder)
    {
        float doubleLineSep = m_lineWidth * stateLineDoubleSep / STATE_LINE_VIEW_COEF; // w/o correction
        float doubleLineWidth = m_lineWidth * stateLineDoubleCoef * STATE_DOUBLE_LINE_VIEW_COEF;
        adjust = doubleLineSep + doubleLineWidth*1.5;
    }
    else
    {
        adjust = m_lineWidth/2;
    }

    myPath = QPainterPath();
    myPath.addEllipse(ellipseRect.adjusted(-adjust,-adjust,
                                            adjust, adjust));
    myPolygon = myPath.toFillPolygon();
}



//<-- Export support functions -------------------------------------------------
/*
QString StateNormal::getEPS() const
{
  QString s = "";
  int r, g, b;
  float rf, gf, bf;
  QColor lineC, labelC, fillC;
  Qt::PenStyle lineS;
  float lineWidth, lineSep = 0;
    
  if (dimmed){
    lineC = dimStateLineColor;
    labelC = dimStateLabelColor;
    lineS = dimStateLineStyle;
    fillC = dimStateFillColor;
    lineWidth = editor->stateLineWidth * dimStateLineCoef; // nasobi se jeste pres zmenu na stavu
  }
  else{
    lineC = stateLineColor;
    labelC = stateLabelColor;
    lineS = stateLineStyle;
    fillC = stateFillColor;
    lineWidth = editor->stateLineWidth * stateLineWidth;
  }
  
  // draw state
  // x y radius lineWidth r g b x y radius r g b sCircle
  // x y radius x y radius lineWidth r g b x y radius r g b sDbCircle
  s += trLineStyle(lineS); // TODO: make "none" better
  if (doubleBorder){
    lineSep = lineWidth * stateLineDoubleSep;
    lineWidth *= stateLineDoubleCoef;
    s += QString (" %1 %2 %3")
           .arg(x())
           .arg(scene()->height()-2 - y())
           .arg(-S_LX+lineSep/2+lineWidth);
  }
  lineC.getRgb(&r,&g,&b);
  rf = r / 255.; gf = g / 255.; bf = b / 255.;
  s += QString (" %1 %2 %3 %4 %5 %6 %7 %1 %2 %3")
         .arg(x())
         .arg(scene()->height()-2 - y())
         .arg(-S_LX-lineSep/2)
         .arg(lineWidth)
         .arg(rf).arg(gf).arg(bf);
  fillC.getRgb(&r,&g,&b);
  rf = r / 255.; gf = g / 255.; bf = b / 255.;  
  s += QString (" %1 %2 %3")
         .arg(rf).arg(gf).arg(bf);
  
  if (doubleBorder){
    s += " sDbCircle\n";
  }
  else
    s += " sCircle\n";

  // draw label
  if (label != "")
      s += stringProcessor->getEPS(QPointF(x() - stringProcessor->getWidth()/2,
                                   scene()->height()-2 - y() - (getTextAscent() - getTextDescent())/2));

  return s;
}
*/
//------------------------------------------------- Export support functions -->



//<-- QGraphicsItem functions --------------------------------------------------

QPainterPath StateNormal::shape() const
{
    return myPath;
}

void StateNormal::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{    
    QColor lineC, labelC, fillC;
    Qt::PenStyle lineS;
    float doubleLineSep, doubleLineWidth;

    if (dimmed)
    {
        lineC = dimStateLineColor;
        labelC = dimStateLabelColor;
        lineS = dimStateLineStyle;
        fillC = dimStateFillColor;
    }
    else
    {
        lineC = stateLineColor;
        labelC = stateLabelColor;
        lineS = stateLineStyle;
        fillC = stateFillColor;
    }

#ifdef TESTING_PAINTING
    fillC.setAlpha(100);
#endif

    // BUG in manual, recomputed stateLineWidth is used for doubleLine
    doubleLineSep = m_lineWidth * stateLineDoubleSep / STATE_LINE_VIEW_COEF; // w/o correction
    doubleLineWidth = m_lineWidth * stateLineDoubleCoef * STATE_DOUBLE_LINE_VIEW_COEF;

    QRectF ellipseRect = QRectF(S_LX,S_LY,S_W,S_H);
    (doubleBorder) ? painter->setPen(QPen(lineC,doubleLineWidth,lineS)) :
                     painter->setPen(QPen(lineC,m_lineWidth,lineS));

    if (doubleBorder){
    if (stateFillStatus != Qt::NoBrush){
        painter->setBrush(QColor("white"));
    }
    else {
        painter->setBrush(Qt::NoBrush);
    }
    // TODO: hold right doubleLineSep?
    painter->drawEllipse(ellipseRect.adjusted(-doubleLineSep-doubleLineWidth,
                                              -doubleLineSep-doubleLineWidth,
                                              doubleLineSep+doubleLineWidth,
                                              doubleLineSep+doubleLineWidth));
    }

    if (stateFillStatus != Qt::SolidPattern) {// only for better edge visibility TODO: maybe not necessary more
        fillC = "black";
        if (stateFillStatus != Qt::NoBrush){
            painter->setBrush(QBrush("white",Qt::SolidPattern));
            if (doubleBorder){
                painter->drawEllipse(ellipseRect.adjusted(doubleLineSep,doubleLineSep,-doubleLineSep,-doubleLineSep));
            }
            else{
                painter->drawEllipse(ellipseRect);
            }
        }  
    }

    if (checked) 
    {
        painter->setBrush(checkedColor);  
    }
    else
    {
        painter->setBrush(QBrush(fillC,stateFillStatus));
    }

    if (doubleBorder)
    {
        painter->drawEllipse(ellipseRect.adjusted(doubleLineSep,doubleLineSep,-doubleLineSep,-doubleLineSep));
    }
    else
    {
        painter->drawEllipse(ellipseRect);
    }
    
    painter->setPen(labelC);
    if (stringProcessor->text() != "")
    {
        QPointF point(-getTextWidth()/2, (getTextAscent() - getTextDescent())/2);
        stringProcessor->drawText(painter, point);
    }

    paintSelectionDecoration(painter);

#ifdef TESTING_PAINTING
#   ifdef TESTING_BOUNDING_RECT_PAINTING
    painter->setBrush(QBrush(QColor(50,255,0,80)));
    painter->fillRect(boundingRect(), painter->brush());
#   endif

    painter->setBrush(QBrush(QColor(0,0,255,50)));
    painter->fillPath(shape(), painter->brush());
#endif
}

//-------------------------------------------------- QGraphicsItem functions -->
