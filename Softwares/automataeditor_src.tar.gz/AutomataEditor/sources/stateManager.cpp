#include "constants.h"

#include "stateManager.h"
#include "editor.h"
#include "state.h"
#include "stateNormal.h"
#include "stateVar.h"
#include "stateDialogs.h"

#include <QPoint>
#include <QtGlobal>

bool StateManager::instantiated = false;
StateManager* StateManager::manager = NULL;

StateManager::StateManager()
{
    stateTypeList << "State" << "FinalState" << "StateVar" << "FinalStateVar";
    int i = 0;
    typeNameToInstanceMap[stateTypeList[i++]] = &StateManager::createStateNormal;
    typeNameToInstanceMap[stateTypeList[i++]] = &StateManager::createStateNormalFinal;
    typeNameToInstanceMap[stateTypeList[i++]] = &StateManager::createStateVar;
    typeNameToInstanceMap[stateTypeList[i++]] = &StateManager::createStateVarFinal;
}

StateManager* StateManager::getInstance()
{
    if(!instantiated)
    {
        manager = new StateManager();
        instantiated = true;
        return manager;
    }
    else
    {
        return manager;
    }
}

const QList<QString>& StateManager::getTypeNameList() const
{
    return stateTypeList;
}

int StateManager::getTypeNameId(const QString &typeName) const
{
    Q_ASSERT(stateTypeList.contains(typeName));
    return stateTypeList.indexOf(typeName);
}

State* StateManager::createState(Editor *editor, const QPoint& pos, const StateDialog &sd)
{    
    Q_ASSERT(typeNameToInstanceMap.contains(stateTypeList[sd.getType()]));
    return (this->*(typeNameToInstanceMap[stateTypeList[sd.getType()]]))
        (editor, pos, sd.getLabel(), sd.getName(), sd.isDimmed());
}

State* StateManager::createState(const QString& typeName, Editor *editor, const QPoint& pos, 
                                 const QString& label, const QString& name, bool dimmed)
{
    Q_ASSERT(typeNameToInstanceMap.contains(typeName));
    return (this->*(typeNameToInstanceMap[typeName]))
        (editor, pos, label, name, dimmed);
}

/*------------------------------------------------|
 * Implementation of concrete state constructors  |
 *------------------------------------------------V*/

State* StateManager::createStateNormal(Editor *editor, const QPoint& pos, const QString& label, 
                                       const QString& name,bool dimmed)
{
    return new StateNormal(pos, editor, label, name, false, dimmed);
}

State* StateManager::createStateNormalFinal(Editor *editor, const QPoint& pos, const QString& label, 
                                            const QString& name,bool dimmed)
{
    return new StateNormal(pos, editor, label, name, true, dimmed);
}

State* StateManager::createStateVar(Editor *editor, const QPoint& pos, const QString& label, 
                                    const QString& name,bool dimmed)
{
    return new StateVar(pos, editor, label, name, false, dimmed);
}

State* StateManager::createStateVarFinal(Editor *editor, const QPoint& pos, const QString& label, 
                                         const QString& name,bool dimmed)
{
    return new StateVar(pos, editor, label, name, true, dimmed);
}
