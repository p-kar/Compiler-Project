#ifndef _TRANSITIONVARC_H_2565645773590_
#define _TRANSITIONVARC_H_2565645773590_

#include "twoStatesTransition.h"

class TransitionVArc : public TwoStatesTransition
{
public: 
  TransitionVArc(Editor *parent, State *ss, State *es, const QString &label, 
                 bool leftOriented, bool dimmed);
  virtual ~TransitionVArc();
  
  virtual void adjust();
  virtual void setLabelPosition();

  virtual QString getTypeName() const;

  virtual void setArcAngle(int aa) { arcangle = aa; adjust(); }
  virtual void setNCurv(float nc) { ncurv = nc; }
  virtual int getArcAngle() const { return arcangle; }
  virtual float getNCurv() const { return ncurv; }
  
  virtual QString getVCCommand() const;
  virtual QString getGraphMLParams() const;
  //virtual QString getEPS() const;
  
protected:
  //void paint(QPainter * painter, const QStyleOptionGraphicsItem * option, QWidget * widget = 0);
    
  int arcangle;
  float ncurv;
  
  //float r; // radius of arc
  //float startAngle;
  //float endAngle;
  
  QPointF a_point;
  QPointF b_point;
};

#endif //_TRANSITIONVARC_H_2565645773590_
