#include "constants.h"

#include "dialogs.h"
#include "transforms.h"
#include "commands.h"
#include "state.h"
#include "transition.h"
#include "editor.h"
#include "ialgorithm.h"

#include "iautomaton.h"

// dialogs
#include <QGroupBox>
#include <QSpinBox>
#include <QComboBox>
#include <QCheckBox>
#include <QPushButton>
#include <QLabel>
#include <QLayout>
#include <QLineEdit>
#include <QTextEdit>
#include <QTextDocumentFragment>
#include <QListWidget>
#include <QTableWidget>
#include <QFileDialog>
#include <QMessageBox>
#include <QUndoStack>

//<-- GridRectDialog --------------------------------------------------------

GridRectDialog::GridRectDialog(QWidget *parent)
: QDialog(parent)
{
    QLabel *lblLowerLeftX = new QLabel(QString("LowerLeft x"),this);
    spinLowerLeftX = new QSpinBox(this);
    QLabel *lblLowerLeftY = new QLabel(QString("LowerLeft y"),this);
    spinLowerLeftY = new QSpinBox(this);
    QLabel *lblUpperRightX = new QLabel(QString("UpperRight x"),this);
    spinUpperRightX = new QSpinBox(this);
    QLabel *lblUpperRightY = new QLabel(QString("UpperRight y"),this);
    spinUpperRightY = new QSpinBox(this);
    QLabel *lblBorder = new QLabel(QString("Scene border"), this);
    spinBorder = new QSpinBox(this);
  
    // by default
    spinLowerLeftX->setMinimum(MIN_RECT_VALUE);
    spinLowerLeftY->setMinimum(MIN_RECT_VALUE);
    spinUpperRightX->setMinimum(MIN_RECT_VALUE);
    spinUpperRightY->setMinimum(MIN_RECT_VALUE);
    spinBorder->setMinimum(MIN_BORDER_VALUE);
  
    spinLowerLeftX->setMaximum(MAX_RECT_VALUE);
    spinLowerLeftY->setMaximum(MAX_RECT_VALUE);
    spinUpperRightX->setMaximum(MAX_RECT_VALUE);
    spinUpperRightY->setMaximum(MAX_RECT_VALUE);
    spinBorder->setMaximum(MAX_BORDER_VALUE);

    spinBorder->setSingleStep(10);
    
    QWidget *hBox = new QWidget(this);
    QPushButton *buttonOk = new QPushButton("Ok");
    QPushButton *buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(buttonOk);
    hBoxLayout->addWidget(buttonCancel);
    hBox->setLayout(hBoxLayout);
    connect(buttonOk, SIGNAL(clicked()), this, SLOT(accept()));  
    connect(buttonCancel, SIGNAL(clicked()), this, SLOT(reject()));
  
    QGridLayout *gridLayout = new QGridLayout(this);
    gridLayout->addWidget(lblLowerLeftX, 0, 0);
    gridLayout->addWidget(spinLowerLeftX, 0, 1);
    gridLayout->addWidget(lblLowerLeftY, 1, 0);
    gridLayout->addWidget(spinLowerLeftY, 1, 1);
    gridLayout->addWidget(lblUpperRightX, 2, 0);
    gridLayout->addWidget(spinUpperRightX, 2, 1);
    gridLayout->addWidget(lblUpperRightY, 3, 0);
    gridLayout->addWidget(spinUpperRightY, 3, 1);
    gridLayout->addWidget(lblBorder, 4, 0);
    gridLayout->addWidget(spinBorder, 4, 1);
    gridLayout->addWidget(hBox, 5, 0, 1, 2); // buttons
  
    QString s = "GridRect dialog";
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/grid.xpm"));
}

void GridRectDialog::setLowerLeftX(int x){
  spinLowerLeftX->setValue(x);
}

void GridRectDialog::setLowerLeftY(int y){
  spinLowerLeftY->setValue(y);
}

void GridRectDialog::setUpperRightX(int x){
  spinUpperRightX->setValue(x);
}

void GridRectDialog::setUpperRightY(int y){
  spinUpperRightY->setValue(y);
}

void GridRectDialog::setBorder(int b)
{
    spinBorder->setValue(b);
}

int GridRectDialog::getLowerLeftX(){
  return spinLowerLeftX->value();
}

int GridRectDialog::getLowerLeftY(){
  return spinLowerLeftY->value();
}

int GridRectDialog::getUpperRightX(){
  return spinUpperRightX->value();
}

int GridRectDialog::getUpperRightY(){
  return spinUpperRightY->value();
}

int GridRectDialog::getBorder()
{
    return spinBorder->value();
}

//-------------------------------------------------------- GridRectDialog -->



//<-- State Style Dialog --------------------------------------------------

StateStyleDialog::StateStyleDialog(Editor *parent)
: QDialog(parent), editor(parent)
{
  QStringList sls; // lineStyle
  sls.append("solid");
    sls.append("dashed");
    sls.append("dotted");
    sls.append("none");
  
  QStringList slf; // fillColor
  slf.append("solid");
  slf.append("vlines");
  slf.append("hlines");
  slf.append("crosshatch");
  slf.append("none");
  
  QStringList sla; // apply
  sla.append("Apply as new global style - to coming states");
    sla.append("Apply as global style - to current states with style equal with last global style");
    sla.append("Apply as global style - to all states");
  
  QRegExp rx("^[\\-]{0,1}[0-9]{1,3}\\.[0-9]{1,3}$"); // vyrobim validator pro float
    QValidator *v = new QRegExpValidator(rx,this); 
    
  // parameters adjusted
  QLabel *lineStyle = new QLabel(QString("StateLineStyle"),this);
  comboLineStyle = new QComboBox(this);
  comboLineStyle->addItems(sls);
  comboLineStyle->setCurrentIndex(0);
  
  QLabel *lineWidth = new QLabel(QString("StateLineWidth"),this);
  edtLineWidth = new QLineEdit(this);
  edtLineWidth->setValidator(v);
  
  QLabel *lineColor = new QLabel(QString("StateLineColor"),this);
  edtLineColor = new QLineEdit(this);  
  
  QLabel *labelColor = new QLabel(QString("StateLabelColor"),this);
  edtLabelColor = new QLineEdit(this);
  
  QLabel *labelScale = new QLabel(QString("StateLabelScale"),this);
  edtLabelScale = new QLineEdit(this);
  edtLabelScale->setValidator(v);
  
  QLabel *fillStatus = new QLabel(QString("StateFillStatus"),this);
  comboFillStatus = new QComboBox(this);
  comboFillStatus->addItems(slf);
  comboFillStatus->setCurrentIndex(0);
  
  QLabel *fillColor = new QLabel(QString("StateFillColor"),this);
  edtFillColor = new QLineEdit(this);
  
  // parameters preset (dim state)
  QLabel *dimLineStyle = new QLabel(QString("DimStateLineStyle"),this);
  comboDimLineStyle = new QComboBox(this);
  comboDimLineStyle->addItems(sls);
  comboDimLineStyle->setCurrentIndex(0);
  
  QLabel *dimLineColor = new QLabel(QString("DimStateLineColor"),this);
  edtDimLineColor = new QLineEdit(this);
  
  QLabel *dimLineCoef = new QLabel(QString("DimStateLineCoef"),this);
  edtDimLineCoef = new QLineEdit(this);
  edtDimLineCoef->setValidator(v);
  
  QLabel *dimLabelColor = new QLabel(QString("DimStateLabelColor"),this);
  edtDimLabelColor = new QLineEdit(this);
  
  QLabel *dimFillColor = new QLabel(QString("DimStateFillColor"),this);
  edtDimFillColor = new QLineEdit(this);
  
  // state double
  QLabel *lineDblCoef = new QLabel(QString("StateLineDblCoef"),this);
  edtLineDblCoef = new QLineEdit(this);
  edtLineDblCoef->setValidator(v);
  
  QLabel *lineDblSep = new QLabel(QString("StateLineDblSep"),this);
  edtLineDblSep= new QLineEdit(this);
  edtLineDblSep->setValidator(v);
  
  // apply
  comboApply = new QComboBox(this);
  comboApply->addItems(sla);
  comboApply->setCurrentIndex(0);
  
  // buttons
    QWidget *hBox = new QWidget(this);
    QPushButton *buttonOk = new QPushButton("Ok");
    QPushButton *buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(buttonOk);
    hBoxLayout->addWidget(buttonCancel);
    hBox->setLayout(hBoxLayout);    
    hBox->setMaximumWidth(300);
    connect(buttonOk, SIGNAL(clicked()), this, SLOT(myAccept()));
    connect(buttonCancel, SIGNAL(clicked()), this, SLOT(reject()));
    
    QGroupBox *advancedGroup = new QGroupBox("Advanced parameters");
    QGridLayout *advancedLayout = new QGridLayout(advancedGroup);
    advancedLayout->addWidget(lineStyle,0,0);
    advancedLayout->addWidget(comboLineStyle,0,1);
    advancedLayout->addWidget(lineWidth,0,2);
    advancedLayout->addWidget(edtLineWidth,0,3); // \n
    advancedLayout->addWidget(lineColor,1,0);
    advancedLayout->addWidget(edtLineColor,1,1);
    advancedLayout->addWidget(labelColor,1,2);
    advancedLayout->addWidget(edtLabelColor,1,3); // \n
    advancedLayout->addWidget(labelScale,2,0,1,2,Qt::AlignRight);
    advancedLayout->addWidget(edtLabelScale,2,2,1,2,Qt::AlignLeft); // \n
    advancedLayout->addWidget(fillStatus,3,0);
    advancedLayout->addWidget(comboFillStatus,3,1);
    advancedLayout->addWidget(fillColor,3,2);
    advancedLayout->addWidget(edtFillColor,3,3); // \n\n

    QGroupBox *presetGroup = new QGroupBox("Preset parameters (dim state)");
    QGridLayout* presetLayout = new QGridLayout(presetGroup);
    presetLayout->addWidget(dimLineStyle, 0,0);  
    presetLayout->addWidget(comboDimLineStyle, 0,1);  
    presetLayout->addWidget(dimLineCoef, 0,2);
    presetLayout->addWidget(edtDimLineCoef, 0,3); // \n
    presetLayout->addWidget(dimLineColor, 1,0);
    presetLayout->addWidget(edtDimLineColor, 1,1);    
    presetLayout->addWidget(dimLabelColor, 1,2);
    presetLayout->addWidget(edtDimLabelColor, 1,3); // \n
    presetLayout->addWidget(dimFillColor, 2,0,1,2, Qt::AlignRight);
    presetLayout->addWidget(edtDimFillColor, 2,2,1,2, Qt::AlignLeft); // \n\n
    
    QGroupBox *doubleGroup = new QGroupBox("Line double parameters (final state)");
    QHBoxLayout *doubleLayout = new QHBoxLayout(doubleGroup);
    doubleLayout->addWidget(lineDblCoef);
    doubleLayout->addWidget(edtLineDblCoef);
    doubleLayout->addWidget(lineDblSep);
    doubleLayout->addWidget(edtLineDblSep); // \n

  QGroupBox *localGroup = new QGroupBox("Not storable as style (will not loaded to editor style when loading...)");
  QVBoxLayout *localLayout = new QVBoxLayout(localGroup);    
    localLayout->addWidget(presetGroup);
    localLayout->addWidget(doubleGroup);
    
    QGroupBox *applyGroup = new QGroupBox("Apply to ...");
    QHBoxLayout *applyLayout = new QHBoxLayout(applyGroup);
    applyLayout->addWidget(comboApply);
    
    QVBoxLayout *dialogLayout = new QVBoxLayout(this);
    dialogLayout->addWidget(advancedGroup);
    dialogLayout->addWidget(localGroup);
    dialogLayout->addWidget(applyGroup);
    dialogLayout->addWidget(hBox, 0, Qt::AlignHCenter);

  QString    s = "State style parameters";
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/state.xpm"));
    
    setParams();
}

void StateStyleDialog::setParams()
{
  comboLineStyle->setCurrentIndex(trLineStyleI(editor->stateLineStyle));
  edtLineWidth->setText(QString("%1").arg(editor->stateLineWidth));
  edtLineColor->setText(editor->stateLineColor);
  edtLabelColor->setText(editor->stateLabelColor);
  edtLabelScale->setText(QString("%1").arg(editor->stateLabelScale));
  comboFillStatus->setCurrentIndex(trFillStatusI(editor->stateFillStatus));  
  edtFillColor->setText(editor->stateFillColor);
  
  comboDimLineStyle->setCurrentIndex(trLineStyleI(editor->dimStateLineStyle));
  edtDimLineColor->setText(editor->dimStateLineColor);
  edtDimLineCoef->setText(QString("%1").arg(editor->dimStateLineCoef));
  edtDimLabelColor->setText(editor->dimStateLabelColor);
  edtDimFillColor->setText(editor->dimStateFillColor);
  
  edtLineDblCoef->setText(QString("%1").arg(editor->stateLineDoubleCoef));
  edtLineDblSep->setText(QString("%1").arg(editor->stateLineDoubleSep));
}

void StateStyleDialog::myAccept()
{
  //if (!editor->isChanged()) editor->setChanged(true);
  
  editor->m_undoStack->push(
    new StateStyleChangeCommand(editor,comboApply->currentIndex() ,
        trLineStyle(comboLineStyle->currentIndex()),
        edtLineWidth->text().toFloat(), edtLineColor->text(), edtLabelColor->text(),
        edtLabelScale->text().toFloat(), trFillStatus(comboFillStatus->currentIndex()),
        edtFillColor->text(), trLineStyle(comboDimLineStyle->currentIndex()),
        edtDimLineColor->text(), edtDimLineCoef->text().toFloat(), edtDimLabelColor->text(),
        edtDimFillColor->text(), edtLineDblCoef->text().toFloat(),  edtLineDblSep->text().toFloat())
  );
    
  accept();
}

//-------------------------------------------------- State Style Dialog -->



//<-- Transition Extended Dialog ---------------------------------------------

TransitionStyleDialog::TransitionStyleDialog(Editor *parent)
: QDialog(parent), editor(parent)
{
    QStringList sls; // lineStyle
    sls.append("solid");
    sls.append("dashed");
    sls.append("dotted");
    sls.append("none");
  
    QStringList sla; // apply
    sla.append("Apply as new global style - to coming transitions");
    sla.append("Apply as global style - to current transitinos with style equal with last global style");
    sla.append("Apply as global style - to all transitions");
  
    QRegExp rx("^[\\-]{0,1}[0-9]{1,3}\\.[0-9]{1,3}$"); // vyrobim validator pro float
    QValidator *v = new QRegExpValidator(rx,this); 
    
    // parameters adjusted
    QLabel *lineStyle = new QLabel(QString("EdgeLineStyle"),this);
    comboLineStyle = new QComboBox(this);
    comboLineStyle->addItems(sls);
    comboLineStyle->setCurrentIndex(0);
  
    QLabel *lineWidth = new QLabel(QString("EdgeLineWidth"),this);
    edtLineWidth = new QLineEdit(this);
    edtLineWidth->setValidator(v);
  
    QLabel *lineColor = new QLabel(QString("EdgeLineColor"),this);
    edtLineColor = new QLineEdit(this);
  
    QLabel *labelColor = new QLabel(QString("EdgeLabelColor"),this);
    edtLabelColor = new QLineEdit(this);

    QLabel *labelScale = new QLabel(QString("EdgeLabelScale"),this);
    edtLabelScale = new QLineEdit(this);
    edtLabelScale->setValidator(v);

    QLabel *dblStatus = new QLabel(QString("EdgeLineDblStatus"),this);
    checkDblStatus = new QCheckBox(this);
    checkDblStatus->setChecked(false);

    // parameters preset (dim transition)
    QLabel *dimLineStyle = new QLabel(QString("DimEdgeLineStyle"),this);
    comboDimLineStyle = new QComboBox(this);
    comboDimLineStyle->addItems(sls);
    comboDimLineStyle->setCurrentIndex(0);

    QLabel *dimLineColor = new QLabel(QString("DimEdgeLineColor"),this);
    edtDimLineColor = new QLineEdit(this);

    QLabel *dimLineCoef = new QLabel(QString("DimEdgeLineCoef"),this);
    edtDimLineCoef = new QLineEdit(this);
    edtDimLineCoef->setValidator(v);

    QLabel *dimLabelColor = new QLabel(QString("DimEdgeLabelColor"),this);
    edtDimLabelColor = new QLineEdit(this);

    // transition border
    QLabel *lineBorderCoef = new QLabel(QString("EdgeLineBorderCoef"),this);
    edtLineBorderCoef = new QLineEdit(this);
    edtLineBorderCoef->setValidator(v);

    QLabel *lineBorderColor = new QLabel(QString("EdgeLineBorderColor"),this);
    edtLineBorderColor = new QLineEdit(this);

    // transition double
    QLabel *lineDblCoef = new QLabel(QString("EdgeLineDblCoef"),this);
    edtLineDblCoef = new QLineEdit(this);
    edtLineDblCoef->setValidator(v);

    QLabel *lineDblSep = new QLabel(QString("EdgeLineDblSep"),this);
    edtLineDblSep= new QLineEdit(this);
    edtLineDblSep->setValidator(v);
  
    // apply
    comboApply = new QComboBox(this);
    comboApply->addItems(sla);
    comboApply->setCurrentIndex(0);
  
  
  // buttons
    QWidget *hBox = new QWidget(this);
    QPushButton *buttonOk = new QPushButton("Ok");
    QPushButton *buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(buttonOk);
    hBoxLayout->addWidget(buttonCancel);
    hBox->setLayout(hBoxLayout);    
    hBox->setMaximumWidth(300);
    connect(buttonOk, SIGNAL(clicked()), this, SLOT(myAccept()));
    connect(buttonCancel, SIGNAL(clicked()), this, SLOT(reject()));
    
    QGroupBox *advancedGroup = new QGroupBox("Advanced parameters");
    QGridLayout *advancedLayout = new QGridLayout(advancedGroup);
    advancedLayout->addWidget(lineStyle,0,0);
    advancedLayout->addWidget(comboLineStyle,0,1);
    advancedLayout->addWidget(lineWidth,0,2);
    advancedLayout->addWidget(edtLineWidth,0,3); // \n
    advancedLayout->addWidget(lineColor,1,0);
    advancedLayout->addWidget(edtLineColor,1,1);
    advancedLayout->addWidget(labelColor,1,2);
    advancedLayout->addWidget(edtLabelColor,1,3); // \n
    advancedLayout->addWidget(labelScale,2,0);
    advancedLayout->addWidget(edtLabelScale,2,1); // \n
    advancedLayout->addWidget(checkDblStatus,2,2,Qt::AlignRight);
    advancedLayout->addWidget(dblStatus,2,3,Qt::AlignLeft); // \n\n
  
    QGroupBox *presetGroup = new QGroupBox("Preset parameters (dim edge)");
    QGridLayout* presetLayout = new QGridLayout(presetGroup);
    presetLayout->addWidget(dimLineStyle, 0,0);  
    presetLayout->addWidget(comboDimLineStyle, 0,1);  
    presetLayout->addWidget(dimLineCoef, 0,2);
    presetLayout->addWidget(edtDimLineCoef, 0,3); // \n
    presetLayout->addWidget(dimLineColor, 1,0);
    presetLayout->addWidget(edtDimLineColor, 1,1);    
    presetLayout->addWidget(dimLabelColor, 1,2);
    presetLayout->addWidget(edtDimLabelColor, 1,3); // \n\n
    
    QGroupBox *borderGroup = new QGroupBox("Edge border parameters (edge line double) - unsupported in editor :+(");
    QHBoxLayout *borderLayout = new QHBoxLayout(borderGroup);
    borderLayout->addWidget(lineBorderCoef);
    borderLayout->addWidget(edtLineBorderCoef);
    borderLayout->addWidget(lineBorderColor);
    borderLayout->addWidget(edtLineBorderColor); // \n
    
    QGroupBox *doubleGroup = new QGroupBox("Line double parameters (final state) - unsupported in editor :+(");
    QHBoxLayout *doubleLayout = new QHBoxLayout(doubleGroup);
    doubleLayout->addWidget(lineDblCoef);
    doubleLayout->addWidget(edtLineDblCoef);
    doubleLayout->addWidget(lineDblSep);
    doubleLayout->addWidget(edtLineDblSep); // \n
    
    QGroupBox *localGroup = new QGroupBox("Not storable as style (will not loaded to editor style when loading...)");
    QVBoxLayout *localLayout = new QVBoxLayout(localGroup);    
    localLayout->addWidget(presetGroup);
    localLayout->addWidget(borderGroup);
    localLayout->addWidget(doubleGroup);
    
    QGroupBox *applyGroup = new QGroupBox("Apply to ...");
    QHBoxLayout *applyLayout = new QHBoxLayout(applyGroup);
    applyLayout->addWidget(comboApply);
    
    QVBoxLayout *dialogLayout = new QVBoxLayout(this);
    dialogLayout->addWidget(advancedGroup);
    dialogLayout->addWidget(localGroup);
    dialogLayout->addWidget(applyGroup);
    dialogLayout->addWidget(hBox, 0, Qt::AlignHCenter);

    QString s = "Transition style parameters";
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/transition.xpm"));
    
    setParams();
}

void TransitionStyleDialog::setParams(){
  comboLineStyle->setCurrentIndex(trLineStyleI(editor->edgeLineStyle));
  edtLineWidth->setText(QString("%1").arg(editor->edgeLineWidth));
  edtLineColor->setText(editor->edgeLineColor);
  edtLabelColor->setText(editor->edgeLabelColor);
  edtLabelScale->setText(QString("%1").arg(editor->edgeLabelScale));
  checkDblStatus->setChecked(editor->edgeLineDblStatus);
  
  comboDimLineStyle->setCurrentIndex(trLineStyleI(editor->dimEdgeLineStyle));
  edtDimLineColor->setText(editor->dimEdgeLineColor);
  edtDimLineCoef->setText(QString("%1").arg(editor->dimEdgeLineCoef));
  edtDimLabelColor->setText(editor->dimEdgeLabelColor);
  
  edtLineBorderCoef->setText(QString("%1").arg(editor->edgeLineBorderCoef));
  edtLineBorderColor->setText(QString("%1").arg(editor->edgeLineBorderColor));
  
  edtLineDblCoef->setText(QString("%1").arg(editor->edgeLineDblCoef));
  edtLineDblSep->setText(QString("%1").arg(editor->edgeLineDblSep));
}

void TransitionStyleDialog::myAccept()
{
  //if(!editor->isChanged()) editor->setChanged(true);
  editor->m_undoStack->push(
    new TransitionStyleChangeCommand(editor, comboApply->currentIndex(),
          trLineStyle(comboLineStyle->currentIndex()), edtLineWidth->text().toFloat(),
          edtLineColor->text(), edtLabelColor->text(), edtLabelScale->text().toFloat(),
          checkDblStatus->isChecked(), trLineStyle(comboDimLineStyle->currentIndex()),
          edtDimLineColor->text(), edtDimLineCoef->text().toFloat(),
          edtDimLabelColor->text(), edtLineBorderCoef->text().toFloat(),
          edtLineBorderColor->text(), edtLineDblCoef->text().toFloat(),
          edtLineDblSep->text().toFloat())
  );
  
  accept();
}

//--------------------------------------------- Transition Style Dialog -->



//-- GraphGenerationDialog ------------------------------------------------

GraphGenerationDialog::GraphGenerationDialog(Editor *parent)
: QDialog(parent), editor(parent)
{
    QStringList sl;
    sl << "Exact string matching";
    sl << "Hamming distance";
    sl << "Levenshtein distance";

    QLabel *labelString = new QLabel(QString("Searched string"),this);
    edtString = new QLineEdit(this);
  
    QLabel *labelType = new QLabel(QString("Searching"),this);
    comboAlgorithm = new QComboBox(this);
    comboAlgorithm->addItems(sl);
  
    connect(comboAlgorithm, SIGNAL(currentIndexChanged(int)), this, SLOT(algorithmChanged(int)));
  
    QLabel *labelDistance = new QLabel(QString("Distance"), this);
    spinDistance = new QSpinBox(this);
    spinDistance->setEnabled(false);
  
    QLabel *LabelLR = new QLabel(QString("x-coordinate"), this);
    spinX = new QSpinBox(this);
    spinX->setRange(MIN_RECT_VALUE,MAX_RECT_VALUE);
  
    QLabel *labelY = new QLabel(QString("y-coordinate"), this);
    spinY = new QSpinBox(this);
    spinY->setRange(MIN_RECT_VALUE,MAX_RECT_VALUE);
  
    spinX->setValue(editor->getGridRect().x() + 2); // default start point for good view
    spinY->setValue(editor->getGridRect().y() + editor->getGridRect().height() - 2);
  
    QGroupBox *pointGroup = new QGroupBox(QString("Start at point ..."));
    QGridLayout *pointLayout = new QGridLayout(pointGroup);
    pointLayout->addWidget(LabelLR, 1, 0);
    pointLayout->addWidget(spinX, 1, 1);
    pointLayout->addWidget(labelY, 2, 0);
    pointLayout->addWidget(spinY, 2, 1);
  
    QLabel *labelExpandGrid = new QLabel(QString("Expand grid proportion"), this);
    checkExpandGrid = new QCheckBox(this);
    checkExpandGrid->setChecked(true);
  
  // buttons
    QWidget *hBox = new QWidget(this);
    QPushButton *buttonOk = new QPushButton("Ok");
    QPushButton *buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(buttonOk);
    hBoxLayout->addWidget(buttonCancel);
    hBox->setLayout(hBoxLayout);    
    hBox->setMaximumWidth(300);
    connect(buttonOk, SIGNAL(clicked()), this, SLOT(myAccept()));
    connect(buttonCancel, SIGNAL(clicked()), this, SLOT(reject()));
  
    QGridLayout *dialogLayout = new QGridLayout(this);
    dialogLayout->addWidget(labelString, 0, 0);
    dialogLayout->addWidget(edtString, 0, 1);
    dialogLayout->addWidget(labelType, 1, 0);
    dialogLayout->addWidget(comboAlgorithm, 1, 1);
    dialogLayout->addWidget(labelDistance, 2, 0);
    dialogLayout->addWidget(spinDistance, 2, 1);
    dialogLayout->addWidget(pointGroup, 3,0, 2, 2);
    dialogLayout->addWidget(labelExpandGrid, 5,0, Qt::AlignRight);
    dialogLayout->addWidget(checkExpandGrid, 5,1);
    dialogLayout->addWidget(hBox, 6, 0, 1, 2);
  
    QString    s = "Graph generation dialog";
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/generating.png"));
}

int GraphGenerationDialog::getType()
{
    return comboAlgorithm->currentIndex();
}

QString GraphGenerationDialog::getString()
{
    return edtString->text();
}

QPoint GraphGenerationDialog::getStartPoint()
{
    return QPoint(spinX->value(), spinY->value());
}

int GraphGenerationDialog::getDistance()
{
    return spinDistance->value();
}

bool GraphGenerationDialog::isExpandRequired()
{
    return checkExpandGrid->isChecked();
}

// slots:
void GraphGenerationDialog::myAccept()
{
    accept();
}

void GraphGenerationDialog::algorithmChanged(int i)
{
  spinDistance->setEnabled(i); // 0 is exact matching
}

//----------------------------------------------- GraphGenerationDialog -->



//-- LaTeXTableDialog -----------------------------------------------------

LaTeXTableDialog::LaTeXTableDialog(Editor *parent,
                                   const QSharedPointer<ITransitionTable> &table)
: QDialog(parent), m_pTable(table), m_viewType(eLaTeXTable)
{
    m_textEdit = new QTextEdit(this);
    m_textEdit->setFont(QFont("Courier"));
    m_textEdit->setReadOnly(true);
    m_textEdit->setLineWrapMode(QTextEdit::NoWrap);

    m_switchButton = new QPushButton(m_viewType == eStringTable ?
                                     "LaTeX table" : "String table", this);
    connect(m_switchButton, SIGNAL(clicked()), this, SLOT(switchView()));

    QPushButton *copyButton = new QPushButton("Copy to clipboard", this);
    connect(copyButton, SIGNAL(clicked()), this, SLOT(copyAll()));

    QGridLayout *dialogLayout = new QGridLayout(this);
    dialogLayout->addWidget(m_textEdit, 0, 0, 1, 2);
    dialogLayout->addWidget(m_switchButton, 1, 0, 1, 1);
    dialogLayout->addWidget(copyButton, 1, 1, 1, 1);

    setViewText();

    resize(500,400);

    QString s = "Transition table";
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/table.png"));
}

QString LaTeXTableDialog::text() const
{
    return m_textEdit->toPlainText();
}

void LaTeXTableDialog::setViewText()
{
    switch (m_viewType)
    {
    case eStringTable:
        m_textEdit->setText(m_pTable->toStringTable());
        break;
    case eLaTeXTable:
        m_textEdit->setText(m_pTable->toLaTeXTable());
        break;
    }
}

// slots:

void LaTeXTableDialog::switchView()
{
    m_viewType = (m_viewType == eStringTable ?
                  eLaTeXTable : eStringTable);

    m_switchButton->setText(m_viewType == eStringTable ?
                            "LaTeX table" : "String table");

    setViewText();
}

void LaTeXTableDialog::copyAll()
{
    if (!m_textEdit->textCursor().selection().isEmpty())
    {
        m_textEdit->copy();
    }
    else
    {
        m_textEdit->selectAll();
        m_textEdit->copy();
        m_textEdit->moveCursor(QTextCursor::Start);
    }
}

//---------------------------------------------------- LaTeXTableDialog -->



//<-- LoadAutomataDialog --------------------------------------------------

LoadAutomataDialog::LoadAutomataDialog(Editor *editor, const QString &dialogTitle,
                                       int count, const QStringList &drawAlgorithmList,
                                       bool useCurrent, IAlgorithm *algorithm)
:   QDialog(editor), m_count(count), m_editorFileName(editor->getFileName()),
    m_lastFileName(editor->getFileName()), m_algorithm(algorithm),
    m_comboDrawList(NULL)
{
    QGroupBox   *fileGroup = NULL;
    if (count != 0)
    {
// files
        fileGroup = new QGroupBox(QString("Automata files (%1 required)").arg(count), 
                                  this);
        QGridLayout *fileLayout = new QGridLayout(fileGroup);
        
        m_checkUseCurrent = new QCheckBox("Use the current automaton", this);
        fileLayout->addWidget(m_checkUseCurrent, 0, 1, 1, 3, Qt::AlignRight);
        connect(m_checkUseCurrent, SIGNAL(stateChanged(int)), this, SLOT(checkChanged(int)));

        for(int i=0; i<m_count; ++i)
        {
            fileLayout->addWidget(new QLabel(QString("Automata %1").arg(i+1), this), i+1, 0);
            
            QLineEdit *lineEdit = new QLineEdit(this);
            lineEdit->setReadOnly(true);
            fileLayout->addWidget(lineEdit, i+1, 1);
            m_fileEdits << lineEdit;
            
            QPushButton *button = new QPushButton("...", this);
            button->setMaximumWidth(20);
            fileLayout->addWidget(button, i+1, 2);
            m_fileButtons << button;
            connect(button, SIGNAL(clicked()), this, SLOT(buttonClicked()));
        }
    }
    
// settings    
    QGroupBox *globalGroup = new QGroupBox("Automata settings");
    QGridLayout *globalLayout = new QGridLayout(globalGroup);
    
    QLabel *lblAlphabet = new QLabel("Alphabet", this);
    QLabel *lblAlphabetSymbol = new QLabel("Alphabet symbol", this);
    QLabel *lblEpsilonSymbol = new QLabel("Epsilon symbol", this);
    
    m_alphabetRegex = QRegExp("[^,\\[\\]]+(?:,[^,\\[\\]]+)*");
    QValidator *v = new QRegExpValidator(m_alphabetRegex,this);
    
    m_edtAlphabet = new QLineEdit(this);
    m_edtAlphabet->setValidator(v);
    m_edtAlphabetSymbol = new QLineEdit(this);
    m_edtEpsilonSymbol = new QLineEdit(this);    
    
    const QString alphabetTip = "Alphabet syntax: '[character], [character], ...' (e.g.: 'a, b, c')";
    m_edtAlphabet->setToolTip(alphabetTip);
    m_edtAlphabet->setWhatsThis(alphabetTip);
    const QString aSymbTip = "Alphabet symbol syntax: '[character]' (e.g.: '\\Sigma{}')";
    m_edtAlphabetSymbol->setToolTip(aSymbTip);
    m_edtAlphabetSymbol->setWhatsThis(aSymbTip);
    const QString eSymbTip = "Epsilon symbol syntax: '[character]' (e.g.: '\\varepsilon{}')";
    m_edtEpsilonSymbol->setToolTip(eSymbTip);
    m_edtEpsilonSymbol->setWhatsThis(eSymbTip);
    
    m_checkAlphabet = new QCheckBox("autodetect", this);
    m_checkAlphabet->setChecked(true);
    m_checkAlphabetSymbol = new QCheckBox("autodetect", this);
    m_checkAlphabetSymbol->setChecked(true);
    m_checkEpsilonSymbol = new QCheckBox("autodetect", this);
    m_checkEpsilonSymbol->setChecked(true);
    
    checkAlphabetChanged(Qt::Checked);
    checkAlphabetSymbChanged(Qt::Checked);
    checkEpsilonSymbChanged(Qt::Checked);
    
    connect(m_checkAlphabet, SIGNAL(stateChanged(int)), this, SLOT(checkAlphabetChanged(int)));
    connect(m_checkAlphabetSymbol, SIGNAL(stateChanged(int)), this, SLOT(checkAlphabetSymbChanged(int)));
    connect(m_checkEpsilonSymbol, SIGNAL(stateChanged(int)), this, SLOT(checkEpsilonSymbChanged(int)));
    
    globalLayout->addWidget(lblAlphabet, 0, 0);
    globalLayout->addWidget(m_checkAlphabet, 0, 1, Qt::AlignRight);
    globalLayout->addWidget(m_edtAlphabet, 1, 0, 1, 2);
    
    globalLayout->addWidget(lblAlphabetSymbol, 2, 0);
    globalLayout->addWidget(m_checkAlphabetSymbol, 2, 1, Qt::AlignRight);
    globalLayout->addWidget(m_edtAlphabetSymbol, 3, 0, 1, 2);
    
    globalLayout->addWidget(lblEpsilonSymbol, 4, 0);
    globalLayout->addWidget(m_checkEpsilonSymbol, 4, 1, Qt::AlignRight);
    globalLayout->addWidget(m_edtEpsilonSymbol, 5, 0, 1, 2);

// algorithm
    QGroupBox *algorithmGroup = NULL;
    if (m_algorithm && m_algorithm->hasSettingsDialog())
    {
        algorithmGroup = new QGroupBox("Algorithm settings");
        QVBoxLayout *algorithmLayout = new QVBoxLayout(algorithmGroup);
        
        QPushButton *btnAlgorithmSettings = new QPushButton("Settings ...", this);
        connect(btnAlgorithmSettings, SIGNAL(clicked()), this, SLOT(algorithmSettings()));
        
        algorithmLayout->addWidget(btnAlgorithmSettings);
    }

// draw algorithm
    QGroupBox *drawGroup = NULL;
    if (!drawAlgorithmList.isEmpty())
    {
        drawGroup = new QGroupBox("Drawing algorithm");
        QVBoxLayout *drawLayout = new QVBoxLayout(drawGroup);

        m_comboDrawList = new QComboBox(this);
        m_comboDrawList->addItems(drawAlgorithmList);
        m_comboDrawList->setCurrentIndex(drawAlgorithmList.size()-1);

        drawLayout->addWidget(m_comboDrawList);
    }

// buttons
    QWidget *hBox = new QWidget(this);
    QPushButton *buttonOk = new QPushButton("Ok");
    QPushButton *buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(buttonOk);
    hBoxLayout->addWidget(buttonCancel);
    hBox->setLayout(hBoxLayout);
    connect(buttonOk, SIGNAL(clicked()), this, SLOT(myAccept()));  
    connect(buttonCancel, SIGNAL(clicked()), this, SLOT(reject()));

    buttonOk->setFocus();

// layout    
    int row = 0;
    QGridLayout *layout = new QGridLayout(this);
    if (count != 0)
    {
        layout->addWidget(fileGroup, row++, 0);
        m_checkUseCurrent->setChecked(useCurrent);
    }
    layout->addWidget(globalGroup, row++, 0);
    if (algorithmGroup)
        layout->addWidget(algorithmGroup, row++, 0);
    if (drawGroup)
        layout->addWidget(drawGroup, row++, 0);
    layout->addWidget(hBox, row++, 0);
        
    setWindowTitle(dialogTitle);
}

QStringList LoadAutomataDialog::getFileNames() const
{
    Q_ASSERT(m_count != 0);    
    
    QStringList result;
    
    if (m_count == 0)
        return result;
    
    for (int i=0; i<m_count; ++i)
    {
        result << m_fileEdits[i]->text();
    }

    return result;
}

bool LoadAutomataDialog::useCurrentAutomaton() const
{
    Q_ASSERT(m_count != 0);
    
    if (m_count == 0)
        return true;
        
    return m_checkUseCurrent->isChecked();
}

int LoadAutomataDialog::getDrawAlgorithmIndex() const
{
    if (!m_comboDrawList) return 0;

    return m_comboDrawList->currentIndex();
}

void LoadAutomataDialog::setDrawAlgorithmIndex(int index)
{
    Q_ASSERT(m_comboDrawList && m_comboDrawList->count() > index);

    m_comboDrawList->setCurrentIndex(index);
}

bool LoadAutomataDialog::alphabetIsSet() const
{
    return !m_checkAlphabet->isChecked();
}

bool LoadAutomataDialog::alphabetSymbolIsSet() const
{
    return !m_checkAlphabetSymbol->isChecked();
}

bool LoadAutomataDialog::epsilonSymbolIsSet() const
{
    return !m_checkEpsilonSymbol->isChecked();
}

ITransition::TCharSet LoadAutomataDialog::getAlphabet() const
{
    Q_ASSERT(!m_alphabet.empty());
    
    DBGLOG(DBGPAR(m_alphabet));
    return m_alphabet;
}

QString LoadAutomataDialog::getAlphabetSymbol() const
{
    Q_ASSERT(alphabetSymbolIsSet());
    
    DBGLOG(DBGPAR(m_alphabetSymbol));
    return m_alphabetSymbol;
}

QString LoadAutomataDialog::getEpsilonSymbol() const
{
    Q_ASSERT(epsilonSymbolIsSet());
    
    DBGLOG(DBGPAR(m_epsilonSymbol));
    return m_epsilonSymbol;
}

//slots:
void LoadAutomataDialog::myAccept()
{
    bool okFiles = true;
    bool okSettings = true;
    
    if (m_count != 0)
    {
        Q_ASSERT(!m_fileEdits.empty());
        
        if (!m_checkUseCurrent->isChecked())
            okFiles &= (m_fileEdits[0]->text() != "");

        for (int i=1; i<m_count; i++)
        {        
            okFiles &= (m_fileEdits[i]->text() != "");
        }
    }

    if ((!m_checkAlphabet->isChecked() && m_edtAlphabet->text() == "") ||
        (!m_checkAlphabetSymbol->isChecked() && m_edtAlphabetSymbol->text() == "") ||
        (!m_checkEpsilonSymbol->isChecked() && m_edtEpsilonSymbol->text() == ""))
    {
        okSettings = false;
    }
    
    if (!m_checkAlphabetSymbol->isChecked())
    {
        m_alphabetSymbol = Editor::parseCharacter(m_edtAlphabetSymbol->text());
        DBGLOG(DBGPAR(m_alphabetSymbol));
        okSettings == okSettings && (m_alphabetSymbol != "");
    }

    if (!m_checkEpsilonSymbol->isChecked())
    {
        m_epsilonSymbol = Editor::parseCharacter(m_edtEpsilonSymbol->text());
        DBGLOG(DBGPAR(m_epsilonSymbol));
        okSettings == okSettings && (m_epsilonSymbol != "");
    }
    
    if (!m_checkAlphabet->isChecked())
    {
        m_alphabet = Editor::parseCharSet(m_edtAlphabet->text());
        DBGLOG(DBGPAR(m_alphabet));
        okSettings = okSettings && !m_alphabet.empty();
    
        if (!m_checkAlphabetSymbol)
            okSettings = okSettings && !m_alphabet.contains(m_alphabetSymbol);
        if (!m_checkEpsilonSymbol)
            okSettings = okSettings && !m_alphabet.contains(m_epsilonSymbol);
    }    

    if (okFiles && okSettings)
    {
        accept();
    }
    else
    {
        if (!okFiles)
        {   
            QMessageBox::information(this, "Select all files!",
                                    "Please select all required files or Cancel",
                                    QMessageBox::Ok);
        }
        else // !okSettings
        {
            QMessageBox::information(this, "Fill settings!",
                                 "Please fill required settings correctly or select autodetection.",
                                 QMessageBox::Ok);
        }
    }
}

void LoadAutomataDialog::checkChanged(int state)
{
    Q_ASSERT(!m_fileEdits.empty() && !m_fileButtons.empty());
    
    // TODO: move filled filenames down when checkbox is to be checked or 
    //       remember once selected filename
    
    if (state == Qt::Checked)
    {
        m_fileEdits[0]->setEnabled(false); 
        m_fileButtons[0]->setEnabled(false);
        
        m_fileEdits[0]->setText(m_editorFileName);
    }
    else
    {
        m_fileEdits[0]->setEnabled(true);
        m_fileButtons[0]->setEnabled(true);
    }
}

void LoadAutomataDialog::buttonClicked()
{
    QPushButton *button = qobject_cast<QPushButton *>(sender());
    Q_ASSERT(button);
    
    int i = m_fileButtons.indexOf(button);

    QString fn = QFileDialog::getOpenFileName(0,"Open file", m_lastFileName,
                                              "VauCanSon-G and LaTeX (*.vcg *.tex);;All files (*.*)");
    if (fn != QString::null) 
    {    
        Q_ASSERT(m_fileEdits.count() > i);
        m_fileEdits[i]->setText(fn);
        m_lastFileName = fn.left(fn.lastIndexOf(QRegExp("[/\\\\]")));
    }
}

void LoadAutomataDialog::checkAlphabetChanged(int state)
{
    if (state == Qt::Checked)
    {
        m_edtAlphabet->setEnabled(false);        
    }
    else
    {
        m_edtAlphabet->setEnabled(true);
    }
}

void LoadAutomataDialog::checkAlphabetSymbChanged(int state)
{
    if (state == Qt::Checked)
    {
        m_edtAlphabetSymbol->setEnabled(false);
    }
    else
    {
        m_edtAlphabetSymbol->setEnabled(true);
    }
}

void LoadAutomataDialog::checkEpsilonSymbChanged(int state)
{
    if (state == Qt::Checked)
    {
        m_edtEpsilonSymbol->setEnabled(false);        
    }
    else
    {
        m_edtEpsilonSymbol->setEnabled(true);
    }
}

void LoadAutomataDialog::algorithmSettings()
{
    Q_ASSERT(m_algorithm);    
    m_algorithm->runSettingsDialog();
}

//-------------------------------------------------- LoadAutomataDialog -->



//<-- ReportDialog --------------------------------------------------------

ReportDialog::ReportDialog(const QString &reportText, QWidget *parent)
: QDialog(parent)
{
    QTextEdit *reportEdit = new QTextEdit(reportText, this);
    reportEdit->setReadOnly(true);
    reportEdit->setMinimumSize(600,400);

    QPushButton *closeButton = new QPushButton("&Close", this);
    connect(closeButton, SIGNAL(clicked()), this, SLOT(close()));

    QVBoxLayout *dialogLayout = new QVBoxLayout(this);
    dialogLayout->addWidget(reportEdit);
    dialogLayout->addWidget(closeButton, 0, Qt::AlignHCenter);

    setWindowTitle(QString("Report"));
}

//-------------------------------------------------------- ReportDialog -->
