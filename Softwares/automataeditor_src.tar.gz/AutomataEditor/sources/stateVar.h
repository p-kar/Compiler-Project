#ifndef _STATEVAR_H_532436342435_
#define _STATEVAR_H_532436342435_

#include "state.h"

class StateVar : public State
{
public:
    StateVar(const QPoint &position, Editor *parent, const QString l,
             const QString n, bool dBorder, bool dim);
        
    virtual QString getTypeName() const;
    
    virtual int getWidth() const {return S_W > stringProcessor->getWidth() + VAR_STATE_WIDTH_ADDITION ?
                                         S_W : stringProcessor->getWidth() + VAR_STATE_WIDTH_ADDITION;}
    virtual int getHeight() const {return S_H;}

    virtual void setLabel(const QString &label);

    //! export support functions
    //virtual QString getEPS() const;

    //! implements QGraphicsItems functions
    virtual QPainterPath shape() const;
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

protected:
    virtual void updateMyPolygon();
};

#endif //_STATEVAR_H_532436342435_