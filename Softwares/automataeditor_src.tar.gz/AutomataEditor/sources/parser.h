#ifndef PARSER_H_1467785685834255
#define PARSER_H_1467785685834255

#include <QString>
#include <QStringList>
#include <QRect>

// logging enabled/disabled
#ifdef TESTING_LEXER
#   define DBGLOG_LEX(x) DBGLOG_("LEXER", x)
#else
#   define DBGLOG_LEX(x)
#endif
#ifdef TESTING_PARSER
#   define DBGLOG_PAR(x) DBGLOG_("PARSER", x)
#else
#   define DBGLOG_PAR(x)
#endif

class QFile;
class Editor;
class Transition;
class State;

namespace VaucansonKeywords
{

enum Token {IDENT, COMMENT, NUMB, FLOAT, MINUS, EQUAL, DOT,
            COMMA, LPAR, RPAR, LBRACE, RBRACE, LBRACKET, RBRACKET,
            UNDERLINE, SPECIAL, OTHER,
            eFirstKw,
            kwShowGrid = eFirstKw, kwShowFrame, kwHideGrid, kwHideFrame,
            kwVCPut,
            kwBeginVCPicture, kwBegin, kwEnd, kwState, kwFinalState, kwStateVar, kwFinalStateVar,
            kwInitial, kwFinal,
            kwLoopN, kwLoopS, kwLoopE, kwLoopW, kwLoopNE, kwLoopNW, kwLoopSE, kwLoopSW,
            kwCLoopN, kwCLoopS, kwCLoopE, kwCLoopW, kwCLoopNE, kwCLoopNW, kwCLoopSE, kwCLoopSW,
            kwLoopVarN, kwLoopVarS,
            kwVarLoopOn, kwVarLoopOff,
            kwEdgeL, kwEdgeR, kwArcL, kwArcR, kwLArcL, kwLArcR,
            kwVArcL, kwVArcR, kwVCurveL, kwVCurveR,
            kwLabelL, kwLabelR,
            kwDimState, kwRstState, kwDimEdge, kwRstEdge, kwEdgeBorder, kwEdgeBorderOff, 
            kwStateLineDouble, kwStateLineSimple, kwEdgeLineDouble, kwEdgeLineSimple,
            setStateLineStyle, setStateLineWidth, setStateLineColor, setStateLabelColor, setStateLabelScale,
            setStateFillStatus, setStateFillColor,
            setEdgeLineStyle, setEdgeLineWidth, setEdgeLineColor, setEdgeLabelColor, setEdgeLabelScale,
            chgStateLineStyle, chgStateLineWidth, chgStateLineColor, chgStateLabelColor, chgStateLabelScale,
            chgStateFillStatus, chgStateFillColor,
            chgEdgeLineStyle, chgEdgeLineWidth, chgEdgeLineColor, chgEdgeLabelColor, chgEdgeLabelScale,
            rstStateLineStyle, rstStateLineWidth, rstStateLineColor, rstStateLabelColor, rstStateLabelScale,
            rstStateFillStatus, rstStateFillColor,
            rstEdgeLineStyle, rstEdgeLineWidth, rstEdgeLineColor, rstEdgeLabelColor, rstEdgeLabelScale,
            fixDimState, fixStateLineDouble, fixDimEdge, fixEdgeBorder, fixEdgeLineDouble,
            eLastKw = fixEdgeLineDouble,
            ERR,EOI};
};


/*!
 * Lexical analyzer used for splitting lexical symbols from input 'stream'.
 */
class LexAn
{
public:
    typedef QMap<QString, VaucansonKeywords::Token>    TKeywordMap;    
    static TKeywordMap keywordMap;
    static void initialize();
    
    LexAn();
    ~LexAn();
  
    //! opens input file, returns false if opening fails
    bool openFile(const QString &fn);

    //! reads string between characters pair, if allowMatching is false,
    //! first closing character stops reading, otherwise balances matching is used
    //! never call matching on opening character, but ever call matching to closing character!
    QString readStringBetween(const QChar &opening, const QChar &closing, bool allowMatching = true);
    //! reads single new token
    VaucansonKeywords::Token readToken();
    //! returns last readed token
    VaucansonKeywords::Token getToken();
    //! returns token data
    QString getTokenData();
    //! returns current line number
    int getLineNumber();
  
private:
    QFile *inFile;
    bool fileOpened;
  
    char input; // type of input character (n - number, c - char, e - EOI, ...)
    unsigned char character;  // read character
    int       lineNumber;
    char      line[1024];     // read line
    int       lineIndex;      // index of currently read character
    int       lineLength;     // currentyl read line length  
    VaucansonKeywords::Token token;
    QString tokenData;
  
    char readChar();
    VaucansonKeywords::Token keyWordTest(const QString &tokenData);    
    bool isAllowed(char character);
};



/*!
 *   Parser implemented by recursive descending method.
 */
class Parser
{  
public: 
    Parser(Editor *editor, bool canChangeEditor = true);
    ~Parser();
    
    //! fill created states (with assigned transitions) -> editor will add it all to scene or
    //! do with it something other
    bool run(const QString &filename, QList<State*> &stateList, QRect &gridRect);

    inline QString getReport() const
    {
        return report.join("<br>");
    }

    //! Returns true if name is in correct form, otherwise returns false
    //! \param error - sets error string if not NULL
    //! \sa Parser::Name, NameAcceptDialog::myAccept
    static bool checkNameCorrectness(const QString &name, QString *error);
    
protected:
    Editor *editor;
    LexAn *lexan;    

    bool    m_canChangeEditor;
    Transition *lastTr; // for Label element addition
    
    QMap<QString, State*>    m_stateMap;
    QRect                    m_gridRect;    

    QStringList report;
    int err_count, war_count;

    bool loaded;
  
    // switches
    bool dimState;
    bool dimEdge;
    bool edgeBorder;
    bool stateLineDouble;
    bool varLoop;
    
    void resetParams();
    
    // parameters which can be changed
    // state parameters
    Qt::PenStyle stateLineStyle;
    float stateLineWidth;
    QString stateLineColor;
    QString stateLabelColor;
    float stateLabelScale;
    Qt::BrushStyle stateFillStatus;
    QString stateFillColor;
    // edge parameters
    Qt::PenStyle edgeLineStyle;
    float edgeLineWidth;
    QString edgeLineColor;
    QString edgeLabelColor;
    float edgeLabelScale;
    bool edgeLineDblStatus;
  
    // state parametres preset
    float stateLineDoubleCoef;
    float stateLineDoubleSep;
    // transition parametres preset
    float edgeLineBorderCoef;
    QString edgeLineBorderColor;
    float edgeLineDblCoef;
    float edgeLineDblSep;
  
    // state parametres dimmed
    Qt::PenStyle dimStateLineStyle;
    QString dimStateLineColor;
    float dimStateLineCoef;
    QString dimStateLabelColor;
    QString dimStateFillColor;
    // transition parametres dimmed
    Qt::PenStyle dimEdgeLineStyle;
    QString dimEdgeLineColor;
    float dimEdgeLineCoef;
    QString dimEdgeLabelColor;
  
    // object params
    QString param;
  
    struct CurveParam{
        int angleA; bool isAngleA;
        int angleB; bool isAngleB;
        float ncurv; bool isNCurv;
    } cParam;
  
    void matching(VaucansonKeywords::Token token, bool end = false);

    void checkTrParam(Transition *tr);
    bool kwTest(VaucansonKeywords::Token token);

    void resetStateParams();
    void resetTrParams();

    // functions of recurcive descent
    void File();
    void Predeclaration();
    void VCPicture();
    void VCPut();
    bool Element();
    void Switch();
    void ChgParam();
    Qt::BrushStyle FillStatus();
    Qt::PenStyle LineStyle();
    QString Color();
    void State_r();
    void StateDeclaration(const QString &typeName);
    void StateLabel();
    void Transition_r();
    void Label_r();
    void OneStateTransition();
    int Loop();
    void TwoStateTransition();
    bool Edge();
    bool Arc(bool &small);
    bool VArc();
    bool VCurve();
    void VArcParam();
    void VArcParamNext();
    void VArcParamIdent();
    void VCurveParam();
    void VCurveParamNext();
    void VCurveParamIdent();
    void EndTransitionDeclaration(const QString &typeName, bool left, float pos, bool isPosParam);
    void TransitionLabel();
    void NextLabel(); // next transition label
    float PosParam(bool &isParam);
    float Pos(bool &isParam);
    int DirParam(bool &isParam);
    int Dir(bool &isParam);
    float Number();
    float NumberNextPart();
    int Numb();
    bool Sign();
    void Name();
    void NameNextPart();
    void NameAllowedToken();
    bool NoBracesToken();
    bool NoBracketsToken();

    inline void errorReportUTOKEN()
    {
        report << QString("%1: Error %2 - Unexpected token '%3'")
            .arg(lexan->getLineNumber())
            .arg(++err_count)
            .arg(lexan->getTokenData());
    }
};

#endif
