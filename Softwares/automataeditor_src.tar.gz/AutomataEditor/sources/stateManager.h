#ifndef _STATEMANAGER_H_4684351181311_
#define _STATEMANAGER_H_4684351181311_

class State;
class StateDialog;
class Editor;

class QPoint;
#include <QList>
#include <QMap>

/*!
 * Creates concrete state and returns State supertype.
 * Implemented as singelton.
 */
class StateManager
{
private:
    static bool instantiated;
    static StateManager *manager;
    StateManager();

public:
    ~StateManager()
    {
        instantiated = false;
    }

    //! returns states type list, used for dialog (filling comboBox)
    const QList<QString> &getTypeNameList() const;

    //! returns typeID by given typeName - important to hold elements's types consistent
    int getTypeNameId(const QString &typeName) const;    

    static StateManager* getInstance(); //!< returns instance of StateManager

    State* createState(Editor *editor, const QPoint& pos, const StateDialog& sd);   //!< returns State type
    //! overloaded function for parser needs
    State* createState(const QString& typeName, Editor *editor, const QPoint& pos, 
                       const QString& label, const QString& name, bool dimmed);

protected:
    //! createConcreteState methods
    State* createStateNormal(Editor *editor, const QPoint& pos, const QString& label, 
                             const QString& name, bool dimmed);
    State* createStateNormalFinal(Editor *editor, const QPoint& pos, const QString& label, 
                                  const QString& name, bool dimmed);
    State* createStateVar(Editor *editor, const QPoint& pos, const QString& label, 
                          const QString& name, bool dimmed);
    State* createStateVarFinal(Editor *editor, const QPoint& pos, const QString& label, 
                               const QString& name, bool dimmed);

    QList<QString> stateTypeList;
    //! pointer to StateManager::createConcreteState
    typedef State* (StateManager::*StateConstructor)
        (Editor *editor, const QPoint& pos, const QString&, const QString&, bool);
    typedef QMap<QString, StateConstructor> TypeNameToInstanceMap;
    TypeNameToInstanceMap typeNameToInstanceMap; //!< maps type name to State createConcreteState function
};

#endif //_STATEMANAGER_H_4684351181311_
