#include "constants.h"

#include "automataWorkSimulator.h"
#include "editor.h"
#include "stringProcessor.h"
#include "utils.h"
#include "scopedsetter.h" // utility

#include <QRubberBand>
#include <QPainterPath>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTableWidget>
#include <QGridLayout>
#include <QList>
#include <QVector>
#include <QTextEdit>
#include <QCheckBox>
#include <QDoubleSpinBox>
#include <QMessageBox>
#include <QTimer>
#include <QCoreApplication>
#include <QUndoStack>
#include <QFileDialog>

#ifdef TESTING_ANIMATIONS
#   define DBGLOG_ANIM(x) DBGLOG_("ANIMATIONS", x)
#else
#   define DBGLOG_ANIM(x)
#endif

//<-- SimulationMarker ----------------------------------------------------

// TODO: marker doesn't seem much well, maybe implement it rather using QGraphicsItem
/*!
 * Marks active states during simulation process. One marker for each active state.
 */
class SimulationMarker : public QRubberBand        
{
public:
    SimulationMarker(const QPainterPath &path, Shape s, QWidget *p = 0)
    : QRubberBand(s, p), m_pos(0.0f), m_path(path), m_moveStep(0.05f)
    {
        updatePosition();
    }
    
    void setPos(float pos)
    {
        m_pos = pos;
        updatePosition();
    }
    
    float pos()
    {
        return m_pos;
    }
    
    void setMoveStep(float step)
    {
        m_moveStep = step;
    }
    
    bool moveByStep()
    {
        m_pos += m_moveStep;
        if (m_pos >= 1.0f)
            return false;
        
        updatePosition();
        return true;
    }
    
    void setPath(const QPainterPath &path)
    {
        m_path = path;
        // updatePosition(); // should be neccesary maybe when dynamic paths will be used ;-)
    }
    
public:
    static const float  width;
    static const float  height;    
    
protected:
    void updatePosition()
    {
        QPointF point = m_path.pointAtPercent(m_pos);
        setGeometry(point.x()-width/2, point.y()-height/2, width, height);
    }

    void paintEvent(QPaintEvent * /*event*/)
    {
        // TODO: implement better for OpenGL usage!!! - currently problem with drawing
        QPainter painter(this);        
        painter.setPen(Qt::NoPen);

#ifndef DONT_USE_OPENGL_RENDERING // hack due to rendering problems - now seems better
        painter.fillRect(QRectF(0, 0, width, height), QColor(255, 255, 255, 255));
#endif

        painter.setBrush(QColor(50, 50, 200, 80));
        painter.drawEllipse(QRectF(0, 0, width, height));
    }
    
    QPointF         m_center;
    float           m_pos;
    QPainterPath    m_path;
    float           m_moveStep;
};

const float SimulationMarker::width      = 10.0f;
const float SimulationMarker::height     = 10.0f;

//---------------------------------------------------- SimulationMarker -->



//<-- AutomataWorkSimulator -----------------------------------------------

AutomataWorkSimulator::AutomataWorkSimulator(Editor *editor, QUndoStack &undoStack,
                                             const QSharedPointer<AutomatonImpl> &automaton)
:   m_editor(editor), m_undoStack(undoStack), m_undoStackStartIdx(undoStack.index()),
    m_automaton(automaton), m_status(Configuration::eNoStatus),
    m_inputIndex(0), m_dialog(new SimulationDialog(editor, this)),
    m_activeStatesAreMarked(false), m_simulationTimer(new QTimer(this)), 
    m_playing(false), m_animationTimer(new QTimer(this)),
    m_useAnimations(USE_ANIMS_BY_DEFAULT), m_animationSpeed(ANIM_SPEED_DEFAULT)
{    
    DBGLOG(DBGPAR(m_undoStackStartIdx));

    m_simulationTimer->setInterval(SIMULATION_STEP_DEFAULT * 1000);
    connect(m_simulationTimer.data(), SIGNAL(timeout()), this, SLOT(processStep()));
    
    m_animationTimer->setInterval(ANIMATION_FRAME_TIME);
    connect(m_animationTimer.data(), SIGNAL(timeout()), this, SLOT(animate()));
    
    connect(m_dialog.data(), SIGNAL(closed()), this, SLOT(dialogClosed()));
    connect(m_dialog.data(), SIGNAL(useAnimChanged(int)), this, SLOT(useAnimChanged(int)));
    connect(m_dialog.data(), SIGNAL(animSpeedChanged(double)), this, SLOT(animSpeedChanged(double)));
    connect(m_dialog.data(), SIGNAL(stepSpeedChanged(double)), this, SLOT(stepSpeedChanged(double)));
}

AutomataWorkSimulator::~AutomataWorkSimulator()
{
    DBGLOG("called");
    foreach(SimulationMarker *sm, m_markers)
    {
        delete sm;
    }
    
    m_markers.clear();
}

bool AutomataWorkSimulator::hasStateBefore() const
{
    return (m_inputIndex > 0);
}

bool AutomataWorkSimulator::hasStateAfter() const
{
    // m_inputIndex is increased after process input, so value
    // equals to next processing character's index
    return (m_inputIndex < m_inputList.count() &&            
            !(m_status == Configuration::eError && m_backSteps == 0)); // error aplied only if not replayed
}

bool AutomataWorkSimulator::isPlaying() const
{
    Q_ASSERT(m_simulationTimer->isActive() == m_playing);
    return m_playing;
}

bool AutomataWorkSimulator::isSet() const
{
    return !m_inputList.empty();
}

int AutomataWorkSimulator::getPos() const
{
    if (m_inputList.isEmpty()) return 0;
    if (m_inputIndex == m_inputList.size()) return m_dialog->getInputLength();
    
    int result = m_inputList[m_inputIndex].textIdx;
    return result;
}

AutomataWorkSimulator::TConfigurationList AutomataWorkSimulator::getConfigurations() const
{
    return m_configurationList.mid(0, m_inputIndex + 1);
}

void AutomataWorkSimulator::run()
{    
    m_dialog->show();
    reset();
}

bool AutomataWorkSimulator::setInput(const QString &text)
{
    ITransition::TCharSet alphabet = m_automaton->getAlphabet();
    
    m_inputList = StringProcessor::computeCharacterList(text);
    Q_ASSERT(!(text != "" && m_inputList.empty()));
        
    foreach(const StringProcessor::CharacterInfo &c, m_inputList)
    {
        if (!alphabet.contains(c.character))
        {
            m_inputList.clear();
            return false;
        }
    }

    Q_ASSERT(!m_automaton->getActiveStates().isEmpty());    
    m_configurationList << Configuration(m_automaton->getActiveStatesNames(),
                                         QStringList(AutomataCreator::defaultEpsilonSymbList[0]),
                                         StringProcessor::parseSymbols(m_inputList),
                                         m_automaton->isConfigurationAccepted() ? Configuration::eAccepted : Configuration::eNoStatus);
    
    m_dialog->updateState();
    
    return true;
}

void AutomataWorkSimulator::stepForward()
{
    if (isPlaying())
        pause();
        
    Q_ASSERT(!m_animationTimer->isActive());

    processStep();
}

void AutomataWorkSimulator::stepBackward()
{
    if (isPlaying())
        pause();

    Q_ASSERT(!m_animationTimer->isActive());

    Q_ASSERT(m_inputIndex > 0);
    if (m_inputIndex == 0) return;
    
    m_backSteps++;
    m_inputIndex--;
    
    m_editor->undo(); // unmark states
    
    if (m_useAnimations) // if statement due to revertPaths calling
        doAnimation(revertPaths(m_animationPathMemory[m_animationPathMemory.count()-m_backSteps]));
    
    m_editor->undo(); // mark states
    
    m_activeStates = m_activeStatesMemory[m_activeStatesMemory.count()-m_backSteps];
    
    m_dialog->updateState();
}

void AutomataWorkSimulator::play()
{
    Q_ASSERT(!m_animationTimer->isActive());
    
    // keep timer start calling before processStep because of logic in processStep!!!
    m_simulationTimer->start();
    m_playing = true;
    
    m_dialog->updateState();
    
    processStep(); // first step procces right now
}

void AutomataWorkSimulator::pause()
{
    if (m_playing)
    {
        m_playing = false;
        m_simulationTimer->stop();
    }

    m_dialog->updateState();
}

void AutomataWorkSimulator::reset()
{
    Q_ASSERT(!m_animationTimer->isActive());
    
    m_playing = false;
    m_simulationTimer->stop();

#ifdef RESET_UNDO_STACK_AFTER_SIMULATION
    m_undoStack.setIndex(m_undoStackStartIdx);
    m_activeStatesAreMarked = false;
#else
    setActiveStatesMarked(false);
#endif

    m_status = Configuration::eNoStatus;
    m_inputIndex = 0;
    m_inputList.clear();
    m_backSteps = 0;
    m_animationPathMemory.clear();
    m_configurationList.clear();

    m_automaton->reset();
        
    m_activeStates = m_automaton->getPrivateActiveStates();
    setActiveStatesMarked(true);

    m_activeStatesMemory.clear();

    m_dialog->updateState();
}

void AutomataWorkSimulator::doAnimation(const QList<QPainterPath> &paths)
{
    if (m_useAnimations)
    {        
        m_pathCount = paths.count();
        for (int i = 0; i < m_pathCount; ++i) // create enough of markers when required
        {
            if (i < m_markers.count())
            {
                m_markers[i]->setPath(paths[i]);
                m_markers[i]->setPos(0.0f);
            }
            else
            {
                m_markers << new SimulationMarker(paths[i], QRubberBand::Line, m_editor);
            }
            
            m_markers[i]->setMoveStep(ANIMATION_FRAME_TIME / m_animationSpeed);
            m_markers[i]->show();
        }
    
        m_animationState = eMoving;
        m_animationTimer->start();
        animate();
        
        // wait until animation is finished ( process only timer event! )
        while (m_animationTimer->isActive()) { QCoreApplication::processEvents(QEventLoop::ExcludeUserInputEvents); } 

        for (int i = 0; i < paths.count(); ++i)
        {
            m_markers[i]->hide();
        }        
    }
}

void AutomataWorkSimulator::animate()
{
    DBGLOG_ANIM("called");
    switch(m_animationState)
    {    
    case eMoving:
        if (!animateMove())
            m_animationState = eStopped;
        break;
    case eStopped:
        m_animationTimer->stop();
        break;
    }
    
    m_editor->update();
}

bool AutomataWorkSimulator::animateMove()
{
    bool resume = false;
    Q_ASSERT(m_pathCount <= m_markers.count());
    for(int i=0; i < m_pathCount; ++i)
    {
        resume |= m_markers[i]->moveByStep();
    }    
    
    DBGLOG_ANIM(DBGPAR(resume));
    return resume;
}

void AutomataWorkSimulator::refreshPlayingStatus()
{
    if (!m_playing) return;
     
    if (m_inputIndex != m_inputList.count())    // don't run again if processing is finished
        m_simulationTimer->start();
    else
        m_playing = false;                      // playing not possible - stop
}

void AutomataWorkSimulator::processStep()
{    
    m_simulationTimer->stop(); // ever stop! - due to bug when processing is longer than timer interval!
    
    if (m_backSteps > 0)
    {
        m_editor->redo(); // unmark states
                
        doAnimation(m_animationPathMemory[m_animationPathMemory.count()-m_backSteps]);
        
        m_editor->redo(); // mark states
        m_backSteps--;
        m_inputIndex++;
       
        m_activeStates = m_activeStatesMemory[m_activeStatesMemory.count()-1-m_backSteps];
       
        refreshPlayingStatus();
        
        m_dialog->updateState();
        return;
    }

    Q_ASSERT(m_inputIndex < m_inputList.count());
    QString currentCharacter = m_inputList[m_inputIndex].character;
        
    QList<QPainterPath>                 animationPaths;
    IState::TIStateNameSet              newActiveStatesNames = 
        m_automaton->processCharacterWithInfo(currentCharacter, animationPaths);
    StateImpl::TStateList               newActiveStates =
        m_automaton->getPrivateActiveStates();
    
    setActiveStatesMarked(false); // unmark states
    
    for(int i=0; i<animationPaths.count(); ++i)
    {
        animationPaths[i] = m_editor->mapFromScene(animationPaths[i]);
    }    
    doAnimation(animationPaths); // blocking method waiting until animation is done
    
    m_activeStates = newActiveStates;
    setActiveStatesMarked(true); // makr states

    m_inputIndex++;    
    
    if (m_activeStates.empty()) // no more states available, not possible processing input
    {
        m_status = Configuration::eError;
    }
    else if(m_automaton->isConfigurationAccepted())
    {
        m_status = Configuration::eAccepted;
    }
    else
    {
        m_status = Configuration::eNoStatus;
    }
    
    QStringList remainingString(m_inputIndex == m_inputList.count() ?
                                QStringList(AutomataCreator::defaultEpsilonSymbList[0]) :
                                StringProcessor::parseSymbols((m_inputList.mid(m_inputIndex))));
    m_configurationList << Configuration(m_automaton->getActiveStatesNames(),
                                         m_automaton->getProcessedString(),
                                         remainingString,
                                         m_status);
    
    m_activeStatesMemory << m_activeStates; // TODO: is this array necessary?
    
    // store for enabling animations when using undo/redo    
    m_animationPathMemory << animationPaths;
    
    refreshPlayingStatus();
    
    m_dialog->updateState();
}

void AutomataWorkSimulator::setActiveStatesMarked(bool marked)
{
    if (m_activeStatesAreMarked == marked) return;
    
    QList<State*> statesToBeMarked;
    foreach(const QSharedPointer<StateImpl> &state, m_activeStates)
    {
        State *graphicsState = state->getGraphicsState();
        Q_ASSERT(graphicsState);
        statesToBeMarked << graphicsState;
    }
    
    emit setStatesMarked(statesToBeMarked, marked);
    
    m_activeStatesAreMarked = marked;
    m_editor->update();
}

void AutomataWorkSimulator::stepSpeedChanged(double val)
{
    m_simulationTimer->setInterval(val * 1000);
}

void AutomataWorkSimulator::animSpeedChanged(double val)
{
    m_animationSpeed = val;    
}

void AutomataWorkSimulator::useAnimChanged(int state)
{
    m_useAnimations = (state == Qt::Checked);
}

void AutomataWorkSimulator::dialogClosed()
{   
#ifdef RESET_UNDO_STACK 
    m_undoStack.setIndex(m_undoStackStartIdx);
    m_activeStatesAreMarked = false;
#else
    setActiveStatesMarked(false);
#endif
    emit finished();
}

QList<QPainterPath> AutomataWorkSimulator::revertPaths(const QList<QPainterPath> &paths) const
{
    QList<QPainterPath> result;    
    
    foreach(const QPainterPath &path, paths)
    {
        result << path.toReversed();
    }
    
    return result;
}

bool AutomataWorkSimulator::getFileName(QString &fileName, bool &latexHeader)
{
    fileName = "";
    latexHeader = false;
    
    QStringList formats;
    formats << tr("LaTeX file (*.tex)")
            << tr("LaTeX file w/o head and tail (*.tex)")
            << tr("VauCanSon-G (*.vcg)");
    
    QString filter;
    fileName = QFileDialog::getSaveFileName(m_dialog.data(), "Save file", "slideshow",
        formats.join(";;"), &filter);
    
    if (fileName == "") return false;
    
    if (filter == formats[0] || filter == formats[1])
    {
        appendFilenameSuffix(fileName, "tex");
        if (filter == formats[0]) latexHeader = true;
    }    
    else if (filter == formats[2])
    {
        appendFilenameSuffix(fileName, "vcg");
    }
    else
    {
        RELLOG("Incorrect filter, please report bug to developer");
        Q_ASSERT(0);
        return false;
    }
        
    return true;
}

void AutomataWorkSimulator::generateSlideshow()
{
    // TODO: implement configuratin exporting too!
    DBGLOG("Slideshow generating ...");

    ScopedSetter<bool> scopedSetter(m_useAnimations, false); // turn off animations for this scope
    
    reset();
    if (!setInput(m_dialog->getInput()))
    {
        SimulationDialog::showMessageSetInputFailed(m_dialog.data());
        return;
    }
    
    QString fileName;
    bool latexHeader;
    if (!getFileName(fileName, latexHeader)) return;
    
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly))
    {
        RELLOG("Unable to save file " << fileName << ".");
        return;
    }
    QTextStream out(&file);        
    
    if (latexHeader)
        m_editor->saveLaTeXHeader(out);
    
    out << "% Global slideshow settings" << endl;
    m_editor->saveVCSettings(out);
    out << endl;
    
    int frameNum = 0;
    out << "% FRAME NUMBER " << ++frameNum << endl;
    // current state
    m_editor->saveHeader(out);
    saveInputState(out);
    m_editor->saveGraph(out);
    m_editor->saveFooter(out);
    
    while (hasStateAfter())
    {
        processStep();
        out << endl;
        out << "% FRAME NUMBER " << ++frameNum << endl;
        m_editor->saveHeader(out);
        saveInputState(out);
        m_editor->saveGraph(out);
        m_editor->saveFooter(out);
    }        
    
    if (latexHeader)
        m_editor->saveLaTeXFooter(out);
    
    out.setDevice(0);
    file.close();
    
    DBGLOG("Slideshow generated sucessfully");
}

void AutomataWorkSimulator::saveInputState(QTextStream &out)
{
    const int x_pos = m_editor->getGridRect().x() + 1;
    const int y_pos = m_editor->getGridRect().y() + m_editor->getGridRect().height() + 1;

    out << "\\VCPut{(" << x_pos << "," << y_pos << ")}" << "{";

    DBGLOG(DBGPAR(m_inputIndex));

    if (m_inputIndex > 0)
        out << "\\textbf{";
    int i = 0;
    for (; i < m_inputIndex; ++i)
    {
        Q_ASSERT(i < m_inputList.count());
        StringProcessor::CharacterInfo ci = m_inputList[i];
        QString symb = StringProcessor::isSpecialSymbol(ci.character) ? "$%1$" : "%1";
        out << symb.arg(ci.character);
    }
    if (m_inputIndex > 0)
        out << "}";
    for (; i < m_inputList.count(); ++i)
    {
        StringProcessor::CharacterInfo ci = m_inputList[i];
        QString symb = StringProcessor::isSpecialSymbol(ci.character) ? "$%1$" : "%1";
        out << symb.arg(ci.character);
    }

    out << "}" << endl;
}

//----------------------------------------------- AutomataWorkSimulator -->



//<-- SimulationDialog ----------------------------------------------------

SimulationDialog::SimulationDialog(Editor *editor, AutomataWorkSimulator *simulator)
: QDialog(editor), m_editor(editor), m_simulator(simulator), m_bUsePrettyPrint(true)
{
    m_edtInput = new QLineEdit(this);
    m_edtInput->setReadOnly(false);
    const QString inputTip = "Input syntax: '[character][character]...' (e.g.: 'abc')\n"
                             "Note that special symbols is connected as in LaTeX (e.g. '\\alpha\\beta{}c')";
    m_edtInput->setToolTip(inputTip);
    m_edtInput->setWhatsThis(inputTip);
    
    m_btnStepBack = new QPushButton(QIcon(":images/stepBack.png"), "", this);
    m_btnStepBack->setToolTip(tr("Step backward"));
    m_btnStepBack->setEnabled(false);
    connect(m_btnStepBack, SIGNAL(clicked()), simulator, SLOT(stepBackward()));
    
    m_btnStepFwd = new QPushButton(QIcon(":images/stepFwd.png"), "", this);
    m_btnStepFwd->setToolTip(tr("Step forward"));
    connect(m_btnStepFwd, SIGNAL(clicked()), this, SLOT(stepForward()));
    
    m_btnPlay = new QPushButton(QIcon(":images/play.png"), "", this);
    m_btnPlay->setToolTip(tr("Simulate"));
    connect(m_btnPlay, SIGNAL(clicked()), this, SLOT(play()));
    
    m_btnPause = new QPushButton(QIcon(":images/pause.png"), "", this);
    m_btnPause->setToolTip(tr("Pause"));
    m_btnPause->setEnabled(false);
    connect(m_btnPause, SIGNAL(clicked()), simulator, SLOT(pause()));
    
    m_btnReset = new QPushButton(QIcon(":images/stop.png"), "", this);
    m_btnReset->setToolTip(tr("Reset"));
    m_btnReset->setEnabled(false);
    connect(m_btnReset, SIGNAL(clicked()), simulator, SLOT(reset()));
    
    m_textSimulation = new QTextEdit(this);
    m_textSimulation->setReadOnly(true);
    
    QLabel *lblStepSpeed = new QLabel("Step speed:", this);
    m_stepSpeed = new QDoubleSpinBox(this);
    m_stepSpeed->setRange(SIMULATION_STEP_MIN, SIMULATION_STEP_MAX);
    m_stepSpeed->setValue(SIMULATION_STEP_DEFAULT);
    m_stepSpeed->setSingleStep(0.1);
    m_stepSpeed->setDecimals(1);
    m_stepSpeed->setSuffix(" s");
    connect(m_stepSpeed, SIGNAL(valueChanged(double)), this, SIGNAL(stepSpeedChanged(double)));
    
    QLabel *lblAnimSpeed = new QLabel("Animation speed:", this);
    m_animSpeed = new QDoubleSpinBox(this);
    m_animSpeed->setRange(ANIM_SPEED_MIN, ANIM_SPEED_MAX);
    m_animSpeed->setValue(ANIM_SPEED_DEFAULT);
    m_animSpeed->setSingleStep(50);
    m_animSpeed->setDecimals(0);
    m_animSpeed->setSuffix(" ms");
    connect(m_animSpeed, SIGNAL(valueChanged(double)), this, SIGNAL(animSpeedChanged(double)));
    
    m_checkUseAnim = new QCheckBox("Use animations", this);
    m_checkUseAnim->setChecked(true);
    connect(m_checkUseAnim, SIGNAL(stateChanged(int)), this, SIGNAL(useAnimChanged(int)));
    
    m_checkPrettyPrint = new QCheckBox("Pretty printing", this);
    m_checkPrettyPrint->setChecked(true);
    connect(m_checkPrettyPrint, SIGNAL(stateChanged(int)), this, SLOT(prettyPrintChanged(int)));
    
    m_btnGenerate = new QPushButton("&Generate slideshow", this);
    connect(m_btnGenerate, SIGNAL(clicked()), m_simulator, SLOT(generateSlideshow()));    
    
    QPushButton *closeButton = new QPushButton("&Close", this);
    connect(closeButton, SIGNAL(clicked()), this, SLOT(close()));
    
    connect(this, SIGNAL(accepted()), this, SIGNAL(closed()));
    connect(this, SIGNAL(rejected()), this, SIGNAL(closed()));
        
    QGridLayout *layout = new QGridLayout(this);
    int i = 0;
    layout->addWidget(m_edtInput, i++, 0, 1, 5);                    // \n
    layout->addWidget(m_btnStepBack, i, 0);
    layout->addWidget(m_btnStepFwd, i, 1);
    layout->addWidget(m_btnPlay, i, 2);
    layout->addWidget(m_btnPause, i, 3);
    layout->addWidget(m_btnReset, i++, 4);                          // \n
    layout->addWidget(m_textSimulation, i++, 0, 1, 5);              // \n
    layout->addWidget(lblAnimSpeed, i, 0);
    layout->addWidget(m_animSpeed, i, 1);
    layout->addWidget(m_checkUseAnim, i, 2);                      
    layout->addWidget(m_btnGenerate, i++, 3, 1, 2, Qt::AlignRight);// \n
    layout->addWidget(lblStepSpeed, i, 0);
    layout->addWidget(m_stepSpeed, i, 1); 
    layout->addWidget(m_checkPrettyPrint, i, 2);
    layout->addWidget(closeButton, i++, 3, 1, 2, Qt::AlignRight);   // \n
    
    setWindowTitle(tr("Simulation dialog"));
    setWindowIcon(QIcon(":images/simulating.png"));
}

SimulationDialog::~SimulationDialog()
{
    DBGLOG("called");
}

int SimulationDialog::getInputLength() const
{
    return m_edtInput->text().length();
}

QString SimulationDialog::getInput() const
{
    return m_edtInput->text();
}

void SimulationDialog::updateState()
{
    m_edtInput->setReadOnly(m_simulator->isSet());
    m_btnReset->setEnabled(m_simulator->isSet());
    
    m_btnPause->setEnabled(m_simulator->isPlaying());
    
    m_btnStepBack->setEnabled(m_simulator->hasStateBefore());
    m_btnStepFwd->setEnabled(!m_simulator->isSet() || m_simulator->hasStateAfter());
    m_btnPlay->setEnabled(!m_simulator->isSet() || (m_simulator->hasStateAfter() && !m_simulator->isPlaying()));
    
    int pos = m_simulator->getPos();
    m_edtInput->setSelection(0, pos);
    
    m_textSimulation->clear();
    AutomataWorkSimulator::TConfigurationList info = m_simulator->getConfigurations();
    for(AutomataWorkSimulator::TConfigurationList::ConstIterator confIt = info.begin();
        confIt != info.end();
        ++confIt)
    {
        const AutomataWorkSimulator::Configuration &conf = *confIt;

        appendSymbol("(");
        
        QStringList symbols = conf.activeStates;
        if (symbols.count() > 1) appendSymbol("{");
        bool forFirst = true;
        foreach(const QString &symb, symbols)
        {
            if (!forFirst) appendSymbol(",");
            else forFirst = false;
            appendSymbol(symb);
        }
        if (symbols.count() > 1) appendSymbol("}");
        
        appendSymbol(",");
        
        symbols = conf.processed;
        foreach(const QString &symb, symbols)
        {
            appendSymbol(symb);
        }
        
        appendSymbol(",");
        
        symbols = conf.input;
        foreach(const QString &symb, symbols)
        {
            appendSymbol(symb);
        }
        
        appendSymbol(")");
        if ((confIt+1 != info.end()) || m_simulator->hasStateAfter())
        {
            appendSymbol(" ");
            appendSymbol("\\vdash");
        }
        
        switch(conf.status)
        {
        case AutomataWorkSimulator::Configuration::eAccepted:
            appendSymbol(" ACCEPT");
            break;
        case AutomataWorkSimulator::Configuration::eError:
            appendSymbol(" ERROR");
            break;
        default:
            break;
        }
        appendSymbol("\n");
    }
}

void SimulationDialog::appendSymbol(const QString &symb)
{
    if (!m_bUsePrettyPrint)
    {        
        m_textSimulation->textCursor().insertText(symb);
        if (StringProcessor::isSpecialSymbol(symb))
            m_textSimulation->textCursor().insertText("{}");
        return;
    }
    
    QString curFamily;
    QString symbol;
    const QString prevFamily = m_textSimulation->fontFamily();
    
    symbol = StringProcessor::getSymbolPrintInfo(symb, curFamily);
    
    m_textSimulation->setFontFamily(curFamily);
    m_textSimulation->textCursor().insertText(symbol);
    
    m_textSimulation->setFontFamily(prevFamily);
}

void SimulationDialog::prettyPrintChanged(int status)
{
    m_bUsePrettyPrint = (status == Qt::Checked);
    updateState(); // TODO: create method only for configuration field updating
}

void SimulationDialog::stepForward()
{
    set();
    
    if (!m_simulator->isSet()) return;

    m_simulator->stepForward();
}

void SimulationDialog::play()
{   
    set();
        
    if (!m_simulator->isSet()) return;
        
    m_simulator->play();
}

void SimulationDialog::set()
{
    if (m_simulator->isSet()) return;
    
    if (!setInput())
    {
        showMessageSetInputFailed(this);
        return;
    }
}

bool SimulationDialog::setInput()
{
    if (m_edtInput->text() == "")
        return false;
    
    return m_simulator->setInput(m_edtInput->text());    
}

void SimulationDialog::showMessageSetInputFailed(QWidget *parent)
{
    QMessageBox::information(parent, "Incorrect input",
                             "Please set correct input before running,\n"
                             "Be sure to use only characters in alphabet!",
                             QMessageBox::Ok);
}

//---------------------------------------------------- SimulationDialog -->
