#ifndef _TRANSITIONDIALOGS_H_234896546321_
#define _TRANSITIONDIALOGS_H_234896546321_

#include "stateDialogs.h" // due to NameAcceptDialog predecessor

#include <QDialog>

class Transition;
class Editor;
class LabelX;

class QLineEdit;
class QCheckBox;
class QComboBox;
class QListWidget;

class TransitionDialog : public NameAcceptDialog
{
    Q_OBJECT
public:
    enum EMode {eAdd, eEdit};

    TransitionDialog(EMode mode = eAdd, QWidget* parent = 0);

    QString getLabel() const;
    float getLabelPos() const;
    int getType() const;
    bool isLeftOriented() const;
    bool isRadius() const;
    bool isDimmed() const;
    float getNCurv() const;
    int getArcAngle() const;
    int getArcAngleB() const;

    void setName(const QString& name);
    void setLabelPos(float lp);
    void setDimmed(bool dimmed);
    void setType(int type);
    void setTrOrientation(bool leftOriented);
    void setRadius(bool radius);
    void setNCurv(float ncurv);
    void setArcAngle(int arcA);
    void setArcAngleB(int arcAB);
    
protected:
    QLineEdit* lineLabelPos; 
    QCheckBox* checkDimmed;
    QComboBox* comboType;
    QComboBox* comboOrientation;    
    QLineEdit* edtArcAngle;
    QLineEdit* edtArcAngleB;
    QLineEdit* edtNCurv;    
    
protected slots:    
    void showEdits(int typ);
    
private:
    EMode   m_mode; //!< holds selected mode
};

class TransitionLoopSEDialog : public NameAcceptDialog
{
  Q_OBJECT
public:
  enum EMode {eAdd, eEdit};

  TransitionLoopSEDialog(EMode mode = eAdd, QWidget *parent = 0);
  
  QString getLabel() const;
  float getLabelPos() const;
  bool isDimmed() const;
  int getDirection() const;
  int getType() const;
  
  void setLabel(const QString &lab);
  void setLabelPos(float lp);
  void setDimmed(bool d);
  void setDirection(int d);
  void setType(int typ);
  
protected:
  QLineEdit* lineLabelPos; 
  QComboBox *comboType;
  QComboBox *comboDirection;
  QCheckBox *checkDimmed;  

      
protected slots:
    void showEdits(int typ);
    
private:
    EMode   m_mode; //!< holds selected mode
};

class TransitionExtendedDialog: public QDialog
{
  Q_OBJECT
public:
  TransitionExtendedDialog(QWidget *parent = 0);
  
  void setParams(Transition *tr);

  Qt::PenStyle getLineStyle();
  float getLineWidth();
  QString getLineColor();
  QString getLabelColor();
  float getLabelScale();
  bool getDblStatus();
  
  Qt::PenStyle getDimLineStyle();
  QString getDimLineColor();
  float getDimLineCoef();
  QString getDimLabelColor();
  
  float getLineBorderCoef();
  QString getLineBorderColor();
  
  float getLineDblCoef();
  float getLineDblSep();
  
protected:
  // adjusted
  QComboBox *comboLineStyle;
  QLineEdit *edtLineWidth;
  QLineEdit *edtLineColor;
  QLineEdit *edtLabelColor;
  QLineEdit *edtLabelScale;
  QCheckBox *checkDblStatus;
  // preset
  QComboBox *comboDimLineStyle;
  QLineEdit *edtDimLineColor;
  QLineEdit *edtDimLineCoef;
  QLineEdit *edtDimLabelColor;
  // border
  QLineEdit *edtLineBorderCoef;
  QLineEdit *edtLineBorderColor;
  // double
  QLineEdit *edtLineDblCoef;
  QLineEdit *edtLineDblSep;
};



class NextLabelsDialog : public QDialog
{
    Q_OBJECT
public:
    NextLabelsDialog(Editor *editor, Transition *tr, QWidget *parent = 0);

protected:
    Editor          *m_pEditor;
    Transition      *m_pTransition;
    
    QListWidget     *labelList;
    QPushButton     *btnAdd;
    QPushButton     *btnEdit;
    QPushButton     *btnDelete;

    enum EActionType {eAdd, eEdit};    

    QString getListLine(LabelX *label);

    class NextLabelsEditDialog : public QDialog
    {            
    public:
        NextLabelsEditDialog(EActionType action, QWidget *parent);
        NextLabelsEditDialog(EActionType action, QWidget *parent, const QString& str,
                             float pos, bool left);

        QLineEdit *edtLabel;
        QLineEdit *edtPos;  
        QCheckBox *checkLeft;

    private:
        void init(EActionType action, const QString &str, float pos, bool left);
    };

protected slots:
    void selectionChanged();
    
    void addLabel();
    void editLabel();
    void deleteLabel();
};

#endif //_TRANSITIONDIALOGS_H_234896546321_
