#ifndef MAINWINDOW_H_42312624626347
#define MAINWINDOW_H_42312624626347

#include "editor.h"

#include <QMainWindow>
#include <QDialog>

class QAction;
class QToolBar;
class QMenu;

class IAlgorithmHolder;
class IGraphViz;

class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
  Editor* editor;
 
  void createActions();
  void createMenus();
  void createToolBars();
  void createStatusBar();

  QMenu *fileMenu;
  QMenu *editMenu;
  QMenu *itemsMenu;
  QMenu *toolsMenu;
  QMenu *showMenu;
  QMenu *extraMenu;
  QMenu *helpMenu;
  
  QToolBar *fileToolBar;
  QToolBar *editToolBar;
  QToolBar *zoomToolBar;
  QToolBar *itemsToolBar;
  QToolBar *toolsToolBar;
  QToolBar *showToolBar;
  QToolBar *extraToolBar;
  
  QAction *fileNew;
  QAction *fileOpen;
  QAction *fileSave;
  QAction *fileSaveAs;
  QAction *fileExport;
  QAction *fileQuit;
  
  QAction *editUndo;
  QAction *editRedo;  
  QAction *editShowUndoStack;
  QAction *editCopy;
  QAction *editPaste;
  QAction *editCut;
  QAction *editRemove;
  QAction *zoomIn;
  QAction *zoomOut;
  QAction *resetZoom;
  QAction *editGridRect;
  QAction *editStateParams;
  QAction *editTransitionParams;
  
  QAction *itemsSelection;
  QAction *itemsState;
  QAction *itemsTransition;  
  
  QAction *toolsSnapToGrid;
  QAction *toolsAlignStatesToGrid;  
  QAction *toolsExpandGrid;
  
  QAction *showGrid;
  QAction *showFrame;
  QAction *showAntialias;
  
  QAction *helpAbout;
  QAction *helpAboutQt;
  
  QAction *extraLaTeXTable;
  QAction *extraGeneration;
  QAction *extraSimulation;
  QMenu *algorithmMenu;  


public:
    MainWindow(const QString &fileName = "");
    ~MainWindow() {}
    void setStatusBar(const QString& s);
    void setStatusBar(const QString& s, int ms);    

protected:
  void closeEvent(QCloseEvent *event); // on close maybe save file  

  // for saving
  void addSuffix(QString &fn, Editor::Format f);

  void loadPlugins();
  void processAlgorithmsPlugin(IAlgorithmHolder *algHolder);
  void processGraphVizPlugin(IGraphViz *graphVizWrapper);

private slots:
    // file
    void newFile();
    void openFile();
    bool save();
    bool saveAs();
    void exportTo();

    // edit    
    void undoViewClosed();
    void updateEditMenu();
    void enableEditMenu();
    void copy();
    void paste();
    void cut();
    void remove();
    
    // actions
    void setSelection();    
    void setState();
    void setTransition();

    // tools
    void snapToGrid();
    void alignToGrid();    
  
    //help
    void about();
    void aboutQt();
    
    void actualizeChecking(bool,bool);
    void actionChanged(int);
    
    void setItemsAvailable(bool available);
    void setToolsAvailable(bool available);
    void setUtilsAvailable(bool available);
};

#endif //MAINWINDOW_H_42312624626347
