#ifndef _DRAWALGORITHM_H_7435185424786_
#define _DRAWALGORITHM_H_7435185424786_

#include "idrawalgorithm.h"
#include "igraphviz.h"

//#define USE_TRANSITION_GROUPING_IN_DRAWING_ALGORITHM

/*!
 * Base class for drawing algorithms, provides basic graph algorithms.
 */
class BaseDrawAlgorithm : public IDrawAlgorithm
{
public:
    typedef QMap<QString, unsigned int>     TDistanceMap;
    typedef QMap<QString, QString>          TPredecessorMap;

protected:
    IState::TIStateList getBFSSortedStates(const QSharedPointer<IAutomaton> &automaton) const;

    void fillDijkstraShortestPaths(const QSharedPointer<IAutomaton> &automaton,                     // in
                                   const QString &fromStateName,                                    // in
                                   TDistanceMap &distances, TPredecessorMap &predecessors) const;   // out

    void relax (const QString &u, const QString &v,                                                 // in
                TDistanceMap &distances, TPredecessorMap &predecessors) const;                      // out
    
    void initPaths(const IState::TIStateList &states, const QString& fromStateName,                 // in
                   TDistanceMap &distances, TPredecessorMap &predecessors) const;                   // out
                   
    IState::TIStateNameSet getStatesInDistance(unsigned int distance,                               // in
                                               const TDistanceMap &distances) const;                // out
                                              
    unsigned int getMaxDistance(const TDistanceMap &distances) const;

    void drawTransitions(Editor *editor,                                        // in
                         const Editor::TStateMap &states,                       // in
                         const QSharedPointer<IAutomaton> &automaton,           // in
                         const ITransition::TITransitionList &transitions,      // in
                         const QPoint &startPos) const;                         // in

    QString charactersToLabel(const QSharedPointer<IAutomaton> &automaton,
                              const QSharedPointer<ITransition> &transition) const;

#ifdef USE_TRANSITION_GROUPING_IN_DRAWING_ALGORITHM
    ITransition::TITransitionList getGroupedTransitions(const QSharedPointer<IAutomaton> &automaton) const;    // in
#endif

    static const int X_STEP;
    static const int Y_STEP;
};



/*!
 * Trivial algorithm only for put automaton on scene. Used mainly for testing automaton
 * algorithms correctness.
 */
class NaiveDrawAlgorithm : public BaseDrawAlgorithm
{
public:    
    QList<State*> drawAutomaton(Editor *editor, const QSharedPointer<IAutomaton> &automaton);

    QString getName() const { return "Naive drawing algorithm"; }
};



/*!
 * Heuristic algorithm which is based on finding farthest final state from inital state.
 * This path is then used as backbone. Other states and transitions are placed to area
 * according to count of their count.
 */
class FarthestFinalDrawAlgorithm : public BaseDrawAlgorithm
{
public:
    QList<State*> drawAutomaton(Editor *editor, const QSharedPointer<IAutomaton> &automaton);

    QString getName() const { return "Farthest final state drawing algorithm"; }
};



/*!
 * Drawing algorithm based on GraphViz library. GraphViz layout elements and theirs parameters
 * are used for direct drawing.
 */
class GraphVizDrawAlgorithm : public BaseDrawAlgorithm
{
public:
    GraphVizDrawAlgorithm(IGraphViz *graphVizWrapper);

    QList<State*> drawAutomaton(Editor *editor, const QSharedPointer<IAutomaton> &automaton);

    QString getName() const { return "GraphViz drawing algorithm"; }

protected:
    enum ETransitionType {eLine, eLoop, eCurve};

    void drawTransitionsAccordingToGV(Editor *editor,                                        // in
                                      const Editor::TStateMap &states,                       // in
                                      const QSharedPointer<IAutomaton> &automaton,           // in
                                      const QSharedPointer<IGVGraph> &graph) const;          // in

    IGVEdge::TCPList convertCPToBezierCP(const QSharedPointer<IGVEdge> &edge) const;
    ETransitionType getTransitionType(const QSharedPointer<IGVEdge> &edge, const IGVEdge::TCPList &bezierCP) const;

private:
    IGraphViz   *m_graphVizWrapper;
};

#endif //_DRAWALGORITHM_H_7435185424786_
