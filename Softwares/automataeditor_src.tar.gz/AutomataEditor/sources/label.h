#ifndef LABEL_H_1316851651
#define LABEL_H_1316851651

#include "stringProcessor.h"
#include <QGraphicsItem>

class Transition;

class LabelX : public QGraphicsItem
{
public:
    LabelX(Transition *tr, const QString &text, bool leftOriented, 
           int fontSize = EDGE_LABEL_SIZE*DEF_LABEL_SCALE, 
           const QColor &color = QColor("black"),
           float posParam = DEF_EDGE_LAB_POS, const QPointF &pos = QPoint(0,0));

    ~LabelX();

    virtual QRectF boundingRect() const;
    virtual QPainterPath shape() const;
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

    const QString& text() const { return m_text; }
    //! check brace matching and if it's incorrect, change isn't applied
    bool setText(const QString& text);
    
    const QColor& color() const { return m_color; }
    void setColor(const QColor &color) { m_color = color; update(); }

    bool left() const { return m_leftOriented; }
    void setLeftOriented(bool leftOriented) { m_leftOriented = leftOriented;}
        
    float posParam() const { return m_posParam; }
    void setPosParam(float posParam) { m_posParam = posParam; }

    int getWidth() const;
    int getHeight() const;

    void setFontSize(int fontSize);

    Transition* getTransition() { return m_pTransition; }

    //! Support method, returns list of used characters in label text. 
    //! \sa StringProcessor::getCharacters()
    QStringList getCharacters() const;
    
    //! Support method, returns list of CharcterInfo parsed from label text.
    //! \sa StringProcessor::getCharacterList()
    StringProcessor::TCharacterList getCharacterList() const;    

protected:
    Transition *m_pTransition;
    StringProcessor *m_pStringProcessor;

    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event);

    QString m_text;
    bool    m_leftOriented;
    int     m_fontSize;    
    QColor  m_color;
    float   m_posParam;
};

#endif
