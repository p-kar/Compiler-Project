#include "constants.h"

#include "label.h"
#include "stringProcessor.h"
#include "transition.h"

#include <QPainter>
#include <QGraphicsScene>
#include <QGraphicsSceneMouseEvent>
#include <QPointF>

#include <QtDebug>

LabelX::LabelX(Transition *tr, const QString &text, bool leftOriented, int fontSize,
               const QColor &color, float posParam, const QPointF &pos)
: m_pTransition(tr), m_text(text), m_leftOriented(leftOriented), m_fontSize(fontSize),
  m_color(color), m_posParam(posParam)//, m_pos(pos)
{
    setPos(pos);

    setFlag(QGraphicsItem::ItemIsMovable, false);
    setFlag(QGraphicsItem::ItemIsSelectable, false);

    m_pStringProcessor = new StringProcessor(m_text, m_fontSize);
}

LabelX::~LabelX()
{
    DBGLOG("called");
    if (m_pStringProcessor != NULL) delete m_pStringProcessor;
}

QRectF LabelX::boundingRect() const
{
    int adjust = 5;
    QRectF rect = QRectF(0,
                         0, // becouse pos denotes left top corner // TODO: check this!
                         m_pStringProcessor->getWidth(),
                         m_pStringProcessor->getHeight()).adjusted(-adjust, -adjust, adjust, adjust);
    return rect;
}

QPainterPath LabelX::shape() const
{    
    QPainterPath path;
    path.setFillRule(Qt::WindingFill);
    path.addRect(boundingRect());    
    return path;
}

void LabelX::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->setPen(QColor(m_color));
    QPointF position(0, getHeight()); // because m_pStringProcessor changes pos to next current point
    if (m_text != "")
    {
        m_pStringProcessor->drawText(painter, position);
    }
}

bool LabelX::setText(const QString &text)
{
    prepareGeometryChange();
    
    if (!m_pStringProcessor->setText(text))
    {
        return false;
    }
    
    m_text = m_pStringProcessor->text();
    return true;
}

int LabelX::getWidth() const
{
    return m_pStringProcessor->getWidth();
}

int LabelX::getHeight() const
{
    return m_pStringProcessor->getHeight();
}

void LabelX::setFontSize(int fontSize)
{
    prepareGeometryChange();
    m_fontSize = fontSize;
    m_pStringProcessor->setFontSize(fontSize);    
}

QStringList LabelX::getCharacters() const
{
    Q_ASSERT(m_pStringProcessor);
    return m_pStringProcessor->getCharacters();
}

StringProcessor::TCharacterList LabelX::getCharacterList() const
{
    Q_ASSERT(m_pStringProcessor);
    return m_pStringProcessor->getCharacterList();
}

void LabelX::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    event->ignore();
}
