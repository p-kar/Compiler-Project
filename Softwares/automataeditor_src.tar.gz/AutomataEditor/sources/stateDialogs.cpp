#include "constants.h"

#include "stateDialogs.h"
#include "editor.h"
#include "state.h"
#include "transforms.h"
#include "stringProcessor.h"
#include "parser.h"

#include <QPushButton>
#include <QLayout>
#include <QLabel>
#include <QLineEdit>
#include <QCheckBox>
#include <QComboBox>
#include <QStringList>
#include <QWidget>
#include <QGroupBox>
#include <QFontMetrics>
#include <QString>
#include <QMenu>
#include <QColor>
#include <QRegExpValidator>
#include <QRegExp>
#include <QMessageBox>

#include <QtDebug>


NameAcceptDialog::NameAcceptDialog(QWidget *parent)
: QDialog(parent), edtLabel(NULL), edtName(NULL)
{

}

// TODO: is this class yet needed? see StateDialog::nameBraceMatch()
void NameAcceptDialog::myAccept()
{
    QString errorMsg;
    if (edtName && !Parser::checkNameCorrectness(edtName->text(), &errorMsg))
    {
        showMessage(errorMsg);
        return;
    }

    try
    {   
        StringProcessor::computeCharacterList(edtLabel->text());
    }
    catch(const StringProcessorBraceMatchException &e)
    {
        DBGLOG("StringProcessorException: " << e.what());
        showMessage("Brace matching failed. Don't use unbalanced braces ('{', '}')!");
        return;
    }
    catch(const StringProcessorException &e)
    {
        RELLOG("Unexpected StringProcessorException: " << e.what());
        showMessage("Unexpected error in StringProcessor\nMaybe brace matching failed. Don't use unbalanced braces ('{', '}')!");
        return;
    }
    
    accept();    
}

void NameAcceptDialog::showMessage(const QString &msg)
{
    QMessageBox::warning(this,"Incorrect syntax!", msg, tr("&Ok"));
}

//<-- State Dialog -----------------------------------------------------------

// dialog window for setting initial state parameters (name of state, ending/normal state)
StateDialog::StateDialog(Editor *editor, const QList<QString> &typeList, EMode mode, bool hasInitial, QWidget* parent)
    : NameAcceptDialog(parent), editor(editor)
{
    // edit section
    QLabel* lblLabel = new QLabel(QString("Label"), this);
    edtLabel = new QLineEdit(this);
    checkAutoName = new QCheckBox(QString("Automatically generated name"),this);
    QLabel* lblName = new QLabel(QString("Name"), this);
    edtName = new QLineEdit(this);

    QLabel* lblType = new QLabel(QString("Type"), this);
    comboType = new QComboBox(this);
    foreach(QString typeName, typeList)
    {
        comboType->addItem(typeName);
    }

    checkDimmed = new QCheckBox(QString("Dimmed"),this);

    connect(checkAutoName,SIGNAL(clicked()),this, SLOT(changeAutoName()));

    checkQuickInitial = new QCheckBox(QString("Quick mark Initial"), this);
    const QString tip = tr("Only allowed to add single Initial transition to state which has no initials yet.\nOnly \\InitialW can be added.");
    checkQuickInitial->setToolTip(tip);
    checkQuickInitial->setWhatsThis(tip);
    checkQuickInitial->setEnabled(!hasInitial);
    checkQuickInitial->setChecked(hasInitial);

    QWidget *hBox = new QWidget(this);
    QPushButton *buttonOk = new QPushButton("Ok");
    QPushButton *buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(buttonOk);
    hBoxLayout->addWidget(buttonCancel);
    hBox->setLayout(hBoxLayout);    
    connect(buttonOk, SIGNAL(clicked()), this, SLOT(testAccept()));
    connect(buttonCancel, SIGNAL(clicked()), this, SLOT(reject()));
    
    QGridLayout* gridLayout = new QGridLayout(this);

    gridLayout->addWidget(lblLabel, 0, 0);
    gridLayout->addWidget(edtLabel, 0, 1);
    gridLayout->addWidget(checkAutoName, 1, 0, 1, 2);
    gridLayout->addWidget(lblName, 2, 0);
    gridLayout->addWidget(edtName, 2, 1);
    gridLayout->addWidget(lblType, 3, 0);
    gridLayout->addWidget(comboType, 3, 1);
    gridLayout->addWidget(checkDimmed,4,0,1,2);
    gridLayout->addWidget(checkQuickInitial, 5, 0, 1, 2);
    gridLayout->addWidget(hBox, 6, 0, 1, 2);

    QString s = "State dialog";
    if (mode == eAdd)
        s += " - add";
    else
        s += " - edit";

    setWindowTitle(s);
    setWindowIcon(QIcon(":images/state.xpm"));
}

bool StateDialog::quickInitial() const
{
    return checkQuickInitial->isEnabled() ? checkQuickInitial->isChecked() : false;
}

QString StateDialog::getName() const
{
    return edtName->text();
}

QString StateDialog::getLabel() const
{
    return edtLabel->text();
}

int StateDialog::getType() const
{
    return comboType->currentIndex();
}

bool StateDialog::isDimmed() const
{
    return checkDimmed->isChecked();
}

bool StateDialog::isAutoNammed() const
{
    return checkAutoName->isChecked();
}

void StateDialog::setName(const QString& name, bool editing)
{
    edtName->setText(name);
    currentStateName = (editing) ? name : "";
}

void StateDialog::setLabel(const QString& label)
{
    edtLabel->setText(label);
}

void StateDialog::setType(int type)
{
    comboType->setCurrentIndex(type);
}

void StateDialog::setDimmed(bool dim)
{
    checkDimmed->setChecked(dim);
}

void StateDialog::setAutoNammed(bool aN){
    edtName->setEnabled(!aN);
    checkAutoName->setChecked(aN);
}


// protected slots

void StateDialog::changeAutoName()
{
    if(checkAutoName->isChecked())
    {
        if(QMessageBox::question(this,"Use automatic name?",
            "Would you realy use automatic name? Current name will be lost!",
            tr("&Yes"),tr("&No")))
        {
            checkAutoName->setChecked(false);
            return;
        }
        
        QRegExp rx("^Q[0-9]{1,10}$"); // was it autonamed originally?
        QRegExpValidator v(rx,this);
    
        int pos = 0;
        if (v.validate(currentStateName,pos) == QValidator::Acceptable)
        {
            edtName->setText(currentStateName);
        }
        else
        { // set name to new autoname
            edtName->setText(editor->getUniqueAutoName());            
        }
    }
    edtName->setEnabled(!checkAutoName->isChecked());
}


// TODO: check if this is needed, maybe could be exanged with myAccept in NameAcceptDialog?
bool StateDialog::nameBraceMatch()
{
    QString name = edtName->text();
    int b_count = 0;
    int pos = 0;
    
    QRegExp braceRegex("(\\{|\\})");
    while((pos = name.indexOf(braceRegex, pos)) != -1)
    {
        if (braceRegex.cap(1) == "{")
        {
            b_count++;
        }
        else
        {
            Q_ASSERT(braceRegex.cap(1) == "}");
            b_count--;
            if (b_count < 0) return false;
        }
        pos++;
    }
        
    return (b_count == 0);
}

void StateDialog::testAccept()
{  
    QString s;
    s = edtName->text();
    if (!checkAutoName->isChecked())
    {
        if (s == "")
        {
            QMessageBox::warning(this,"Wrong format of name!",
                                 "Name might not be empty!"); 
            return;
        }
        if (s != currentStateName)
        {
            if (editor->testStateName(s))
            {
                QMessageBox::warning(this,"Name si used!",
                                    "This state name is now used by another state. Use another name please!");
                return;
            }
        }
    }
    else
    {
        if (s != currentStateName) 
        {
            //editor->increaseNewStateNumber(); // je nutno zvysit pocitadlo // TODO: check this
        }
    }
    
    if (s.contains(QRegExp("(?:\\{|\\})")))
    {
        if (!nameBraceMatch())
        {
            NameAcceptDialog::showMessage("Brace matching failed. Don't use unbalanced braces ('{', '}')!");
            return;
        }
    }
    
    myAccept();
}

//----------------------------------------------------------- State Dialog -->



//<-- State Extended Dialog --------------------------------------------------

StateExtendedDialog::StateExtendedDialog(QWidget *parent)
: QDialog(parent)
{
    QStringList sls; // lineStyle
    sls.append("solid");
    sls.append("dashed");
    sls.append("dotted");
    sls.append("none");
  
    QStringList slf; // fillColor
    slf.append("solid");
    slf.append("vlines");
    slf.append("hlines");
    slf.append("crosshatch");
    slf.append("none");
  
    QRegExp rx("^[\\-]{0,1}[0-9]{1,3}\\.[0-9]{1,3}$"); //!< float validator
    QValidator *v = new QRegExpValidator(rx,this); 
    
    // parameters adjusted
    QLabel *lineStyle = new QLabel(QString("StateLineStyle"),this);
    comboLineStyle = new QComboBox(this);
    comboLineStyle->addItems(sls);
    comboLineStyle->setCurrentIndex(0);
  
    QLabel *lineWidth = new QLabel(QString("StateLineWidth"),this);
    edtLineWidth = new QLineEdit(this);
    edtLineWidth->setValidator(v);

    QLabel *lineColor = new QLabel(QString("StateLineColor"),this);
    edtLineColor = new QLineEdit(this);  

    QLabel *labelColor = new QLabel(QString("StateLabelColor"),this);
    edtLabelColor = new QLineEdit(this);

    QLabel *labelScale = new QLabel(QString("StateLabelScale"),this);
    edtLabelScale = new QLineEdit(this);
    edtLabelScale->setValidator(v);

    QLabel *fillStatus = new QLabel(QString("StateFillStatus"),this);
    comboFillStatus = new QComboBox(this);
    comboFillStatus->addItems(slf);
    comboFillStatus->setCurrentIndex(0);
  
    QLabel *fillColor = new QLabel(QString("StateFillColor"),this);
    edtFillColor = new QLineEdit(this);

    // parameters preset (dim state)
    QLabel *dimLineStyle = new QLabel(QString("DimStateLineStyle"),this);
    comboDimLineStyle = new QComboBox(this);
    comboDimLineStyle->addItems(sls);
    comboDimLineStyle->setCurrentIndex(0);

    QLabel *dimLineColor = new QLabel(QString("DimStateLineColor"),this);
    edtDimLineColor = new QLineEdit(this);

    QLabel *dimLineCoef = new QLabel(QString("DimStateLineCoef"),this);
    edtDimLineCoef = new QLineEdit(this);
    edtDimLineCoef->setValidator(v);

    QLabel *dimLabelColor = new QLabel(QString("DimStateLabelColor"),this);
    edtDimLabelColor = new QLineEdit(this);

    QLabel *dimFillColor = new QLabel(QString("DimStateFillColor"),this);
    edtDimFillColor = new QLineEdit(this);
  
    // state double
    QLabel *lineDblCoef = new QLabel(QString("StateLineDblCoef"),this);
    edtLineDblCoef = new QLineEdit(this);
    edtLineDblCoef->setValidator(v);

    QLabel *lineDblSep = new QLabel(QString("StateLineDblSep"),this);
    edtLineDblSep= new QLineEdit(this);
    edtLineDblSep->setValidator(v);
  
  // buttons
    QWidget *hBox = new QWidget(this);
    QPushButton *buttonOk = new QPushButton("Ok");
    QPushButton *buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(buttonOk);
    hBoxLayout->addWidget(buttonCancel);
    hBox->setLayout(hBoxLayout);    
    hBox->setMaximumWidth(300);
    connect(buttonOk, SIGNAL(clicked()), this, SLOT(accept()));
    connect(buttonCancel, SIGNAL(clicked()), this, SLOT(reject()));
    
    QGroupBox *advancedGroup = new QGroupBox("Advanced parameters");
    QGridLayout *advancedLayout = new QGridLayout(advancedGroup);
    advancedLayout->addWidget(lineStyle,0,0);
    advancedLayout->addWidget(comboLineStyle,0,1);
    advancedLayout->addWidget(lineWidth,0,2);
    advancedLayout->addWidget(edtLineWidth,0,3); // \n
    advancedLayout->addWidget(lineColor,1,0);
    advancedLayout->addWidget(edtLineColor,1,1);
    advancedLayout->addWidget(labelColor,1,2);
    advancedLayout->addWidget(edtLabelColor,1,3); // \n
    advancedLayout->addWidget(labelScale,2,0,1,2,Qt::AlignRight);
    advancedLayout->addWidget(edtLabelScale,2,2,1,2,Qt::AlignLeft); // \n
    advancedLayout->addWidget(fillStatus,3,0);
    advancedLayout->addWidget(comboFillStatus,3,1);
    advancedLayout->addWidget(fillColor,3,2);
    advancedLayout->addWidget(edtFillColor,3,3); // \n\n
  
    QGroupBox *presetGroup = new QGroupBox("Preset parameters (dim state)");
    QGridLayout* presetLayout = new QGridLayout(presetGroup);
    presetLayout->addWidget(dimLineStyle, 0,0);  
    presetLayout->addWidget(comboDimLineStyle, 0,1);  
    presetLayout->addWidget(dimLineCoef, 0,2);
    presetLayout->addWidget(edtDimLineCoef, 0,3); // \n
    presetLayout->addWidget(dimLineColor, 1,0);
    presetLayout->addWidget(edtDimLineColor, 1,1);    
    presetLayout->addWidget(dimLabelColor, 1,2);
    presetLayout->addWidget(edtDimLabelColor, 1,3); // \n
    presetLayout->addWidget(dimFillColor, 2,0,1,2, Qt::AlignRight);
    presetLayout->addWidget(edtDimFillColor, 2,2,1,2, Qt::AlignLeft); // \n\n
    
    QGroupBox *doubleGroup = new QGroupBox("Line double parameters (final state)");
    QHBoxLayout *doubleLayout = new QHBoxLayout(doubleGroup);
    doubleLayout->addWidget(lineDblCoef);
    doubleLayout->addWidget(edtLineDblCoef);
    doubleLayout->addWidget(lineDblSep);
    doubleLayout->addWidget(edtLineDblSep); // \n
    
    QVBoxLayout *dialogLayout = new QVBoxLayout(this);
    dialogLayout->addWidget(advancedGroup);
    dialogLayout->addWidget(presetGroup);
    dialogLayout->addWidget(doubleGroup);
    dialogLayout->addWidget(hBox, 0, Qt::AlignHCenter);

    QString    s = "Extended parameters";
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/state.xpm"));
}

void StateExtendedDialog::setParams(State *state){
  comboLineStyle->setCurrentIndex(trLineStyleI(state->stateLineStyle));
  edtLineWidth->setText(QString("%1").arg(state->stateLineWidth));
  edtLineColor->setText(state->stateLineColor);
  edtLabelColor->setText(state->stateLabelColor);
  edtLabelScale->setText(QString("%1").arg(state->stateLabelScale));
  comboFillStatus->setCurrentIndex(trFillStatusI(state->stateFillStatus));  
  edtFillColor->setText(state->stateFillColor);
  
  comboDimLineStyle->setCurrentIndex(trLineStyleI(state->dimStateLineStyle));
  edtDimLineColor->setText(state->dimStateLineColor);
  edtDimLineCoef->setText(QString("%1").arg(state->dimStateLineCoef));
  edtDimLabelColor->setText(state->dimStateLabelColor);
  edtDimFillColor->setText(state->dimStateFillColor);
  
  edtLineDblCoef->setText(QString("%1").arg(state->stateLineDoubleCoef));
  edtLineDblSep->setText(QString("%1").arg(state->stateLineDoubleSep));
}

Qt::PenStyle StateExtendedDialog::getLineStyle(){
  return trLineStyle(comboLineStyle->currentIndex());
}

float StateExtendedDialog::getLineWidth(){
  return edtLineWidth->text().toFloat();
}

QString StateExtendedDialog::getLineColor(){
  return edtLineColor->text();
}

QString StateExtendedDialog::getLabelColor(){
  return edtLabelColor->text();
}

float StateExtendedDialog::getLabelScale(){
  return edtLabelScale->text().toFloat();
}

Qt::BrushStyle StateExtendedDialog::getFillStatus(){
  return trFillStatus(comboFillStatus->currentIndex());
}

QString StateExtendedDialog::getFillColor(){
  return edtFillColor->text();
}
  
Qt::PenStyle StateExtendedDialog::getDimLineStyle(){
  return trLineStyle(comboDimLineStyle->currentIndex());
}

QString StateExtendedDialog::getDimLineColor(){
  return edtDimLineColor->text();
}

float StateExtendedDialog::getDimLineCoef(){
  return edtDimLineCoef->text().toFloat();
}

QString StateExtendedDialog::getDimLabelColor(){
  return edtDimLabelColor->text();
}

QString StateExtendedDialog::getDimFillColor(){
  return edtDimFillColor->text();
}
  
float StateExtendedDialog::getLineDblCoef(){
  return edtLineDblCoef->text().toFloat();
}

float StateExtendedDialog::getLineDblSep(){
  return edtLineDblSep->text().toFloat();
}

//-------------------------------------------------- State Extended Dialog -->
