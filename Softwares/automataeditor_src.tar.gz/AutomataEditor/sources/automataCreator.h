#ifndef _AUTOMATACREATOR_H_32627795824_
#define _AUTOMATACREATOR_H_32627795824_

#include "iautomaton.h"

class State;
class Transition;

#include <QStringList>
#include <QMap>
#include <QList>
class QPainterPath;

class TransitionImpl : public ITransition
{
private:
    Q_DISABLE_COPY(TransitionImpl)
    
public:
    typedef QList<QSharedPointer<TransitionImpl> >  TTransitionList;

    TransitionImpl(const QString &source, const QString &destination, 
                   const ITransition::TCharSet characters,
                   Transition *graphicsTransition = NULL);
                   
    ~TransitionImpl();
    
    void setSourceState(const QString &stateName);
    void setDestinationState(const QString &stateName);
    
    QString getSourceState() const;
    QString getDestinationState() const;
    
    bool passOn(const QString &character) const;
    
    ITransition::TCharSet getCharacters() const;
    void setCharacters(const ITransition::TCharSet &characters);

    Transition* getGraphicsTransition();

protected:
    QString                 m_sourceState;
    QString                 m_destinationState;

    ITransition::TCharSet   m_characters;
    Transition*             m_graphicsTransition;
};

inline bool operator==(const ITransition &lhs, const ITransition &rhs)
{
    return (lhs.getSourceState() == rhs.getSourceState() &&
            lhs.getDestinationState() == rhs.getDestinationState() &&
            lhs.getCharacters() == rhs.getCharacters());
}

inline uint qHash(const ITransition &key)
{    
    uint hash = qHash(key.getSourceState()+key.getDestinationState());
    
    foreach(const QString &character, key.getCharacters())
    {
        hash ^= qHash(character);
    }
    
    return hash;
}

class StateImpl : public IState
{
private:
    Q_DISABLE_COPY(StateImpl)
    
public:
    typedef QList<QSharedPointer<StateImpl> >          TStateList;
    typedef QMap<QString, QSharedPointer<StateImpl> >  TStateMap;

    StateImpl(const QString &name, const QString &label, bool initial, bool final, 
              State *graphicsState = NULL);
    ~StateImpl();

    //! \name IState implementation
    //!@{
    //! implements IState interface
    void setName(const QString &name);
    QString getName() const;
    
    void setLabel(const QString &label);
    QString getLabel() const;
    
    void setInitial(bool is = true);
    void setFinal(bool is = true);
    
    bool isInitial() const;
    bool isFinal() const;
    
    IState::TIStateNameSet getStatesOn(const QString &character) const;
    IState::TIStateNameList getAdjacentStates() const;
    
    ITransition::TITransitionList getTransitions() const;
    ITransition::TITransitionList getTransitionsTo() const;
    //!@}
    
    void addTransition(const QSharedPointer<TransitionImpl> &tr);
    void addTransitionTo(const QSharedPointer<TransitionImpl> &tr);
    
    void removeTransition(const QSharedPointer<TransitionImpl> &tr);
    void removeTransitionTo(const QSharedPointer<TransitionImpl> &tr);
    
    TransitionImpl::TTransitionList getPrivateTransitions() const;
    TransitionImpl::TTransitionList getPrivateTransitionsTo() const;

    IState::TIStateNameSet getStatesAndPathsOn(const QString &character, QList<QPainterPath> &paths) const;

    State* getGraphicsState() const;

protected:
    QString                                 m_name;
    QString                                 m_label;
    bool                                    m_initial;
    bool                                    m_final;

    TransitionImpl::TTransitionList         m_transitions;
    TransitionImpl::TTransitionList         m_transitionsTo;
    
    State*                                  m_graphicsState;
};



/*!
 * Implements IAutomaton, provides some methods for giving private implementations.
 */
class AutomatonImpl : public IAutomaton
{
private:
    Q_DISABLE_COPY(AutomatonImpl)

public:
    typedef QList<QSharedPointer<AutomatonImpl> >  TAutomatonList;
    
    AutomatonImpl(const ITransition::TCharSet &alphabet, const QString &alphabetSymbol,
                  const QString &epsilonSymbol);
                  
    ~AutomatonImpl();
    
    virtual QSharedPointer<IState> createState
        (const QString &name, const QString &label, bool initial, bool final);
        
    virtual QSharedPointer<ITransition> createTransition
        (const QString &source, const QString &dest, const ITransition::TCharSet &characters);
    
    virtual IState::TIStateList getStates() const;
    virtual IState::TIStateList getInitialStates() const;
    virtual IState::TIStateList getFinalStates() const;
    
    virtual IState::TIStateNameList getStateNameList() const;

    StateImpl::TStateList getPrivateStates() const;
    StateImpl::TStateList getPrivateInitialStates() const;
    StateImpl::TStateList getPrivateFinalStates() const;    
        
    virtual bool hasPositions() const { return !m_positioningMap.isEmpty(); }
	virtual IAutomaton::TPositioningMap getPositioningMap() const;
	virtual void setPositioningMap(const IAutomaton::TPositioningMap &map);
    
    virtual ITransition::TITransitionList getTransitions() const;
    virtual QSharedPointer<ITransitionTable> getTransitionTable() const;
    
    TransitionImpl::TTransitionList getPrivateTransitions() const;
    
    virtual void setAlphabet(const ITransition::TCharSet &alphabet);
    virtual void setAlphabetSymbol(const QString &alphabetSymbol);
    virtual void setEpsilonSymbol(const QString &epsilonSymbol);
    
    virtual ITransition::TCharSet getAlphabet() const;
    virtual QString getAlphabetSymbol() const;
    virtual QString getEpsilonSymbol() const ;
    
    virtual QSharedPointer<IState> getState(const QString &name) const;
    virtual bool removeState(const QSharedPointer<IState> &state);
    virtual bool removeState(const QString &stateName);
    virtual bool renameState(const QSharedPointer<IState> &state,
                             const QString &newName);
    
    virtual bool addState(const QSharedPointer<StateImpl> &state);                         
    QSharedPointer<StateImpl> getPrivateState(const QString &name) const;
    
    virtual bool addTransition(const QSharedPointer<TransitionImpl> &tr);
    virtual bool removeTransition(const QSharedPointer<TransitionImpl> &tr);
    virtual bool removeTransition(const QSharedPointer<ITransition> &tr);
    
    virtual void addLists(const StateImpl::TStateList &states,
                          const TransitionImpl::TTransitionList &transitions);
    
    virtual bool hasMultipleInitials() const;
    virtual bool hasEpsilonTransitions() const;
    virtual bool isDeterministic() const;
    virtual bool hasState(const QString &name) const;    
    virtual ITransition::TCharSet getTransitionSymbols(const QString &source,
                                                       const QString &dest) const;
    
    virtual bool allowRedundantTransitions() const { return m_allowRenundancies; }
    //! Takes effect only for newly added transitions, if needed, call immediately when construct automaton
    virtual void setAllowRedundantTransitions(bool allow);

    virtual void reset();
    virtual bool processCharacter(const QString &character);
    virtual bool isConfigurationAccepted() const;
    virtual IState::TIStateList getActiveStates() const;
    virtual QStringList getActiveStatesNames() const;
    virtual QStringList getProcessedString() const;
    
    StateImpl::TStateList getPrivateActiveStates() const;
    IState::TIStateNameSet processCharacterWithInfo(const QString &character,
                                                    QList<QPainterPath> &paths);

    //! Creates new transition, doesn't add it! It has to be done manually if created is true.
    //! This method keeps consistency with redundant transitions handling.
    //! \sa allowRedundantTransitions, createTransition
    QSharedPointer<TransitionImpl> createPrivateTransition
        (const QString &source, const QString &dest, const ITransition::TCharSet &characters,
         const TransitionImpl::TTransitionList &transitions, bool &created, Transition *graphicsTransition);
    //! Creates new transition and add it to automaton. Keeps consistency witch redundant transitions handling.
    //! \sa allowRedundantTransitions, createTransition, createPrivateTransition
    QSharedPointer<TransitionImpl> createAndAddPrivateTransition
        (const QString &source, const QString &dest, const ITransition::TCharSet &characters, Transition *graphicsTransition);

protected:
    //! Called from IAutomaton::createTransition.
    QSharedPointer<TransitionImpl> createPrivateTransitionInternal
        (const QString &source, const QString &dest, const ITransition::TCharSet &characters, bool &created);
    QSharedPointer<TransitionImpl> createPrivateTransitionIfNotExists
        (const QString &source, const QString &dest, const ITransition::TCharSet &characters,
         const TransitionImpl::TTransitionList &transitions, bool &created, Transition *graphicsTransition = NULL);
    QSharedPointer<TransitionImpl> createEpsilonTransitionIfNotExists
            (const QString &source, const QString &dest, const QString &epsilonSymbol,
             const TransitionImpl::TTransitionList &transitions, bool &created, Transition *graphicsTransition = NULL);
    QSharedPointer<TransitionImpl> createCharactersTransitionIfNotExists
        (const QString &source, const QString &dest, ITransition::TCharSet &characters,
         const TransitionImpl::TTransitionList &transitions, bool &created, Transition *graphicsTransition = NULL);

    void appendStatesOnEpsilon();

private:
    //! helper function for creating transition table's rows
    void fillRowData(const QSharedPointer<IState> &state, ITTRow &row) const;
    
    StateImpl::TStateMap            m_stateMap;
    IAutomaton::TPositioningMap     m_positioningMap;

    TransitionImpl::TTransitionList m_transitions;
    
    ITransition::TCharSet           m_alphabet;
    QString                         m_alphabetSymbol;
    QString                         m_epsilonSymbol;

    StateImpl::TStateList           m_activeStates;
    QStringList                     m_processedString;

    bool                            m_allowRenundancies;
};



/*!
 * Implements IAutomataCreator and has some additional methods for giving private implementations.
 */
class AutomataCreator : public IAutomataCreator
{
public:
    ~AutomataCreator() {}

    QSharedPointer<AutomatonImpl>  createPrivateAutomaton
        (const ITransition::TCharSet &alphabet, 
         const QString &alphabetSymbol,
         const QString &epsilonSymbol);

    //! Creates private state.
    //! Note that private transition can be created only using automaton instance to avoid inconsistency with handling of redundancies.
    QSharedPointer<StateImpl>      createPrivateState
        (const QString &name, const QString &label, bool initial, bool final,
         State *graphicsState);

    //! \name IAutomataCreator implementation
    //!@{
    //! Implements IAutomataCreator interface
    QSharedPointer<IAutomaton>  createAutomaton
        (const ITransition::TCharSet &alphabet,
         const QString &alphabetSymbol,
         const QString &epsilonSymbol);
    //!@}
    
    //! list of default alphabet symbols, sorted by priority
    static const QStringList defaultAlphabetSymbList;
    //! list of default epsilon symbols, sorted by priority
    static const QStringList defaultEpsilonSymbList;
};

#endif
