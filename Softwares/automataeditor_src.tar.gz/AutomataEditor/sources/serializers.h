#ifndef _SERIALIZERS_68443198787331_
#define _SERIALIZERS_68443198787331_

#include "state.h"
#include "transition.h"

class QGraphicsItem;
#include <QStringList>

// logging enabled/disabled
#ifdef TESTING_SERIALIZERS
#   define DBGLOG_SER(x) DBGLOG_("SERIALIZER", x)
#else
#   define DBGLOG_SER(x)
#endif

struct StateSerializer
{
    StateSerializer() : m_valid(false) {};
    //! serialize state info
    StateSerializer(const State &state);
    //! copy constructor
    StateSerializer(const StateSerializer &other);

    //! returns new state instance, owner is to be delete it
    State* createState(Editor *editor, const QPoint &pos);

    bool    m_valid;        //!< if true, contains real state

    QString m_stateName;    //!< holds original state name -> for copying transitions
    QPointF m_pos;          //!< needed when pasted in selection
    QString m_typeName;     //!< state typeName (StateManager create state according to this)
    QString m_label;

    bool    m_dimmed;

    unsigned char   m_stateLineStyle;
    float           m_stateLineWidth;
    QString         m_stateLineColor;
    QString         m_stateLabelColor;
    float           m_stateLabelScale;
    unsigned char   m_stateFillStatus;
    QString         m_stateFillColor;

    unsigned char   m_dimStateLineStyle;
    QString         m_dimStateLineColor;
    float           m_dimStateLineCoef;
    QString         m_dimStateLabelColor;
    QString         m_dimStateFillColor;

    float           m_stateLineDoubleCoef;
    float           m_stateLineDoubleSep;

    int             m_stateLabelSize;
};

/*!qRegisterMetaTypeStreamOperators<StateSerializer>("StateSerializer");
 * is in editor's constructor.
 */ 
QDataStream &operator<<(QDataStream &out, const StateSerializer &serializer);
QDataStream &operator>>(QDataStream &in, StateSerializer &serializer);

Q_DECLARE_METATYPE(StateSerializer)



struct TransitionSerializer
{
    TransitionSerializer() : m_valid(false){};

    TransitionSerializer(const Transition &tr);

    TransitionSerializer(const TransitionSerializer &other);

    //! stateNames is stored in order - startState, endState (or just one state)
    Transition* createTransition(Editor *editor, QList<State*> &states);

    bool m_valid;

    QStringList m_stateNames;
    QString     m_typeName;
    QString     m_label;
    int         m_labelPos;

    bool        m_dimmed;

    int     m_arcAngleA;
    int     m_arcAngleB;
    float   m_nCurv;

    bool        m_leftOriented;
    int         m_direction;

    QStringList     m_labels;
    QList<float>    m_labelsPositions;
    QList<bool>     m_labelsLeftOriented;
    
    unsigned char   m_edgeLineStyle;
    float           m_edgeLineWidth;
    QString         m_edgeLineColor;
    QString         m_edgeLabelColor;
    float           m_edgeLabelScale;
    bool            m_edgeLineDblStatus;
    float           m_edgeLineBorderCoef;
    QString         m_edgeLineBorderColor;
    float           m_edgeLineDblCoef;
    float           m_edgeLineDblSep;
    unsigned char   m_dimEdgeLineStyle;
    QString         m_dimEdgeLineColor;
    float           m_dimEdgeLineCoef;
    QString         m_dimEdgeLabelColor;
};

/*!qRegisterMetaTypeStreamOperators<TransitionSerializer>("TransitionSerializer");
 * is in editor's constructor.
 */ 
QDataStream &operator<<(QDataStream &out, const TransitionSerializer &serializer);
QDataStream &operator>>(QDataStream &in, TransitionSerializer &serializer);

Q_DECLARE_METATYPE(TransitionSerializer)



struct SelectionSerializer
{
    SelectionSerializer() : m_valid(false) {};

    SelectionSerializer(const QList<QGraphicsItem*> &items);

    SelectionSerializer(const SelectionSerializer &other);

    //! only states are needed in list, since pointers to transitions are stored in states
    typedef QList<State*>                       TStateList;
    typedef QList<Transition*>                  TTransitionList;
    typedef QPair<TStateList, TTransitionList>  TItemsPair;
    TItemsPair createItems(Editor *editor, const QPoint& pos);    

    typedef QList<QGraphicsItem*>   TItemList;      //!< constructor argument
    typedef QMap<QString, State*>   TStateNameMap;  //!< maps original to new state's names

    bool    m_valid;

    QPointF m_hotSpot; //!< center of selection, states needs to memorize translation against this point

    typedef QList<StateSerializer>      TSerializedStatesList;
    typedef QList<TransitionSerializer> TSerializedTransitionsList;

    TSerializedStatesList       m_serializedStates;
    TSerializedTransitionsList  m_serializedTransitions;    
};

/*!qRegisterMetaTypeStreamOperators<SelectionSerializer>("SelectionSerializer");
 * is in editor's constructor.
 */ 
QDataStream &operator<<(QDataStream &out, const SelectionSerializer &serializer);
QDataStream &operator>>(QDataStream &in, SelectionSerializer &serializer);

Q_DECLARE_METATYPE(SelectionSerializer)



#endif //_SERIALIZERS_68443198787331_
