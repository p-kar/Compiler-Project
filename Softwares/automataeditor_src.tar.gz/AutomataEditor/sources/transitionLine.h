#ifndef _TRANSITIONLINE_H_8798638745242_
#define _TRANSITIONLINE_H_8798638745242_

#include "twoStatesTransition.h"

class TransitionLine : public TwoStatesTransition
{
public:
  TransitionLine(Editor *parent, State *ss, State *es, const QString &label,
                 bool leftOriented=true, bool dimmed=false);
  virtual ~TransitionLine();
  
  virtual void adjust();
  virtual void setLabelPosition();
    
  virtual QString getTypeName() const;

  virtual QString getVCCommand() const;
  //virtual QString getEPS() const;
protected:
  //void paint (QPainter * painter, const QStyleOptionGraphicsItem * option, QWidget * widget = 0);
};

#endif //_TRANSITIONLINE_H_8798638745242_
