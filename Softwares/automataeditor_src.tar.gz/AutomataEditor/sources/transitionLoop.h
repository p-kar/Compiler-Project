#ifndef _TRANSITIONLOOP_H_877372374243_
#define _TRANSITIONLOOP_H_877372374243_

#include "oneStateTransition.h"

class TransitionLoop : public OneStateTransition
{
public :
    enum ELoopType {eLoop, eCLoop, eLoopVar};
public:
    TransitionLoop(Editor *parent, State *state, const QString &label, int type = eLoop,
                   bool dimmed = false, int direction = 0);
    ~TransitionLoop();

    virtual void adjust();
        
    virtual QString getTypeName() const;

    virtual void setDirection(int d);
    virtual int getDirection() const;

    virtual void setLabelPosition();
    
    virtual QString getVCCommand() const;
    //virtual QString getEPS() const;

    virtual State* getEndState() const { return startState; }
    
    virtual QPainterPath path() const
    {
        return p.translated(pos());
    }

    void paint(QPainter * painter, const QStyleOptionGraphicsItem * option, QWidget * widget = 0);

protected:
    int loopType;
    int direction;    
};

#endif //_TRANSITIONLOOP_H_877372374243_
