#include "constants.h"

#include "transitionLine.h"
#include "state.h"
#include "label.h"
#include "transforms.h"

#include <math.h>

#include <QtDebug>

TransitionLine::TransitionLine(Editor *parent, State *ss, State *es, const QString &labelText,
                               bool lo, bool dimmed):
  TwoStatesTransition(parent, ss, es, lo, dimmed)
{  
    setZValue(Z_TRANSITION);
    label = new LabelX(this, labelText, lo, m_labelFontSize,
            dimmed ? QColor(dimEdgeLabelColor) : QColor(edgeLabelColor));
    label->setZValue(Z_TR_LABEL);
    label->setPosParam(DEF_EDGE_LAB_POS);
    adjust();
    setLabelPosition();
}

void TransitionLine::adjust()
{
    prepareGeometryChange();
    if ((!startState) || (!endState))
    {
        RELLOG("some of states NULL!");
        return;
    }

    startPoint = startState->pos();
    endPoint = endState->pos();
    
    // HACK for hold label on right position
    if (startPoint == endPoint)
    {
        startPoint -= QPointF(0.1f, 0.1f);
        endPoint += QPointF(0.1f, 0.1f);
    }
     
    QPolygonF line;
    line << endPoint << startPoint;
    QPolygonF p1 = findIntersectedPoints(line, mapFromItem(startState, startState->getMyPolygon()), eFIND_FIRST);
    line.clear();
    line << startPoint << endPoint;
    QPolygonF p2 = findIntersectedPoints(line, mapFromItem(endState, endState->getMyPolygon()), eFIND_FIRST);
    
    QPainterPath path;
    if (p1.empty() || p2.empty())
    {
        path.moveTo(line[0]);
        path.lineTo(line[1]);
    }
    else
    {
        path.moveTo(p1[0]);
        path.lineTo(p2[0]);
    }
    p = path;

    pa = getArrowPolygon(p);
    
    setLabelPosition();
    createStrokes(p);
}

TransitionLine::~TransitionLine()
{
    DBGLOG("called");
}

QString TransitionLine::getTypeName() const
{
    return "Edge";
}

void TransitionLine::setLabelPosition()
{
    if (label)
    {
        Transition::setLabelPosition(label, label->posParam(), leftOriented, label->getWidth(), label->getHeight());
    } // if
    Transition::setLabelPosition();
}

/*void TransitionLine::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    if (startPoint == endPoint) return; // do not paint if states are overlapped    
  
    QColor lineC;
    Qt::PenStyle lineS;
    
    if (dimmed)
    {
        lineS = dimEdgeLineStyle;
        lineC = dimEdgeLineColor;
    } 
    else
    {
        lineS = edgeLineStyle;
        lineC = edgeLineColor;
    }
  
    if (checked)
    {
        painter->setPen(QPen(checkedColor, m_lineWidth, lineS));
        painter->setBrush(checkedColor);
    } 
    else
    {
        painter->setPen(QPen(lineC, m_lineWidth, lineS));
        painter->setBrush(lineC);
    }

    painter->strokePath(p, painter->pen());
    painter->drawPolygon(pa);
    
    paintSelectionDecoration(painter);

#ifdef TESTING_PAINTING
#   ifdef TESTING_BOUNDING_RECT_PAINTING
        painter->setBrush(QBrush(QColor(50,255,0,100)));
        painter->fillRect(boundingRect(), painter->brush());
#   endif

    painter->setBrush(QBrush(QColor(0,0,255,150)));
    painter->fillPath(shape(), painter->brush());
#endif
}*/

QString TransitionLine::getVCCommand() const
{
    QString command = "\\";

    command += getTypeName();
    command += getTypeNameSuffix();
    
    Q_ASSERT(label != NULL);
    if (label->posParam() != DEF_EDGE_LAB_POS) 
        command += QString("[%1]").arg(label->posParam());

    command += "{" + startState->getName() + "}";
    command += "{" + endState->getName() + "}";

    command += "{" + label->text() + "}";

    command += getNextLabelsVCCommand();

    return command;
}

/*
QString TransitionLine::getEPS() const
{
  QString s = "";
  
  QColor lineC;
  Qt::PenStyle lineS;
  
  int r, g, b; float rf, gf, bf;
  
  if (dimmed)
  {
    lineS = dimEdgeLineStyle;
    lineC = dimEdgeLineColor;
  }
  else
  {
    lineS = edgeLineStyle;
    lineC = edgeLineColor;
  }
  lineC.getRgb(&r,&g,&b);
  rf = r / 255.; gf = g / 255.; bf = b / 255.;
  // r g b width lx ly mx my trLine 
  s += trLineStyle(lineS);
  s += QString(" %1 %2 %3 %4 %5 %6 %7 %8 trLine\n")
         .arg(rf).arg(gf).arg(bf)
         .arg(m_lineWidth)
         .arg(endPoint.x()).arg(scene()->height()-2 - endPoint.y())
         .arg(startPoint.x()).arg(scene()->height()-2 - startPoint.y()); 
  
  s += Transition::getEPS();   // label in the end
  return s;
}
*/
