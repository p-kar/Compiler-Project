#ifndef TRANSFORMS_H_12324142424121
#define TRANSFORMS_H_12324142424121

#include <QString>
#include <QStringList>
#include <QPen>

#include <QtDebug>

// declarations -------------------------------->

//!compute marker color to be sure that change will be visible enough
QString toMarkerColor(const QString &color);

QString trLineStyle(const Qt::PenStyle &style);
int trLineStyleI(const Qt::PenStyle &style);
Qt::PenStyle trLineStyle(const QString &style);
Qt::PenStyle trLineStyle(int i);

QString trFillStatus(const Qt::BrushStyle &status);
int trFillStatusI(const Qt::BrushStyle &status);
Qt::BrushStyle trFillStatus(const QString &status);
Qt::BrushStyle trFillStatus(int i);

QString trBool(bool is);
bool trBool(const QString &is);

int trLoopVarDirection(int trLoopDirection); // used in parser to recognize type
int trCLoopDirection(int trLoopDirection); 
int trLoopDirection(int trCLoopDirection);
int trLoopType(int direction);

int trAngleFromDirection(int dir); // for Loops

QString trMouseAction(unsigned char mouseAction);



// definitions --------------------------------->

inline QString toMarkerColor(const QString &color)
{
    // TODO: make nice for most colors
    if (color.toLower() != "darkgray" && color.toLower() != "black" && color.toLower() != "gray")
        return "gray";
    else
        return "lightblue";
}

inline QString trLineStyle(const Qt::PenStyle &style){
  if (style == Qt::NoPen) return "none";
  else if (style == Qt::DashLine) return "dashed";
  else if (style == Qt::DotLine) return "dotted";
  else return "solid"; // default
}

inline int trLineStyleI(const Qt::PenStyle &style){
  switch (style){
  case Qt::SolidLine: return 0;
  case Qt::DashLine: return 1;
  case Qt::DotLine: return 2;
  default: return 3;
  }
}

inline Qt::PenStyle trLineStyle(const QString &style){
  if (style == "none") return Qt::NoPen;
  else if (style == "dashed") return Qt::DashLine;
  else if (style == "dotted") return Qt::DotLine;
  else return Qt::SolidLine;
}

inline Qt::PenStyle trLineStyle(int i){
  switch (i){
  case 0: return Qt::SolidLine;
  case 1: return Qt::DashLine;
  case 2: return Qt::DotLine;
  default: return Qt::NoPen;  
  }
}

inline QString trFillStatus(const Qt::BrushStyle &status){
  if (status == Qt::SolidPattern) return "solid";
  else if (status == Qt::BDiagPattern) return "hlines";
  else if (status == Qt::FDiagPattern) return "vlines";
  else if (status == Qt::DiagCrossPattern) return "crosshatch";
  else if (status == Qt::NoBrush) return "none";
  else return "solid"; 
}

inline int trFillStatusI(const Qt::BrushStyle &status){
  switch (status){
    case Qt::SolidPattern: return 0;
    case Qt::FDiagPattern: return 1;
    case Qt::BDiagPattern: return 2;
    case Qt::DiagCrossPattern: return 3;
    default: return 4;
  }
}

inline Qt::BrushStyle trFillStatus(const QString &status){
  if (status == "hlines") return Qt::BDiagPattern;
  else if (status == "vlines") return Qt::FDiagPattern;
  else if (status == "crosshatch") return Qt::DiagCrossPattern;
  else if (status == "none") return Qt::NoBrush;
  else return Qt::SolidPattern;
}

inline Qt::BrushStyle trFillStatus(int i){
  switch (i){
  case 0: return Qt::SolidPattern;
  case 1: return Qt::FDiagPattern;
  case 2: return Qt::BDiagPattern;
  case 3: return Qt::DiagCrossPattern;
  default: return Qt::NoBrush;
  }
}

inline QString trBool(bool is){
  if (is)
    return "true";
  else
    return "false";
}

inline bool trBool(const QString &is){
  if (is == "true")
    return true;
  else
    return false;
}

inline int trCLoopDirection(int trLoopDirection)
{
    return trLoopDirection + SOUTH_WEST + 1;
}

inline int trLoopVarDirection(int trLoopDireciton)
{
    return trLoopDireciton + SOUTH_WEST*2 + 2;
}

inline int trLoopDirection(int trDirection)
{
    if (trDirection > SOUTH_WEST*2 + 1)
    {
        return trDirection - SOUTH_WEST*2 - 2;
    }
    else if(trDirection > SOUTH_WEST)
    {
        return trDirection - SOUTH_WEST - 1;
    }
    else return trDirection;
}

inline int trLoopType(int direction)
{
    if (direction > SOUTH_WEST*2 + 1)
    {
        return 2;
    }
    else if(direction > SOUTH_WEST)
    {
        return 1;
    }
    else return 0;
}

inline int trAngleFromDirection(int dir)
{   
    switch (dir)
    {
        case NORTH:
            return (90);
        case SOUTH:
            return (270);            
        case EAST:
            return (0);            
        case WEST:
            return (180);            
        case NORTH_EAST:
            return (45);            
        case NORTH_WEST:
            return (135);            
        case SOUTH_EAST:
            return (315);            
        case SOUTH_WEST:
            return (225);
        default:
            RELLOG("direction out of range!!!");
            return (90);
    }
}

//! keep this consistent with definition in "editor.h"
/*enum EMouseAction {eNoMouseAction, eMoveItem, eMoveMultItem, 
                     eInsertItem, eSelectItem, eSelectMultipleItems, 
                     eShowPopup, eShowSelectionPopup};*/

inline QString trMouseAction(unsigned char mouseAction)
{
    switch(mouseAction)
    {
    case 0:
        return "eNoMouseAction";
        break;
    case 1:
        return "eMoveItem";
        break;
    case 2:
        return "eMoveMultItem";
        break;
    case 3:
        return "eInsertItem";
        break;
    case 4:
        return "eSelectItem";
        break;
    case 5:
        return "eSelectMultipleItems";
        break;
    case 6:
        return "eShowPopup";
        break;
    case 7:
        return "eShowSelectionPopup";
        break;
    default:
        RELLOG("Unknown mouse action!, define it in trMouseAction");
        return "<unknown>Action";
    }
}

#endif //TRANSFORMS_H_12324142424121
