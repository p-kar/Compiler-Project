#ifndef STATE_H_5737489843734890
#define STATE_H_5737489843734890

#include <QList>
#include <QGraphicsEllipseItem>
#include "editor.h"
#include "stringProcessor.h"

class QPoint;
class QPointF;
class Transition;
class TransitionLine;
class QTextStream;

struct StatePrevParams
{
    Qt::PenStyle stateLineStyle;
    float stateLineWidth;
    QString stateLineColor;
    QString stateLabelColor;
    float stateLabelScale;
    Qt::BrushStyle stateFillStatus;
    QString stateFillColor;

    float stateLineDoubleCoef;
    float stateLineDoubleSep;

    Qt::PenStyle dimStateLineStyle;
    QString dimStateLineColor;
    float dimStateLineCoef;
    QString dimStateLabelColor;
    QString dimStateFillColor;
};

class State : public QGraphicsItem
{
public:
    State(const QPoint &position, Editor *parent,const QString label = "",
          const QString name = "", bool dBorder = false, bool dim = false);
    
    virtual ~State();

    State(){};

    friend class Parser;
    friend class StateExtendedDialog;
    friend class StateEditWithDelCommand;
    friend class StateEditExtendedCommand;
    friend class StateStyleChangeCommand;
    friend void Editor::exportToGraphML(const QString &fn);
    friend struct StateSerializer;

    virtual QRectF boundingRect() const;
    virtual QPainterPath shape() const = 0;
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) = 0;
    virtual void paintSelectionDecoration(QPainter *painter);

    void setChecked(bool checked = true);
  
    virtual int getWidth() const = 0;
    virtual int getHeight() const = 0;

    int getTextWidth() const { return stringProcessor->getWidth(); }
    int getTextHeight() const { return stringProcessor->getHeight(); }
    int getTextAscent() const { return stringProcessor->getAscent(); }  
    int getTextDescent() const { return stringProcessor->getDescent(); }
  
    virtual void setLabel(const QString &label);
    virtual void setName(const QString &name);
    virtual void setDoubleBorder(bool dBroder);
    virtual void setDimmed(bool dim);
    virtual void setAutoNammed(bool autoNammed);

    virtual QString getLabel() const { return label; }
    virtual bool isDoubleBorder() const { return doubleBorder; }
    virtual QString getName() const { return name; }
    virtual bool isDimmed() const { return dimmed; }
    virtual bool isAutoNammed() const { return autoNammed; }
    
    virtual QString getTypeName() const = 0;

    virtual void addTransition(Transition* transition);
    virtual void removeTransition(Transition* transition);
    
    virtual void deleteTransitions();
    
    QList<Transition *> getTransitionList() { return transitionList; }
    void setTransitionList(const QList<Transition*> &trList) { transitionList = trList; }
    void clearTransitionList() { transitionList.clear(); }
    void adjustTransitions();
    
    virtual QPolygonF getMyPolygon() const;

    // for export
    virtual bool getVCParams(QTextStream &out, StatePrevParams &prevParams);
    
    virtual QString getVCCommand() const;

    //virtual QString getEPS() const = 0;    

    void setStateLabelScale(float labelScale);
    void setStateLineWidth(float lineWidth);
    void setDimStateLineCoef(float lineCoef);
    
    void setStateLineDoubleCoef(float lineCoef);
    void setStateLineDoubleSep(float lineSep);
    
    void setMarked(bool marked);

protected:
    //! give know about moving with state to all connected trasitions
    virtual QVariant itemChange(GraphicsItemChange change, const QVariant &value);
    //! compute states polygon
    virtual void updateMyPolygon() = 0;

    //! mouseEvents
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event);
    //! moving with state
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);

    Editor *editor;
    QPointF oldPos;             //!< due to Undo and Redo

    QPolygonF       myPolygon;  //!< polygon to finding intersection with transitions
    QPainterPath    myPath;     //!< state painter path, corresponding to myPolygon

    //! transitions connected to state
    QList<Transition *> transitionList;

    bool autoNammed;    //!< atomatic naming
    QString name;       //!< name of state

    QString label;      //!< original label
    StringProcessor *stringProcessor; //!< handles greek symbols, provide painting and export funcitons

    bool dimmed;        //!< by default solid gray

    bool doubleBorder;  //!< if true, it is FinalState

    //! \name state parameters
    //! \{
    Qt::PenStyle stateLineStyle;
    float stateLineWidth;
    QString stateLineColor;
    QString stateLabelColor;
    float stateLabelScale;
    Qt::BrushStyle stateFillStatus;
    QString stateFillColor;
    //! \}

    //! \name state parametres dimmed
    //! \{
    Qt::PenStyle dimStateLineStyle;
    QString dimStateLineColor;
    float dimStateLineCoef;
    QString dimStateLabelColor;
    QString dimStateFillColor;
    //! \}

    //! \name state parametres double
    //! \{
    float stateLineDoubleCoef;
    float stateLineDoubleSep;
    //! \}

    int stateLabelSize;
    float m_lineWidth;

    bool            checked;
    const QColor    checkedColor;
    
    QString m_origColor;    //!< stores original color before state is marked
    bool    m_marked;

    bool    m_otherMoved;   //!< for moving with multiple states

    EMouseClick m_lastMouseClickType;

public:
    //! \name Support methods for IState creation
    //! \{
    bool isInitial() const;
    bool isFinal() const;

    QList<State*> getAccessibleStates() const; //!< returns list of accessible states from this state on sigle transition, ignores orientation
    QList<Transition*> getOutgoingTransitions() const; //<! returns only transitions which goes from this state, without initals and finals
    //! \}
};

#endif
