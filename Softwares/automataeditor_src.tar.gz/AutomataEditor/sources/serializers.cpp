#include "constants.h"

#include "serializers.h"
#include "state.h"
#include "stateManager.h"
#include "transition.h"
#include "oneStateTransition.h"
#include "twoStatesTransition.h"
#include "transitionManager.h"
#include "editor.h"
#include "label.h"

#include <QGraphicsItem>
#include <QPoint>
#include <QList>
#include <QString>
#include <QDataStream>
#include <QMetaType>



//<-- StateSerializer --------------------------------------------------

#define SS_PARAMS(obj, xx) obj.m_stateName xx \
    obj.m_pos xx obj.m_typeName xx obj.m_label xx \
    obj.m_dimmed xx obj.m_stateLineStyle xx \
    obj.m_stateLineWidth xx obj.m_stateLineColor xx \
    obj.m_stateLabelColor xx obj.m_stateLabelScale xx \
    obj.m_stateFillStatus xx obj.m_stateFillColor xx \
    obj.m_dimStateLineStyle xx obj.m_dimStateLineColor xx \
    obj.m_dimStateLineCoef xx obj.m_dimStateLabelColor xx \
    obj.m_dimStateFillColor xx obj.m_stateLineDoubleCoef xx \
    obj.m_stateLineDoubleSep xx obj.m_stateLabelSize


QDataStream &operator<<(QDataStream &out, const StateSerializer &s)
{
    Q_ASSERT(s.m_valid && "do NOT use uninitialized serializer!");
    out << SS_PARAMS(s, <<);
    
    return out;
}

QDataStream &operator>>(QDataStream &in, StateSerializer &s)
{    
    in >> SS_PARAMS(s, >>);
    
    s.m_valid = true;
    return in;
}

StateSerializer::StateSerializer(const State &s)
: m_valid(true), m_stateName(s.name), m_pos(s.pos()),
  m_typeName(s.getTypeName()), m_label(s.label), m_dimmed(s.dimmed),
  m_stateLineStyle(s.stateLineStyle),
  m_stateLineWidth(s.stateLineWidth), m_stateLineColor(s.stateLineColor),
  m_stateLabelColor(s.stateLabelColor), m_stateLabelScale(s.stateLabelScale),
  m_stateFillStatus(s.stateFillStatus), m_stateFillColor(s.stateFillColor),
  m_dimStateLineStyle(s.dimStateLineStyle), m_dimStateLineColor(s.dimStateLineColor),
  m_dimStateLineCoef(s.dimStateLineCoef), m_dimStateLabelColor(s.dimStateLabelColor),
  m_dimStateFillColor(s.dimStateFillColor), m_stateLineDoubleCoef(s.stateLineDoubleCoef),
  m_stateLineDoubleSep(s.stateLineDoubleSep), m_stateLabelSize(s.stateLabelSize)
{}

StateSerializer::StateSerializer(const StateSerializer &other)
: m_valid(other.m_valid), m_stateName(other.m_stateName), m_pos(other.m_pos),
  m_typeName(other.m_typeName), m_label(other.m_label), m_dimmed(other.m_dimmed),
  m_stateLineStyle(other.m_stateLineStyle),
  m_stateLineWidth(other.m_stateLineWidth), m_stateLineColor(other.m_stateLineColor),
  m_stateLabelColor(other.m_stateLabelColor), m_stateLabelScale(other.m_stateLabelScale),
  m_stateFillStatus(other.m_stateFillStatus), m_stateFillColor(other.m_stateFillColor),
  m_dimStateLineStyle(other.m_dimStateLineStyle), m_dimStateLineColor(other.m_dimStateLineColor),
  m_dimStateLineCoef(other.m_dimStateLineCoef), m_dimStateLabelColor(other.m_dimStateLabelColor),
  m_dimStateFillColor(other.m_dimStateFillColor), m_stateLineDoubleCoef(other.m_stateLineDoubleCoef),
  m_stateLineDoubleSep(other.m_stateLineDoubleSep), m_stateLabelSize(other.m_stateLabelSize)
{}

State* StateSerializer::createState(Editor *editor, const QPoint &pos)
{
    if (m_valid)
    {
        StateManager *stateManager = StateManager::getInstance();

        QString name = editor->getUniqueAutoName();
        editor->increaseNewStateNumber();
        
        State *state = stateManager->createState(
            m_typeName, editor, pos , m_label, name, m_dimmed
                        );

        state->stateLineStyle = (Qt::PenStyle) m_stateLineStyle;
        state->setStateLineWidth(m_stateLineWidth);
        state->stateLineColor = m_stateLineColor;
        state->stateLabelColor = m_stateLabelColor;
        state->setStateLabelScale(m_stateLabelScale);
        state->stateFillStatus = (Qt::BrushStyle) m_stateFillStatus;
        state->stateFillColor = m_stateFillColor;
        state->dimStateLineStyle = (Qt::PenStyle) m_dimStateLineStyle;
        state->dimStateLineColor = m_dimStateLineColor;
        state->setDimStateLineCoef(m_dimStateLineCoef);
        state->dimStateLabelColor = m_dimStateLabelColor;
        state->dimStateFillColor = m_dimStateFillColor;
        state->setStateLineDoubleCoef(m_stateLineDoubleCoef);
        state->setStateLineDoubleSep(m_stateLineDoubleSep);
        state->stateLabelSize = m_stateLabelSize;
        
        return state;
    }
    return NULL;
}

//-------------------------------------------------- StateSerializer -->



//<-- TransitionSerializer ---------------------------------------------

#define TS_PARAMS(obj, xx) obj.m_stateNames xx \
    obj.m_typeName xx obj.m_label xx obj.m_labelPos xx \
    obj.m_dimmed xx obj.m_arcAngleA xx obj.m_arcAngleB xx \
    obj.m_nCurv xx obj.m_leftOriented xx obj.m_direction xx obj.m_labels xx \
    obj.m_edgeLineStyle xx obj.m_edgeLineWidth xx \
    obj.m_edgeLineColor xx obj.m_edgeLabelColor xx \
    obj.m_edgeLabelScale xx obj.m_edgeLineDblStatus xx \
    obj.m_edgeLineBorderCoef xx obj.m_edgeLineBorderColor xx \
    obj.m_edgeLineDblCoef xx obj.m_edgeLineDblSep xx \
    obj.m_dimEdgeLineStyle xx obj.m_dimEdgeLineColor xx \
    obj.m_dimEdgeLineCoef xx obj.m_dimEdgeLabelColor xx \
    obj.m_labels xx obj.m_labelsPositions xx obj.m_labelsLeftOriented

QDataStream &operator<<(QDataStream &out, const TransitionSerializer &s)
{
    Q_ASSERT(s.m_valid && "do NOT use uninitialized serializer!");
    DBGLOG_SER("stateNames=" << s.m_stateNames);
    out << TS_PARAMS(s, <<);
    return out;
}

QDataStream &operator>>(QDataStream &in, TransitionSerializer &s)
{
    in >> TS_PARAMS(s, >>);
    DBGLOG_SER("stateNames=" << s.m_stateNames);
    s.m_valid = true;
    return in;
}

TransitionSerializer::TransitionSerializer(const Transition &tr)
: m_valid(true), m_typeName(tr.getTypeName()),
  m_label(tr.getLabelText()), m_labelPos(tr.getLabelPos()), m_dimmed(tr.dimmed),
  m_arcAngleA(tr.getArcAngle()), m_arcAngleB(tr.getArcAngleB()),
  m_nCurv(tr.getNCurv()), m_leftOriented(tr.leftOriented),
  m_direction(tr.getDirection()), m_edgeLineStyle(tr.edgeLineStyle),
  m_edgeLineWidth(tr.edgeLineWidth), m_edgeLineColor(tr.edgeLineColor),
  m_edgeLabelColor(tr.edgeLabelColor), m_edgeLabelScale(tr.edgeLabelScale),
  m_edgeLineDblStatus(tr.edgeLineDblStatus), m_edgeLineBorderCoef(tr.edgeLineBorderCoef),
  m_edgeLineBorderColor(tr.edgeLineBorderColor), m_edgeLineDblCoef(tr.edgeLineDblCoef),
  m_edgeLineDblSep(tr.edgeLineDblSep), m_dimEdgeLineStyle(tr.dimEdgeLineStyle),
  m_dimEdgeLineColor(tr.dimEdgeLineColor), m_dimEdgeLineCoef(tr.dimEdgeLineCoef),
  m_dimEdgeLabelColor(tr.dimEdgeLabelColor)
{
    foreach(LabelX *label, tr.getNextLabels())
    {
        m_labels << label->text();
        m_labelsPositions << label->posParam();
        m_labelsLeftOriented << label->left();
    }

    m_stateNames << tr.getStartStateName();
    if (tr.hasEndState())
    {
        m_stateNames << tr.getEndStateName();
    }
}

TransitionSerializer::TransitionSerializer(const TransitionSerializer &other)
: m_valid(other.m_valid), m_stateNames(other.m_stateNames), m_typeName(other.m_typeName),
  m_label(other.m_label), m_labelPos(other.m_labelPos), m_dimmed(other.m_dimmed),
  m_arcAngleA(other.m_arcAngleA), m_arcAngleB(other.m_arcAngleB), m_nCurv(other.m_nCurv),
  m_leftOriented(other.m_leftOriented), m_direction(other.m_direction), m_labels(other.m_labels),
  m_labelsPositions(other.m_labelsPositions), 
  m_labelsLeftOriented(other.m_labelsLeftOriented),
  m_edgeLineStyle(other.m_edgeLineStyle),
  m_edgeLineWidth(other.m_edgeLineWidth), m_edgeLineColor(other.m_edgeLineColor),
  m_edgeLabelColor(other.m_edgeLabelColor), m_edgeLabelScale(other.m_edgeLabelScale),
  m_edgeLineDblStatus(other.m_edgeLineDblStatus), m_edgeLineBorderCoef(other.m_edgeLineBorderCoef),
  m_edgeLineBorderColor(other.m_edgeLineBorderColor), m_edgeLineDblCoef(other.m_edgeLineDblCoef),
  m_edgeLineDblSep(other.m_edgeLineDblSep), m_dimEdgeLineStyle(other.m_dimEdgeLineStyle),
  m_dimEdgeLineColor(other.m_dimEdgeLineColor), m_dimEdgeLineCoef(other.m_dimEdgeLineCoef),
  m_dimEdgeLabelColor(other.m_dimEdgeLabelColor)
{}

Transition* TransitionSerializer::createTransition(Editor *editor, QList<State*> &states)
{
    if (m_valid)
    {
        Q_ASSERT(m_stateNames.count() >= 1);
        Q_ASSERT(m_stateNames.count() == states.count());

        State *startState = states[0];

        TransitionManager *transitionManager = TransitionManager::getInstance();
        
        Transition *transition;
        if (m_stateNames.count() == 1)
        {
            transition = transitionManager->createOneStateTransition(
                m_typeName, editor, startState, m_label, m_direction, m_dimmed
                   );
        }
        else
        {
            State *endState = states[1];
            Q_ASSERT(startState->getName() != endState->getName());

            transition = transitionManager->createTwoStatesTransition(
                m_typeName, editor, startState, endState, m_label, m_leftOriented, m_dimmed
                   );
        }

        Q_ASSERT(transition && "Transition wasn't created!");
        
        for (int i=0; i < m_labels.count(); ++i)
        {
            LabelX *label = 
                new LabelX(transition, m_labels[i], m_labelsLeftOriented[i],
                    transition->m_labelFontSize, transition->getLabelColor(),
                    m_labelsPositions[i]);
            transition->addNextLabel(label);
        }

        transition->setArcAngle(m_arcAngleA);
        transition->setArcAngleB(m_arcAngleB);
        transition->setNCurv(m_nCurv);

        transition->edgeLineStyle = (Qt::PenStyle) m_edgeLineStyle;
        transition->setEdgeLineWidth(m_edgeLineWidth);
        transition->edgeLineColor = m_edgeLineColor;
        transition->edgeLabelColor = m_edgeLabelColor;
        transition->setEdgeLabelScale(m_edgeLabelScale);
        transition->edgeLineDblStatus = m_edgeLineDblStatus;
        transition->edgeLineBorderCoef = m_edgeLineBorderCoef;
        transition->edgeLineBorderColor = m_edgeLineBorderColor;
        transition->edgeLineDblCoef = m_edgeLineDblCoef;
        transition->edgeLineDblSep = m_edgeLineDblSep;
        transition->dimEdgeLineStyle = (Qt::PenStyle) m_dimEdgeLineStyle;
        transition->dimEdgeLineColor = m_dimEdgeLineColor;
        transition->setDimEdgeLineCoef(m_dimEdgeLineCoef);
        transition->dimEdgeLabelColor = m_dimEdgeLabelColor;

        transition->adjust();
        return transition;
    }
    return NULL;
}

//--------------------------------------------- TransitionSerializer -->



//<-- SelectionSerializer ----------------------------------------------

QDataStream &operator<<(QDataStream &out, const SelectionSerializer &s)
{
    Q_ASSERT(s.m_valid && "do NOT use uninitialized serializer!");

    out << s.m_hotSpot;
    
    // since QDataStream operators are defined for QList<T>
    // where T has to have QDataStream operators defined, 
    // we can use just this
    out << s.m_serializedStates;
    
    out << s.m_serializedTransitions;
    
    return out;
}

QDataStream &operator>>(QDataStream &in, SelectionSerializer &s)
{
    in >> s.m_hotSpot;

    // since QDataStream operators are defined for QList<T>
    // where T has to have QDataStream operators defined, 
    // we can use just this
    in >> s.m_serializedStates;

    in >> s.m_serializedTransitions;
    
    s.m_valid = true;
    return in;
}

SelectionSerializer::SelectionSerializer(const TItemList &items)
: m_valid(true)
{
    State *state = NULL;
    Transition *transition = NULL;

    QRectF boundingBox;

    foreach(QGraphicsItem *item, items)
    {
        if ((state = dynamic_cast<State *>(item)))
        {
            DBGLOG_SER("state serialized");
            m_serializedStates << StateSerializer(*state);
            boundingBox |= state->mapToScene(state->boundingRect()).boundingRect();
            state = NULL;
        }
        else if ((transition = dynamic_cast<Transition *>(item)))
        {
            DBGLOG_SER("transition serialized");
            m_serializedTransitions << TransitionSerializer(*transition);
            transition = NULL;
        }
        // else -> e.g LabelX type, not important for serializing (only text is stored)
        // now there shouln't be any other items
    }

    m_hotSpot = boundingBox.center();

    DBGLOG_SER(DBGPAR(boundingBox) << DBGPAR(m_hotSpot));
}

SelectionSerializer::SelectionSerializer(const SelectionSerializer &other)
: m_valid(true)
{
    m_serializedStates = other.m_serializedStates;

    m_serializedTransitions = other.m_serializedTransitions;
}

SelectionSerializer::TItemsPair SelectionSerializer::createItems(Editor *editor, const QPoint &pos)
{
    TStateList states;
    TTransitionList transitions;
    QPointF translation;
    
    TStateNameMap stateMap; // for transitons adding
    State *state;    

    for(int i=0; i<m_serializedStates.count(); ++i)
    {
        translation = m_serializedStates[i].m_pos - m_hotSpot;

        state = m_serializedStates[i].createState(editor, pos + translation.toPoint());        
        Q_ASSERT(state && "state wasn't created!");

        stateMap.insert(m_serializedStates[i].m_stateName, state);

        DBGLOG_SER("origStateName" << m_serializedStates[i].m_stateName <<
                   "newstateName=" << state->getName());
        states << state;
    }

    Transition *transition;

    for(int i=0; i<m_serializedTransitions.count(); ++i)
    {
        QList<State *> trStates;
        foreach(QString name, m_serializedTransitions[i].m_stateNames)
        {
            if (!stateMap.contains(name))
            {
                continue; // TODO: implement state selecting
            }
            
            trStates << stateMap.value(name);
        }

        if (trStates.count() != m_serializedTransitions[i].m_stateNames.count())
        {
            DBGLOG_SER("transition dropped");
            continue;
        }

        transition = m_serializedTransitions[i].createTransition(editor, trStates);
        transition->assign(); // assign to states
        
        DBGLOG_SER(DBGPAR(trStates));

        transitions << transition;
    }

    return qMakePair(states, transitions);
}

//---------------------------------------------- SelectionSerializer -->
