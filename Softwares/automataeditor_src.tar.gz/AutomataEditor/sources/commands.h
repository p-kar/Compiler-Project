#ifndef COMMANDS_H_13452674738
#define COMMANDS_H_13452674738

#include <QUndoCommand>
#include <QPointF>
#include <QRect>
#include <QMap>
#include <QGraphicsItem>
#include <QVector>
#include <QList>

class Editor;
class State;
class Transition;
class OneStateTransition;
class TwoStatesTransition;
class LabelX;

QString createCommandString(State *state, const QPointF &point);

class ShowGridFrameCommand : public QUndoCommand
{
public:
    ShowGridFrameCommand(Editor *editor, bool origGrid, bool origFrame,
                                         bool grid, bool frame);

    void undo();
    void redo();

private:
    QString getMsg() const;

    Editor *m_editor;
    bool    m_origGrid, m_grid;
    bool    m_origFrame, m_frame;
};

class StateMoveCommand : public QUndoCommand
{
public:
  StateMoveCommand(State *state, const QPointF &oldPos, QUndoCommand *parent = 0);
  
  void undo();
  void redo();

private:
  State *state;
  QPointF oldPos;
  QPointF newPos;
};

class StateAddCommand : public QUndoCommand
{
public:
  StateAddCommand(Editor *editor, State *state, QUndoCommand *parent = 0);
  ~StateAddCommand();
  
  void undo();
  void redo();

private:
  Editor *editor;
  State *state;
  
  bool wasUndo; // osetreni fyzickeho deletnuti stavu
};

class StateDeleteCommand: public QUndoCommand
{
public:
  StateDeleteCommand(Editor *editor, State *state, QUndoCommand *parent = 0);
  ~StateDeleteCommand();  
  
  void undo();
  void redo();

private:
  Editor *editor;
  State *state;
  QList<Transition *> transitionList;
  
  bool wasUndo;
};

class StateEditCommand: public QUndoCommand
{
public:
  StateEditCommand(Editor *editor, State *state, QString label, QString name, bool db, bool dimmed,
                   bool autoNammed, QUndoCommand *parent = 0);
  
  void undo();
  void redo();
private:
  Editor *editor;
  State *state;
  
  QString label_old, label_new;
  QString name_old, name_new;
  bool db_old, db_new;
  bool dimmed_old, dimmed_new;
  bool an_old, an_new;   
};

class StateEditWithDelCommand: public QUndoCommand
{
public:
    StateEditWithDelCommand(Editor *editor, State *state_backup, State *state_new,
                            QUndoCommand *parent = 0);
    ~StateEditWithDelCommand();

    void undo();
    void redo();

    void copyExtendedParameters(State* s1, State* const s2);
private:
    Editor *editor;
    State *state_backup, *state_new;
    QList<Transition *> transitionList;

    bool wasUndo;
};

class StateEditExtendedCommand: public QUndoCommand
{
public:
  StateEditExtendedCommand(State *state, Qt::PenStyle lineS, float lineW, const QString &lineC,
                           const QString &labelC, float labelS, Qt::BrushStyle fillS, 
                           const QString &fillC, Qt::PenStyle dimLineS, const QString &dimLineC,
                           float dimLineCoef, const QString &dimLabelC, const QString &dimFillC,
                           float lineDC, float lineDS, QUndoCommand *parent = 0);
                           
  void undo();
  void redo();
private:
  State *state;
  // state parameters
  Qt::PenStyle lineStyle, lineStyle_old;
  float lineWidth, lineWidth_old;
  QString lineColor, lineColor_old;
  QString labelColor, labelColor_old;
  float labelScale, labelScale_old;
  Qt::BrushStyle fillStatus, fillStatus_old;
  QString fillColor, fillColor_old;
    
  // state parametres dimmed
  Qt::PenStyle dimLineStyle, dimLineStyle_old;
  QString dimLineColor, dimLineColor_old;
  float dimLineCoef, dimLineCoef_old;
  QString dimLabelColor, dimLabelColor_old;
  QString dimFillColor, dimFillColor_old;
    
  // state parametres double
  float lineDoubleCoef, lineDoubleCoef_old;
  float lineDoubleSep, lineDoubleSep_old;
};



class TransitionAddCommand: public QUndoCommand
{
public: 
  TransitionAddCommand(Editor *editor, Transition *transition, QUndoCommand *parent = 0);                       
  ~TransitionAddCommand();
                       
  void undo();
  void redo();
private:
  Editor *editor;
  Transition *transition; // jen pro undo akci k AddCommandu
  
  bool wasUndo;
};

class TransitionDeleteCommand: public QUndoCommand
{
public:
  TransitionDeleteCommand(Editor *editor, Transition *transition, QUndoCommand *parent = 0);
  ~TransitionDeleteCommand();
  
  void undo();
  void redo();

private:
  Editor *editor;
  Transition *transition; // jen pro undo akci k AddCommandu
  
  bool wasUndo;
};

class OneStateTransitionEditCommand: public QUndoCommand
{
public:
    OneStateTransitionEditCommand
        (OneStateTransition *tr, QString label, float labelPos, int direction, bool dimmed,
         QUndoCommand *parent = 0);

    void undo();
    void redo();

private:
    OneStateTransition *tr;

    QString lab_old, lab_new;
    float labelPos_old, labelPos_new;
    int dir_old, dir_new;
    bool dimmed_old, dimmed_new;
};

class TwoStatesTransitionEditCommand: public QUndoCommand
{
public:
  TwoStatesTransitionEditCommand
      (TwoStatesTransition *tr, QString label, float labelPos, bool dimmed,
       bool leftOriented = false, int arcAngle = 0,
       int arcAngleB = 0, float ncurv = 0, QUndoCommand *parent = 0);
  
  void undo();
  void redo();

private:
  TwoStatesTransition *tr;
  
  QString lab_old, lab_new;
  float labelPos_old, labelPos_new;
  bool dimmed_old, dimmed_new;
  bool lo_old, lo_new;
  int angle_old, angle_new;
  int angleB_old, angleB_new;
  float ncurv_old, ncurv_new;
};

class TransitionEditWithDelCommand: public QUndoCommand
{
public:
  TransitionEditWithDelCommand(Editor *editor, Transition *tr_backup, Transition *tr_new,
                               QUndoCommand *parent = 0);
  ~TransitionEditWithDelCommand();
  
  void undo();
  void redo();
  
  void copyExtendedParameters(Transition *tr1, Transition* const tr2);
private:
  Editor *editor;
  Transition *tr_backup, *tr_new;
  
  bool wasUndo;
};

class TransitionEditExtendedCommand: public QUndoCommand
{
public:
  TransitionEditExtendedCommand(Transition *tr, Qt::PenStyle lineS, float lineW, const QString &lineC,
                           const QString &labelC, float labelS, bool lineDoubleS, Qt::PenStyle dimLineS, 
                           const QString &dimLineC, float dimLineCoef, const QString &dimLabelC,
                           float borderCoef, const QString &borderColor,
                           float lineDC, float lineDS, QUndoCommand *parent = 0);
                           
  void undo();
  void redo();
private:
  Transition *tr;
  // edge parameters
  Qt::PenStyle lineStyle, lineStyle_old;
  float lineWidth, lineWidth_old;
  QString lineColor, lineColor_old;
  QString labelColor, labelColor_old;
  float labelScale, labelScale_old;
  bool lineDoubleStatus, lineDoubleStatus_old;
    
  // edge parametres dimmed
  Qt::PenStyle dimLineStyle, dimLineStyle_old;
  QString dimLineColor, dimLineColor_old;
  float dimLineCoef, dimLineCoef_old;
  QString dimLabelColor, dimLabelColor_old;
  
  // edge parameters border  
  float borderCoef, borderCoef_old;
  QString borderColor, borderColor_old;
  
  // edge parametres double
  float lineDoubleCoef, lineDoubleCoef_old;
  float lineDoubleSep, lineDoubleSep_old;
};

class NextLabelAddCommand: public QUndoCommand
{
public:
    NextLabelAddCommand(Editor *editor, LabelX *label, QUndoCommand *parent = 0);
    ~NextLabelAddCommand();

    void undo();
    void redo();

protected:
    Editor*     editor;
    LabelX*    label;
    bool        wasUndo;
};

class NextLabelDeleteCommand: public QUndoCommand
{
public:
    NextLabelDeleteCommand(Editor *editor, LabelX *label, QUndoCommand *parent = 0);
    ~NextLabelDeleteCommand();

    void undo();
    void redo();

protected:
    Editor*     editor;
    LabelX*     label;
    bool        wasUndo;
};

class NextLabelEditCommand: public QUndoCommand
{
public:
    NextLabelEditCommand(LabelX *label, const QString &labelText, float labelPos, bool isLeft, QUndoCommand *parent = 0);
    
    void undo();
    void redo();

protected:
    LabelX*     label;
    QString     labelText_backup;
    float       labelPos_backup;
    QString     labelText_new;
    float       labelPos_new;
    bool        isLeft_backup;
    bool        isLeft_new;
};

class EditorChangeGridRectCommand: public QUndoCommand
{
public:
  EditorChangeGridRectCommand(Editor *editor, QRect gridRect ,int border, QUndoCommand *parent = 0);
  
  void undo();
  void redo();
private:
  Editor *editor;
  QRect gridRect_old, gridRect_new;
  int border_old, border_new;
};

class StateStyleChangeCommand: public QUndoCommand
{
public:
  StateStyleChangeCommand(Editor *editor, int changeT, Qt::PenStyle lineS, float lineW, 
                          const QString &lineC, const QString &labelC, float labelS,
                          Qt::BrushStyle fillS, const QString &fillC, Qt::PenStyle dimLineS,
                          const QString &dimLineC, float dimLineCoef, const QString &dimLabelC,
                          const QString &dimFillC, float lineDC, float lineDS,
                          QUndoCommand *parent = 0);
                           
  void undo();
  void redo();
private:
  Editor *editor;
  int changeType; // type of change | 0 .. new style | 1 .. global style | 2 .. all states |
  
  QList<State *> changedStates; // filling by changeType
  
  //for posibility to restore change for each state
  QMap<State *, Qt::PenStyle> lineStyleMap; 
  QMap<State *, float> lineWidthMap;
  QMap<State *, QString> lineColorMap;
  QMap<State *, QString> labelColorMap;
  QMap<State *, float> labelScaleMap;
  QMap<State *, Qt::BrushStyle> fillStatusMap;
  QMap<State *, QString> fillColorMap;
  QMap<State *, Qt::PenStyle> dimLineStyleMap;
  QMap<State *, QString> dimLineColorMap;
  QMap<State *, float> dimLineCoefMap;
  QMap<State *, QString> dimLabelColorMap;
  QMap<State *, QString> dimFillColorMap;
  QMap<State *, float> lineDoubleCoefMap;
  QMap<State *, float> lineDoubleSepMap;
  
  // state parameters
  Qt::PenStyle lineStyle, lineStyle_old;
  float lineWidth, lineWidth_old;
  QString lineColor, lineColor_old;
  QString labelColor, labelColor_old;
  float labelScale, labelScale_old;
  Qt::BrushStyle fillStatus, fillStatus_old;
  QString fillColor, fillColor_old;
    
  // state parametres dimmed
  Qt::PenStyle dimLineStyle, dimLineStyle_old;
  QString dimLineColor, dimLineColor_old;
  float dimLineCoef, dimLineCoef_old;
  QString dimLabelColor, dimLabelColor_old;
  QString dimFillColor, dimFillColor_old;
    
  // state parametres double
  float lineDoubleCoef, lineDoubleCoef_old;
  float lineDoubleSep, lineDoubleSep_old;
};

class TransitionStyleChangeCommand: public QUndoCommand
{
public:
  TransitionStyleChangeCommand(Editor *editor, int ChangeT,  Qt::PenStyle lineS, float lineW, 
    const QString &lineC, const QString &labelC, float labelS, bool lineDoubleS,
    Qt::PenStyle dimLineS, const QString &dimLineC, float dimLineCoef,
    const QString &dimLabelC, float borderCoef, const QString &borderColor,
    float lineDC, float lineDS, QUndoCommand *parent = 0);
                           
  void undo();
  void redo();
private:
  Editor *editor;
  int changeType;
  
  QList<Transition *> changedTransitions; // filling by changeType
  
  //for posibility to restore change for each state
  QMap<Transition *, Qt::PenStyle> lineStyleMap;
  QMap<Transition *, float> lineWidthMap;
  QMap<Transition *, QString> lineColorMap;
  QMap<Transition *, QString> labelColorMap;
  QMap<Transition *, float> labelScaleMap;
  QMap<Transition *, bool> lineDoubleStatusMap;
  QMap<Transition *, Qt::PenStyle> dimLineStyleMap;
  QMap<Transition *, QString> dimLineColorMap;
  QMap<Transition *, float> dimLineCoefMap;
  QMap<Transition *, QString> dimLabelColorMap;
  QMap<Transition *, float> lineBorderCoefMap;
  QMap<Transition *, QString> lineBorderColorMap;
  QMap<Transition *, float> lineDoubleCoefMap;
  QMap<Transition *, float> lineDoubleSepMap;
  
  // edge parameters
  Qt::PenStyle lineStyle, lineStyle_old;
  float lineWidth, lineWidth_old;
  QString lineColor, lineColor_old;
  QString labelColor, labelColor_old;
  float labelScale, labelScale_old;
  bool lineDoubleStatus, lineDoubleStatus_old;
    
  // edge parametres dimmed
  Qt::PenStyle dimLineStyle, dimLineStyle_old;
  QString dimLineColor, dimLineColor_old;
  float dimLineCoef, dimLineCoef_old;
  QString dimLabelColor, dimLabelColor_old;
  
  // edge parameters border  
  float borderCoef, borderCoef_old;
  QString borderColor, borderColor_old;
  
  // edge parametres double
  float lineDoubleCoef, lineDoubleCoef_old;
  float lineDoubleSep, lineDoubleSep_old;
};

template <typename T>
class MoveItemsCommand : public QUndoCommand
{
public:
    MoveItemsCommand(const QList<T *> &items, const QVector<QPointF> &origPos)
    :   m_itemList(items), m_origPositions(origPos), m_newPositions(origPos.size())
    {
        int i = 0;
        foreach(QGraphicsItem *item, items)
        {
            m_newPositions[i] = item->pos();
            ++i;
        }
    }
  
    void undo()
    {
        QPointF pos;
        int i = 0;
        foreach(QGraphicsItem* item, m_itemList)
        {
            pos = m_origPositions[i];
            if (pos != item->pos())
            {
                item->setPos(pos.x(), pos.y());
            }
            ++i;
        }
        setText(QObject::tr("Move items"));
    }

    void redo()
    {
        QPointF pos;
        int i = 0;
        foreach(QGraphicsItem* item, m_itemList)
        {
            pos = m_newPositions[i];
            if (pos != item->pos())
            {
                item->setPos(pos.x(), pos.y());
            }
            ++i;
        }
        setText(QObject::tr("Move items"));
    }

private:
    QList<T *> m_itemList;
    QVector<QPointF> m_origPositions, m_newPositions;
};

template <typename T>
MoveItemsCommand<T>* createMoveItemsCommand(const QList<T *> &items, const QVector<QPointF> &origPos)
{
    return new MoveItemsCommand<T>(items, origPos);
}

// TODO: remove this and use ItemsAddCommand istead -> needed to change generation
class GeneratedGraphAddCommand : public QUndoCommand
{
public:
  GeneratedGraphAddCommand(Editor *editor, const QList<State *> &stateList, QRect gr_new,
    QUndoCommand *parent = 0);

  ~GeneratedGraphAddCommand();

  void undo();
  void redo();
private:
  Editor *editor;
  QList<State *> stateList;
  
  QRect gridRect_new, gridRect_old;
  bool wasUndo;
};

class ItemsAddCommand : public QUndoCommand
{
public:
    ItemsAddCommand(Editor *editor, const QList<State *> &stateList, QRect gr_new,
                    QUndoCommand *parent = 0);

    ~ItemsAddCommand();

    void undo();
    void redo();    

protected:
    Editor *editor;
    QList<State *> stateList;

    QRect gridRect_new, gridRect_old;
    bool wasUndo;
};

class ItemsRemoveCommand : public QUndoCommand
{
public:
    ItemsRemoveCommand(Editor *editor, const QList<State *> &stateList,
                       const QList<Transition *> &transitionList,
                       QUndoCommand *parent = 0);    

    ~ItemsRemoveCommand();

    void undo();
    void redo();

protected:
    Editor *editor;
    QList<State *> stateList;
    QList<Transition *> transitionList;

    bool wasUndo;
};

class StatesSetMarkedCommand : public QUndoCommand
{
public:
    StatesSetMarkedCommand(QList<State*> states, bool marked, QUndoCommand *parent = 0);
    
    ~StatesSetMarkedCommand();
    
    void undo();
    void redo();
    
protected:
    QList<State*>   m_states;
    bool            m_marked;
};

#endif
