#ifndef _AUTOMATAWORKSIMULATOR_H_68481631923_
#define _AUTOMATAWORKSIMULATOR_H_68481631923_

#include "automataCreator.h"
#include "stringProcessor.h"

#include <QObject>
#include <QDialog>
class Editor;
class State;
class SimulationMarker;
class SimulationDialog;
class QUndoStack;

#include <QTimer>

/*!
 * Main simulation class, implements simulation logic.
 */
class AutomataWorkSimulator : public QObject
{
    Q_OBJECT
public:
    AutomataWorkSimulator(Editor *editor, QUndoStack &undoStack,
                          const QSharedPointer<AutomatonImpl> &automaton);    

    ~AutomataWorkSimulator();

    bool    hasStateBefore() const;     //!< determines, if it's possible to do step back
    bool    hasStateAfter() const;      //!< determines, if it's possible to process next step
    bool    isPlaying() const;          //!< determines, if automatic simulation is running
    bool    isSet() const;              //!< determines, if input is set correctly
    int     getPos() const;             //!< returns current position in input string

    //! helper struct for storing configurations
    struct Configuration
    {
        enum EStatus { eNoStatus, eAccepted, eError };
        QStringList activeStates;                       //!< active states in current configuration
        QStringList processed;                          //!< processed part of input
        QStringList input;                              //!< left part of input
        EStatus     status;                             //!< configuration status, \value eError means that no next step is possible
        
        Configuration(const QStringList &a, const QStringList &p, const QStringList &i, EStatus s = eNoStatus)
        : activeStates(a), processed(p), input(i), status(s)
        {}
    };
    
    typedef QList<Configuration>    TConfigurationList;

    TConfigurationList      getConfigurations() const;

public slots:
    void run();                         //!< runs simulation dialog
    
    bool setInput(const QString &text); //!< sets input string, if it's correctly defined
    
    void stepForward();                 //!< process single step
    
    void stepBackward();                //!< reverts last step
    
    void play();                        //!< runs automatic simulation
    
    void pause();                       //!< stops automatic simulation
    
    void reset();                       //!< resets state of simulation

    void generateSlideshow();           //!< processes all steps of simulation and stores it to slideshow

signals:
    void finished();                            //!< signal emited when simulation ends
    void setStatesMarked(QList<State*>, bool);  //!< signal catched by editor \sa Editor::setStatesMarked()

protected slots:
    void animate();         //!< processes single step of animation (called by timer)
    void dialogClosed();

    void processStep();     //!< processes single step of simulation
        
    void stepSpeedChanged(double);
    void animSpeedChanged(double);
    void useAnimChanged(int);

protected:    
    bool animateMove();
    void setActiveStatesMarked(bool);
    void doAnimation(const QList<QPainterPath> &paths);
    QList<QPainterPath> revertPaths(const QList<QPainterPath> &paths) const;
    
    void refreshPlayingStatus();
    
    bool getFileName(QString &fileName, bool &latexHeader);
    void saveInputState(QTextStream &out);
        
private:
    Editor                                  *m_editor;
    QUndoStack                              &m_undoStack;
    int                                     m_undoStackStartIdx;
    
    QSharedPointer<AutomatonImpl>           m_automaton;
    QList<SimulationMarker*>                m_markers;
    Configuration::EStatus                  m_status;
    int                                     m_inputIndex;   //!< position in input stringList
    StringProcessor::TCharacterList         m_inputList;
    QScopedPointer<SimulationDialog>        m_dialog;
    
    //! step back uses undoStack, so when then is steping forward required again, only redo is done
    int                                     m_backSteps;
        
    StateImpl::TStateList                   m_activeStates;
    bool                                    m_activeStatesAreMarked;
    
    QScopedPointer<QTimer>                  m_simulationTimer;
    bool                                    m_playing;
    
    enum EAnimateState { eMoving, eStopped };
    QScopedPointer<QTimer>                  m_animationTimer;
    EAnimateState                           m_animationState;
    bool                                    m_useAnimations;
    int                                     m_pathCount;
    float                                   m_animationSpeed;
        
    TConfigurationList                      m_configurationList;
    QVector<StateImpl::TStateList>          m_activeStatesMemory;
    QVector<QList<QPainterPath> >           m_animationPathMemory;
};



class QLabel;
class QLineEdit;
class QPushButton;
class QTableWidget;
class QTextEdit;
class QCheckBox;
class QDoubleSpinBox;

/*!
 * Dialog for manipulation with simulation.
 * \sa AutomataWorkSimulator
 */
class SimulationDialog : public QDialog
{
    Q_OBJECT
public:
    SimulationDialog(Editor *editor, AutomataWorkSimulator *simulator);
    ~SimulationDialog();
    
    int         getInputLength() const;
    QString     getInput() const;

    static void showMessageSetInputFailed(QWidget *parent);

public slots:
    void updateState(); //!< called from simulator (owner)
    
private:
    Editor                  *m_editor;
    AutomataWorkSimulator   *m_simulator;
    
    QLineEdit       *m_edtInput;    
    
    QPushButton     *m_btnStepFwd;
    QPushButton     *m_btnStepBack;
    QPushButton     *m_btnPlay;
    QPushButton     *m_btnPause;
    QPushButton     *m_btnReset;
    
    QPushButton     *m_btnGenerate;
    
    QTextEdit       *m_textSimulation;
    
    QCheckBox       *m_checkUseAnim;
    QDoubleSpinBox  *m_stepSpeed;
    QDoubleSpinBox  *m_animSpeed;
    
    QCheckBox       *m_checkPrettyPrint;
    
    bool            m_bUsePrettyPrint; //!< if true, latex symbols are drawed in symbol font,
                                       //!< otherwise is printed latex syntax (e.g. \alpha)
    
protected slots:
    void appendSymbol(const QString &sybmol);
    void prettyPrintChanged(int state);

    void stepForward();
    void play();
    
    void set();
    bool setInput();

signals:
    void closed();
    void useAnimChanged(int /*state*/);
    void stepSpeedChanged(double /*time*/);
    void animSpeedChanged(double /*time*/);
};

#endif
