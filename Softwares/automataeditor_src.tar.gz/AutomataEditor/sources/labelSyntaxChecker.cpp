#include "constants.h"

#include "labelSyntaxChecker.h"
#include "stringProcessor.h"

LabelSyntaxChecker::LabelSyntaxChecker(
    const ITransition::TCharSet &alphabet,
    const QString &alphabetSymb,
    const QString &epsilonSymb)
:   m_alphabet(alphabet), m_alphabetSymb(alphabetSymb), m_epsilonSymb(epsilonSymb)
{
    DBGLOG(DBGPAR(alphabet));
    DBGLOG(DBGPAR(alphabetSymb));
    DBGLOG(DBGPAR(epsilonSymb));
}

QString LabelSyntaxChecker::getReport()
{
    return report.join("<br>");
}

ITransition::TCharSet LabelSyntaxChecker::getCharacters()
{
    return characters;
}

LabelSyntaxChecker::ELabelTextPattern LabelSyntaxChecker::getPattern()
{
    return pattern;
}

StringProcessor::CharacterInfo LabelSyntaxChecker::nextToken()
{
    Q_ASSERT(m_characterList.count() > m_idx);
    return m_characterList[m_idx++];
}

bool LabelSyntaxChecker::hasNextToken()
{
    return m_characterList.count() > m_idx;
}

bool LabelSyntaxChecker::processCharacter(ITransition::TCharSet &charSet,
                                          const StringProcessor::CharacterInfo &charInfo)
{
    if (!m_alphabet.contains(charInfo.character))
    {
        report << "Character isn't in alphabet.";
        return false;
    }
    
    if (charInfo.modifier == StringProcessor::eBar || charInfo.modifier == StringProcessor::eOverline)
    {
        report << "Incorrect syntax, cannot be used overlined character here (" + charInfo.character + ").";
        return false;
    }
    
    charSet << charInfo.character;
    return true;
}

bool LabelSyntaxChecker::processBarredCharacter(ITransition::TCharSet &charSet,
                                                const StringProcessor::CharacterInfo &charInfo)
{
    if (!m_alphabet.contains(charInfo.character))
    {
        report << "Character isn't in alphabet.";
        return false;
    }
    
    if (charInfo.modifier != StringProcessor::eBar && charInfo.modifier != StringProcessor::eOverline)
    {
        report << "Incorrect syntax, expected overlined character.";
        return false;
    }
    
    charSet << charInfo.character;
    return true;
}

// recursive descent ---> 

bool LabelSyntaxChecker::checkSyntax(const StringProcessor::TCharacterList &characterList)
{
    report.clear();
    characters.clear();
    pattern = eEmptyPattern;

    m_characterList = characterList;
    m_idx = 0;
    bool ok = true;
    
    if (!hasNextToken()) return ok; // EMPTY INPUT - generally ok, handle in client code!
    StringProcessor::CharacterInfo charInfo = nextToken();
    
    if (charInfo.character == m_epsilonSymb)
    {
        pattern = eEpsilonSymbPattern;
        characters = ITransition::TCharSet() << m_epsilonSymb;
        ok &= End();
        return ok;
    }
    
    if (charInfo.character == m_alphabetSymb)
    {
        characters = m_alphabet;
        ok &= AlphabetOrAlphabetMinusPattern();
        return ok;
    }
    
    if (charInfo.modifier == StringProcessor::eBar)
    {
        pattern = eBarPattern;
        m_idx--;
        ok &= BarPattern();
        if (!ok) return false;
        ok &= End();
        if (!ok) return false;
        
        characters = m_alphabet - characters; // invert
        if (characters.isEmpty())
        {
            report << "Incorrect definition, empty input isn't possible!";
            return false;
        }
        
        return ok;
    }
    
    m_idx--;
    pattern = eNormalPattern;
    ok &= NormalPattern(characters);
    if (!ok) return false;
    if (hasNextToken())
    {
        report << "info: Normal patter syntax is \"[character], [characeter], ...\"";
    }
    ok &= End();
    return ok;
}

bool LabelSyntaxChecker::NormalPattern(ITransition::TCharSet &charSet)
{
    if (!hasNextToken())
    {
        report << "Unexpected end of input.";
        return false;
    }
    
    bool ok = true;
    StringProcessor::CharacterInfo charInfo = nextToken();
    ok &= processCharacter(charSet, charInfo);
    if (!ok) return false;
    
    return NormalPatternNext(charSet);
}

bool LabelSyntaxChecker::NormalPatternNext(ITransition::TCharSet &charSet)
{
    bool ok = true;
    while (hasNextToken())
    {
        StringProcessor::CharacterInfo charInfo = nextToken();
        if (charInfo.character != ",")
        {
            m_idx--; // go back in input
            return true;
        }
        
        if (!hasNextToken())
        {
            report << "Unexpected end of input.";
            return false;
        }
        
        charInfo = nextToken();
        
        ok &= processCharacter(charSet, charInfo);
        if (!ok) return false;
    }
    
    return true;
}

bool LabelSyntaxChecker::BarPattern()
{
    if (!hasNextToken())
    {
        report << "Unexpected end of input.";
        return false;
    }
    
    bool ok = true;
    StringProcessor::CharacterInfo charInfo = nextToken();
    ok &= processBarredCharacter(characters, charInfo);
    if (!ok) return false;
    
    return BarPatternNext();
}

bool LabelSyntaxChecker::BarPatternNext()
{
    bool ok = true;
    while (hasNextToken())
    {
        StringProcessor::CharacterInfo charInfo = nextToken();
        if (charInfo.character != ",")
        {
            report << "Unexpected character, expected ','.";
            return false;
        }
        
        if (!hasNextToken())
        {
            report << "Unexpected end of input.";
            return false;
        }
        
        charInfo = nextToken();
        
        ok &= processBarredCharacter(characters, charInfo);
        if (!ok) return false;
    }
    
    return true;
}

bool LabelSyntaxChecker::AlphabetOrAlphabetMinusPattern()
{
    if (!hasNextToken())
    {
        pattern = eAlphabetPattern;
        return End();
    }
    
    pattern = eAlphabetMinusPattern;
    
    StringProcessor::CharacterInfo charInfo = nextToken();
    if (charInfo.character != "-")
    {
        report << "Unexpected character, expected '-'.";
        return false;
    }
    
    if (!hasNextToken())
    {
        report << "Unexpected end of input.";
        return false;
    }
    
    charInfo = nextToken();
    if (charInfo.character != "\\{")
    {
        report << "Unexpected character, expected '\\{'.";
        return false;
    }
    
    bool ok = true;
    ITransition::TCharSet minusCharacters;
    ok &= NormalPattern(minusCharacters);
    if (!ok) return false;
    
    if (!hasNextToken())
    {
        report << "Unexpected end of input.";
        return false;
    }
    
    charInfo = nextToken();
    if (charInfo.character != "\\}")
    {
        report << "Unexpected character, expected '\\}'.";
        return false;
    }
    
    ok &= End();
    if (!ok) return false;
    
    characters -= minusCharacters;
    if (characters.isEmpty())
    {
        report << "Incorrect definition, empty input isn't possible!";
        return false;
    }
    
    return true;
}

bool LabelSyntaxChecker::End()
{
    if (hasNextToken())
    {
        report << "Unexpected character, expected end of input.";
        return false;
    }
    return true;    
}
