#include "constants.h"

#include "twoStatesTransition.h"
#include "state.h"

#include <QGraphicsSceneMouseEvent>
#include <QtDebug>

void TwoStatesTransition::paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    if (startPoint == endPoint) return;
    Transition::paint(painter, option, widget);
}

void TwoStatesTransition::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    DBGLOG_ME(event->button());
    if (m_lastMouseClickType == eMouseRightClick)
    {
        editor->showPopup(this, mapToScene(event->pos().toPoint()));
        return; // could be deleted!
    }
    else if (m_lastMouseClickType == eMouseDoubleClick)
    {
        editor->editTransition(this);
        return; // could be deleted when type is changed!
    }
    setChecked(false);
}

void TwoStatesTransition::assign()
{
    startState->addTransition(this);
    endState->addTransition(this);
}

void TwoStatesTransition::unassign()
{
    startState->removeTransition(this);
    endState->removeTransition(this);
}

void TwoStatesTransition::setLeftOriented(bool leftO)
{
    leftOriented = leftO;
    adjust();
}

bool TwoStatesTransition::isLeftOriented()
{
    return leftOriented;
}
