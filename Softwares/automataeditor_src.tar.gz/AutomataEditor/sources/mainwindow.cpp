#include "constants.h"

#include "mainwindow.h"
#include "editor.h"
#include "state.h"
#include "transition.h"
#include "ialgorithm.h"
#include "igraphviz.h"

#include <QApplication>
#include <QStatusBar>
#include <QToolBar>
#include <QAction>
#include <QActionGroup>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QHBoxLayout>
#include <QGraphicsScene>
#include <QCloseEvent>

// exportDialog
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QCheckBox>
#include <QFileDialog>
#include <QGridLayout>

#include <QtDebug>
#include <QDesktopWidget>

#include <QRegExp>
#include <QPluginLoader>

#include "stdio.h"

#if QT_VERSION < 0x040500
#   error "Minimal required Qt's version is 4.5.0!"
#endif

MainWindow::MainWindow(const QString &fileName)
{
    //! check Qt version first!!!
    const QString build_version = QT_VERSION_STR;
    const QString runtime_version = qVersion();

    DBGLOG("\nQt build version=" << build_version <<
           "\nQt runtime version=" << runtime_version);

    if (build_version != runtime_version)
    {
        RELLOG("Qt build version=" << build_version <<
               "\nQt runtime version=" << runtime_version);
        RELLOG("Qt build and runtime version are inconsitent, unexpected behavior can occure!\n"
               << "Please run program rather with same Qt version as which application is compiled again\n"
               << "or recompile it with Qt version which you are using.");
    }
    
    setWindowTitle(QString("%1 - %2")
        .arg(PROGRAM_NAME)
        .arg(NEW_FILENAME));
    setWindowIcon(QIcon(":images/snaptogrid.xpm"));

    editor = new Editor(this);

    createStatusBar();
    createActions();
    createToolBars();
    createMenus();

    editor->setAction((Editor::EAction) INIT_ACTION);
    actionChanged((Editor::EAction) INIT_ACTION);

    connect(editor, SIGNAL(actionChanged(int)),
            this, SLOT(actionChanged(int)));

    connect(editor, SIGNAL(canUndoChanged(bool)),
            editUndo, SLOT(setEnabled(bool)));
    connect(editor, SIGNAL(canRedoChanged(bool)),
            editRedo, SLOT(setEnabled(bool)));
    connect(editor, SIGNAL(showUndoStackAvailable(bool)),
            editShowUndoStack, SLOT(setEnabled(bool)));

    connect(editor, SIGNAL(canNewFile(bool)),
            fileNew, SLOT(setEnabled(bool)));
    connect(editor, SIGNAL(canOpenFile(bool)),
            fileOpen, SLOT(setEnabled(bool)));
    connect(editor, SIGNAL(canSaveFile(bool)),
            fileSave, SLOT(setEnabled(bool)));

    connect(editor, SIGNAL(itemsAvailable(bool)),
            this, SLOT(setItemsAvailable(bool)));
    connect(editor, SIGNAL(toolsAvailable(bool)),
            this, SLOT(setToolsAvailable(bool)));
    connect(editor, SIGNAL(utilsAvailable(bool)),
            this, SLOT(setUtilsAvailable(bool)));

    connect(editor, SIGNAL(canZoomIn(bool)),
            zoomIn, SLOT(setEnabled(bool)));
    connect(editor, SIGNAL(canZoomOut(bool)),
            zoomOut, SLOT(setEnabled(bool)));
          
    connect(editor, SIGNAL(showChanged(bool,bool)),
            this, SLOT(actualizeChecking(bool,bool)));

    connect(editor, SIGNAL(isChanged(bool)),
            fileSave, SLOT(setEnabled(bool)));

    setCentralWidget(editor);

    QDesktopWidget desktopWidget;
    QRect screenResolution = desktopWidget.screenGeometry();
    DBGLOG("Screen resolution is " << screenResolution.width() << "x" << screenResolution.height());
  
    // create window with screen bounds
#ifdef TESTING_USE_SMALLER_WINDOW
    setGeometry(screenResolution.width()-640,100,600, 600);
#else
    if(screenResolution.width() > 400 && screenResolution.height() > 200)  
        setGeometry(200, 100, screenResolution.width()-400, screenResolution.height()-200);
#endif

    loadPlugins();

    if (!fileName.isEmpty())
        editor->openFile(fileName);
}

void MainWindow::loadPlugins()
{
    // load static libraris with plugins
    foreach (QObject *plugin, QPluginLoader::staticInstances())
    {
        IAlgorithmHolder *algHolder = qobject_cast<IAlgorithmHolder*>(plugin);
        if (algHolder)
        {
            processAlgorithmsPlugin(algHolder);
        }
    }

    // load dynamic libraries with plugins
    QDir pluginsDir = QDir(qApp->applicationDirPath());
    pluginsDir.cd("plugins");
    DBGLOG("Libraries in plugins directory: " << pluginsDir.entryList(QDir::Files));
    foreach (QString fileName, pluginsDir.entryList(QDir::Files))
    {
        DBGLOG("Trying to load: " << pluginsDir.absoluteFilePath(fileName));
        QPluginLoader loader(pluginsDir.absoluteFilePath(fileName));        
        QObject *plugin = loader.instance();
        if (plugin)
        {
            IAlgorithmHolder *algHolder = qobject_cast<IAlgorithmHolder*>(plugin);
            if (algHolder)
            {
                processAlgorithmsPlugin(algHolder);
                continue;
            }
            IGraphViz *graphVizWrapper = qobject_cast<IGraphViz*>(plugin);
            if (graphVizWrapper)
            {
                processGraphVizPlugin(graphVizWrapper);
                continue;
            }
        }
        else
        {
            DBGLOG(DBGPAR(loader.errorString()));
        }
     }
}

void MainWindow::processAlgorithmsPlugin(IAlgorithmHolder *algHolder)
{
    QStringList supportedVersions;
    supportedVersions << PROGRAM_VERSION; // TODO: hold supported versions still consistent

    const QString version = algHolder->getVersion();
    if (supportedVersions.contains(version))
    {
        DBGLOG_AI(DBGPAR(algHolder->getPluginName()));

        QMenu *menu = algorithmMenu;
        static bool s_DynamicPlugins = false;
        if (algHolder->getPluginName() != "Basic automata algorthms")
        {
            if (!s_DynamicPlugins)
            {
                s_DynamicPlugins = true;
                /*-------------------------------*/ algorithmMenu->addSeparator();
            }
            menu = new QMenu(algHolder->getPluginName(),algorithmMenu);
            algorithmMenu->addMenu(menu);
        }

        foreach(QSharedPointer<IAlgorithm> alg, algHolder->getAlgorithms())
        {
            QAction *action = menu->addAction(alg->getName(), editor, SLOT(runAlgorithm()));
            action->setData(editor->addAlgorithm(alg)); // sets index of algorithm in editor's algorithmList
        }

        DBGLOG("Plugin" << algHolder->getPluginName() << "loaded successfully.");
    }
    else
    {
        RELLOG("Plugin " << algHolder->getPluginName() <<
               " has version" << version << "which isn't supported!");
    }
}

void MainWindow::processGraphVizPlugin(IGraphViz *graphVizWrapper)
{
    QStringList supportedVersions;
    supportedVersions << PROGRAM_VERSION; // TODO: hold supported versions still consistent

    const QString version = graphVizWrapper->getVersion();
    if (supportedVersions.contains(version))
    {
        DBGLOG("GraphVizWrapper plugin found.");
        editor->addGraphVizDrawAlgorithm(graphVizWrapper);
    }
    else
    {
        RELLOG("Found unsupported GraphVizWrapper plugin (version " << version << ")!");
    }
}

void MainWindow::createStatusBar()
{
  statusBar()->showMessage(tr("Ready ..."),5000);
}

void MainWindow::setStatusBar(const QString& s)
{
  statusBar()->showMessage(s);
}

void MainWindow::setStatusBar(const QString& s, int ms)
{
  statusBar()->showMessage(s,ms);
}

void MainWindow::createActions()
{
    Q_ASSERT(editor && "has to be already created because is used here in connect!");

    //file
    fileNew = new QAction(QIcon(":/images/filenew.png"), tr("&New file"), this);
    fileNew->setShortcut(tr("Ctrl+N"));
    fileNew->setStatusTip(tr("Create a new file"));
    connect(fileNew,SIGNAL(triggered()),this,SLOT(newFile()));

    fileOpen = new QAction(QIcon(":/images/fileopen.png"), tr("&Open file"), this);
    fileOpen->setShortcut(tr("Ctrl+O"));
    fileOpen->setStatusTip(tr("Open an existing file"));
    connect(fileOpen, SIGNAL(triggered()), this, SLOT(openFile()));

    fileSave = new QAction(QIcon(":/images/filesave.png"), tr("&Save"), this);
    fileSave->setShortcut(tr("Ctrl+S"));
    fileSave->setStatusTip(tr("Save changes in current file"));
    connect(fileSave, SIGNAL(triggered()), this, SLOT(save()));

    fileSaveAs = new QAction(QIcon(":/images/filesaveas.png"), tr("&Save As ..."), this);
    fileSaveAs->setShortcut(tr("Ctrl+Shift+S"));
    fileSaveAs->setStatusTip(tr("Save current file as ..."));
    connect(fileSaveAs, SIGNAL(triggered()), this, SLOT(saveAs()));

    fileExport = new QAction(QIcon(":/images/fileexport.png"), tr("&Export"), this);
    fileExport->setShortcut(tr("Ctrl+E"));
    fileExport->setStatusTip(tr("Export to ..."));
    connect(fileExport, SIGNAL(triggered()), this, SLOT(exportTo()));

    fileQuit = new QAction(QIcon(":/images/editdelete.png"), tr("&Quit"), this);
    fileQuit->setShortcut(tr("Ctrl+Q"));
    fileQuit->setStatusTip(tr("Quit application"));
    connect(fileQuit, SIGNAL(triggered()), this, SLOT(close()));

    // edit
    editUndo = new QAction(QIcon(":/images/undo.png"), tr("&Undo"), this);
    editUndo->setShortcut(tr("Ctrl+Z"));
    editUndo->setStatusTip(tr("Undo prevousious action"));
    editUndo->setEnabled(false);
    connect(editUndo, SIGNAL(triggered()), editor, SLOT(undo()));

    editRedo = new QAction(QIcon(":/images/redo.png"), tr("&Redo"), this);
    editRedo->setShortcut(tr("Ctrl+Y"));
    editRedo->setStatusTip(tr("Redo prevousious action"));
    editRedo->setEnabled(false);
    connect(editRedo, SIGNAL(triggered()), editor, SLOT(redo()));

    editCopy = new QAction(QIcon(":/images/copy.png"), tr("&Copy"), this);
    editCopy->setShortcut(tr("Ctrl+C"));
    editCopy->setStatusTip(tr("Copy selection"));  
    connect(editCopy, SIGNAL(triggered()), this, SLOT(copy()));

    editPaste = new QAction(QIcon(":/images/paste.png"), tr("&Paste"), this);
    editPaste->setShortcut(tr("Ctrl+V"));
    editPaste->setStatusTip(tr("Paste items from clipboard"));  
    connect(editPaste, SIGNAL(triggered()), this, SLOT(paste()));

    editCut = new QAction(QIcon(":/images/cut.png"), tr("&Cut"), this);
    editCut->setShortcut(tr("Ctrl+X"));
    editCut->setStatusTip(tr("Remove selected items and store it to clipboard"));
    connect(editCut, SIGNAL(triggered()), this, SLOT(cut()));

    editRemove = new QAction(QIcon(":/images/delete.png"), tr("&Remove"), this);
    editRemove->setShortcut(tr("Delete"));
    editRemove->setStatusTip(tr("Remove selected items"));
    connect(editRemove, SIGNAL(triggered()), this, SLOT(remove()));

    zoomIn = new QAction(QIcon(":/images/zoomin.png"), tr("Zoom&In"), this);
    zoomIn->setShortcut(tr("Ctrl++"));
    zoomIn->setStatusTip(tr("Zoom in the scene"));
    connect(zoomIn, SIGNAL(triggered()), editor, SLOT(zoomIn()));

    zoomOut = new QAction(QIcon(":/images/zoomout.png"), tr("Zoom&Out"), this);
    zoomOut->setShortcut(tr("Ctrl+-"));
    zoomOut->setStatusTip(tr("Zoom out the scene"));
    connect(zoomOut, SIGNAL(triggered()), editor, SLOT(zoomOut()));

    resetZoom = new QAction(QIcon(":/images/resetzoom.png"), tr("&Reset zoom"), this);
    resetZoom->setShortcut(tr("Ctrl+0"));
    resetZoom->setStatusTip(tr("Reset scene zoom to original state."));
    connect(resetZoom, SIGNAL(triggered()), editor, SLOT(resetZoom()));

    editShowUndoStack = new QAction(tr("Show undo stack"), this);    
    editShowUndoStack->setStatusTip(tr("Show/Hide undo stack"));
    editShowUndoStack->setCheckable(true);
    connect(editShowUndoStack, SIGNAL(triggered(bool)), editor, SLOT(showUndoView(bool)));
    connect(editor, SIGNAL(undoViewClosed()), this, SLOT(undoViewClosed()));

    editGridRect = new QAction(QIcon(":/images/grid.xpm"), tr("Set grid rect"), this);
    editGridRect->setStatusTip(tr("Change treshold by setting grid rectangle"));
    connect(editGridRect, SIGNAL(triggered()), editor, SLOT(showGridRectDialog()));

    editStateParams = new QAction(QIcon(":/images/state.xpm"), tr("Set state style"), this);
    editStateParams->setStatusTip(tr("Change state style parameters"));
    connect(editStateParams, SIGNAL(triggered()), editor, SLOT(editStateStyleParams()));

    editTransitionParams = new QAction(QIcon(":/images/transition.xpm"), tr("Set transition style"), this);
    editTransitionParams->setStatusTip(tr("Change transition style parameters"));
    connect(editTransitionParams, SIGNAL(triggered()), editor, SLOT(editTransitionStyleParams()));


    //items
    itemsSelection = new QAction(QIcon(":/images/pointer.png"), tr("&Selection"), this);
    itemsSelection->setShortcut(tr("Ctrl+M"));
    itemsSelection->setStatusTip(tr("Universal operations: double click - insert state, middle click - insert transition"));
    connect(itemsSelection, SIGNAL(triggered()), this, SLOT(setSelection()));
    itemsSelection->setCheckable(true);

    itemsState = new QAction(QIcon(":/images/state.xpm"), tr("Insert &state"), this);
    itemsState->setShortcut(tr("Ctrl+I"));
    itemsState->setStatusTip(tr("Insert new state"));
    connect(itemsState, SIGNAL(triggered()), this, SLOT(setState()));
    itemsState->setCheckable(true);

    itemsTransition = new QAction(QIcon(":/images/transition.xpm"), tr("Insert &transition"), this);
    itemsTransition->setShortcut(tr("Ctrl+T"));
    itemsTransition->setStatusTip(tr("Insert new transition"));
    connect(itemsTransition, SIGNAL(triggered()), this, SLOT(setTransition()));
    itemsTransition->setCheckable(true);

    //tools
    toolsSnapToGrid = new QAction(QIcon(":/images/snaptogrid.xpm"), tr("&Snap to grid"), this);
    toolsSnapToGrid->setShortcut(tr("Ctrl+G"));
    toolsSnapToGrid->setStatusTip(tr("Snap state to grid"));
    connect(toolsSnapToGrid, SIGNAL(triggered()), this, SLOT(snapToGrid()));
    toolsSnapToGrid->setCheckable(true);
    toolsSnapToGrid->setChecked(SNAP_TO_GRID);

    toolsAlignStatesToGrid = new QAction(QIcon(":/images/aligntogrid.xpm"), tr("&Align states"), this);
    toolsAlignStatesToGrid->setShortcut(tr("Ctrl+A"));
    toolsAlignStatesToGrid->setStatusTip(tr("Align all states to grid"));
    connect(toolsAlignStatesToGrid, SIGNAL(triggered()), this, SLOT(alignToGrid()));

    toolsExpandGrid = new QAction(QIcon(":/images/grid_expand.xpm"), tr("&Expand/Shrink grid"), this);
    toolsExpandGrid->setStatusTip("Expands/shrinks grid automatically according to items on scene.");    
    connect(toolsExpandGrid, SIGNAL(triggered()), editor, SLOT(expandGrid()));

    //show
    showGrid = new QAction(QIcon(":/images/grid.xpm"), tr("Show &grid"), this);
    showGrid->setShortcut(tr("Ctrl+Shift+G"));
    showGrid->setStatusTip(tr("Show grid"));
    connect(showGrid, SIGNAL(triggered(bool)), editor, SLOT(slotShowGrid(bool)));
    showGrid->setCheckable(true);
    showGrid->setChecked(SHOW_GRID);

    showFrame = new QAction(QIcon(":/images/frame.xpm"), tr("Show &frame"), this);
    showFrame->setShortcut(tr("Ctrl+Shift+F"));
    showFrame->setStatusTip(tr("Show frame"));
    connect(showFrame, SIGNAL(triggered(bool)), editor, SLOT(slotShowFrame(bool)));
    showFrame->setCheckable(true); 
    showFrame->setChecked(SHOW_FRAME);

    showAntialias = new QAction(QIcon(":/images/antialiasing.png"), tr("Antialiasing On/Off"), this);
    showAntialias->setStatusTip(tr("Turn On/Off antialiasing render method"));
    showAntialias->setCheckable(true);
    showAntialias->setChecked(INIT_ANTIALIASING);
    connect(showAntialias, SIGNAL(triggered()), editor, SLOT(switchAntialiasing()));

    // help
    helpAbout = new QAction(tr("&About"), this);
    helpAbout->setStatusTip(tr("About ..."));
    connect(helpAbout, SIGNAL(triggered()), this, SLOT(about()));

    helpAboutQt = new QAction(tr("About &Qt"),this);
    helpAboutQt->setStatusTip(tr("About Qt ..."));
    connect(helpAboutQt, SIGNAL(triggered()), this, SLOT(aboutQt()));

    QActionGroup *ag = new QActionGroup(this);  
    ag->addAction(itemsSelection);
    ag->addAction(itemsState);
    ag->addAction(itemsTransition);
    ag->setExclusive(true); 

    // extra
    extraLaTeXTable = new QAction(QIcon(":/images/table.png"), tr("&LaTeX table"), this);
    extraLaTeXTable->setStatusTip(tr("Get LaTeX table"));
    connect(extraLaTeXTable, SIGNAL(triggered()), editor, SLOT(createLaTeXTable()));
    
    extraGeneration = new QAction(QIcon(":/images/generating.png"), tr("Show &geration dialog"), this);
    extraGeneration->setStatusTip(tr("Generate graph of searching by selected algorithm"));
    connect(extraGeneration, SIGNAL(triggered()), editor, SLOT(generateGraph()));
    
    extraSimulation = new QAction(QIcon(":/images/simulating.png"), tr("DKA/NKA work &simulation"), this);
    extraSimulation->setStatusTip(tr("Simulation of finite automaton's work"));
    connect(extraSimulation, SIGNAL(triggered()), editor, SLOT(simulateAutomatonWork()));
}

void MainWindow::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(fileNew);
    fileMenu->addAction(fileOpen);
    fileMenu->addAction(fileSave);
    fileMenu->addAction(fileSaveAs);
    fileMenu->addAction(fileExport);
    /*-------------------------------*/ fileMenu->addSeparator();
    fileMenu->addAction(fileQuit);

    editMenu = menuBar()->addMenu(tr("&Edit"));
    editMenu->addAction(editUndo);
    editMenu->addAction(editRedo);
    editMenu->addAction(editShowUndoStack);
    /*-------------------------------*/ editMenu->addSeparator();
    editMenu->addAction(editCut);
    editMenu->addAction(editCopy);
    editMenu->addAction(editPaste);
    editMenu->addAction(editRemove);
    /*-------------------------------*/ editMenu->addSeparator();
    editMenu->addAction(zoomIn);
    editMenu->addAction(zoomOut);
    editMenu->addAction(resetZoom);
    /*-------------------------------*/ editMenu->addSeparator();
    editMenu->addAction(editGridRect);
    editMenu->addAction(editStateParams);
    editMenu->addAction(editTransitionParams);

    connect(editMenu, SIGNAL(aboutToShow()), this, SLOT(updateEditMenu()));
    connect(editMenu, SIGNAL(aboutToHide()), this, SLOT(enableEditMenu()));

    itemsMenu = menuBar()->addMenu(tr("&Items"));
    itemsMenu->addAction(itemsSelection);
    itemsMenu->addAction(itemsState);
    itemsMenu->addAction(itemsTransition);

    toolsMenu = menuBar()->addMenu(tr("&Tools"));
    toolsMenu->addAction(toolsSnapToGrid);
    toolsMenu->addAction(toolsAlignStatesToGrid);
    toolsMenu->addAction(toolsExpandGrid);

    showMenu = menuBar()->addMenu(tr("&Show"));
    showMenu->addAction(showGrid);
    showMenu->addAction(showFrame);
    /*-----------------------------------*/ showMenu->addSeparator();
    showMenu->addAction(showAntialias);

    extraMenu = menuBar()->addMenu(tr("&Utility"));
    extraMenu->addAction(extraGeneration);
    extraMenu->addAction(extraLaTeXTable);
    extraMenu->addAction(extraSimulation);
    /*-----------------------------------*/ extraMenu->addSeparator();
    algorithmMenu = extraMenu->addMenu(tr("&Algorithms..."));

    menuBar()->addSeparator();

    helpMenu = menuBar()->addMenu(tr("&Help"));
    helpMenu->addAction(helpAbout);
    helpMenu->addAction(helpAboutQt);
}

void MainWindow::createToolBars(){
  fileToolBar = addToolBar(tr("File"));
  fileToolBar->addAction(fileNew);
  fileToolBar->addAction(fileOpen);
  fileToolBar->addAction(fileSave);
  // fileToolBar->addAction(fileSaveAs);
  fileToolBar->addAction(fileExport);
  
  editToolBar = addToolBar(tr("Edit"));
  editToolBar->addAction(editUndo);
  editToolBar->addAction(editRedo);

  zoomToolBar = addToolBar(tr("Zoom"));
  zoomToolBar->addAction(zoomIn);
  zoomToolBar->addAction(zoomOut);
  zoomToolBar->addAction(resetZoom);

  itemsToolBar = addToolBar(tr("Items"));
  itemsToolBar->addAction(itemsSelection);
  itemsToolBar->addAction(itemsState);
  itemsToolBar->addAction(itemsTransition);

  toolsToolBar = addToolBar(tr("Tools"));
  toolsToolBar->addAction(toolsSnapToGrid);
  toolsToolBar->addAction(toolsAlignStatesToGrid);
  toolsToolBar->addAction(toolsExpandGrid);

  showToolBar = addToolBar(tr("Show"));
  showToolBar->addAction(showGrid);
  showToolBar->addAction(showFrame);
  showToolBar->addSeparator();
  showToolBar->addAction(showAntialias);
  
  extraToolBar = addToolBar(tr("Extra"));
  extraToolBar->addAction(extraGeneration);
  extraToolBar->addAction(extraLaTeXTable);
  extraToolBar->addAction(extraSimulation);
}

// private slots

void MainWindow::newFile()
{
    if (editor->isChanged())
    {
        int ret = QMessageBox::question(this,
                      tr("New file"),
                      tr("File was modified?\nDo you want to save your changes?"),
                      tr("&Save"), tr("&Discard"), tr("&Cancel"), 0);
        if (ret == 0)
        {
            if (!save()) return;
        }
        else if (ret == 2)
        {
            return;
        }
    }
    
    editor->newFile();
}

void MainWindow::openFile()
{
    if (editor->isChanged())
    {
        int ret = QMessageBox::question(this,
                    tr("Open file"),
                    tr("File was modified?\nDo you want to save your changes?"),
                    tr("&Save"), tr("&Discard"), tr("&Cancel"), 0);
    
        if (ret == 0)
        {
            if (!save()) return;
        }
        else if (ret == 2)
        {
            return;
        }
    }

    QString dir = editor->getFileName();
    int idx = dir.lastIndexOf(QRegExp("[/\\\\]"));
    if (idx != -1)
        dir = dir.left(idx);
    else
        dir = ".";
#if defined(TESTING) && defined(_WINDOWS)
    if (editor->getFileName() == NEW_FILENAME)
    {
        QDir curDir(dir);
        curDir.cdUp();
        DBGLOG(curDir.dirName());    
        if (curDir.cd("tests"))
        {
            dir = curDir.path();
        }
    }
#endif
    DBGLOG(DBGPAR(dir));
    QString fn = QFileDialog::getOpenFileName(0,"Open file",dir,
                                              "VauCanSon-G and LaTeX (*.vcg *.tex);;All files (*.*)");
    //, "Vaucanson-G (*.tex *.vcg);;All files (*.*)", this, "open file dialog", "Choose a file" 
    if (fn != QString::null) 
    {
        editor->openFile(fn);
    }
}

bool MainWindow::save()
{
    QString fn = editor->getFileName();
    if (editor->isSaved() && fn != "")
    {
        if (!editor->isChanged()) 
        {
            DBGLOG("saving isn't necessary");
            return true;
        }
        editor->exportToVaucanson(fn, editor->isAddition());
        return true;
    }
    else return saveAs();
}

void MainWindow::addSuffix(QString &fn, Editor::Format f)
{
    if (fn.lastIndexOf(".") != -1) {
        return;
    }
    
    switch (f) {
        case Editor::vcg : fn.append(".vcg"); break;
        case Editor::tex : fn.append(".tex"); break;
        case Editor::gml : fn.append(".gml"); break;
        case Editor::eps : fn.append(".eps"); break;
        case Editor::svg : fn.append(".svg"); break;
        case Editor::bmp : fn.append(".bmp"); break;
        case Editor::png : fn.append(".png"); break;
        case Editor::xpm : fn.append(".xpm"); break;
        default : break;
    }
}

bool MainWindow::saveAs(){
    QString fn;
    QString filter;
    
    QStringList formats;
    if (DEFAULT_SUFFIX_VCG)
    {
      filter = tr("VauCanSon-G file (*.vcg)");
      formats << filter
              << tr("LaTeX file (*.tex)");
    }
    else
    {
      filter = tr("LaTeX file (*.tex)");
      formats << filter
              << tr("VauCanSon-G file (*.vcg)");
    }
    formats << tr("LaTeX file w/o head and tail (*.tex)")
            << tr("Other (*.*)");

    fn = editor->getFileName();

#if defined(WIN32) || QT_VERSION > 0x040501  // due to bug on Ubuntu system - filter wasn't functional there
    fn = QFileDialog::getSaveFileName(this, "Save file", fn,
         formats.join(";;"), &filter);
#else
    QFileDialog dialog(this, tr("Save as ..."), fn);
    dialog.setAcceptMode(QFileDialog::AcceptSave);
    dialog.setNameFilters(formats);

    if (dialog.exec() != QDialog::Accepted) return false;

    filter = dialog.selectedNameFilter();
    fn = dialog.selectedFiles()[0];
#endif

    DBGLOG(DBGPAR(fn) << DBGPAR(filter));
    
    if (fn != "")
    {
        QDir dir(fn.left(fn.lastIndexOf(QRegExp("[/\\\\]"))));
        if (!dir.exists())
        {
            // directory doesn't exist
            QMessageBox::critical(this, PROGRAM_NAME,
                    "Selected directory doesn't exist!\n"
                    "Please select existing directory.", "OK");
            return false;
        } 
      
        if (filter == "LaTeX file (*.tex)")
        {
            addSuffix(fn, Editor::tex);
            editor->exportToVaucanson(fn, true);
        }
        else 
        {
            if (filter == "LaTeX file w/o head and tail (*.tex)")
                addSuffix(fn, Editor::tex);
            else if (filter == "VauCanSon-G file (*.vcg)")
                addSuffix(fn, Editor::vcg);
        
            editor->exportToVaucanson(fn, false);
        }
        editor->setFileName(fn);
        return true;
    }
    return false;
}

void MainWindow::exportTo()
{
    QString fn;
    QString filter = tr("Encapsulated PostScript (*.eps)");
    Editor::Format f;
    QStringList formats;    

    formats << filter
#ifndef DONT_USE_SVG_MODULE
            << tr("SVG+XML (*.svg)")
#endif
            << tr("GraphML files (*.graphml *.gml)")
            << tr("Images PNG(*.png)")
            << tr("Images BMP(*.bmp)")
            << tr("Images XPM(*.xpm)");

#if defined(WIN32) || QT_VERSION > 0x040501  // due to bug on Ubuntu system
    fn = QFileDialog::getSaveFileName(this, "Export to ...", editor->getFileName(),
             formats.join(";;"),
             &filter);
#else
    QFileDialog dialog(this, tr("Export to ..."),editor->getFileName());
    dialog.setAcceptMode(QFileDialog::AcceptSave);
    dialog.setNameFilters(formats);

    if (dialog.exec() != QDialog::Accepted) return;

    filter = dialog.selectedNameFilter();
    fn = dialog.selectedFiles()[0];
#endif    

    DBGLOG(fn << filter);
    
    if (fn != ""){
      QDir dir(fn.left(fn.lastIndexOf('/')));      
      if (!dir.exists()){
        // directory doesn't exist
         QMessageBox::critical(this, PROGRAM_NAME,
                "Selected directory doesn't exist!\n"
                "Please select existing directory.", "OK");
        return;
      } 
    
      //editor->setFileName(fn); -- toto ne
    if (filter == "Encapsulated PostScript (*.eps)"){
        addSuffix(fn, Editor::eps);
        editor->exportToEPS(fn);
    }
#ifndef DONT_USE_SVG_MODULE
    else if(filter == "SVG+XML (*.svg)"){
        addSuffix(fn, Editor::svg);
        editor->exportToSVG(fn);
    }
#endif
    else if (filter == "GraphML files (*.graphml *.gml)"){
      addSuffix(fn, Editor::gml);
      editor->exportToGraphML(fn);
    }
    else if (filter == "Images PNG(*.png)"){
      f = Editor::png;
      addSuffix(fn,f);
      editor->exportToPixmap(fn, f);
    }
    else if (filter == "Images BMP(*.bmp)"){
      f = Editor::bmp;
      addSuffix(fn,f);
      editor->exportToPixmap(fn, f);
    }
    else if (filter == "Images XPM(*.xpm)"){
      f = Editor::xpm;
      addSuffix(fn,f);
      editor->exportToPixmap(fn,f);
    }
    else{
        RELLOG("No filter selected, file was not saved!");
    }
  }
}

void MainWindow::closeEvent(QCloseEvent *event){
  if (!editor->isChanged()) {
    event->accept();
    return;
  }
  int ret = QMessageBox::question(this,
                    tr("Quit"),
                    tr("File was modified?\nDo you want to save your changes?"),
                    tr("&Save"), tr("&Discard"), tr("&Cancel"), 0);
 
  DBGLOG(DBGPAR(ret));
  if (ret == 2) {
        event->ignore();
    }
    else if (ret == 1){
      event->accept();
    }
    else {
    if (save())
        event->accept();
      else
        event->ignore();
  }
}

void MainWindow::undoViewClosed()
{
    editShowUndoStack->setChecked(false);
}

void MainWindow::updateEditMenu()
{
    editCopy->setEnabled(editor->isSomethingSelected());
    editPaste->setEnabled(editor->isPastePossible());
    editCut->setEnabled(editor->isSomethingSelected());
    editRemove->setEnabled(editor->isSomethingSelected());
}

void MainWindow::enableEditMenu()
{
    editCopy->setEnabled(true);
    editPaste->setEnabled(true);
    editCut->setEnabled(true);
    editRemove->setEnabled(true);
}

void MainWindow::copy()
{
    if (editor->isSomethingSelected()) // needed due to shortcuts are still enabeld
    {
        editor->copySelection();
    }
}

void MainWindow::paste()
{
    if (editor->isPastePossible()) // needed due to shortcuts are still enabeld
    {
        editor->paste();
    }
}

void MainWindow::cut()
{
    if (editor->isSomethingSelected()) // needed due to shortcuts are still enabeld
    {
        editor->cutSelection();
    }
}

void MainWindow::remove()
{
    if (editor->isSomethingSelected()) // needed due to shortcuts are still enabeld
    {
        editor->removeSelection();
    }
}

void MainWindow::setSelection()
{
    statusBar()->showMessage("Selection tool");    
    editor->setAction(Editor::eSelection);
}

void MainWindow::setState()
{
    statusBar()->showMessage("Insert state selected");
    editor->setAction(Editor::eInsertState);
}

void MainWindow::setTransition()
{
    statusBar()->showMessage("Insert transition selected, 2000");
    editor->setAction(Editor::eInsertTransition);
    statusBar()->showMessage("Select first state");
}

void MainWindow::snapToGrid()
{
    editor->slotSnapToGrid();
}

void MainWindow::alignToGrid()
{
    editor->slotAlignToGrid();
}

void MainWindow::about()
{
    QMessageBox::about(this, PROGRAM_NAME,
        "Automata editor version 2, Copyright (C) 2008 Milan Kriz<br>" \
        "(ported to Qt4 and expanded from version 1 by Lukas Stanek)<br>"\
        "This editor comes with ABSOLUTELY NO WARRANTY; for details<br>" \
        "see GPLv2.  This is free software, and you are welcome<br>" \
        "to redistribute it under certain conditions; see GPLv2<br>" \
        "for details.<br><br>" \
        "<b>For more information about Vaucanson-G visit</b><br>" \
        "<a href='http://www-igm.univ-mlv.fr/~lombardy/Vaucanson-G/'>http://www-igm.univ-mlv.fr/~lombardy/Vaucanson-G/</a><br><br>" \
        "For GNU General Public License see<br>" \
        "<a href='http://www.gnu.org/licenses/gpl.html'>http://www.gnu.org/licenses/gpl.html</a><br><br>" \
        "For GraphViz (used in drawing plugin) Common Public License see<br>" \
        "<a href='http://www.graphviz.org/License.php'>http://www.graphviz.org/License.php</a>"
        );
}

void MainWindow::aboutQt()
{
    QMessageBox::aboutQt(this, PROGRAM_NAME);
}

void MainWindow::actualizeChecking(bool sg, bool sf)
{
    showGrid->setChecked(sg);
    showFrame->setChecked(sf);
}

void MainWindow::actionChanged(int action)
{    
    switch (action)
    {
    case Editor::eSelection:
        itemsSelection->setChecked(true);
        break;
    case Editor::eInsertState:
        itemsSelection->setChecked(true);
        break;
    case Editor::eInsertTransition:
        itemsSelection->setChecked(true);
        break;
    default:;
    }
}

void MainWindow::setItemsAvailable(bool available)
{
    itemsMenu->setEnabled(available); // whole menu enable/disable
    
    // due to toolbar and shortcuts enable/disable each one
    itemsSelection->setEnabled(available);
    itemsState->setEnabled(available);
    itemsTransition->setEnabled(available);
}

void MainWindow::setToolsAvailable(bool available)
{
    toolsMenu->setEnabled(available);

    toolsAlignStatesToGrid->setEnabled(available);
    toolsSnapToGrid->setEnabled(available);
}

void MainWindow::setUtilsAvailable(bool available)
{
    extraGeneration->setEnabled(available);
    extraSimulation->setEnabled(available);
    
    algorithmMenu->setEnabled(available);
}



/*-- ExportDialog ---------------------------------------------------------------------------->*/
/*
ExportDialog::ExportDialog(QWidget* parent)
    : QDialog(parent)
{
    QLabel* labelFn = new QLabel("Filename", this);
    fileName = new QLineEdit(QDir::currentPath(), this);
    fileName->setReadOnly(true);
    fileName->setFixedWidth(200);
    
    selectFilename = new QPushButton("...", this);
    connect(selectFilename, SIGNAL(clicked()), SLOT(fileSelect()));
    
    Format format;
    QLabel* labelParameters = new QLabel("Parameters", this);
    latexAddition = new QCheckBox("LaTeX addition (head and tail)", this);
    appendSuffix = new QCheckBox("Append export format suffix", this);
    connect(appendSuffix, SIGNAL(clicked()), SLOT(addSuffix()));
    
    
    QWidget *hBox = new QWidget(this);
    QPushButton* buttonOk = new QPushButton("Ok");
    QPushButton* buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(buttonOk);
    hBoxLayout->addWidget(buttonCancel);
    hBox->setLayout(hBoxLayout);
    connect(buttonOk, SIGNAL(clicked()), SLOT(myAccept()));
    connect(buttonCancel, SIGNAL(clicked()), SLOT(reject()));

    QGridLayout* gridLayout = new QGridLayout(this);
    gridLayout->addWidget(labelFn, 0, 0);
    gridLayout->addWidget(fileName, 0, 1);
    gridLayout->addWidget(selectFilename, 0, 2);
    gridLayout->addWidget(labelParameters, 1, 0);
    gridLayout->addWidget(latexAddition, 1, 1, 1, 2, Qt::AlignLeft);
    gridLayout->addWidget(appendSuffix, 2, 1, 1, 2, Qt::AlignLeft);
    gridLayout->addWidget(hBox, 3, 0, 1, 3, Qt::AlignRight);
    
    fileDialog = new QFileDialog();
    fileDialog->setFileMode( QFileDialog::AnyFile);
    fileDialog->setAcceptMode(QFileDialog::AcceptSave);
                 
    QStringList formats;
    formats <<  "Vaucanson-G (*.tex *.vcg)"
            <<  "GraphML files (*.graphml *.gml)"
            <<  "Encapsulated PostScript (*.eps)"
            <<  "Images (*.png)"
            <<     "Images (*.bmp)"
            <<  "Images (*.xpm)";
    
    fileDialog->setFilters(formats);

    setButtonParameters();
    QString s = "Save dialog";
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/snaptogrid.xpm"));
}

QString ExportDialog::getFilename()
{
    return fileName->text();
}

Format ExportDialog::getFormat()
{
    Format f = vcg;
    
    if (fileDialog->selectedFilter() == "Vaucanson-G (*.tex *.vcg)") {
        f = vcg;
    } else if (fileDialog->selectedFilter() == "GraphML files (*.graphml *.gml)") {
        f = gml;
    } else if (fileDialog->selectedFilter() == "Encapsulated PostScript (*.eps)") {
        f = eps;
    } else if (fileDialog->selectedFilter() == "Images (*.png)") {
        f = png;
    } else if (fileDialog->selectedFilter() == "Images (*.bmp)") {
        f = bmp;
    } else if (fileDialog->selectedFilter() == "Images (*.xpm)") {
        f = xpm;
    }
    
    return f;
}

bool ExportDialog::isAddition()
{
    return latexAddition->isChecked();
}

void ExportDialog::setFilename(const QString& fn)
{
    fileName->setText(fn);
}

void ExportDialog::setButtonParameters()
{
  QStringList files = fileDialog->selectedFiles();
  QString selected;
  if (!files.isEmpty())
      selected = files[0]; 
    QDir dir(selected);
    latexAddition->setEnabled(!dir.exists() && fileDialog->selectedFilter() == "Vaucanson-G (*.tex *.vcg)" );
    appendSuffix->setEnabled(!dir.exists() && selected.lastIndexOf(".") == -1);
}

// private slots
void ExportDialog::fileSelect()
{
  // call dialog window to select file
    if (fileDialog->exec() == QDialog::Rejected) return;
      QStringList files = fileDialog->selectedFiles();
    QString selected;
    if (!files.isEmpty())
      selected = files[0]; 
        setButtonParameters();
        setFilename(selected);
}

void ExportDialog::addSuffix()
{
    QString fn = fileName->text();
    if (fn.lastIndexOf(".") != -1) {
        return;
    }
    
    Format f = getFormat();
    
    switch (f) {
        case vcg : fn.append(".tex"); break;
        case gml : fn.append(".gml"); break;
        case eps : fn.append(".eps"); break;
        case bmp : fn.append(".bmp"); break;
        case png : fn.append(".png"); break;
        case xpm : fn.append(".xpm"); break;
        default : break;
    }
    
    fileName->setText(fn);
}

void ExportDialog::myAccept()
{
    QDir dir(fileName->text());
    
    if ( !dir.exists() ) {
        // selected filename is not a directory
        if (QFile::exists(fileName->text()) ) {
            if (QMessageBox::question(this,
                tr("Rewrite?"),
                tr("File %1 already exists.\n"
                   "Do you really want to rewrite selected file?").arg( fileName->text() ),
                tr("&Yes"), tr("&No"), QString::null, 1, 0)) {
                return;
            } else {
                accept();
            }
        }

        accept();
    } else {
        QMessageBox::information(this, PROGRAM_NAME,
                "No filename selected\n"
                "Please select a regular file", "OK");
        return;
    }
}

*/

/*<---------------------------------------------------------------------------- ExportDialog --*/
