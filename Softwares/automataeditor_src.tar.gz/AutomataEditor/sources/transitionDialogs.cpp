#include "constants.h"

#include "transitionDialogs.h"
#include "editor.h"
#include "transition.h"
#include "transitionManager.h"
#include "transforms.h"
#include "label.h"
#include "commands.h"

#include <QPushButton>
#include <QLayout>
#include <QGroupBox>
#include <QLabel>
#include <QLineEdit>
#include <QCheckBox>
#include <QComboBox>
#include <QWidget>
#include <QListWidget> // NextLabelsDialog
#include <QSpinBox>
#include <QRegExpValidator> // editing float in dialogs
#include <QRegExp>
#include <QMessageBox>


//<-- Transition Dialog ------------------------------------------------------

TransitionDialog::TransitionDialog(EMode mode, QWidget* parent)
: NameAcceptDialog(parent), m_mode(mode)
{
    TransitionManager *transitionManager = TransitionManager::getInstance();

    // transition name
    QLabel* labelName = new QLabel(QString("Label"), this);
    edtLabel = new QLineEdit(this);
  
    QRegExp rx("^[\\-]{0,1}[0-9]{1,3}\\.[0-9]{1,3}$"); // float validator
    QRegExp rx2("^[\\-]{0,1}[0-9]{1,3}$");
    QValidator *v = new QRegExpValidator(rx,this); 
    QValidator *v2 = new QRegExpValidator(rx2,this);
  
    QLabel* labelLabelPos = new QLabel(QString("pos"), this);
    lineLabelPos = new QLineEdit(this);
    lineLabelPos->setValidator(v);
    lineLabelPos->setMaximumWidth(40); // experimental
    lineLabelPos->setText(QString("%1").arg(DEF_EDGE_LAB_POS));
  
    QWidget *labelWidget = new QWidget(this);
    QHBoxLayout *labelLayout = new QHBoxLayout(labelWidget);
    labelLayout->addWidget(labelName);
    labelLayout->addWidget(edtLabel);
    labelLayout->addWidget(labelLabelPos);
    labelLayout->addWidget(lineLabelPos);

    // label position left / right
    QLabel* labelOrientation = new QLabel(QString("Orientation"), this);
    comboOrientation = new QComboBox(this);
    comboOrientation->addItem("Left");
    comboOrientation->addItem("Right");

    // transition type
    QLabel* labelType = new QLabel(QString("Type"), this);
    comboType = new QComboBox(this);
    foreach(QString typeName, transitionManager->getTwoStatesTransitionTypeNameList())
    {
        comboType->addItem(typeName);
    }
        
    QLabel *lblArcAngle = new QLabel(QString("ArcAngleA"), this);
    edtArcAngle = new QLineEdit(this);
    edtArcAngle->setEnabled(false); 
    edtArcAngle->setValidator(v2);
    
    QLabel *lblArcAngleB = new QLabel(QString("ArcAngleB"), this);
    edtArcAngleB = new QLineEdit(this); 
    edtArcAngleB->setEnabled(false);
    edtArcAngleB->setValidator(v2);
    
    QLabel *lblNCurv = new QLabel(QString("NCurv"), this);
    edtNCurv = new QLineEdit(this); 
    edtNCurv->setEnabled(false);
    edtNCurv->setValidator(v);
    
    connect(comboType, SIGNAL(currentIndexChanged(int)), this, SLOT(showEdits(int)));    
  
    checkDimmed = new QCheckBox(QString("Dimmed"), this);
    
    QWidget *hBox = new QWidget(this);
    QPushButton *buttonOk = new QPushButton("Ok");
    QPushButton *buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(buttonOk);
    hBoxLayout->addWidget(buttonCancel);
    hBox->setLayout(hBoxLayout);
    connect(buttonOk, SIGNAL(clicked()), this, SLOT(myAccept()));
    connect(buttonCancel, SIGNAL(clicked()), this, SLOT(reject()));

    QGridLayout* gridLayout = new QGridLayout(this);
    gridLayout->addWidget(labelWidget, 0, 0, 1, 2);
    gridLayout->addWidget(labelOrientation, 1, 0);
    gridLayout->addWidget(comboOrientation, 1, 1);
    gridLayout->addWidget(labelType, 2, 0);
    gridLayout->addWidget(comboType, 2, 1);
    gridLayout->addWidget(lblArcAngle, 3, 0);
    gridLayout->addWidget(edtArcAngle, 3, 1);
    gridLayout->addWidget(lblArcAngleB, 4, 0);
    gridLayout->addWidget(edtArcAngleB, 4, 1);
    gridLayout->addWidget(lblNCurv, 5, 0);
    gridLayout->addWidget(edtNCurv, 5, 1);    
    gridLayout->addWidget(checkDimmed, 6, 1);
    gridLayout->addWidget(hBox, 7, 0, 1, 2);
    
    QString s = "Transition dialog";
    if (mode == eAdd)
        s += " - add";
    else
        s += " - edit";
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/transition.xpm"));
}

QString TransitionDialog::getLabel() const
{
    return edtLabel->text();
}

float TransitionDialog::getLabelPos() const
{
    return lineLabelPos->text().toFloat();
}

int TransitionDialog::getType() const
{
    return comboType->currentIndex();
}

bool TransitionDialog::isLeftOriented() const
{
    return ((comboOrientation->currentIndex() == 0));
}

bool TransitionDialog::isDimmed() const
{
    return checkDimmed->isChecked();
}

int TransitionDialog::getArcAngle() const
{
    return edtArcAngle->text().toInt();
}

int TransitionDialog::getArcAngleB() const
{
    return edtArcAngleB->text().toInt();
}

float TransitionDialog::getNCurv() const
{
    return edtNCurv->text().toFloat();
}

void TransitionDialog::setName(const QString& name)
{
    edtLabel->setText(name);
}

void TransitionDialog::setLabelPos(float lp)
{
    lineLabelPos->setText(QString("%1").arg(lp));
}

void TransitionDialog::setType(int type)
{
    comboType->setCurrentIndex(type);
}

void TransitionDialog::setTrOrientation(bool leftOriented)
{
    DBGLOG("idx=" << ((leftOriented) ? 0 : 1));
    comboOrientation->setCurrentIndex( ((leftOriented) ? 0 : 1) );
}

void TransitionDialog::setDimmed(bool dimmed)
{
    checkDimmed->setChecked(dimmed);
}

void TransitionDialog::setArcAngle(int arcA)
{
    edtArcAngle->setText(QString("%1").arg(arcA));
}

void TransitionDialog::setArcAngleB(int arcAB)
{
    edtArcAngleB->setText(QString("%1").arg(arcAB));
}

void TransitionDialog::setNCurv(float ncurv)
{
    edtNCurv->setText(QString("%1").arg(ncurv));
}

void TransitionDialog::showEdits(int type)
{
    TransitionManager *transitionManager = TransitionManager::getInstance();
    
    const TwoStatesTransitionProperties trProps = 
        transitionManager->getTwoStatesTransitionProperties(type);
    
    edtLabel->setEnabled(trProps.hasLabel);

    lineLabelPos->setEnabled(trProps.hasLabelPos);
    if (trProps.hasLabelPos && (m_mode == eAdd || lineLabelPos->text().isEmpty()))
        lineLabelPos->setText(QString("%1").arg(trProps.defLabelPos));

    edtArcAngle->setEnabled(trProps.hasArcAngleA);
    if (trProps.hasArcAngleA && (m_mode == eAdd || edtArcAngle->text().isEmpty()))
        edtArcAngle->setText(QString("%1").arg(trProps.defArcAngleA));

    edtArcAngleB->setEnabled(trProps.hasArcAngleB);
    if (trProps.hasArcAngleB && (m_mode == eAdd || edtArcAngleB->text().isEmpty()))
        edtArcAngleB->setText(QString("%1").arg(trProps.defArcAngleB));
    
    edtNCurv->setEnabled(trProps.hasNCurve);
    if (trProps.hasNCurve && (m_mode == eAdd || edtNCurv->text().isEmpty()))
        edtNCurv->setText(QString("%1").arg(trProps.defNCurve));
}

//------------------------------------------------------ Transition Dialog -->



//<-- TransitionLoopSE Dialog --------------------------------------------------

TransitionLoopSEDialog::TransitionLoopSEDialog(EMode mode, QWidget *parent)
: NameAcceptDialog(parent), m_mode(mode)
{
    TransitionManager *transitionManager = TransitionManager::getInstance();
    QLabel *labelName = new QLabel(QString("Label"), this);
    edtLabel = new QLineEdit(this);

    QRegExp rx("^[\\-]{0,1}[0-9]{1,3}\\.[0-9]{1,3}$"); // float validator
    QValidator *v = new QRegExpValidator(rx,this); 

    QLabel* labelLabelPos = new QLabel(QString("pos"), this);
    lineLabelPos = new QLineEdit(this);
    lineLabelPos->setValidator(v);
    lineLabelPos->setMaximumWidth(40);
    lineLabelPos->setText(QString("%1").arg(DEF_LOOP_LAB_POS));

    QWidget *labelWidget = new QWidget(this);
    QHBoxLayout *labelLayout = new QHBoxLayout(labelWidget);
    labelLayout->addWidget(labelName);
    labelLayout->addWidget(edtLabel);
    labelLayout->addWidget(labelLabelPos);
    labelLayout->addWidget(lineLabelPos);
  
    QLabel* labelType = new QLabel(QString("Type"), this);
    comboType = new QComboBox(this);
    foreach(QString typeName, transitionManager->getOneStateTransitionTypeNameList())
    {
        comboType->addItem(typeName);
    }    
  
    connect(comboType, SIGNAL(currentIndexChanged(int)), this, SLOT(showEdits(int)));

    QLabel *labelDirection = new QLabel(QString("Direction"),this);

    QStringList sl;
    sl.append("North");
    sl.append("South");
    sl.append("East");
    sl.append("West");
    sl.append("North-East");
    sl.append("North-West");
    sl.append("South-East");
    sl.append("South-West");
    comboDirection = new QComboBox(this);
    comboDirection->addItems(sl);
    comboDirection->setCurrentIndex(0); 
   
    checkDimmed = new QCheckBox(QString("Dimmed"),this);
  
    QWidget *hBox = new QWidget(this);
    QPushButton *buttonOk = new QPushButton("Ok");
    QPushButton *buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(buttonOk);
    hBoxLayout->addWidget(buttonCancel);
    hBox->setLayout(hBoxLayout);
    connect(buttonOk, SIGNAL(clicked()), this, SLOT(accept()));  
    connect(buttonCancel, SIGNAL(clicked()), this, SLOT(reject()));
  
    QGridLayout *gridLayout = new QGridLayout(this);
    gridLayout->addWidget(labelWidget, 0, 0, 1, 2);
    gridLayout->addWidget(labelType, 1, 0);
    gridLayout->addWidget(comboType, 1, 1);
    gridLayout->addWidget(labelDirection, 2, 0);
    gridLayout->addWidget(comboDirection, 2, 1);
    gridLayout->addWidget(checkDimmed, 3, 1);
    gridLayout->addWidget(hBox, 4, 0, 1, 2);
  
    QString s = "Transition dialog";
    if (mode == eAdd)
        s += " - add";
    else
        s += " - edit";
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/transition.xpm"));
}

QString TransitionLoopSEDialog::getLabel() const
{
    return edtLabel->text();
}

float TransitionLoopSEDialog::getLabelPos() const
{
    return lineLabelPos->text().toFloat();
}

int TransitionLoopSEDialog::getDirection() const
{
    return comboDirection->currentIndex();
}

bool TransitionLoopSEDialog::isDimmed() const
{
    return checkDimmed->isChecked();
}

int TransitionLoopSEDialog::getType() const
{
    return comboType->currentIndex();        
}

void TransitionLoopSEDialog::setDirection(int d){
    comboDirection->setCurrentIndex(d);
}

void TransitionLoopSEDialog::setLabel(const QString &lab){
    edtLabel->setText(lab);
}

void TransitionLoopSEDialog::setLabelPos(float lp){
    lineLabelPos->setText(QString("%1").arg(lp));
}

void TransitionLoopSEDialog::setDimmed(bool d){
    checkDimmed->setChecked(d);
}

void TransitionLoopSEDialog::setType(int type)
{    
    comboType->setCurrentIndex(type);
}

void TransitionLoopSEDialog::showEdits(int type)
{
    TransitionManager *transitionManager = TransitionManager::getInstance();
    
    const OneStateTransitionProperties trProps = 
        transitionManager->getOneStateTransitionProperties(type);
    
    edtLabel->setEnabled(trProps.hasLabel);
    lineLabelPos->setEnabled(trProps.hasLabelPos);
    
    if (trProps.hasLabelPos && (m_mode == eAdd || lineLabelPos->text().isEmpty()))
        lineLabelPos->setText(QString("%1").arg(trProps.defLabelPos));
}

//-------------------------------------------------- TransitionLoop Dialog -->



//<-- Transition Extended Dialog ---------------------------------------------

TransitionExtendedDialog::TransitionExtendedDialog(QWidget *parent)
: QDialog(parent)
{
    QStringList sls; // lineStyle
    sls.append("solid");
    sls.append("dashed");
    sls.append("dotted");
    sls.append("none");

    QRegExp rx("^[\\-]{0,1}[0-9]{1,3}\\.[0-9]{1,3}$"); // float validator
    QValidator *v = new QRegExpValidator(rx,this); 

    // parameters adjusted
    QLabel *lineStyle = new QLabel(QString("EdgeLineStyle"),this);
    comboLineStyle = new QComboBox(this);
    comboLineStyle->addItems(sls);
    comboLineStyle->setCurrentIndex(0);

    QLabel *lineWidth = new QLabel(QString("EdgeLineWidth"),this);
    edtLineWidth = new QLineEdit(this);
    edtLineWidth->setValidator(v);

    QLabel *lineColor = new QLabel(QString("EdgeLineColor"),this);
    edtLineColor = new QLineEdit(this);  

    QLabel *labelColor = new QLabel(QString("EdgeLabelColor"),this);
    edtLabelColor = new QLineEdit(this);

    QLabel *labelScale = new QLabel(QString("EdgeLabelScale"),this);
    edtLabelScale = new QLineEdit(this);
    edtLabelScale->setValidator(v);

    QLabel *dblStatus = new QLabel(QString("EdgeLineDblStatus"),this);
    checkDblStatus = new QCheckBox(this);
    checkDblStatus->setChecked(false);

    // parameters preset (dim transition)
    QLabel *dimLineStyle = new QLabel(QString("DimEdgeLineStyle"),this);
    comboDimLineStyle = new QComboBox(this);
    comboDimLineStyle->addItems(sls);
    comboDimLineStyle->setCurrentIndex(0);

    QLabel *dimLineColor = new QLabel(QString("DimEdgeLineColor"),this);
    edtDimLineColor = new QLineEdit(this);

    QLabel *dimLineCoef = new QLabel(QString("DimEdgeLineCoef"),this);
    edtDimLineCoef = new QLineEdit(this);
    edtDimLineCoef->setValidator(v);

    QLabel *dimLabelColor = new QLabel(QString("DimEdgeLabelColor"),this);
    edtDimLabelColor = new QLineEdit(this);
   
    // transition border
    QLabel *lineBorderCoef = new QLabel(QString("EdgeLineBorderCoef"),this);
    edtLineBorderCoef = new QLineEdit(this);
    edtLineBorderCoef->setValidator(v);
  
    QLabel *lineBorderColor = new QLabel(QString("EdgeLineBorderColor"),this);
    edtLineBorderColor = new QLineEdit(this);
   
    // transition double
    QLabel *lineDblCoef = new QLabel(QString("EdgeLineDblCoef"),this);
    edtLineDblCoef = new QLineEdit(this);
    edtLineDblCoef->setValidator(v);
  
    QLabel *lineDblSep = new QLabel(QString("EdgeLineDblSep"),this);
    edtLineDblSep= new QLineEdit(this);
    edtLineDblSep->setValidator(v);
  
    // buttons
    QWidget *hBox = new QWidget(this);
    QPushButton *buttonOk = new QPushButton("Ok");
    QPushButton *buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(buttonOk);
    hBoxLayout->addWidget(buttonCancel);
    hBox->setLayout(hBoxLayout);    
    hBox->setMaximumWidth(300);
    connect(buttonOk, SIGNAL(clicked()), this, SLOT(accept()));
    connect(buttonCancel, SIGNAL(clicked()), this, SLOT(reject()));
    
    QGroupBox *advancedGroup = new QGroupBox("Advanced parameters");
    QGridLayout *advancedLayout = new QGridLayout(advancedGroup);
    advancedLayout->addWidget(lineStyle,0,0);
    advancedLayout->addWidget(comboLineStyle,0,1);
    advancedLayout->addWidget(lineWidth,0,2);
    advancedLayout->addWidget(edtLineWidth,0,3); // \n
    advancedLayout->addWidget(lineColor,1,0);
    advancedLayout->addWidget(edtLineColor,1,1);
    advancedLayout->addWidget(labelColor,1,2);
    advancedLayout->addWidget(edtLabelColor,1,3); // \n
    advancedLayout->addWidget(labelScale,2,0);
    advancedLayout->addWidget(edtLabelScale,2,1); // \n
    advancedLayout->addWidget(checkDblStatus,2,2,Qt::AlignRight);
    advancedLayout->addWidget(dblStatus,2,3,Qt::AlignLeft); // \n\n

    QGroupBox *presetGroup = new QGroupBox("Preset parameters (dim edge)");
    QGridLayout* presetLayout = new QGridLayout(presetGroup);
    presetLayout->addWidget(dimLineStyle, 0,0);  
    presetLayout->addWidget(comboDimLineStyle, 0,1);  
    presetLayout->addWidget(dimLineCoef, 0,2);
    presetLayout->addWidget(edtDimLineCoef, 0,3); // \n
    presetLayout->addWidget(dimLineColor, 1,0);
    presetLayout->addWidget(edtDimLineColor, 1,1);    
    presetLayout->addWidget(dimLabelColor, 1,2);
    presetLayout->addWidget(edtDimLabelColor, 1,3); // \n\n
    
    QGroupBox *borderGroup = new QGroupBox("Edge border parameters (edge line double) - unsupported in editor :+(");
    QHBoxLayout *borderLayout = new QHBoxLayout(borderGroup);
    borderLayout->addWidget(lineBorderCoef);
    borderLayout->addWidget(edtLineBorderCoef);
    borderLayout->addWidget(lineBorderColor);
    borderLayout->addWidget(edtLineBorderColor); // \n
    
    QGroupBox *doubleGroup = new QGroupBox("Line double parameters (final state) - unsupported in editor :+(");
    QHBoxLayout *doubleLayout = new QHBoxLayout(doubleGroup);
    doubleLayout->addWidget(lineDblCoef);
    doubleLayout->addWidget(edtLineDblCoef);
    doubleLayout->addWidget(lineDblSep);
    doubleLayout->addWidget(edtLineDblSep); // \n
    
    QVBoxLayout *dialogLayout = new QVBoxLayout(this);
    dialogLayout->addWidget(advancedGroup);
    dialogLayout->addWidget(presetGroup);
    dialogLayout->addWidget(borderGroup);
    dialogLayout->addWidget(doubleGroup);
    dialogLayout->addWidget(hBox, 0, Qt::AlignHCenter);

    QString    s = "Extended parameters";
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/transition.xpm"));
}

void TransitionExtendedDialog::setParams(Transition *tr){
    comboLineStyle->setCurrentIndex(trLineStyleI(tr->edgeLineStyle));
    edtLineWidth->setText(QString("%1").arg(tr->edgeLineWidth));
    edtLineColor->setText(tr->edgeLineColor);
    edtLabelColor->setText(tr->edgeLabelColor);
    edtLabelScale->setText(QString("%1").arg(tr->edgeLabelScale));
    checkDblStatus->setChecked(tr->edgeLineDblStatus);

    comboDimLineStyle->setCurrentIndex(trLineStyleI(tr->dimEdgeLineStyle));
    edtDimLineColor->setText(tr->dimEdgeLineColor);
    edtDimLineCoef->setText(QString("%1").arg(tr->dimEdgeLineCoef));
    edtDimLabelColor->setText(tr->dimEdgeLabelColor);

    edtLineBorderCoef->setText(QString("%1").arg(tr->edgeLineBorderCoef));
    edtLineBorderColor->setText(QString("%1").arg(tr->edgeLineBorderColor));

    edtLineDblCoef->setText(QString("%1").arg(tr->edgeLineDblCoef));
    edtLineDblSep->setText(QString("%1").arg(tr->edgeLineDblSep));
}

Qt::PenStyle TransitionExtendedDialog::getLineStyle(){
    return trLineStyle(comboLineStyle->currentIndex());
}

float TransitionExtendedDialog::getLineWidth(){
    return edtLineWidth->text().toFloat();
}

QString TransitionExtendedDialog::getLineColor(){
    return edtLineColor->text();
}

QString TransitionExtendedDialog::getLabelColor(){
    return edtLabelColor->text();
}

float TransitionExtendedDialog::getLabelScale(){
    return edtLabelScale->text().toFloat();
}

bool TransitionExtendedDialog::getDblStatus(){
    return checkDblStatus->isChecked();
}
  
Qt::PenStyle TransitionExtendedDialog::getDimLineStyle(){
    return trLineStyle(comboDimLineStyle->currentIndex());
}

QString TransitionExtendedDialog::getDimLineColor(){
    return edtDimLineColor->text();
}

float TransitionExtendedDialog::getDimLineCoef(){
    return edtDimLineCoef->text().toFloat();
}

QString TransitionExtendedDialog::getDimLabelColor(){
    return edtDimLabelColor->text();
}

float TransitionExtendedDialog::getLineBorderCoef(){
    return edtLineBorderCoef->text().toFloat();
}

QString TransitionExtendedDialog::getLineBorderColor(){
    return edtLineBorderColor->text();
}
  
float TransitionExtendedDialog::getLineDblCoef(){
    return edtLineDblCoef->text().toFloat();
}

float TransitionExtendedDialog::getLineDblSep(){
    return edtLineDblSep->text().toFloat();
}

//--------------------------------------------- Transition Extended Dialog -->



// <-- NextLabels Dialog -----------------------------------------------------

NextLabelsDialog::NextLabelsDialog(Editor *editor, Transition *tr, QWidget *parent)
: QDialog(parent), m_pEditor(editor), m_pTransition(tr)
{
    QLabel *lblNextLabels = new QLabel(QString("Next labels:"),this);
    
    labelList = new QListWidget(this);    
    QStringList sl;
    for (Transition::TLabelXList::ConstIterator labelIt = m_pTransition->nextLabels.begin();
         labelIt != m_pTransition->nextLabels.end();
         ++labelIt)
    {
        sl << getListLine(*labelIt);
    }
    labelList->addItems(sl);
    connect(labelList, SIGNAL(itemSelectionChanged()), this, SLOT(selectionChanged()));

    btnAdd = new QPushButton("Add", this);
    connect(btnAdd, SIGNAL(clicked()), this, SLOT(addLabel()));

    btnEdit = new QPushButton("Edit", this);
    connect(btnEdit, SIGNAL(clicked()), this, SLOT(editLabel()));

    btnDelete = new QPushButton("Delete", this);
    connect(btnDelete, SIGNAL(clicked()), this, SLOT(deleteLabel()));    

    QPushButton *buttonClose = new QPushButton("&Close");    
    connect(buttonClose, SIGNAL(clicked()), this, SLOT(close()));

    QGridLayout *dialogLayout = new QGridLayout(this);    
    dialogLayout->addWidget(lblNextLabels, 0, 0, 1, 2);
    dialogLayout->addWidget(labelList, 1, 0, 5, 1);
    dialogLayout->addWidget(btnAdd, 1, 1);
    dialogLayout->addWidget(btnEdit, 2, 1);
    dialogLayout->addWidget(btnDelete, 3, 1);    
    dialogLayout->addWidget(buttonClose, 5, 1);

    QString    s = "Next labels";
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/transition.xpm"));

    selectionChanged();
}

void NextLabelsDialog::selectionChanged()
{    
    DBGLOG("selected row=" << labelList->currentRow());

    // handle state of edit and delete buttons
    btnEdit->setEnabled(labelList->currentRow() != -1);
    btnDelete->setEnabled(labelList->currentRow() != -1);
}

QString NextLabelsDialog::getListLine(LabelX *label)
{
    return QString("%1, pos=%2, orientation=%3")
                .arg(label->text())
                .arg(label->posParam())
                .arg(label->left() ? "left" : "right");
}

void NextLabelsDialog::addLabel()
{
    NextLabelsEditDialog nled(eAdd, this);
    if (nled.exec() == QDialog::Rejected) return;

    LabelX *label = new LabelX(m_pTransition, nled.edtLabel->text(), nled.checkLeft->isChecked(),
        m_pTransition->m_labelFontSize, m_pTransition->getLabelColor(), nled.edtPos->text().toFloat());
        
    m_pEditor->addToUndoStack(new NextLabelAddCommand(m_pEditor,label));

    labelList->insertItem(labelList->count(), getListLine(label));        
}

void NextLabelsDialog::editLabel()
{
    LabelX *label = m_pTransition->nextLabels[labelList->currentRow()];
    NextLabelsEditDialog nled(eEdit, this, label->text(), label->posParam(), label->left());
    if (nled.exec() == QDialog::Rejected) return;

    m_pEditor->addToUndoStack(
        new NextLabelEditCommand(label, nled.edtLabel->text(), nled.edtPos->text().toFloat(),
            nled.checkLeft->isChecked())
    );
    
    // edit item in labelList
    int row = labelList->currentRow();
    labelList->takeItem(row);
    labelList->insertItem(row, getListLine(label));
}

void NextLabelsDialog::deleteLabel()
{   
    if (QMessageBox::question(this, QString("Realy delete?"), QString("Are you sure you want to delete selected label?"),
                              QMessageBox::Yes, QMessageBox::No) == QMessageBox::Yes)
    {        
        LabelX *label = m_pTransition->nextLabels[labelList->currentRow()];
        m_pEditor->addToUndoStack(new NextLabelDeleteCommand(m_pEditor, label));
        labelList->takeItem(labelList->currentRow());              
    }
}

//------------------------------------------------------ NextLabels Dialog -->



// <-- NextLabelsEdit Dialog -------------------------------------------------

NextLabelsDialog::NextLabelsEditDialog::NextLabelsEditDialog
(EActionType action, QWidget *parent)
: QDialog(parent)
{
    init(action, "", DEF_EDGE_LAB_POS, true);
}

NextLabelsDialog::NextLabelsEditDialog::NextLabelsEditDialog
(EActionType action, QWidget *parent, const QString& str, float pos, bool left)
: QDialog(parent)
{
    init(action, str, pos, left);
}

void NextLabelsDialog::NextLabelsEditDialog::init(EActionType action, const QString &str, float pos, bool left)
{
    QLabel *lblLabel = new QLabel(QString("label"), this);
    edtLabel = new QLineEdit(str, this);

    QLabel *lblPos = new QLabel(QString("pos"), this);
    QRegExp rx("^[\\-]{0,1}[0-9]{1,3}\\.[0-9]{1,3}$"); // float validator
    QValidator *v = new QRegExpValidator(rx,this);     
    edtPos = new QLineEdit(QString("%1").arg(pos), this);           
    edtPos->setValidator(v);

    checkLeft = new QCheckBox(QString("isLeft"), this);    
    checkLeft->setChecked(left);

    // buttons
    QWidget *buttonBox = new QWidget(this);
    QPushButton *buttonOk = new QPushButton("Ok");
    QPushButton *buttonCancel = new QPushButton("Cancel");
    QHBoxLayout *buttonBoxLayout = new QHBoxLayout;
    buttonBoxLayout->addWidget(buttonOk);
    buttonBoxLayout->addWidget(buttonCancel);
    buttonBox->setLayout(buttonBoxLayout);    
    buttonBox->setMaximumWidth(300);
    connect(buttonOk, SIGNAL(clicked()), this, SLOT(accept()));
    connect(buttonCancel, SIGNAL(clicked()), this, SLOT(reject()));

    QGridLayout *dialogLayout = new QGridLayout(this);
    dialogLayout->addWidget(lblLabel, 0, 0);
    dialogLayout->addWidget(edtLabel, 0, 1);
    dialogLayout->addWidget(lblPos, 0, 2);
    dialogLayout->addWidget(edtPos, 0, 3);
    dialogLayout->addWidget(checkLeft, 0, 4);
    dialogLayout->addWidget(buttonBox, 1, 0, 1, 5, Qt::AlignHCenter);

    QString    s;
    switch (action)
    {
    case eAdd:
        s = QString("Add label");
        break;
    case eEdit:
        s = QString("Edit label");
        break;    
    }
    setWindowTitle(s);
    setWindowIcon(QIcon(":images/transition.xpm"));
}

// ------------------------------------------------- NextLabelsEdit Dialog -->
