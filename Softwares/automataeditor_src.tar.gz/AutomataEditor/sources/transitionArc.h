#ifndef _TRANSITIONARC_H_2538769212346_
#define _TRANSITIONARC_H_2538769212346_

#include "twoStatesTransition.h"

class TransitionArc : public TwoStatesTransition
{
public: 
  TransitionArc(Editor *parent, State *ss, State *es, const QString &label,
                bool leftOriented, bool dimmed, bool radius);
  virtual ~TransitionArc();
  
  virtual void adjust();
  virtual void setLabelPosition();
  
  virtual QString getTypeName() const;

  virtual QString getVCCommand() const;
  //virtual QString getEPS() const;
protected:
  //void paint(QPainter * painter, const QStyleOptionGraphicsItem * option, QWidget * widget = 0);
  
  bool radius; // angle 15 or 30 degrees

  QPointF a_point;
  QPointF b_point;
};

#endif //_TRANSITIONARC_H_2538769212346_
