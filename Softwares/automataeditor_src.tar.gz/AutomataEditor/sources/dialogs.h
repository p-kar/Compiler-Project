#ifndef _DIALOGS_H_2527828932_
#define _DIALOGS_H_2527828932_

#include <QDialog>
class Editor;

class QSpinBox;
class QComboBox;
class QLineEdit;
class QCheckBox;
class QTextEdit;
class QTableWidget;


class GridRectDialog : public QDialog
{
    Q_OBJECT
public:
    GridRectDialog(QWidget* parent = 0);

  void setLowerLeftX(int x);
  void setLowerLeftY(int y);
  void setUpperRightX(int x);
  void setUpperRightY(int y);
  void setBorder(int b);
  
  int getLowerLeftX();
  int getLowerLeftY();
  int getUpperRightX();
  int getUpperRightY();
  int getBorder();
        
protected:
    QSpinBox *spinLowerLeftX;
    QSpinBox *spinLowerLeftY;
    QSpinBox *spinUpperRightX;
    QSpinBox *spinUpperRightY;
    QSpinBox *spinBorder;    
};



class StateStyleDialog: public QDialog{
  Q_OBJECT
public:
  StateStyleDialog(Editor *parent);
  
  void setParams();
protected:
  Editor *editor;
  // adjusted
  QComboBox *comboLineStyle;
  QLineEdit *edtLineWidth;
  QLineEdit *edtLineColor;
  QLineEdit *edtLabelColor;
  QLineEdit *edtLabelScale;
  QComboBox *comboFillStatus;
  QLineEdit *edtFillColor;
  // preset
  QComboBox *comboDimLineStyle;
  QLineEdit *edtDimLineColor;
  QLineEdit *edtDimLineCoef;
  QLineEdit *edtDimLabelColor;
  QLineEdit *edtDimFillColor;
  // double
  QLineEdit *edtLineDblCoef;
  QLineEdit *edtLineDblSep;
  // apply
  QComboBox *comboApply;
  
protected slots:
  void myAccept(); // set params to editor
};



class TransitionStyleDialog: public QDialog{
  Q_OBJECT
public:
  TransitionStyleDialog(Editor *parent);
  
  void setParams();

  Qt::PenStyle getLineStyle();
  float getLineWidth();
  QString getLineColor();
  QString getLabelColor();
  float getLabelScale();
  bool getDblStatus();
  
  Qt::PenStyle getDimLineStyle();
  QString getDimLineColor();
  float getDimLineCoef();
  QString getDimLabelColor();
  
  float getLineBorderCoef();
  QString getLineBorderColor();
  
  float getLineDblCoef();
  float getLineDblSep();
  
protected:
  Editor *editor;
  // adjusted
  QComboBox *comboLineStyle;
  QLineEdit *edtLineWidth;
  QLineEdit *edtLineColor;
  QLineEdit *edtLabelColor;
  QLineEdit *edtLabelScale;
  QCheckBox *checkDblStatus;
  // preset
  QComboBox *comboDimLineStyle;
  QLineEdit *edtDimLineColor;
  QLineEdit *edtDimLineCoef;
  QLineEdit *edtDimLabelColor;
  // border
  QLineEdit *edtLineBorderCoef;
  QLineEdit *edtLineBorderColor;
  // double
  QLineEdit *edtLineDblCoef;
  QLineEdit *edtLineDblSep;
  // apply
  QComboBox *comboApply;
  
protected slots:
  void myAccept();
};



class GraphGenerationDialog: public QDialog
{
  Q_OBJECT
public:
  GraphGenerationDialog(Editor *parent);
  
  QString getString();
  QPoint getStartPoint();
  int getType();
  int getDistance();
  bool isExpandRequired();
  
protected:
  Editor *editor;
  
  QLineEdit *edtString;
  QComboBox *comboAlgorithm;
  QSpinBox *spinDistance;
  
  QSpinBox *spinX;
  QSpinBox *spinY;
  
  QCheckBox *checkExpandGrid;
  
protected slots:
  void myAccept();
  void algorithmChanged(int i);
};



#include "iautomaton.h"

class LaTeXTableDialog: public QDialog
{
    Q_OBJECT
public:
    LaTeXTableDialog(Editor *parent,
                     const QSharedPointer<ITransitionTable> &table);
    
    QString text() const;    

protected:
    void setViewText();

    QTextEdit                           *m_textEdit;
    QPushButton                         *m_switchButton;
    
    QSharedPointer<ITransitionTable>    m_pTable;
    
    enum EViewType {eStringTable, eLaTeXTable};
    EViewType   m_viewType;

protected slots:
    void switchView();
    void copyAll();
};


#include "ialgorithm.h"
#include "itransition.h"
class LoadAutomataDialog: public QDialog
{
    Q_OBJECT
public:
    LoadAutomataDialog(Editor *editor, const QString &dialogTitle,
                       int count, const QStringList &drawAlgorithmList,
                       bool useCurrent, IAlgorithm *algorithm);
    
    QStringList getFileNames() const;
    bool        useCurrentAutomaton() const;
    int         getDrawAlgorithmIndex() const;

    void setDrawAlgorithmIndex(int index);

    bool alphabetIsSet() const;
    bool alphabetSymbolIsSet() const;
    bool epsilonSymbolIsSet() const;

    ITransition::TCharSet   getAlphabet() const;
    QString                 getAlphabetSymbol() const;
    QString                 getEpsilonSymbol() const;

private:
    QCheckBox*              m_checkUseCurrent;
    QList<QLineEdit*>       m_fileEdits;
    QList<QPushButton*>     m_fileButtons;

    QCheckBox               *m_checkAlphabet;
    QCheckBox               *m_checkAlphabetSymbol;
    QCheckBox               *m_checkEpsilonSymbol;

    QLineEdit               *m_edtAlphabet;
    QLineEdit               *m_edtAlphabetSymbol;
    QLineEdit               *m_edtEpsilonSymbol;
    
    int                     m_count;
    QString                 m_editorFileName;
    QString                 m_lastFileName;
    
    QRegExp                 m_alphabetRegex;
    ITransition::TCharSet   m_alphabet;
    QString                 m_alphabetSymbol;
    QString                 m_epsilonSymbol;
    
    IAlgorithm              *m_algorithm;

    QComboBox               *m_comboDrawList;

protected slots:
    void myAccept();
    void checkChanged(int state);
    void buttonClicked();
    
    void checkAlphabetChanged(int);
    void checkAlphabetSymbChanged(int);
    void checkEpsilonSymbChanged(int);
    
    void algorithmSettings();
};



class ReportDialog : public QDialog
{
public:
    ReportDialog(const QString &reportText = "", QWidget *parent = 0);  
};

#endif //_DIALOGS_H_2527828932_
