#include "constants.h"

#include "stringProcessor.h"
#include "editor.h"
#include "labelSyntaxChecker.h"

#include <QMap>
#include <QList>
#include <QPair>
#include <QString>
#include <QFont>
#include <QFontMetrics>
#include <QRectF>
#include <QPainter>
#include <QRegExp>
#include <QtDebug>

#ifdef TESTING_STRING_PROCESSOR
#   define DBGLOG_SP(x) DBGLOG_("STRINGPROCESSOR", x)
#else
#   define DBGLOG_SP(x)
#endif

#if 0
#   define DBGLOG_SP_DRAW(x) DBGLOG_("SP_DRAW", x)
#else
#   define DBGLOG_SP_DRAW(x)
#endif

//<-- StringProcessor ---------------------------------------------------

// static members
StringProcessor::TString2CharMap    StringProcessor::string2CharMap;

StringProcessor::TString2KwTypeMap  StringProcessor::string2KwTypeMap;

const QRegExp StringProcessor::keywordRegex("((\\\\\\w+)\\s*)");
const QRegExp StringProcessor::specCharacterRegex("(\\\\|\\{|\\})");
const QRegExp StringProcessor::whitespaceRegex("\\s");
const QRegExp StringProcessor::escapedCharacterRegex
(
    "(\\\\\\$|\\\\\\%|\\\\\\#|\\\\\\&|\\\\\\~|\\\\\\_|\\\\\\^|\\\\\\{|\\\\\\}|\\\\\\\\)"
);

#ifdef USE_UNKNOWN_CONVENTION
	const QChar StringProcessor::unknownCharacter = UNKNOWN_CHARACTER;
	const QString StringProcessor::unknownString = UNKNOWN_STRING;
#endif

const QStringList StringProcessor::fontFamilyList = 
    QStringList() << "Arial" << "Symbol";

void StringProcessor::initialize()
{
    // initialize just once
    if (string2CharMap.contains("\\alpha")) 
        return;

    // Greek symbols
    addToMaps("\\alpha",         TCharPair('a',     eSymbolFont));
    addToMaps("\\beta",          TCharPair('b',     eSymbolFont));
    addToMaps("\\gamma",         TCharPair('g',     eSymbolFont));
    addToMaps("\\delta",         TCharPair('d',     eSymbolFont));
    addToMaps("\\varepsilon",    TCharPair('e',     eSymbolFont));
    addToMaps("\\epsilon",       TCharPair(0xCE,    eSymbolFont));
    addToMaps("\\zeta",          TCharPair('z',     eSymbolFont));
    addToMaps("\\eta",           TCharPair('h',     eSymbolFont));
    addToMaps("\\theta",         TCharPair('q',     eSymbolFont));
    addToMaps("\\vartheta",      TCharPair(0x4A,    eSymbolFont));
    addToMaps("\\iota",          TCharPair('i',     eSymbolFont));
    addToMaps("\\kappa",         TCharPair('k',     eSymbolFont));
    addToMaps("\\lambda",        TCharPair('l',     eSymbolFont));
    addToMaps("\\mu",            TCharPair('m',     eSymbolFont));
    addToMaps("\\nu",            TCharPair('n',     eSymbolFont));
    addToMaps("\\xi",            TCharPair('x',     eSymbolFont));
    addToMaps("\\omicron",       TCharPair('o',     eSymbolFont));
    addToMaps("\\pi",            TCharPair('p',     eSymbolFont));
    addToMaps("\\varpi",         TCharPair(0x76,    eSymbolFont));
    addToMaps("\\rho",           TCharPair('r',     eSymbolFont));
    addToMaps("\\varsigma",      TCharPair(0x56,    eSymbolFont));
    addToMaps("\\sigma",         TCharPair('s',     eSymbolFont));
    addToMaps("\\tau",           TCharPair('t',	    eSymbolFont));
    addToMaps("\\upsilon",       TCharPair('u',	    eSymbolFont));
    addToMaps("\\varphi",        TCharPair('j',	    eSymbolFont));
    addToMaps("\\phi",           TCharPair(0x66,    eSymbolFont));
    addToMaps("\\chi",           TCharPair('c',	    eSymbolFont));
    addToMaps("\\psi",           TCharPair('y',	    eSymbolFont));
    addToMaps("\\omega",         TCharPair('w',	    eSymbolFont));

    addToMaps("\\Alpha",         TCharPair('A',     eSymbolFont));
    addToMaps("\\Beta",          TCharPair('B',     eSymbolFont));
    addToMaps("\\Gamma",         TCharPair('G',     eSymbolFont));
    addToMaps("\\Delta",         TCharPair('D',     eSymbolFont));
    addToMaps("\\Epsilon",       TCharPair('E',     eSymbolFont));
    addToMaps("\\Zeta",          TCharPair('Z',	    eSymbolFont));
    addToMaps("\\Eta",           TCharPair('H',	    eSymbolFont));
    addToMaps("\\Theta",         TCharPair('Q',	    eSymbolFont));    
    addToMaps("\\Iota",          TCharPair('I',	    eSymbolFont));
    addToMaps("\\Kappa",         TCharPair('K',	    eSymbolFont));
    addToMaps("\\Lambda",        TCharPair('L',	    eSymbolFont));
    addToMaps("\\Mu",            TCharPair('M',	    eSymbolFont));
    addToMaps("\\Nu",            TCharPair('N',	    eSymbolFont));
    addToMaps("\\Xi",            TCharPair('X',	    eSymbolFont));
    addToMaps("\\Omicron",       TCharPair('O',	    eSymbolFont));    
    addToMaps("\\Pi",            TCharPair('P',	    eSymbolFont));
    addToMaps("\\Rho",           TCharPair('R',	    eSymbolFont));
    addToMaps("\\Sigma",         TCharPair('S',	    eSymbolFont));
    addToMaps("\\Tau",           TCharPair('T',	    eSymbolFont));
    addToMaps("\\Upsilon",       TCharPair(0xA1,    eSymbolFont));
    addToMaps("\\Phi",           TCharPair(0x46,    eSymbolFont));
    addToMaps("\\Chi",           TCharPair('C',	    eSymbolFont));
    addToMaps("\\Psi",           TCharPair('Y',	    eSymbolFont));
    addToMaps("\\Omega",         TCharPair('W',	    eSymbolFont));

    // special symbols
    addToMaps("\\{",             TCharPair('{',     eNormalFont));
    addToMaps("\\}",             TCharPair('}',     eNormalFont));
    addToMaps("\\\\",            TCharPair('\\',    eNormalFont));
    //"(\\\\\\$|\\\\\\%|\\\\\\#|\\\\\\&|\\\\\\~|\\\\\\_|\\\\\\^|\\\\\\\\)"
    addToMaps("\\$",             TCharPair('$',     eNormalFont));
    addToMaps("\\%",             TCharPair('%',     eNormalFont));
    addToMaps("\\#",             TCharPair('#',     eNormalFont));
    addToMaps("\\&",             TCharPair('&',     eNormalFont));
    addToMaps("\\~",             TCharPair('~',     eNormalFont));
    addToMaps("\\_",             TCharPair('_',     eNormalFont));
    addToMaps("\\^",             TCharPair('^',     eNormalFont));
    addToMaps("\\\\",            TCharPair('\\',    eNormalFont));
    
    addToMaps("\\vdash",         TCharPair(0x0370,  eNormalFont)); // used code for Greek HETA, possible to use 0x2C75 for half H

    // font size changers
    string2KwTypeMap["\\scriptstyle"]           =   eFontSize;
    string2KwTypeMap["\\textstyle"]             =   eFontSize;
    string2KwTypeMap["\\scriptscriptstyle"]     =   eFontSize;
    
    //modifiers
    string2KwTypeMap["\\bar"]                   =   eModifier;
    string2KwTypeMap["\\underline"]             =   eModifier;
    string2KwTypeMap["\\overline"]              =   eModifier;    

#if defined(TESTING_STRING_PROCESSOR) || defined(STRING_PROCESSOR_TEST)
    DBGLOG_SP(string2CharMap);
#endif
}

void StringProcessor::addToMaps(const QString &str, const TCharPair &charPair)
{
    string2CharMap[str] = charPair;    
    string2KwTypeMap[str] = eString2Char;
}

StringProcessor::CharacterInfo::CharacterInfo(EChangeType type, int idx, const QString &ch,
                                              EFontSize size, EModifier mod)
: changeType(type), textIdx(idx), character(ch), fontSize(size), modifier(mod)
{
    DBGLOG_SP("creating" << (CharacterInfo) (*this));
}

bool StringProcessor::isSpecialSymbol(const QString &symb)
{
    if (keywordRegex.indexIn(symb) == 0)
    {
        DBGLOG_SP(DBGPAR(symb));
        return true;
    }
    return false;
}

QString StringProcessor::getSymbolPrintInfo(const QString &symb, QString &fontFamily)
{
    initialize();
    
    if (string2CharMap.contains(symb))
    {
        const int fontIdx = string2CharMap[symb].second;
        Q_ASSERT(fontIdx < fontFamilyList.count());
        Q_UNUSED(fontIdx);
        fontFamily = fontFamilyList[fontIdx];
        return string2CharMap[symb].first;
    }
    
    fontFamily = fontFamilyList[eNormalFont];
    return symb;
}

bool StringProcessor::parseFontSize(const QString &symb, EFontSize &fontSize)
{
    if (symb == "\\textstyle")
    {
        fontSize = eTextStyle;
        return true;
    }
    if (symb == "\\displaystyle")
    {
        fontSize = eDisplayStyle;
        return true;
    }
    if (symb == "\\scriptstyle")
    {
        fontSize = eScriptStyle;
        return true;
    }
    if (symb == "\\scriptscriptstyle")
    {
        fontSize = eScriptScriptStyle;
        return true;
    }
    return false;
}

bool StringProcessor::parseModifier(const QString &symb, EModifier &modifier)
{   // hold consistent with string2KwTypeMap !!
    if (symb == "\\bar")
    {
        modifier = eBar;
        return true;
    }
    if (symb == "\\underline")
    {
        modifier = eUnderline;
        return true;
    }
    if (symb == "\\overline")
    {
        modifier = eOverline;
        return true;
    }
    return false;
}

StringProcessor::TCharacterList StringProcessor::computeCharacterListInBlock
    (const QString &input, int &startIdx, EFontSize fs, EModifier m)
{
    TCharacterList result;
    
    QString::ConstIterator inputIt = input.begin();
    if (QString(*inputIt) == "{")
    {
        QString newInput;
        inputIt++;
        ++startIdx; // drop '{'
        int b_count = 1;
        while(b_count != 0)
        {
            if (inputIt == input.end())
            {
                throw StringProcessorBraceMatchException(); // TODO: check if ok
                break;
            }
            
            if      ((*inputIt) == '{') b_count++;
            else if ((*inputIt) == '}') b_count--;
            
            newInput += *inputIt;
            ++inputIt;
        }
        newInput.resize(newInput.length()-1); // drop '}'
        
        result = computeCharacterList(newInput, startIdx, fs, m);
        ++startIdx; // drop '}'
    }
    else
    {
        result << computeCharacterList(input, startIdx, fs, m, true);
    }
    
    return result;
}

StringProcessor::TCharacterList StringProcessor::computeCharacterList(const QString &input)
{
    int idx = 0;
    DBGLOG_SP(DBGPAR(input));
    TCharacterList result = computeCharacterList(input, idx, eTextStyle, eNoModifier);
    return result;
}

StringProcessor::TCharacterList StringProcessor::computeCharacterList
    (const QString &input, int &startIdx, EFontSize fs, EModifier m, bool readOneCharacter)
{
    EFontSize fontSize = fs;
    EModifier modifier = m;
    
    int absPos;
    TCharacterList result;
    
    int idx = -1, pos = 0;
    while((idx = specCharacterRegex.indexIn(input, pos)) != -1)
    {
        for(; pos<idx; ++pos)
        {
            QChar ch = input[pos];
            if (!whitespaceRegex.exactMatch(ch))
            {
                result << CharacterInfo(eNoChange, startIdx+pos, QString(ch), fontSize, modifier);
                if (readOneCharacter) { startIdx += ++pos; return result; }
            }
        }
        
        QString subInput = input.mid(pos);
        
        QString specCharacter = specCharacterRegex.cap(1);        
        if (specCharacter == "{")
        {
            Q_ASSERT(!readOneCharacter); // shouldn't occure!
            absPos = startIdx + pos;
            result << computeCharacterListInBlock(subInput, absPos, fontSize, modifier);
            pos = absPos - startIdx;
            continue;
        }
        else if (specCharacter == "}")
        {
            throw StringProcessorBraceMatchException();
            continue;
        }
        
        // keyword
        if (keywordRegex.indexIn(subInput) == 0)
        {
            QString matchedString = keywordRegex.cap(1);
            QString keyword = keywordRegex.cap(2);
            
            if (!string2KwTypeMap.contains(keyword))
            {
#ifdef USE_UNKNOWN_CONVENTION
                RELLOG(keyword << "is unknown keyword, used " << unknownString <<
                       " instead, please contact developer");
                result << CharacterInfo(eNoChange, startIdx+pos, unknownString, fontSize, eNoModifier);
#else
                DBGLOG(DBGPAR(subInput.mid(keyword.length(),2)));
                if (subInput.mid(keyword.length(),2) == "{}")
                	keyword += "{}";
                RELLOG(keyword << "is unknown keyword, used unmodified, please contact developer");
                result << CharacterInfo(eNoChange, startIdx+pos, keyword, fontSize, eNoModifier);
#endif
                pos += matchedString.length();
                if (readOneCharacter){ startIdx += pos; return result; }
                continue;
            }
                      
            EModifier newMod = modifier;
            switch(string2KwTypeMap[keyword])
            {
                case eString2Char:
                    result << CharacterInfo(eStringToChar, startIdx+pos,
                                            keyword,
                                            fontSize, modifier);
                    pos += matchedString.length();
                    if (readOneCharacter){ startIdx += pos; return result; }
                    break;
                case eFontSize:
                    if (!parseFontSize(keyword, fontSize))
                    {
                        Q_ASSERT(0); // shouldn't occure!
                    }
                    pos += matchedString.length();
                    if (readOneCharacter){ startIdx += pos; return result; }
                    break;
                case eModifier:
                    if (!parseModifier(keyword, newMod))
                    {
                        Q_ASSERT(0); // shouldn't occure!
                    }
                    pos += matchedString.length();
                    
                    absPos = startIdx + pos;
                    subInput = input.mid(pos);
                    result << computeCharacterListInBlock(subInput, absPos, fontSize, newMod);
                    pos = absPos - startIdx;
                    if (readOneCharacter) { startIdx += pos; return result; }
                    break;
                default: 
                    Q_ASSERT(0); break;
            }
            
            continue;            
        }
        
        // can be only character!
        if (escapedCharacterRegex.indexIn(subInput) == 0)
        {
            // print character! -> stored in string2CharMap
            QString character = escapedCharacterRegex.cap(1);
            
            if (string2KwTypeMap.contains(character))
            {
                Q_ASSERT(string2KwTypeMap[character] == eString2Char);
                result << CharacterInfo(eStringToChar, startIdx+pos,
                                        character,
                                        fontSize, modifier);
                pos += character.length();
                if (readOneCharacter) { startIdx += pos; return result; }
                continue;
            }
        }
        
#ifdef USE_UNKNOWN_CONVENTION
        RELLOG(subInput.mid(0,2) << "is unknown sequence, used " << unknownCharacter
                                 << " instead, please contact developer");
        result << CharacterInfo(eNoChange, startIdx+pos,
                                unknownCharacter,
                                eTextStyle, eNoModifier);
#else
        RELLOG(subInput.mid(0,2) << "is unknown sequence, used unmodified, please contact developer");
        result << CharacterInfo(eNoChange, startIdx+pos, subInput.mid(0,2), eTextStyle, eNoModifier);
#endif

        pos += 2; // '\' + next character
        continue;
    }

    for (; pos<input.length(); ++pos)
    {
        QChar ch = input[pos];        
        if (!whitespaceRegex.exactMatch(ch))
        {
            result << CharacterInfo(eNoChange, startIdx+pos, QString(ch), fontSize, modifier);
            if (readOneCharacter){ startIdx += ++pos; return result; }
        }
    }

    startIdx += pos;
    
    DBGLOG_SP(DBGPAR(result));
    return result;
}

QStringList StringProcessor::parseSymbols(const TCharacterList &characterList)
{
    initialize();
    
    QStringList symbols;
    foreach(const CharacterInfo &c, characterList)
    {
        symbols << c.character;
    }
    
    return symbols;
}

QStringList StringProcessor::parseSymbols(const QString &input)
{
    initialize();    
    
    TCharacterList characterList = computeCharacterList(input);
    return parseSymbols(characterList);
}

QStringList StringProcessor::getCharacters() const
{
    return parseSymbols(m_characterList);
}

StringProcessor::TCharacterList StringProcessor::getCharacterList() const
{
    return m_characterList;
}

StringProcessor::StringProcessor(const QString &text, int fontSize)
: m_text(text), m_fontSize(fontSize)
{    
    initialize();

    fillFontLists();
    bool ok = true;
    try
    {
        m_characterList = computeCharacterList(m_text);
    }
    catch(const StringProcessorException &e)
    {
        Q_ASSERT(0);
        RELLOG("StringProcessorException: " << e.what());
        m_text = "";
        ok = false;
    }
    
    if(!ok)
    {
        try
        {
            m_characterList = computeCharacterList(m_text); // should never throw exception for empty input!
        }
        catch(const StringProcessorException &e)
        {
            Q_ASSERT(0);
            RELLOG("StringProcessorException: " << e.what());
            qFatal("Unexpected exception!");
        }
    }
    
    computeMetrics();
}

void StringProcessor::fillFontLists()
{
    m_fontList.clear();
    m_metricsList.clear();
    
    Q_ASSERT(fontFamilyList.size() >= 2);
    
    // fonts in latex are italic, but in editor it does not seem good
    m_fontList << QFont(fontFamilyList[0], m_fontSize, QFont::Normal, false)    // Arial
               << QFont(fontFamilyList[1], m_fontSize, QFont::Normal, false);   // Symbol

    // due to printing to EPS file by printer in PrinterResolution mode
    m_fontList[0].setPixelSize(QFontInfo(m_fontList[0]).pixelSize());
    m_fontList[1].setPixelSize(QFontInfo(m_fontList[1]).pixelSize());

    m_metricsList << QFontMetrics(m_fontList[0])
                  << QFontMetrics(m_fontList[1]);
}

void StringProcessor::computeMetrics()
{                 
    int width = 0;
    int height = 0;
    int ascent = 0;
    int descent = 0;
    
    m_height = height;
    m_ascent = ascent;
    m_descent = descent;
    
    TCharPair tmpPair;
    QFont font;    
    QFontMetrics metrics(font);

    for(TCharacterList::ConstIterator charIt = m_characterList.begin();
        charIt != m_characterList.end();
        ++charIt)
    {
        switch((*charIt).changeType)
        {
            case eNoChange:
                font = m_fontList[eNormalFont];
                updateFont(font, *charIt);
                metrics = QFontMetrics(font);
                width += metrics.width((*charIt).character);                
                break;
            case eStringToChar:
                tmpPair = string2CharMap[(*charIt).character];
                font = m_fontList[tmpPair.second];
                updateFont(font, *charIt);
                metrics = QFontMetrics(font);
                width += metrics.width(tmpPair.first);
                break;            
            default:
                Q_ASSERT(0 && "unexpected value");
                break;
        }
        // find max values
        if ((height = metrics.height()) > m_height) m_height = height;
        if ((ascent = metrics.ascent()) > m_ascent) m_ascent = ascent;
        if ((descent = metrics.descent()) > m_descent) m_descent = descent;
    }   

    m_width = width;
}

int StringProcessor::getHeight() const
{
    return m_height;   
}

int StringProcessor::getDescent() const
{
    return m_descent;
}

int StringProcessor::getAscent() const
{
    return m_ascent;
}

bool StringProcessor::setText(const QString &text)
{    
    try
    {
        m_characterList = computeCharacterList(text);   
    }
    catch(const StringProcessorException &e)
    {
        RELLOG("StringProcessorException: " << e.what());
        RELLOG("Change wasn't applied!");
        return false;
    }
        
    m_text = text;
    computeMetrics();
    return true;
}

void StringProcessor::setFontSize(int fontSize)
{    
    m_fontSize = fontSize;
    fillFontLists();
    computeMetrics();
}

bool StringProcessor::updateFont(QFont &font, const CharacterInfo &c) const
{
    bool chFS = true;
    switch(c.fontSize)
    {
        case eScriptStyle:
            font.setPixelSize(font.pixelSize()*SCRIPT_STYLE_MULT);          break;
        case eScriptScriptStyle:
            font.setPixelSize(font.pixelSize()*SCRIPT_SCRIPT_STYLE_MULT);   break;
        default:
            chFS = false;
            break;
    }

    bool chM = true;
    switch(c.modifier)
    {
        case eBar:         
            font.setOverline(true);                                         break;
        case eUnderline:
            font.setUnderline(true);                                        break;
        case eOverline:
            font.setOverline(true);                                         break;
        default:
            chM = false;
            break;
    }
    
    if (chM || chFS)
        return true;
        
    return false;
}

void StringProcessor::drawText(QPainter *painter, QPointF& point) const
{        
    TCharPair   tmpPair;
    QFont font;    
    QFontMetrics metrics(font);
    
    for(TCharacterList::ConstIterator charIt = m_characterList.begin();
        charIt != m_characterList.end();
        ++charIt)
    {
        switch((*charIt).changeType)
        {
            case eNoChange:                    
                DBGLOG_SP_DRAW((*charIt).character);
                
                font = m_fontList[eNormalFont];
                updateFont(font, (*charIt));
                metrics = QFontMetrics(font);
                painter->setFont(font);
                
                painter->drawText(point, (*charIt).character);
                point.setX(point.x() + metrics.width((*charIt).character));
                break;
            case eStringToChar:
                Q_ASSERT(string2CharMap.contains((*charIt).character));
                DBGLOG_SP_DRAW("character:" << (*charIt).character);
                tmpPair = string2CharMap[(*charIt).character];                
                DBGLOG_SP_DRAW(tmpPair.first);

                font = m_fontList[tmpPair.second];
                updateFont(font, (*charIt));
                metrics = QFontMetrics(font);
                painter->setFont(font);
                
                painter->drawText(point, tmpPair.first);
                point.setX(point.x() + metrics.width(tmpPair.first));
                break;
            default:
                Q_ASSERT(0 && "unexpected value");
                break;
        }
    }
}

#ifdef TESTING_STRING_PROCESSOR
QDebug operator<<(QDebug dbg, const StringProcessor::CharacterInfo &c)
{
    QString tmp;
    switch(c.changeType)
    {
        case StringProcessor::eStringToChar:        tmp = QString("eStringToChar(%1)").arg(c.changeType);   break;        
        default:                                    tmp = QString("eNoChange(%1)").arg(c.changeType);       break;
    }
    dbg.nospace() << endl << tmp << "," << c.textIdx << "," << c.character << ",";
    switch(c.fontSize)
    {
        case StringProcessor::eScriptStyle:         tmp = QString("eScriptStyle(%1)").arg(c.fontSize);      break;
        case StringProcessor::eScriptScriptStyle:   tmp = QString("eScriptScriptStyle(%1)").arg(c.fontSize);break;
        default:                                    tmp = QString("eTextStyle(%1)").arg(c.fontSize);        break;
    }
    dbg.nospace() << tmp;
    switch(c.modifier)
    {
        case StringProcessor::eBar:                 tmp = QString("eBar(%1)").arg(c.modifier);              break;
        default:                                    tmp = QString("eNoModifier(%1)").arg(c.modifier);       break;
    }
    dbg.nospace() << tmp;

    return dbg.nospace();
}
#endif

//--------------------------------------------------- StringProcessor -->



#ifdef STRING_PROCESSOR_TEST

#include "label.h"
#include "labelSyntaxChecker.h"
#include "dialogs.h"

#include <QLineEdit>
#include <QPushButton>
#include <QBoxLayout>
#include <QGraphicsView>
#include <QTimer>
#include <QCheckBox>

ITransition::TCharSet g_alphabet = 
    QSet<QString>::fromList((QStringList() 
    << "a" << "b" << "c" << "d" << "e"
    << "\\alpha" << "\\beta" << "\\gamma" << "\\delta"));

StringProcessorTestDialog::StringProcessorTestDialog(QWidget *parent)
: QDialog(parent), m_idx(0), m_syntaxChecker(new LabelSyntaxChecker(g_alphabet, "A", "\\varepsilon"))
{
    m_timer = new QTimer(this);
    m_timer->setInterval(1000);
    connect(m_timer, SIGNAL(timeout()), this, SLOT(timerEvent()));

    m_edtText = new QLineEdit(tr("\\alpha"), this);
    QPushButton *btnApply = new QPushButton(tr("&Apply"), this);
    connect(btnApply, SIGNAL(clicked()), this, SLOT(changeText()));
    m_checkTimer = new QCheckBox("alpha", this);
    connect(m_checkTimer, SIGNAL(stateChanged(int)), this, SLOT(timerChange(int)));

    m_checkSyntax = new QCheckBox("checkSyntax", this);

    QWidget *editHBox = new QWidget(this);
    QHBoxLayout *editHBoxLayout = new QHBoxLayout;
    editHBoxLayout->addWidget(m_edtText);
    editHBoxLayout->addWidget(btnApply);
    editHBoxLayout->addWidget(m_checkSyntax);
    editHBoxLayout->addWidget(m_checkTimer);
    editHBox->setLayout(editHBoxLayout);

    m_view = new QGraphicsView(this);
    m_view->setScene(new QGraphicsScene(m_view));    
    m_label = new LabelX(0, "\\alpha", true, 20);
    m_label->setPos(QPointF(10, 10));    
    m_view->scene()->addItem(m_label);

    QPushButton *btnClose = new QPushButton(tr("&Close"), this);
    connect(btnClose, SIGNAL(clicked()), this, SLOT(close()));
    
    QVBoxLayout *vBoxLayout = new QVBoxLayout;
    vBoxLayout->addWidget(editHBox);
    vBoxLayout->addWidget(m_view);
    vBoxLayout->addWidget(btnClose, Qt::AlignHCenter);
    vBoxLayout->setSpacing(10);
    
    this->setLayout(vBoxLayout);

    m_greekList << "alpha" << "beta" << "gamma" << "delta" << "varepsilon" << "epsilon" << "zeta" << "eta"
                << "vartheta" << "theta" << "iota" << "kappa" << "lambda" << "mu" << "nu" << "xi" << "omicron"
                << "varpi" << "pi" << "rho" << "varsigma" << "sigma" << "tau" << "upsilon"
                << "varphi" << "phi" << "chi" << "psi" << "omega";

    m_greekList << "Alpha" << "Beta" << "Gamma" << "Delta" << "Epsilon" << "Zeta" << "Eta"
                << "Theta" << "Iota" << "Kappa" << "Lambda" << "Mu" << "Nu" << "Xi" << "Omicron"
                << "Pi" << "Rho" << "Sigma" << "Tau" << "Upsilon" << "Phi" << "Chi" << "Psi" << "Omega";
}

StringProcessorTestDialog::~StringProcessorTestDialog()
{
	delete m_syntaxChecker;
}

void StringProcessorTestDialog::changeText()
{
    bool change = true;
    if (m_checkSyntax->isChecked())
    {        
        try
        {
            StringProcessor::TCharacterList charList = StringProcessor::computeCharacterList(m_edtText->text());
            change &= m_syntaxChecker->checkSyntax(charList);
        }
        catch(const StringProcessorException &e)
        {
            DBGLOG("StringProcessorException: " << e.what());
            return;
        }
        
        DBGLOG_SP(DBGPAR(m_syntaxChecker->getCharacters()));
        DBGLOG_SP(DBGPAR(m_syntaxChecker->getPattern()));
        
        if (!change)
        {
            ReportDialog rd(m_syntaxChecker->getReport(), this);
            rd.exec();
            return;
        }
    }    
    
    m_label->setText(m_edtText->text());
    m_view->scene()->update();   
}

void StringProcessorTestDialog::timerChange(int state)
{
    if (state == Qt::Checked)
        m_timer->start();
    else
        m_timer->stop();
}

void StringProcessorTestDialog::timerEvent()
{    
    if (m_idx == m_greekList.size()) m_idx = 0;    
    m_label->setText("\\" + m_greekList[m_idx]);
    m_view->scene()->update();
    m_checkTimer->setText(m_greekList[m_idx]);
    ++m_idx;
}

void StringProcessor::runTest()
{
    StringProcessorTestDialog sptd;
    sptd.exec();
}

#endif
