#include "constants.h"

#include "transitionVArc.h"
#include "state.h"
#include "label.h"
#include "transforms.h"

#include <math.h>

#include <QtDebug>

#ifdef PERFORMANCE_MEASUREMENT
#   include <QTime>
#endif

TransitionVArc::TransitionVArc(Editor *parent, State *ss, State *es, 
                               const QString &labelText, bool leftO, bool dimmed)
:   TwoStatesTransition(parent, ss, es, leftO, dimmed),
    arcangle(DEF_ARC_ANGLE), ncurv(DEF_ARC_CURV)
{
  setZValue(Z_TRANSITION);
  label = new LabelX(this, labelText, leftOriented, m_labelFontSize,
        dimmed ? QColor(dimEdgeLabelColor) : QColor(edgeLabelColor));
  label->setZValue(Z_TR_LABEL);
  label->setPosParam(DEF_ARC_LAB_POS);
  adjust();
  setLabelPosition();
}

TransitionVArc::~TransitionVArc()
{
    DBGLOG("called");
}

void TransitionVArc::adjust()
{
#ifdef MEASURE_TR_ADJUST 
    QTime timer;
    timer.start();
#endif
    prepareGeometryChange();
    if (!startState || !endState) return;
    
    startPoint = startState->pos();
    endPoint = endState->pos();
    
    QLineF s_v(startPoint, endPoint);
    float angle = s_v.angle(QLineF(0,0,1,0));
    if (startPoint.y() < endPoint.y()){
        angle *= -1;
    }

    QPolygonF anglePol, statePol, iPol;
    anglePol << startState->pos() << startState->pos() + 
                QPointF(cos(M_PI/180*(arcangle+angle)), -sin(M_PI/180*(arcangle+angle)))*startState->getWidth();
    statePol << mapFromItem(startState, startState->getMyPolygon());
    iPol = (findIntersectedPoints(anglePol, statePol, eFIND_FIRST));
    if (iPol.empty())
    {
        qWarning("TransitionVArc::adjust -> startPoint is set to startState->pos()!");
        startPoint = startState->pos();
    }
    else
    {
        startPoint = iPol[0];
    }

    anglePol.clear();
    statePol.clear();
    anglePol << endState->pos() << endState->pos() +
                QPointF(cos(M_PI/180*(180-arcangle+angle)), -sin(M_PI/180*(180-arcangle+angle)))*endState->getWidth();
    statePol << mapFromItem(endState, endState->getMyPolygon());
    iPol = (findIntersectedPoints(anglePol, statePol, eFIND_FIRST));
    if (iPol.empty())
    {
        qWarning("TransitionVArc::adjust -> endPoint is set to endState->pos()!");
        endPoint  = endState->pos();
    }
    else
    {
        endPoint = iPol[0];
    }    
    
    if (startPoint == endPoint) {
        setLabelPosition();
        return;
    }
  
    QPainterPath path;
  
    s_v.setPoints(startPoint, endPoint);
    float len = s_v.length()/2;

    angle = s_v.angle(QLineF(0,0,1,0));
    if (startPoint.y() < endPoint.y()){
        angle *= -1;
    }
  
    float angleA, angleB; // left or right orientation
    angleA = arcangle + angle;
    angleB = 180 - arcangle + angle; // the same angle as angelA, to seems like arc
  
    float x,y;  // compute vector form start point
    x = cos(M_PI/180*(angleA));
    y = sin(M_PI/180*(angleA)); // compute new unitVector
    QPointF point = QPointF(x,-y); 
    point += startPoint; // place to startPoint

    QLineF a_v(startPoint,point); // vector from startPoint
  
    // now compute vector from end point
    x = cos(M_PI/180*(angleB));
    y = sin(M_PI/180*(angleB)); // compute new unitVector
    point = QPointF(x,-y); 
    point += endPoint; // place to endPoint
      
    QLineF b_v(s_v.p2(),point); // vector from endPoint
  
  
    // set length by ncurv
    float current_ncurv = len * ncurv; // experiment
    a_v.setLength(current_ncurv);
    b_v.setLength(current_ncurv);

    a_point = a_v.p2(); b_point = b_v.p2();
    path.moveTo(startPoint);
    path.cubicTo(a_point, b_point, endPoint);
  
  
    p = path;

    QList<QPolygonF> pathList = p.toSubpathPolygons();
    if (pathList.size() > 1)
        RELLOG("not only one sub-path polygon!");

    iPol = pathList[0];
    iPol << endState->pos();
    pa = getArrowPolygon(p);
        
    setLabelPosition();
    createStrokes(p);
#ifdef MEASURE_TR_ADJUST
    DBGLOG("PM:" << "takes" << timer.elapsed() << "ms");
#endif
}

void TransitionVArc::setLabelPosition()
{
    if (label)
    { 
        Transition::setLabelPosition(label, label->posParam(), leftOriented, label->getWidth(), label->getHeight());
    } // if
    Transition::setLabelPosition();
}

QString TransitionVArc::getTypeName() const
{
    return "VArc";
}

/*void TransitionVArc::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    if (startPoint == endPoint) return;
    
    QColor lineC;
    Qt::PenStyle lineS;
  
    if (dimmed)
    {
        lineS = dimEdgeLineStyle;
        lineC = dimEdgeLineColor;
    }
    else
    {
        lineS = edgeLineStyle;
        lineC = edgeLineColor;
    }
  
    if (checked)
    {
        painter->setPen(QPen(checkedColor, m_lineWidth, lineS));
    } 
    else
    {
        painter->setPen(QPen(lineC, m_lineWidth, lineS));
    }
  
    painter->setBrush(Qt::NoBrush);
    painter->strokePath(p, painter->pen());  
  
    // draw arrow
    if (checked)
        painter->setBrush(checkedColor);
    else
        painter->setBrush(lineC);
      
    painter->drawPolygon(pa); // computed in adjust

    paintSelectionDecoration(painter);

#ifdef TESTING_PAINTING
#   ifdef TESTING_BOUNDING_RECT_PAINTING
        painter->setBrush(QBrush(QColor(50,255,0,100)));
        painter->fillRect(boundingRect(), painter->brush());
#   endif

    painter->setBrush(QBrush(QColor(0,0,255,150)));
    painter->fillPath(shape(), painter->brush());
#endif
}*/

QString TransitionVArc::getVCCommand() const
{
    QString command = "\\";

    command += getTypeName();
    command += getTypeNameSuffix();
    
    const int def_arcangle = leftOriented ? DEF_ARC_ANGLE : -DEF_ARC_ANGLE;

    Q_ASSERT(label != NULL);
    if (label->posParam() != DEF_ARC_LAB_POS) 
        command += QString("[%1]").arg(label->posParam());
    
    command += "{";
    if (getArcAngle() != def_arcangle) 
        command += QString("arcangle=%1").arg(getArcAngle());        
    if (getNCurv() != DEF_ARC_CURV)
    {
        if (getArcAngle() != DEF_ARC_ANGLE)            
            command += ",";
        command += QString("ncurv=%1").arg(getNCurv());
    }
    command += "}";

    command += "{" + startState->getName() + "}";
    command += "{" + endState->getName() + "}";

    command += "{" + label->text() + "}";

    command += getNextLabelsVCCommand();

    return command;
}

QString TransitionVArc::getGraphMLParams() const
{
    QString params = "";

    if (getArcAngle() != DEF_ARC_ANGLE)
    {
        params += QString("      <data key=\"d130\">%1</data>\n")
                    .arg(getArcAngle());
    }
    if (getNCurv() != DEF_ARC_CURV)
    {
        params += QString("      <data key=\"d133\">%1</data>\n")
                    .arg(getNCurv());
    }

    return params;
}

/*
// export
QString TransitionVArc::getEPS() const
{
  QString s = "";
  
  QColor lineC;
  Qt::PenStyle lineS;
  
  int r, g, b; float rf, gf, bf;
  
  if (dimmed)
  {
    lineS = dimEdgeLineStyle;
    lineC = dimEdgeLineColor;
  }
  else
  {
    lineS = edgeLineStyle;
    lineC = edgeLineColor;
  }
  
  lineC.getRgb(&r,&g,&b);
  rf = r / 255.; gf = g / 255.; bf = b / 255.;
  // % r g b width x0 y0 x1 y1 x2 y2 x y trVArc
  s += trLineStyle(lineS);
  s += QString(" %1 %2 %3 %4 %5 %6 %7 %8 %9 %10 %11 %12 trVArc\n")
         .arg(rf).arg(gf).arg(bf)
         .arg(m_lineWidth)
         .arg(a_point.x()).arg(scene()->height()-2 - a_point.y())
         .arg(b_point.x()).arg(scene()->height()-2 - b_point.y())
         .arg(endPoint.x()).arg(scene()->height()-2 - endPoint.y())
         .arg(startPoint.x()).arg(scene()->height()-2 - startPoint.y());
  
  s += Transition::getEPS();   // nakonec se vykresli label
  
  return s;
}
*/
