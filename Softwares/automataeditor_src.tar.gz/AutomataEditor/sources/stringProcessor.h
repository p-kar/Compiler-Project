#ifndef STRING_PROCESSOR_H_46554745872
#define STRING_PROCESSOR_H_46554745872

class Editor;
class LabelX;

class QString;
class QChar;
class QPointF;
class QPainter;
class QFont;
class QFontMetrics;
class QGraphicsView;
class QLineEdit;
class QTimer;
class QStringList;
class QCheckBox;

#include <QDialog>
#include <QPair>
#include <QtDebug>
#include <exception>

class StringProcessorException : public std::exception
{
public:
    StringProcessorException(const QString &what = "") : m_what(what) {}

    virtual ~StringProcessorException() throw() {}

    virtual const char* what() const throw()
    {
        return m_what.toStdString().c_str();
    }
    
protected:
    QString m_what;
};

class StringProcessorBraceMatchException : public StringProcessorException
{
public:
    virtual ~StringProcessorBraceMatchException() throw() {}

    virtual const char * what() const throw()
    {
        return "Matching braces failed - too many '}' found.";
    }
};

class StringProcessor
{
public:
    //! determines if change is needed
    enum EChangeType { eStringToChar = 0,   //!< image is in string2CharMap
                       eNoChange };         //!< no change needed or implemented

    //! list of fonts
    enum EFont { eNormalFont = 0,
                 eSymbolFont };
    
    //! according to LaTeX
    enum EFontSize { eTextStyle = 0,
                     eDisplayStyle,
                     eScriptStyle,
                     eScriptScriptStyle };

    //! list of symbol modifiers
    enum EModifier { eBar = 0,
                     eUnderline,
                     eOverline,
                     eNoModifier };

    struct CharacterInfo
    {
        EChangeType changeType;             //!< type of change to do
        int         textIdx;                //!< idx to original string, where change starts
        QString     character;              //!< character to be used
        EFontSize   fontSize;               //!< font size changer
        EModifier   modifier;               //!< symbol modifier
        
        explicit CharacterInfo(EChangeType type, int idx, const QString &ch, 
                               EFontSize size, EModifier mod);
    };
    
    typedef QList<CharacterInfo>        TCharacterList;

    StringProcessor(const QString& text = "", int fontSize = 0);    
    
    bool setText(const QString& text);
    const QString& text() const {return m_text;}

    //! Related to eTextStyle.
    //! \sa EFontSize
    void setFontSize(int fontSize);
    int getWidth() const { return m_width; }
    int getHeight() const;
    int getDescent() const;
    int getAscent() const;

    // TODO: should be moved to LabelX class? StringProcessor shouldn't draw ...
    //! Draw text using painter, final position will be stored to point, 
    //! so it is possible to append next drawing next to drawed text
    void drawText(QPainter *painter, QPointF& point) const;

    //! Checks if given symbol matches with keyword regex.
    static bool         isSpecialSymbol(const QString &symb);    
    //! Convert symbol to single character and get font info for printing out.
    static QString      getSymbolPrintInfo(const QString &symb, QString &fontFamily);
    //! Parse symbols to list (each character as one string).
    static QStringList  parseSymbols(const QString &input);
    //! Parse symbols to list.
    static QStringList  parseSymbols(const TCharacterList &characterList);
    
    //! Returns character list parsed from input text.
    QStringList getCharacters() const;
    
    //! Process input string to TCharacterList
    static TCharacterList computeCharacterList(const QString &input);
    
    //! Returns character list computed for current instance of SP.
    TCharacterList getCharacterList() const;
    
    static const QRegExp        keywordRegex;
    static const QRegExp        specCharacterRegex;
    static const QRegExp        whitespaceRegex;
    static const QRegExp        escapedCharacterRegex;
    
#ifdef USE_UNKNOWN_CONVENTION
    static const QChar          unknownCharacter;
    static const QString        unknownString;
#endif
    
#ifdef STRING_PROCESSOR_TEST
    static void runTest();    
#endif
    
protected:
    typedef QPair<QChar, EFont>         TCharPair;
    typedef QMap<QString, TCharPair>    TString2CharMap;    
    typedef QList<QFont>                TFontList;    
    typedef QList<QFontMetrics>         TMetricsList;
    typedef QMap<QString, int>          TString2KwTypeMap;
    
    enum EKeywordType { eString2Char = 0,
                        eFontSize,
                        eModifier };
    
    static void initialize();
    static void addToMaps(const QString &str, const TCharPair &charPair);
    void processText();
    void fillFontLists();
    void computeMetrics();

    //! Runs computeCharacterList on text inside balanced '{', '}'
    static TCharacterList computeCharacterListInBlock
        (const QString &input, int &startIdx, EFontSize fs, EModifier m);
    static TCharacterList computeCharacterList
        (const QString &input, int &startIdx, EFontSize fs, EModifier m, bool useModifierOnce = false);
        
    static bool parseFontSize
        (const QString &symb, EFontSize &fontSize);
    static bool parseModifier
        (const QString &symb, EModifier &modifier);
            
    //! Updates given font according to given charcter, returns true if font was changed
    bool updateFont(QFont &font, const CharacterInfo &c) const;

    static TString2KwTypeMap string2KwTypeMap;    

    //! First in pair is required character, second is index to fontList
    static TString2CharMap      string2CharMap;
    static const QStringList    fontFamilyList;
    
    TFontList    m_fontList;    //!< index 0 (== eNormalFont) is standard font used in editor
                                //!< index 1 (== eSymbolFont) is font Symbol

    TMetricsList m_metricsList;
    
    //! List of parsed characters
    TCharacterList m_characterList;

    QString m_text;
    int     m_fontSize;
    int     m_width;
    int     m_height;       //!< max height in parsed m_text
    int     m_ascent;       //!< max ascent in parsed m_text
    int     m_descent;      //!< max descentf in parsed m_text
};

class LabelSyntaxChecker;

#if !defined(QT_NO_DEBUG_OUTPUT)
	QDebug operator<<(QDebug dbg, const StringProcessor::CharacterInfo &c);
#endif

class StringProcessorTestDialog : public QDialog
{
    Q_OBJECT
public:    

protected:
#ifdef STRING_PROCESSOR_TEST
    friend void StringProcessor::runTest();
    StringProcessorTestDialog(QWidget* parent = 0);
    ~StringProcessorTestDialog();
#endif

    QLineEdit           *m_edtText;
    QGraphicsView       *m_view;
    LabelX              *m_label;
    QCheckBox           *m_checkTimer;
    QCheckBox           *m_checkSyntax;
    QTimer              *m_timer;
    int                 m_idx;
    QStringList         m_greekList;
    LabelSyntaxChecker  *m_syntaxChecker;

protected slots:
#ifdef STRING_PROCESSOR_TEST
    void changeText();
    void timerChange(int);
    void timerEvent();
#endif
};

#endif //STRING_PROCESSOR_H_46554745872
