#include "constants.h"

#include "state.h"
#include "mainwindow.h"
#include "editor.h"
#include "transition.h"
#include "stringProcessor.h"
#include "transforms.h"

#include <QPoint> 
#include <QPointF>
#include <QRect>
#include <QRectF>
#include <QGraphicsView>
#include <QGraphicsSceneMouseEvent>
#include <QColor>

#include <QTextStream>

// debug
#include <QtDebug>

//<-- State ------------------------------------------------------------------

State::State(const QPoint &position, Editor *parent, const QString l,
             const QString n, bool dBorder, bool dim)
  : editor(parent), name(n), label(l), dimmed(dim), doubleBorder(dBorder), checked(false),
    checkedColor(QColor(CheckedColor::r, CheckedColor::g, CheckedColor::b, CheckedColor::a)),
    m_marked(false), m_otherMoved(false)
{
    this->setZValue(Z_STATE);
    this->setPos(position);
    setFlag(QGraphicsItem::ItemIsMovable, true);
    setFlag(QGraphicsItem::ItemIsSelectable, true);

// due to undesirable change in Qt 4.6, this flat should be enabled by defaut, but it isn't
#if QT_VERSION >= 0x040600
    setFlag(QGraphicsItem::ItemSendsGeometryChanges);
    setFlag(QGraphicsItem::ItemSendsScenePositionChanges);
#endif

    // editor's values are determinate
    stateLineStyle = editor->stateLineStyle;
    stateLineWidth = 1;
    stateLineColor = editor->stateLineColor; 
    stateLabelColor = editor->stateLabelColor;
    stateLabelScale = 1;
    stateFillStatus = editor->stateFillStatus;
    stateFillColor = editor->stateFillColor;

    // state parametres preset
    stateLineDoubleCoef = editor->stateLineDoubleCoef; //DEF_STATE_LINE_DBL_COEF;
    stateLineDoubleSep = editor->stateLineDoubleSep; //DEF_STATE_LINE_DBL_SEP;

    // state parametres dimmed
    dimStateLineStyle = editor->dimStateLineStyle; //DEF_DIM_LINE_STYLE;
    dimStateLineColor = editor->dimStateLineColor; //DEF_DIM_COLOR;
    dimStateLineCoef = editor->dimStateLineCoef; //DEF_DIM_STATE_LINE_COEF;
    dimStateLabelColor = editor->dimStateLabelColor; //DEF_DIM_COLOR;
    dimStateFillColor = editor->dimStateFillColor; //DEF_DIM_FILL_COLOR;    

    stateLabelSize = (int) (STATE_LABEL_SIZE * editor->stateLabelScale * stateLabelScale);
    m_lineWidth = editor->stateLineWidth * STATE_LINE_VIEW_COEF;

    if (dimmed)
        m_lineWidth *= dimStateLineCoef;
    else
        m_lineWidth *= stateLineWidth;
    
    stringProcessor = new StringProcessor(label, stateLabelSize);
}

State::~State()
{
    delete stringProcessor;
    deleteTransitions();
    DBGLOG("called");
}

QPolygonF State::getMyPolygon() const
{
    return myPolygon;
}

bool State::getVCParams(QTextStream &out, StatePrevParams &prevParams){
    bool stChanged = false;
    if (!dimmed)
    {
        if (stateLineStyle != prevParams.stateLineStyle)
        {
            prevParams.stateLineStyle = stateLineStyle;
            stChanged = true;
            if (stateLineStyle != editor->stateLineStyle)
            {
                out << endl << "\\ChgStateLineStyle{";
                out << trLineStyle(stateLineStyle);
                out << "}";
            }
            else
            {
                out << endl << "\\RstStateLineStyle";
            } 
        }

        if (stateLineWidth != prevParams.stateLineWidth)
        {
            stChanged = true;
            prevParams.stateLineWidth = stateLineWidth;
            if (stateLineWidth != 1)
                out << endl << "\\ChgStateLineWidth{" << stateLineWidth << "}";
            else
                out << endl << "\\RstStateLineWidth";
        }
    
        if (stateLineColor != prevParams.stateLineColor)
        {
            stChanged = true;
            prevParams.stateLineColor = stateLineColor;
            if (stateLineColor != editor->stateLineColor)
                out << endl << "\\ChgStateLineColor{" << stateLineColor.toLower() << "}";
            else
                out << endl << "\\RstStateLineColor";
        }
    
        if (stateLabelColor != prevParams.stateLabelColor)
        {
            stChanged = true;
            prevParams.stateLabelColor = stateLabelColor;
            if (stateLabelColor != editor->stateLabelColor)
                out << endl << "\\ChgStateLabelColor{" << stateLabelColor.toLower() << "}";
            else
                out << endl << "\\RstStateLabelColor";
        }

        if (stateLabelScale != prevParams.stateLabelScale)
        {
            stChanged = true;
            prevParams.stateLabelScale = stateLabelScale;
            if (stateLabelScale != 1)
                out << endl << "\\ChgStateLabelScale{" << stateLabelScale << "}";
            else
                out << endl << "\\RstStateLabelScale";
        }

        if (stateFillStatus != prevParams.stateFillStatus)
        {
            stChanged = true;
            prevParams.stateFillStatus = stateFillStatus;
            if (stateFillStatus != editor->stateFillStatus)
                out << endl << "\\ChgStateFillStatus{" << trFillStatus(stateFillStatus) << "}"; 
            else
                out << endl << "\\RstStateFillStatus";
        }

        if (stateFillColor != prevParams.stateFillColor)
        {
            stChanged = true;
            prevParams.stateFillColor = stateFillColor;
            if (stateFillColor != editor->stateFillColor)
                out << endl << "\\ChgStateFillColor{" << stateFillColor.toLower() << "}"; 
            else
                out << endl << "\\RstStateFillColor";
        } 
    } // if (!dimmed)
    else 
    {
        if (dimStateLineStyle != prevParams.dimStateLineStyle ||
            dimStateLineColor != prevParams.dimStateLineColor ||
            dimStateLineCoef != prevParams.dimStateLineCoef ||
            dimStateLabelColor != prevParams.dimStateLabelColor ||
            dimStateFillColor != prevParams.dimStateFillColor)
        {
            stChanged = true;
            prevParams.dimStateLineStyle = dimStateLineStyle;
            prevParams.dimStateLineColor = dimStateLineColor;
            prevParams.dimStateLineCoef = dimStateLineCoef;
            prevParams.dimStateLabelColor = dimStateLabelColor;
            prevParams.dimStateFillColor = dimStateFillColor;
            out << endl <<"\\FixDimState{" << trLineStyle(dimStateLineStyle) << "}"
                                       "{" << dimStateLineColor.toLower() << "}"
                                       "{" << dimStateLineCoef << "}"
                                       "{" << dimStateLabelColor.toLower() << "}"
                                       "{" << dimStateFillColor.toLower() << "}";
        }
    }
  
    if (doubleBorder)
    {
        if (stateLineDoubleCoef != prevParams.stateLineDoubleCoef ||
            stateLineDoubleSep != prevParams.stateLineDoubleSep)
        {
            stChanged = true;
            prevParams.stateLineDoubleCoef = stateLineDoubleCoef;
            prevParams.stateLineDoubleSep = stateLineDoubleSep;
            out << endl << "\\FixStateLineDouble{" << stateLineDoubleCoef << "}"
                                               "{" << stateLineDoubleSep << "}";
        }
    }
  
    if (stChanged) out << endl;
    return stChanged;
}

QString State::getVCCommand() const
{
    QString command = "";

    QPointF s_pos = editor->mapToGrid(pos());
    command = "\\" + getTypeName();
    if (getLabel() != "") command += "[" + getLabel() + "]";
    command += QString("{(%1,%2)}{%3}")
                    .arg(s_pos.x())
                    .arg(s_pos.y())
                    .arg(getName());    

    return command;
}

void State::addTransition(Transition *transition)
{
    if (transitionList.contains(transition))
        RELLOG("transition is currently assigned!!!");
    else
        transitionList << transition;
}

void State::removeTransition(Transition *transition)
{  
    int i = transitionList.indexOf(transition);
    if (i != -1) transitionList.removeAt(i);
}

void State::deleteTransitions()
{
    Transition *tr;
    while (!transitionList.isEmpty())
    {
        tr = transitionList.takeFirst();
        tr->unassign();
        delete tr;
    }
}

void State::setLabel(const QString &l)
{
    prepareGeometryChange();
    label = l;
    stringProcessor->setText(label);
}

void State::setName(const QString &n)
{
    name = n;
}

void State::setDoubleBorder(bool db)
{
    if (doubleBorder == db) return;
    
    prepareGeometryChange();
    
    doubleBorder = db;

    updateMyPolygon();
}

void State::setDimmed(bool dim)
{
    if (dimmed == dim) return;

    dimmed = dim;

    if (dimmed)
        m_lineWidth = m_lineWidth * dimStateLineCoef/stateLineWidth;
    else
        m_lineWidth = m_lineWidth * stateLineWidth/dimStateLineCoef;

    updateMyPolygon();
}

void State::setAutoNammed(bool aN)
{
    autoNammed = aN;
}

QRectF State::boundingRect() const
{
    int width = getWidth() > getTextWidth() ? getWidth() : getTextWidth();
    int height = getHeight() > getTextHeight() ? getHeight() : getTextHeight();    
    
    QRectF ellipseRect(-width/2, -height/2, width, height);
    float adjust;

    if (doubleBorder)
    {
        float doubleLineSep = m_lineWidth * stateLineDoubleSep / STATE_LINE_VIEW_COEF; // w/o correction
        float doubleLineWidth = m_lineWidth * stateLineDoubleCoef * STATE_DOUBLE_LINE_VIEW_COEF;
        adjust = doubleLineSep + doubleLineWidth*1.5 + 2;
    }
    else
    {
        adjust = m_lineWidth/2 + 2;
    }

    return ellipseRect.adjusted(-adjust, -adjust,
                                 adjust,  adjust);
}

void State::paintSelectionDecoration(QPainter *painter)
{
    if (isSelected())
    {
        const QColor selectedColor(SelectedColor::r,SelectedColor::g,
                                   SelectedColor::b, SelectedColor::a);
        painter->setPen(QPen(selectedColor,1,Qt::DashLine));
        painter->setBrush(Qt::NoBrush);
        painter->drawRect(boundingRect().adjusted(2,2,-2,-2));
    }
}

void State::setChecked(bool checked)
{
    if (this->checked ==  checked) return;
    DBGLOG_ME(DBGPAR(checked));
    this->checked = checked;
    update();
}

QVariant State::itemChange(GraphicsItemChange change, const QVariant &value)
{
    switch (change) 
    {
        case ItemPositionHasChanged:  // update transitions
            adjustTransitions();
            break;
        default:
            break;
    }
    
    return QGraphicsItem::itemChange(change, value);
}

void State::adjustTransitions()
{
    foreach(Transition *tr, transitionList)
    {
        tr->adjust();
    }
}

void State::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    DBGLOG_ME("called," <<  "pos=" << event->pos());
    m_lastMouseClickType = eMouseNoClick;
    setChecked();

    if (editor->getAction() == Editor::eSelection &&
        event->button() == Qt::LeftButton)
    {
        DBGLOG_ME("cursor=ClosedHandCursor");
        editor->setCursor(Qt::ClosedHandCursor);
    }

    if(event->button() == Qt::RightButton)
    {        
        m_lastMouseClickType = eMouseRightClick;
    }
    else if (event->button() == Qt::LeftButton)
    {        
        m_lastMouseClickType = eMouseLeftClick;
        oldPos = pos(); // original position
    }    
    else if (event->button() == Qt::MidButton)
    {
        m_lastMouseClickType = eMouseMiddleClick;
    }
    else
        event->ignore();
}

void State::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{    
    DBGLOG_ME("called");
    if (event->button() == Qt::LeftButton && m_lastMouseClickType == eMouseMove)
    {           
        if (oldPos != pos())
        {            
            editor->stateMoved(this, oldPos);
        }
        setChecked(false);
    }
    else if ((m_lastMouseClickType == eMouseLeftClick && editor->getAction() == Editor::eInsertTransition) ||
             (m_lastMouseClickType == eMouseMiddleClick &&
                (editor->getAction() == Editor::eSelection || editor->getAction() == Editor::eInsertState)))
    {
        editor->setSelectedState(this);
        editor->insertTransition();
    }
    else if (m_lastMouseClickType == eMouseRightClick)
    {
        editor->showPopup(this);        
    }
    else if (m_lastMouseClickType == eMouseDoubleClick)
    {
        editor->editState(this);
        setChecked(false);
    }    
    else
    {
        setChecked(false);
    }
}

void State::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event)
{
    DBGLOG_ME("called");
    if (event->button() == Qt::LeftButton && editor->getAction() == Editor::eSelection)
    {
        m_lastMouseClickType = eMouseDoubleClick;
        setChecked();             
    }
}

void State::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    Q_ASSERT(event != NULL);    

    if (editor->getAction() != Editor::eSelection)
        return;

    if (m_lastMouseClickType != eMouseLeftClick && m_lastMouseClickType != eMouseMove)
        return;

    m_lastMouseClickType = eMouseMove;

    QPointF g_pos = event->scenePos(); 

    QPointF e_pos = mapFromScene(g_pos);

    prepareGeometryChange();

    QPointF movePoint(0,0);

    if (!editor->snapped())
    {
        movePoint = e_pos;
    }
    else
    {
        editor->itemAlignToGrid(this);
        
        // move only when change is greather than half of grid step
        if (e_pos.toPoint().x() > (GRID_STEP / 2))
        {
            movePoint = QPoint(GRID_STEP, 0);
        } 
        else if (e_pos.toPoint().x() < (-GRID_STEP / 2))
        {
            movePoint = QPoint(-GRID_STEP, 0);
        }
        if(e_pos.toPoint().y() > (GRID_STEP / 2))
        {
            movePoint = QPoint(0, GRID_STEP);
        }
        else if(e_pos.toPoint().y() < (-GRID_STEP / 2))
        {
            movePoint = QPoint(0,-GRID_STEP);
        }
    }

    moveBy(movePoint.x(), movePoint.y());
}

void State::setStateLabelScale(float labelScale)
{
    if (stateLabelScale == labelScale) return;

    prepareGeometryChange();
    stateLabelSize = (int) (stateLabelSize * labelScale/stateLabelScale);
    stateLabelScale = labelScale;
    stringProcessor->setFontSize(stateLabelSize);
    updateMyPolygon();
}

void State::setStateLineWidth(float lineWidth)
{
    if (stateLineWidth == lineWidth) return;

    prepareGeometryChange();
    
    if (!dimmed)
        m_lineWidth = m_lineWidth * lineWidth/stateLineWidth;    
    stateLineWidth = lineWidth;
    
    if (!dimmed)
        updateMyPolygon();
}

void State::setDimStateLineCoef(float lineCoef)
{
    if (dimStateLineCoef  == lineCoef) return;

    prepareGeometryChange();
    
    if (dimmed)
        m_lineWidth = m_lineWidth * lineCoef/dimStateLineCoef;
    dimStateLineCoef = lineCoef;

    if (dimmed)
        updateMyPolygon();
}

void State::setStateLineDoubleCoef(float lineCoef)
{
    if (stateLineDoubleCoef == lineCoef) return;
    
    prepareGeometryChange();

    stateLineDoubleCoef = lineCoef;

    if (doubleBorder)
        updateMyPolygon();
}

void State::setStateLineDoubleSep(float lineSep)
{
    if (stateLineDoubleSep == lineSep) return;

    prepareGeometryChange();

    stateLineDoubleSep = lineSep;

    if (doubleBorder)
        updateMyPolygon();
}

void State::setMarked(bool marked)
{
    prepareGeometryChange();
    
    if (m_marked == marked) return;
        
    m_marked = marked;
        
    if (m_marked)
    {
        if (isDimmed())
        {
            m_origColor = dimStateFillColor;
            dimStateFillColor = toMarkerColor(dimStateFillColor);
        }
        else
        {
            m_origColor = stateFillColor;
            stateFillColor = toMarkerColor(stateFillColor);
        }
    }
    else
    {
        if (isDimmed())
        {
            dimStateFillColor = m_origColor;
        }
        else
        {
            stateFillColor = m_origColor;
        }
    }
}

bool State::isInitial() const
{
    foreach(const Transition *tr, transitionList)
    {
        if (tr->getTypeName() == "Initial")
        {
            return true;
        }
    }

    return false;
}

bool State::isFinal() const
{
    if (doubleBorder) return true;

    foreach(const Transition *tr, transitionList)
    {
        if (tr->getTypeName() == "Final")
        {
            return true;
        }
    }

    return false;
}

QList<Transition*> State::getOutgoingTransitions() const
{
    QList<Transition*> transitions;

    foreach(Transition *tr, transitionList)
    {
        if (tr->getStartState() == this &&
            tr->getTypeName() != "Initial" && tr->getTypeName() != "Final")
        {
            transitions << tr;
        }
    }

    return transitions;
}

//! only for BFS - finding automata, so orientation of transition is skipped
QList<State*> State::getAccessibleStates() const
{
    QList<State*> accessibleStates;

    foreach(Transition *tr, transitionList)
    {
        if (tr->getStartState() == this && tr->getEndState() != NULL)
        {
            accessibleStates << tr->getEndState();
        }        
        else
        {
            accessibleStates << tr->getStartState(); // ever ok
        }
    }

    return accessibleStates;
}

//------------------------------------------------------------------ State -->
