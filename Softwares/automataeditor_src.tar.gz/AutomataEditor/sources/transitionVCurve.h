#ifndef _TRANSITIONVCURVE_H_2523452656797_
#define _TRANSITIONVCURVE_H_2523452656797_

#include "twoStatesTransition.h"

class TransitionVCurve : public TwoStatesTransition
{
public: 
    TransitionVCurve(Editor *parent, State *ss, State *es, const QString &label, 
                     bool leftOriented, bool dimmed);
                    // leftOriented only due to bug in VauCanSon
  virtual ~TransitionVCurve();
  
  virtual void adjust();
  virtual void setLabelPosition();
    
  virtual QString getTypeName() const;

  virtual void setArcAngle(int aa){arcangle = aa;}
  virtual void setArcAngleB(int aaB){arcangleB = aaB;}
  virtual void setNCurv(float nc){ncurv = nc;}
  virtual int getArcAngle() const { return arcangle; }
  virtual int getArcAngleB() const { return arcangleB; }
  virtual float getNCurv() const { return ncurv; }

  virtual QString getVCCommand() const;
  virtual QString getGraphMLParams() const;
  //virtual QString getEPS() const;
  
protected:
  //void paint(QPainter * painter, const QStyleOptionGraphicsItem * option, QWidget * widget = 0);
  
private:
  bool radius; // if true, angle is 15 degrees, otherwise 30 degrees
  
  QLineF text_v; // label vector
  
  int arcangle;
  int arcangleB;
  float ncurv;
  
  //float r; // radius of arc
  //float startAngle;
  //float endAngle;
  
  // TODO: make possible to move with them using mouse
  QPointF a_point; // point for curve contruction
  QPointF b_point;
};

#endif //_TRANSITIONVCURVE_H_2523452656797_
