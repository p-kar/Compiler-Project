#ifndef TRANSITION_H_21234567890987654
#define TRANSITION_H_21234567890987654

#include "editor.h"
#include "stringProcessor.h"
#include "labelSyntaxChecker.h"

#include "itransition.h"

#include <QGraphicsItem>

class State;
class QTextStream;
class QPolygonF;
class QPointF;
class LabelX;

struct EdgePrevParams{
    Qt::PenStyle edgeLineStyle;
    float edgeLineWidth;
    QString edgeLineColor;
    QString edgeLabelColor;
    float edgeLabelScale;
    bool edgeLineDblStatus;

    float edgeLineBorderCoef;
    QString edgeLineBorderColor;
    float edgeLineDblCoef;
    float edgeLineDblSep;

    Qt::PenStyle dimEdgeLineStyle;
    QString dimEdgeLineColor;
    float dimEdgeLineCoef;
    QString dimEdgeLabelColor; 
};

class Transition : public QGraphicsItem
{
public:
    typedef QList<LabelX *> TLabelXList;

    Transition(Editor *parent, State *ss, State *es, bool dimmed);
    virtual ~Transition();

    friend class Parser;
    friend class TransitionExtendedDialog;
    friend class NextLabelsDialog;
    friend class TransitionEditWithDelCommand;
    friend class TransitionEditExtendedCommand;
    friend class TransitionStyleChangeCommand;
    friend struct TransitionSerializer;
    friend void Editor::exportToGraphML(const QString &fn);

    QString getLabelText() const;
    void setLabelText(const QString &label);
    virtual void setLabelPosition();
    virtual void setLabelPosition(LabelX *pLabel, float pos, bool isLeft, int width, int height);    

    LabelX *getLabel() const;
    const TLabelXList& getNextLabels() const { return nextLabels; } //! ??? Check return type correctness!!!
    
    void setLabelPos(float pos);
    float getLabelPos() const;

    QColor getColor() { return dimmed ? QColor(dimEdgeLineColor) : QColor(edgeLineColor); }
    QColor getLabelColor() { return dimmed ? QColor(dimEdgeLabelColor) : QColor(edgeLabelColor); }

    void addNextLabel(LabelX *pLabel);
    void removeNextLabel(LabelX *pLabel);

    virtual void adjust() = 0; //!< The only method where graphics changes are computed

    //! Return path mapped to scene
    virtual QPainterPath path() const { return p; }
    
    virtual QRectF boundingRect() const;
    virtual QPainterPath shape() const;
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    virtual void paintSelectionDecoration(QPainter *painter);
    
    virtual QString getTypeName() const = 0;
    virtual QString getTypeNameSuffix() const { return ""; }

    //! Assign to all referenced states (to theirs trList)
    virtual void assign() = 0;
    virtual void unassign() = 0;

    virtual void setDirection(int){}
    virtual int getDirection() const {return 0;}

    virtual void setArcAngle(int){} //!< for VArc and VCurve
    virtual void setNCurv(float){}
    virtual int getArcAngle() const {return 0;}
    virtual float getNCurv() const {return 0;}

    // TODO: how to solve this better? don't miss TransitionSerializer!
    virtual void setArcAngleB(int){} //!< only for VCurve
    virtual int getArcAngleB() const {return 0;}    

    bool isDimmed();
    void setDimmed(bool dim);

    void setChecked(bool checked = true);
    void setSelected(bool selected = true);

    State* getStartState() const { return startState; }
    virtual State* getEndState() const { if (endState) return endState; else return 0; }

    //! Pay attention to Loop - doesn't have end state, but getEndState() returns startState due to automaton sence
    bool hasEndState() const { if (endState) return true; else return false; }

    QString getStartStateName()  const;
    QString getEndStateName() const;

    //! \note Neded too if state type is changed
    void setStartState(State *state);
    void setEndState(State *state);

    Editor * getEditor() const { return editor; }

    // for export
    bool getVCParams(QTextStream &out, EdgePrevParams &prevParams) const; //!< VauCanSon-G params
    virtual QString getNextLabelsVCCommand() const;

    virtual QString getVCCommand() const = 0; //!< VauCanSon-G transition command
    
    // TODO: divide to subtypes (solve better)
    virtual QString getGraphMLParams() const { return ""; } //!< GraphML export

    //virtual QString getEPS() const = 0;
    
    void setEdgeLabelScale(float labelScale);
    void setDimEdgeLineCoef(float lineCoef);
    void setEdgeLineWidth(float lineWidth);

protected:
    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event);
    virtual void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) = 0;
    virtual void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event);

    enum EIntersectionFindMethod {eFIND_FIRST, eFIND_TWO, eFIND_ALL};

    //virtual void makeAreas(const QPainterPath &p); //!< updates click and selection areas
    void  createStrokes(const QPainterPath &path);
    const QPainterPath& getClickPath() const;
    const QPainterPath& getSelectionPath() const;

    QPainterPath createShape(const QPainterPath &path, int bounds) const;

    QPainterPath m_clickPath; //!< holds area for mouse click
    QPainterPath m_selectionPath; //!< holds area showed when item is selected
    
    static QPolygonF findIntersectedPoints(const QPolygonF &curve, const QPolygonF &polygon,
                                           const EIntersectionFindMethod method);    
    
    //! Sincle transition path starts in circuit of state, only path is need
    //! This computes arrow points from anlge of last part of transition
    QPolygonF getArrowPolygon(const QPainterPath &path);
    QPolygonF m_arrowPoints; //!< default transition arrow, angle 0 degrees, pointing to point 0,0

    Editor *editor;

    State *startState, *endState;
    QPointF startPoint, endPoint;

    int m_labelFontSize;
    LabelX *label;

    //! next labels (command \LabelL, \LabelR) - stored as pair item + isLeft
    TLabelXList nextLabels;    

    QPolygonF pa;   //!< arrow polygon -> transformed and rotatted m_arrowPoints
    QPainterPath p; //!< path of transition

    bool dimmed;
    bool leftOriented;

    //! \name edge parameters
    //! \{
    Qt::PenStyle edgeLineStyle;
    float edgeLineWidth;
    QString edgeLineColor;
    QString edgeLabelColor;
    float edgeLabelScale;
    bool edgeLineDblStatus;
    //! \}

    //! \name transition parameters preset
    //! \{
    float edgeLineBorderCoef;
    QString edgeLineBorderColor;    

    float edgeLineDblCoef;
    float edgeLineDblSep;
    //! \}

    //! \name transition parameters dimmed
    //! \{
    Qt::PenStyle dimEdgeLineStyle;
    QString dimEdgeLineColor;
    float dimEdgeLineCoef;
    QString dimEdgeLabelColor;
    //! \}

    float m_lineWidth;

    bool checked; //!< coloring when selected
    const QColor checkedColor;

    EMouseClick m_lastMouseClickType;

    //! \name Support methods for ITransition
    //! \{
public:
    QString getSourceState() const;
    QString getDestinationState() const;
   
    //! Returns all character occurences, supposed to be inspected to find alphabet and epsilon symbol.
    //! Used when automata setting detection is required.
    //! \sa Editor::getAutomata()
    void getCharactersOccurences(ITransition::TCharSet &characters) const;  // out
  
    //! Returns character on which transition passes.
    bool getCharacters(ITransition::TCharSet &characters,               // out
                       const ITransition::TCharSet &alphabet,           // in
                       const QString &alphabetSymbol,                   // in
                       const QString &epsilonSymbol) const;             // in

protected:
    void showErrorReport(const QString &reportText = QString("")) const;

    //! Dismembers characters (found specific smybols and fill occurences param).
    void dismemberCharacters(const QStringList &occurences,             // in
                             ITransition::TCharSet &characters) const;  // out                             
    //! \}
};

#endif //TRANSITION_H_21234567890987654
