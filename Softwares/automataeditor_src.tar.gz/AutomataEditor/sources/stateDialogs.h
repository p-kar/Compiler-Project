#ifndef _STATEDIALOGS_H_4314235325_
#define _STATEDIALOGS_H_4314235325_

#include <QDialog>

class QLineEdit;
class QCheckBox;
class QComboBox;
class Editor;
class State;

class NameAcceptDialog : public QDialog
{
    Q_OBJECT
public:
    NameAcceptDialog(QWidget *parent = 0);
    
protected:
    QLineEdit* edtLabel;
    QLineEdit* edtName;

    void showMessage(const QString &msg);

protected slots:
    void myAccept();
};



class StateDialog : public NameAcceptDialog
{
    Q_OBJECT
public:
    enum EMode {eAdd, eEdit};

    StateDialog(Editor *editor, const QList<QString> &typeList, EMode mode = eAdd, bool hasInitial = false, QWidget* parent = 0);

    QString getLabel() const;
    QString getName() const;
    int getType() const;
    bool isDimmed() const;
    bool isAutoNammed() const;

    bool quickInitial() const;

    void setLabel(const QString &label);
    void setName(const QString &name, bool editing = true);
    void setType(int type);
    void setDimmed(bool dim);
    void setAutoNammed(bool aN);

protected:
    bool nameBraceMatch();
    
    QCheckBox* checkAutoName;
    QComboBox* comboType;
    QCheckBox* checkDimmed;
    QCheckBox* checkQuickInitial;
    
    Editor *editor;
    QString currentStateName;
    
protected slots:
    void changeAutoName();
    void testAccept();
};



class StateExtendedDialog: public QDialog{
  Q_OBJECT
public:
    StateExtendedDialog(QWidget *parent = 0);

    void setParams(State *state);

    Qt::PenStyle getLineStyle();
    float getLineWidth();
    QString getLineColor();
    QString getLabelColor();
    float getLabelScale();
    Qt::BrushStyle getFillStatus();
    QString getFillColor();

    Qt::PenStyle getDimLineStyle();
    QString getDimLineColor();
    float getDimLineCoef();
    QString getDimLabelColor();
    QString getDimFillColor();

    float getLineDblCoef();
    float getLineDblSep();
  
protected:
    // adjusted
    QComboBox *comboLineStyle;
    QLineEdit *edtLineWidth;
    QLineEdit *edtLineColor;
    QLineEdit *edtLabelColor;
    QLineEdit *edtLabelScale;
    QComboBox *comboFillStatus;
    QLineEdit *edtFillColor;
    // preset
    QComboBox *comboDimLineStyle;
    QLineEdit *edtDimLineColor;
    QLineEdit *edtDimLineCoef;
    QLineEdit *edtDimLabelColor;
    QLineEdit *edtDimFillColor;
    // double
    QLineEdit *edtLineDblCoef;
    QLineEdit *edtLineDblSep;
};

#endif //_STATEDIALOGS_H_4314235325_
