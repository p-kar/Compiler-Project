#ifndef _TRANSITIONINITIAL_H_987765215760_
#define _TRANSITIONINITIAL_H_987765215760_

#include "oneStateTransition.h"

class TransitionSELine : public OneStateTransition
{
public:
    TransitionSELine(Editor *parent, State *state, bool start, int direction, bool dimmed);
    virtual ~TransitionSELine();

    virtual void adjust();
        
    virtual QString getTypeName() const;

    virtual void setDirection(int d);
    virtual int getDirection() const;

    virtual QString getVCCommand() const;

    //virtual QString getEPS() const;    
protected:
    //void paint (QPainter * painter, const QStyleOptionGraphicsItem * option, QWidget * widget = 0);
    void setRotation();
    bool starting;
    int direction;
    QLineF line;
};


#endif //_TRANSITIONINITIAL_H_987765215760_
