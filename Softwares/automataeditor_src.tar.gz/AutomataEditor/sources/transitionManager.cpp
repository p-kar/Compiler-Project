#include "constants.h"

#include "transitionManager.h"
#include "editor.h"
#include "state.h"
#include "transition.h"
#include "oneStateTransition.h"
#include "twoStatesTransition.h"
#include "transitionDialogs.h"
#include "transitionLoop.h"
#include "transitionInitialFinal.h"
#include "transitionLine.h"
#include "transitionArc.h"
#include "transitionVArc.h"
#include "transitionVCurve.h"

bool TransitionManager::instantiated = false;
TransitionManager* TransitionManager::manager = NULL;

TransitionManager::TransitionManager()
{    
    oneStateTransitionTypeList <<
        "Loop" << "CLoop" << "LoopVar" << "Initial" << "Final";
    int i = 0;    
    typeNameToOneStateInstanceMap[oneStateTransitionTypeList[i++]] =
        &TransitionManager::createTransitionLoop;    
    typeNameToOneStateInstanceMap[oneStateTransitionTypeList[i++]] =
        &TransitionManager::createTransitionCLoop;
    typeNameToOneStateInstanceMap[oneStateTransitionTypeList[i++]] =
        &TransitionManager::createTransitionLoopVar;
    typeNameToOneStateInstanceMap[oneStateTransitionTypeList[i++]] = 
        &TransitionManager::createTransitionInitial;
    typeNameToOneStateInstanceMap[oneStateTransitionTypeList[i++]] =
        &TransitionManager::createTransitionFinal;
    i = 0; // properties
    typeNameToOneStatePropsMap[oneStateTransitionTypeList[i++]] = /*Loop*/
        OneStateTransitionProperties(true, true, DEF_LOOP_LAB_POS);
    typeNameToOneStatePropsMap[oneStateTransitionTypeList[i++]] = /*CLoop*/
        OneStateTransitionProperties(true, true, DEF_LOOP_LAB_POS);
    typeNameToOneStatePropsMap[oneStateTransitionTypeList[i++]] = /*LoopVar*/
        OneStateTransitionProperties(true,true, DEF_LOOP_LAB_POS);
    typeNameToOneStatePropsMap[oneStateTransitionTypeList[i++]] = /*Initial*/
        OneStateTransitionProperties(false, false);
    typeNameToOneStatePropsMap[oneStateTransitionTypeList[i++]] = /*Final*/
        OneStateTransitionProperties(false, false);

    
    twoStatesTransitionTypeList
        << "Edge" << "Arc" << "LArc" << "VArc" << "VCurve";
    i = 0;
    typeNameToTwoStatesInstanceMap[twoStatesTransitionTypeList[i++]] =
        &TransitionManager::createTransitionLine;
    typeNameToTwoStatesInstanceMap[twoStatesTransitionTypeList[i++]] =
        &TransitionManager::createTransitionArc;
    typeNameToTwoStatesInstanceMap[twoStatesTransitionTypeList[i++]] =
        &TransitionManager::createTransitionLArc;
    typeNameToTwoStatesInstanceMap[twoStatesTransitionTypeList[i++]] =
        &TransitionManager::createTransitionVArc;
    typeNameToTwoStatesInstanceMap[twoStatesTransitionTypeList[i++]] =
        &TransitionManager::createTransitionVCurve;
    i = 0; // properties
    typeNameToTwoStatesPropsMap[twoStatesTransitionTypeList[i++]] = /*Edge*/
        TwoStatesTransitionProperties(true, true, false, false, false,
        DEF_EDGE_LAB_POS);    
    typeNameToTwoStatesPropsMap[twoStatesTransitionTypeList[i++]] = /*Arc*/
        TwoStatesTransitionProperties(true, true, false, false, false,
        DEF_ARC_LAB_POS);
    typeNameToTwoStatesPropsMap[twoStatesTransitionTypeList[i++]] = /*LArc*/
        TwoStatesTransitionProperties(true, true, false, false, false,
        DEF_ARC_LAB_POS);
    typeNameToTwoStatesPropsMap[twoStatesTransitionTypeList[i++]] = /*VArc*/
        TwoStatesTransitionProperties(true, true, true, true, false,
        DEF_ARC_LAB_POS, DEF_ARC_ANGLE, DEF_ARC_CURV);
    typeNameToTwoStatesPropsMap[twoStatesTransitionTypeList[i++]] = /*VCurve*/
        TwoStatesTransitionProperties(true, true, true, true, true,
        DEF_ARC_LAB_POS, DEF_VCURV_ANGLE, DEF_VCURV_CURV, DEF_VCURV_ANGLE_B);
}

TransitionManager* TransitionManager::getInstance()
{
    if(!instantiated)
    {
        manager = new TransitionManager();
        instantiated = true;
        return manager;
    }
    else
    {
        return manager;
    }
}

const QList<QString>& TransitionManager::getOneStateTransitionTypeNameList() const
{
    return oneStateTransitionTypeList;
}

const QList<QString>& TransitionManager::getTwoStatesTransitionTypeNameList() const
{
    return twoStatesTransitionTypeList;
}

int TransitionManager::getTypeNameId(const QString &typeName) const
{
    Q_ASSERT(oneStateTransitionTypeList.contains(typeName)
             || twoStatesTransitionTypeList.contains(typeName));
    
    if (oneStateTransitionTypeList.contains(typeName))
        return oneStateTransitionTypeList.indexOf(typeName);
    else
        return twoStatesTransitionTypeList.indexOf(typeName);
}

const OneStateTransitionProperties& TransitionManager::
    getOneStateTransitionProperties(int typeId) const
{
    Q_ASSERT(oneStateTransitionTypeList.size() > typeId &&
             typeId >= 0);    
    TypeNameToOneStatePropsMap::const_iterator constIt =
        typeNameToOneStatePropsMap.find(oneStateTransitionTypeList[typeId]);
    Q_ASSERT(constIt != typeNameToOneStatePropsMap.end());
    return *constIt;
}

const TwoStatesTransitionProperties& TransitionManager::
    getTwoStatesTransitionProperties(int typeId) const
{
    Q_ASSERT(twoStatesTransitionTypeList.size() > typeId &&
             typeId >= 0);        
    TypeNameToTwoStatesPropsMap::const_iterator constIt =
        typeNameToTwoStatesPropsMap.find(twoStatesTransitionTypeList[typeId]);
    Q_ASSERT(constIt != typeNameToTwoStatesPropsMap.end());
    return *constIt;
}

OneStateTransition* TransitionManager::createOneStateTransition
    (Editor *editor, State *state, const TransitionLoopSEDialog& td)
{
    Q_ASSERT(oneStateTransitionTypeList.size() > td.getType() &&
             td.getType() >= 0);
    return createOneStateTransition(oneStateTransitionTypeList[td.getType()],
                editor, state, td.getLabel(), td.getDirection(), td.isDimmed());
}

OneStateTransition* TransitionManager::createOneStateTransition
    (const QString& typeName, Editor *editor, State *state, 
     const QString& label, int direction, bool dimmed)
{
    Q_ASSERT(typeNameToOneStateInstanceMap.contains(typeName));
    return (this->*(typeNameToOneStateInstanceMap[typeName]))
        (editor, state, label, direction, dimmed);
}

TwoStatesTransition* TransitionManager::createTwoStatesTransition
    (Editor *editor, State *s1, State *s2, const TransitionDialog& td)
{
    Q_ASSERT(twoStatesTransitionTypeList.size() > td.getType() &&
             td.getType() >= 0);    
    return createTwoStatesTransition(twoStatesTransitionTypeList[td.getType()],
                editor, s1, s2, td.getLabel(), td.isLeftOriented(), td.isDimmed());
}

TwoStatesTransition* TransitionManager::createTwoStatesTransition
    (const QString& typeName, Editor *editor, State* s1, State* s2, 
     const QString& label, bool leftOriented, bool dimmed)
{
    Q_ASSERT(typeNameToTwoStatesInstanceMap.contains(typeName));
    return (this->*(typeNameToTwoStatesInstanceMap[typeName]))
        (editor, s1, s2, label, leftOriented, dimmed);
}

/*-----------------------------------------------------|
 * Implementation of concrete transitoin constructors  |
 *-----------------------------------------------------V*/

OneStateTransition* TransitionManager::createTransitionInitial
    (Editor *editor, State *state, const QString &/*label*/, int direction, bool dimmed)
{
    return new TransitionSELine(editor, state, true, direction, dimmed);
}

OneStateTransition* TransitionManager::createTransitionFinal
    (Editor *editor, State *state, const QString &/*label*/, int direction, bool dimmed)
{
    return new TransitionSELine(editor, state, false, direction, dimmed);
}

OneStateTransition* TransitionManager::createTransitionLoop
    (Editor *editor, State *state, const QString &label, int direction, bool dimmed)
{
    return new TransitionLoop(editor, state, label, TransitionLoop::eLoop, dimmed, direction);
}

OneStateTransition* TransitionManager::createTransitionCLoop
    (Editor *editor, State *state, const QString &label, int direction, bool dimmed)
{
    return new TransitionLoop(editor, state, label, TransitionLoop::eCLoop, dimmed, direction);
}

OneStateTransition* TransitionManager::createTransitionLoopVar
    (Editor *editor, State *state, const QString &label, int direction, bool dimmed)
{
    return new TransitionLoop(editor, state, label, TransitionLoop::eLoopVar, dimmed, direction);
}



TwoStatesTransition* TransitionManager::createTransitionLine
    (Editor *editor, State *s1, State *s2, const QString &label, bool leftOriented, bool dimmed)
{
    return new TransitionLine(editor, s1, s2, label, leftOriented, dimmed);
}

TwoStatesTransition* TransitionManager::createTransitionArc
    (Editor *editor, State *s1, State *s2, const QString &label, bool leftOriented, bool dimmed)
{
    return new TransitionArc(editor, s1, s2, label, leftOriented, dimmed, false);
}

TwoStatesTransition* TransitionManager::createTransitionLArc
    (Editor *editor, State *s1, State *s2, const QString &label, bool leftOriented, bool dimmed)
{
    return new TransitionArc(editor, s1, s2, label, leftOriented, dimmed, true);
}

TwoStatesTransition* TransitionManager::createTransitionVArc
    (Editor *editor, State *s1, State *s2, const QString &label, bool leftOriented, bool dimmed)
{
    return new TransitionVArc(editor, s1, s2, label, leftOriented, dimmed);
}

TwoStatesTransition* TransitionManager::createTransitionVCurve
    (Editor *editor, State *s1, State *s2, const QString &label, bool leftOriented, bool dimmed)
{
    return new TransitionVCurve(editor, s1, s2, label, leftOriented, dimmed);
}
