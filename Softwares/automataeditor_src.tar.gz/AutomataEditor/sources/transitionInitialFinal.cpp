#include "constants.h"

#include "transitionInitialFinal.h"
#include "state.h"
#include "label.h"
#include "transforms.h"

#include <math.h>

#include <QtDebug>

TransitionSELine::TransitionSELine(Editor *parent, State *state, bool start, int direction, bool dimmed):
  OneStateTransition(parent,state,dimmed), starting(start), direction(direction)
{
    label = NULL;
    setZValue(Z_TRANSITION);
    setRotation();    
}

TransitionSELine::~TransitionSELine()
{
    DBGLOG("called");
}

void TransitionSELine::adjust()
{
    prepareGeometryChange();
    if (!startState)
    { 
        qWarning("TransitionSELine::adjust -> startState is not valid!");
        return;
    }
    startPoint = startState->pos();
    setPos(startPoint.x(), startPoint.y());
    
    // due to StateVar (on StateVar are not supported diagonal SELines)
    int offset = (direction == NORTH || direction == SOUTH) ? 
                    startState->getHeight() / 2 :
                    startState->getWidth() / 2;

    line = QLineF(0,-offset,0,-TR_SE_LENGTH-offset);

    QPainterPath path;
    path.moveTo(starting ? line.p2() : line.p1());
    path.lineTo(starting ? line.p1() : line.p2());
    p = path;

    pa.clear();
    QMatrix matrix;

    if (starting)
    {
        matrix.rotate(-90);
        pa = matrix.map(m_arrowPoints);
        pa.translate(0, -offset);
    }
    else
    {
        matrix.rotate(90);
        pa = matrix.map(m_arrowPoints);
        pa.translate(0,-TR_SE_LENGTH-offset);
    }
    
    setLabelPosition();
    createStrokes(p);
}

QString TransitionSELine::getTypeName() const
{
    return starting ? "Initial" : "Final";
}

void TransitionSELine::setDirection(int d)
{
    direction = d;
    setRotation();
}

int TransitionSELine::getDirection() const
{
    return direction;
}

void TransitionSELine::setRotation()
{
    resetTransform();
    switch (direction)
    {
        case NORTH:
            break;
        case SOUTH:
            rotate(180);
            break;
        case EAST:
            rotate(90);
            break;
        case WEST:
            rotate(-90);
            break;
        case NORTH_EAST:
            rotate(45);
            break;
        case NORTH_WEST:
            rotate(-45);
            break;
        case SOUTH_EAST:
            rotate(135);
            break;
        case SOUTH_WEST:
            rotate(-135);
            break;  
    }  
    adjust();
}

/*void TransitionSELine::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *){
  QColor lineC;
  Qt::PenStyle lineS;

  if (dimmed)
  {
    lineS = dimEdgeLineStyle;
    lineC = dimEdgeLineColor;
  }
  else
  {
    lineS = edgeLineStyle;
    lineC = edgeLineColor;
  }
  
  if (checked)
  {
    painter->setPen(QPen(checkedColor, m_lineWidth, lineS));
    painter->setBrush(checkedColor);
  } 
  else
  {
    painter->setPen(QPen(lineC, m_lineWidth, lineS));
    painter->setBrush(lineC);
  }
  
  painter->strokePath(p, painter->pen());
  painter->drawPolygon(pa);

  paintSelectionDecoration(painter);

#ifdef TESTING_PAINTING
#   ifdef TESTING_BOUNDING_RECT_PAINTING
        painter->setBrush(QBrush(QColor(50,255,0,100)));
        painter->fillRect(boundingRect(), painter->brush());
#   endif

    painter->setBrush(QBrush(QColor(0,0,255,150)));
    painter->fillPath(shape(), painter->brush());
#endif
}*/

QString TransitionSELine::getVCCommand() const
{
    QString command = "\\";
    
    command += getTypeName();
    
    if (getDirection() != (starting ? DEF_TR_S_DIR : DEF_TR_E_DIR))
    {
        command += "[";
        command += getTypeNameSuffix().toLower();       
        command += "]";
    }
    command += "{" + startState->getName() + "}";
    
    command += getNextLabelsVCCommand();
    
    return command;
}

/*
QString TransitionSELine::getEPS() const
{
  QString s = "";
  
  QColor lineC;
  Qt::PenStyle lineS;
  
  int r, g, b; float rf, gf, bf;
  
  if (dimmed)
  {
    lineS = dimEdgeLineStyle;
    lineC = dimEdgeLineColor;
  }
  else
  {
    lineS = edgeLineStyle;
    lineC = edgeLineColor;
  }
  
  lineC.getRgb(&r,&g,&b);
  rf = r / 255.; gf = g / 255.; bf = b / 255.;
  // r g b width lx ly mx my trLine 
  s += trLineStyle(lineS);
  
  s += QString(" %1 %2 %3 %4 %5 %6 %7 %8 trLine\n")
         .arg(rf).arg(gf).arg(bf)
         .arg(m_lineWidth)
         .arg(mapToScene(line.p2()).x()).arg(scene()->height()-2 - mapToScene(line.p2()).y())
         .arg(mapToScene(line.p1()).x()).arg(scene()->height()-2 - mapToScene(line.p1()).y());
  
  s += Transition::getEPS();
    
  return s;
}
*/
