#include "constants.h"

#include "transitionLoop.h"
#include "state.h"
#include "label.h"
#include "transforms.h"

#include <math.h>

#include <QtDebug>

TransitionLoop::TransitionLoop(Editor *parent, State *state, const QString &labelText, int type,
                               bool dimmed, int d)
  : OneStateTransition(parent,state,dimmed), loopType(type), direction(d)
{
    setZValue(Z_TRANSITION);
    label = new LabelX(this, labelText, leftOriented, m_labelFontSize,
        dimmed ? QColor(dimEdgeLabelColor) : QColor(edgeLabelColor));    
    label->setZValue(Z_TR_LABEL);    
    label->setPosParam(DEF_LOOP_LAB_POS);
    adjust();
}

TransitionLoop::~TransitionLoop()
{
    DBGLOG("called");
}

void TransitionLoop::adjust()
{
    prepareGeometryChange();
    if (!startState) return;
    startPoint = startState->pos();
    setPos(startPoint.x(), startPoint.y());   
    
    int angle = (loopType == eLoop ? TR_LOOP_OPENING_ANGLE : 
        (loopType == eCLoop ? TR_CLOOP_OPENING_ANGLE : TR_LOOPVAR_OPENING_ANGLE));

    QLineF firstLine(0,0,startState->getWidth()+10,0);
    firstLine.setAngle(trAngleFromDirection(direction) + angle);
    QPolygonF anglePol;
    anglePol << firstLine.p1() << firstLine.p2();
    QPolygonF firstPol = findIntersectedPoints(anglePol, startState->getMyPolygon(), eFIND_FIRST);    
    firstLine.translate(firstPol[0]); // move to first point

    QLineF secondLine(0,0,startState->getWidth()+10, 0);
    secondLine.setAngle(trAngleFromDirection(direction) - angle);
    anglePol.clear();
    anglePol << secondLine.p1() << secondLine.p2();
    QPolygonF secondPol = findIntersectedPoints(anglePol, startState->getMyPolygon(), eFIND_FIRST);    
    secondLine.translate(secondPol[0]); // move to second point

    QLineF lenLine(firstPol[0], secondPol[0]);
    lenLine.setLength(lenLine.length() * TR_LOOP_MULTIPLICATOR);

    firstLine.setLength(lenLine.length());
    secondLine.setLength(lenLine.length());    

    QPainterPath path;
    path.moveTo(firstPol[0]); // create loop
    path.cubicTo(firstLine.p2(),secondLine.p2(), secondPol[0]);
    p = path;
    
    QList<QPolygonF> pathList;
    
    QPolygonF loopPol;
    QLineF testLine;
    switch (direction)
    { // different arrow direction according to Loop direction
        case NORTH:
        case NORTH_EAST:
        case EAST:
        case SOUTH_WEST:
            pathList = p.toSubpathPolygons();            
            loopPol << pathList[0] << QPointF(0,0); // QPointF(0,0) due to ensure, that right arrow point will be found
            break;
        case NORTH_WEST:
        case WEST:
        case SOUTH:
        case SOUTH_EAST:
            p = p.toReversed();            
            pathList = p.toSubpathPolygons();                        
            loopPol << pathList[0] << QPointF(0,0);
            break;
        default:
            RELLOG("unexpected state!!!");
    }

    if (pathList.size() > 1)
    {
        RELLOG("not only one subpath polygon!");
        Q_ASSERT(!"not only one subpath polygon");
    }
    
    pa = getArrowPolygon(p);

    setLabelPosition();
    createStrokes(p);
}

QString TransitionLoop::getTypeName() const
{
    if (loopType == TransitionLoop::eCLoop)
        return "CLoop";
    else if (loopType == TransitionLoop::eLoopVar)
        return "LoopVar";      
    else
        return "Loop";
}

void TransitionLoop::setDirection(int d)
{
    direction = d;
    adjust();
    setLabelPosition();
}

int TransitionLoop::getDirection() const
{
    return direction;
}

void TransitionLoop::setLabelPosition()
{
    bool isLeft = (direction == NORTH || direction == NORTH_EAST || direction == EAST || direction == SOUTH_WEST);
    
    if (label)
    {
        Transition::setLabelPosition(label, label->posParam(), isLeft, label->getWidth(), label->getHeight());
    }
    Transition::setLabelPosition();
}

void TransitionLoop::paint(QPainter * painter, const QStyleOptionGraphicsItem * , QWidget * )
{
    QColor lineC;
    Qt::PenStyle lineS;

    if (dimmed)
    {
        lineS = dimEdgeLineStyle;
        lineC = dimEdgeLineColor;
    }
    else
    {
        lineS = edgeLineStyle;
        lineC = edgeLineColor;
    }
  
    if (checked)
        painter->setPen(QPen(checkedColor, m_lineWidth, lineS));
    else
        painter->setPen(QPen(lineC, m_lineWidth, lineS));
    
    painter->setBrush(Qt::NoBrush);
    painter->drawPath(p);
    
    // paint arrow
    if (checked)
        painter->setBrush(checkedColor);
    else
        painter->setBrush(lineC);
    
    painter->drawPolygon(pa);
    
    paintSelectionDecoration(painter);

#ifdef TESTING_PAINTING
#   ifdef TESTING_BOUNDING_RECT_PAINTING
        painter->setBrush(QBrush(QColor(50,255,0,100)));
        painter->fillRect(boundingRect(), painter->brush());
#   endif

    painter->setBrush(QBrush(QColor(0,0,255,150)));
    painter->fillPath(shape(), painter->brush());    
#endif
}
 
QString TransitionLoop::getVCCommand() const
{
    QString command = "\\";
    
    bool isVarLoopNotNorthOrSouth = false;
    
    // getTypeName not used due to special handling of 
    // LoopVar in directions other then north or south
    if (loopType == eCLoop)
    {
        command += "CLoop";
    }
    else if (loopType == eLoop)
    {
        command += "Loop";
    }
    else
    {
        Q_ASSERT(loopType == eLoopVar);
        if (getDirection() != NORTH &&
            getDirection() != SOUTH)
        {
            isVarLoopNotNorthOrSouth = true;
            command += "VarLoopOn \\";
            command += "Loop";
        }
        else
        {
            command += "LoopVar";
        }
    }

    command += getTypeNameSuffix().toUpper();

    Q_ASSERT(label != NULL);

    if (label->posParam() != DEF_LOOP_LAB_POS) 
        command += QString("[%1]").arg(label->posParam());

    command += "{" + startState->getName() + "}";

    command += "{" + label->text() + "}";

    if (isVarLoopNotNorthOrSouth)
      command += " \\VarLoopOff";

    command += getNextLabelsVCCommand();

    return command;
}

/*
QString TransitionLoop::getEPS() const
{
  QString s;
  
  QColor lineC;
  Qt::PenStyle lineS;

  int r, g, b; float rf, gf, bf;
  
  if (dimmed)
  {
    lineS = dimEdgeLineStyle;
    lineC = dimEdgeLineColor;
  }
  else
  {
    lineS = edgeLineStyle;
    lineC = edgeLineColor;
  }
  
  lineC.getRgb(&r,&g,&b);
  rf = r / 255.; gf = g / 255.; bf = b / 255.;
  
  QPointF p1, p2, p3;
  p1 = mapToScene(QPointF(0,0));      
  p2 = mapToScene(QPointF(-80,-100));
  p3 = mapToScene(QPointF(80, -100));
   
  // r g b width cx cy cx cy cx cy mx my trLoop
  s += trLineStyle(lineS);
  s += QString(" %1 %2 %3 %4 %5 %6 %7 %8 %9 %10 %9 %10 trLoop\n")
         .arg(rf).arg(gf).arg(bf)
         .arg(m_lineWidth)
         .arg(p3.x()).arg(scene()->height()-2 - p3.y())
         .arg(p2.x()).arg(scene()->height()-2 - p2.y())
         .arg(p1.x()).arg(scene()->height()-2 - p1.y());
  
  s += Transition::getEPS();   // nakonec se vykresli label
  return s;
}
*/
