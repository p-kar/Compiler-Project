#ifndef _LABELSYNTAXCHECKER_H_23546777390_
#define _LABELSYNTAXCHECKER_H_23546777390_

#include "stringProcessor.h"
#include "itransition.h"

/*!
 *  Syntax checker implemented by recursive descending method.
 *  Computes characters and gives pattern used in label text.
 *  If fails, report is available.
 *  \param characterList (created by StringProcessor)
 *  \sa StringProcessor
 */
class LabelSyntaxChecker
{
public:
    enum ELabelTextPattern { eEmptyPattern = 0,
                             eNormalPattern,
                             eAlphabetMinusPattern,
                             eBarPattern,
                             eAlphabetPattern,
                             eEpsilonSymbPattern };

    LabelSyntaxChecker(const ITransition::TCharSet &alphabet,
                       const QString &alphabetSymb,
                       const QString &epsilonSymb);

    ~LabelSyntaxChecker() {}

    QString getReport();
    ITransition::TCharSet getCharacters();
    ELabelTextPattern getPattern();
    
    //! starts recursive descent
    bool checkSyntax(const StringProcessor::TCharacterList &characterList);
    
protected:
    //! return next CharacterInfo from input list and 
    StringProcessor::CharacterInfo nextToken();
    bool hasNextToken();

    const ITransition::TCharSet         m_alphabet;
    const QString                       m_alphabetSymb;
    const QString                       m_epsilonSymb;
    StringProcessor::TCharacterList     m_characterList;
    int                                 m_idx;

    ITransition::TCharSet           characters;
    ELabelTextPattern               pattern;
    QStringList                     report;
    
    //! adds character to charSet and check if it's in alphabet
    bool processCharacter(ITransition::TCharSet &charSet, 
                          const StringProcessor::CharacterInfo &charInfo);
    //! adds barred character to charSet and check if it's in alphabet
    bool processBarredCharacter(ITransition::TCharSet &charSet,
                                const StringProcessor::CharacterInfo &charInfo);
    
    //! recursive descent methods
    bool NormalPattern(ITransition::TCharSet &charSet);
    bool NormalPatternNext(ITransition::TCharSet &charSet);
    bool BarPattern();
    bool BarPatternNext();
    bool AlphabetOrAlphabetMinusPattern();
    bool End();
};

#endif //_LABELSYNTAXCHECKER_H_23546777390_
