#ifndef _TRANSITIONMANAGER_H_12353466884_
#define _TRANSITIONMANAGER_H_12353466884_

class Editor;
class Transition;
class OneStateTransition;
class TwoStatesTransition;
class State;
class TransitionDialog;
class TransitionLoopSEDialog;

#include <QList>
#include <QMap>
#include <QtDebug>

/*!
 * Holds properties of each transition type for dialogs needs.
 */
struct OneStateTransitionProperties
{
    OneStateTransitionProperties(bool label = false, bool labelPos = false,                                  
                                 float labelPosVal = .0f)
    :   hasLabel(label), hasLabelPos(labelPos),        
        defLabelPos(labelPosVal)
    {}

    bool hasLabel;
    bool hasLabelPos;    
    float defLabelPos;
};

struct TwoStatesTransitionProperties
{
    TwoStatesTransitionProperties
        (bool label = false, bool labelPos = false,
         bool arcAngleA = false, bool nCurve = false,
         bool arcAngleB = false, float labelPosVal = .0f, 
         float arcAngleAVal = .0f, float nCurveVal = .0f,
         float arcAngleBVal = .0f)
    :   hasLabel(label), hasLabelPos(labelPos),
        hasArcAngleA(arcAngleA), hasNCurve(nCurve),
        hasArcAngleB(arcAngleB), defLabelPos(labelPosVal), defArcAngleA(arcAngleAVal),
        defNCurve(nCurveVal), defArcAngleB(arcAngleBVal)
    {}

    bool hasLabel;
    bool hasLabelPos;    
    bool hasArcAngleA;    
    bool hasNCurve;    
    bool hasArcAngleB;

    float defLabelPos;
    float defArcAngleA;    
    float defNCurve;
    float defArcAngleB;
};

/*!
 * Creates concrete state and returns Transition supertype.
 * Implemented as singelton.
 */
class TransitionManager
{
private:
    static bool instantiated;
    static TransitionManager *manager;
    TransitionManager();

public:
    //! returns instance of TransitionManager
    static TransitionManager* getInstance();
    
    ~TransitionManager()
    {
        instantiated = false;
    }

    //! returns transition type list, used for dialog (filling comboBox)
    const QList<QString> &getOneStateTransitionTypeNameList() const;
    const QList<QString> &getTwoStatesTransitionTypeNameList() const;

    //! returns typeID by given typeName - important to hold elements's types consistent
    int getTypeNameId(const QString &typeName) const;    

    //! returns editable properties of transition type for transition dialogs
    const OneStateTransitionProperties& getOneStateTransitionProperties(int typeId) const;
    const TwoStatesTransitionProperties& getTwoStatesTransitionProperties(int typeId) const;

    OneStateTransition* createOneStateTransition
        (Editor *editor, State *state, const TransitionLoopSEDialog& td);
    OneStateTransition* createOneStateTransition
        (const QString& typeName, Editor *editor, State *state, 
         const QString& label, int direction, bool dimmed);

    TwoStatesTransition* createTwoStatesTransition
        (Editor *editor, State *s1, State *s2, const TransitionDialog& td);
    TwoStatesTransition* createTwoStatesTransition
        (const QString& typeName, Editor *editor, State* s1, State* s2,
         const QString& label, bool leftOriented, bool dimmed);

protected:
    //! createConcreteTransition methods
    //! oneStateTransitions creators
    OneStateTransition* createTransitionInitial
        (Editor *editor, State *state, const QString &/*label*/, int direction, bool dimmed);
    OneStateTransition* createTransitionFinal
        (Editor *editor, State *state, const QString &/*label*/, int direction, bool dimmed);
    OneStateTransition* createTransitionLoop
        (Editor *editor, State *state, const QString &label, int direction, bool dimmed);
    OneStateTransition* createTransitionCLoop
        (Editor *editor, State *state, const QString &label, int direction, bool dimmed);
    OneStateTransition* createTransitionLoopVar    
        (Editor *editor, State *state, const QString &label, int direction, bool dimmed);

    //! twoStatesTransitions creators
    TwoStatesTransition* createTransitionLine
        (Editor *editor, State *s1, State *s2, const QString &label, bool leftOriented, bool dimmed);
    TwoStatesTransition* createTransitionArc
        (Editor *editor, State *s1, State *s2, const QString &label, bool leftOriented, bool dimmed);
    TwoStatesTransition* createTransitionLArc
        (Editor *editor, State *s1, State *s2, const QString &label, bool leftOriented, bool dimmed);
    TwoStatesTransition* createTransitionVArc
        (Editor *editor, State *s1, State *s2, const QString &label, bool leftOriented, bool dimmed);
    TwoStatesTransition* createTransitionVCurve
        (Editor *editor, State *s1, State *s2, const QString &label, bool leftOriented, bool dimmed);


    QList<QString> oneStateTransitionTypeList;
    QList<QString> twoStatesTransitionTypeList;
    
    //! pointer to TransitionManager::createConcreteTransition
    typedef OneStateTransition* (TransitionManager::*OneStateTransitionConstructor)
        (Editor* /*editor*/, State* /*state*/, const QString& /*label*/,
         int /*direction*/, bool /*dimmed*/);
    typedef QMap<QString, OneStateTransitionConstructor> TypeNameToOneStateInstanceMap;
    
    typedef QMap<QString, OneStateTransitionProperties> TypeNameToOneStatePropsMap;
    typedef QMap<QString, TwoStatesTransitionProperties> TypeNameToTwoStatesPropsMap;
    
    //! maps type name to createConcreteOneStateTransition function
    TypeNameToOneStateInstanceMap   typeNameToOneStateInstanceMap;
    
    TypeNameToOneStatePropsMap      typeNameToOneStatePropsMap;
    TypeNameToTwoStatesPropsMap     typeNameToTwoStatesPropsMap;

    typedef TwoStatesTransition* (TransitionManager::*TwoStatesTransitionConstructor)
        (Editor* /*editor*/, State* /*s1*/, State* /*s2*/, const QString& /*label*/,
         bool /*leftOriented*/, bool /*dimmed*/);
    typedef QMap<QString, TwoStatesTransitionConstructor> TypeNameToTwoStatesInstanceMap;
    //! maps type name to createConcreteTwoStatesTransition function
    TypeNameToTwoStatesInstanceMap typeNameToTwoStatesInstanceMap;
};

#endif //_TRANSITIONMANAGER_H_12353466884_
