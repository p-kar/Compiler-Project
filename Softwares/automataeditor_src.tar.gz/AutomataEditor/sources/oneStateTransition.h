#ifndef _ONESTATETRANSITION_H_323442986296_
#define _ONESTATETRANSITION_H_323442986296_

#include "transition.h"

class OneStateTransition : public Transition
{
public:
    OneStateTransition(Editor *parent, State *ss, bool dimmed)
    : Transition(parent, ss, NULL, dimmed)
    {}

    virtual QString getTypeNameSuffix() const;

    virtual void assign();
    virtual void unassign();

protected:
    virtual void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
};

#endif //_ONESTATETRANSITION_H_323442986296_
