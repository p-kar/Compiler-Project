#include "constants.h"

#include "oneStateTransition.h"
#include "state.h"

#include <QGraphicsSceneMouseEvent>
#include <QtDebug>

QString OneStateTransition::getTypeNameSuffix() const
{
    switch (this->getDirection())
    {
        case NORTH:       return "N";   break;
        case SOUTH:       return "S";   break;
        case EAST:        return "E";   break;
        case WEST:        return "W";   break;
        case NORTH_EAST:  return "NE";  break;
        case NORTH_WEST:  return "NW";  break;
        case SOUTH_EAST:  return "SE";  break;
        case SOUTH_WEST:  return "SW";  break;
        default: 
            RELLOG("unknown direction!!!");
            return "N";
    }
}

void OneStateTransition::assign()
{
    startState->addTransition(this);
}

void OneStateTransition::unassign()
{
    startState->removeTransition(this);
}

void OneStateTransition::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    DBGLOG_ME("called");
    if (m_lastMouseClickType == eMouseRightClick)
    {
        editor->showPopup(this, mapToScene(event->pos().toPoint()));
        return; // could be deleted
    }
    else if (m_lastMouseClickType == eMouseDoubleClick)
    {
        editor->editTransition(this);
        return; // could be deleted
    }
    setChecked(false);
}
