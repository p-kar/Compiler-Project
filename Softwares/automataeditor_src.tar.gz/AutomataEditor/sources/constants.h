#ifndef CONSTANTS_H_4125434583252
#define CONSTANTS_H_4125434583252

//! \file constants.h
//! Contains all constants and editor's settings.

//! name of this program
#define PROGRAM_NAME                "Automata editor"

//! current version of editor
#define PROGRAM_VERSION             "2.0"

// TODO: define some version macros to make gvwrapper supporting more then just one version
//! set GraphViz library version, which will be required in runtime (can be reset in sources.pro)
#ifndef GRAPHVIZ_VERSION
#   ifdef WIN32
#       define GRAPHVIZ_VERSION         "2.26.3"
#   else
#       define GRAPHVIZ_VERSION         "2.20.2"
#   endif
#endif

// if defined, no OpenGL rendering is used
// note: do NOT define QT_* macros manually, they are set by qmake depending on enabled modules
#ifndef QT_OPENGL_LIB
#   define DONT_USE_OPENGL_RENDERING // TODO: still only experimental usage
#endif

#ifndef QT_SVG_LIB
#   define DONT_USE_SVG_MODULE
#endif

// if defined, undefined characters are displayed as UNKNOWN_CHARACTER and undefined strings are displayed as UNKNOWN_STRING
// #define USE_UNKNOWN_CONVENTION

//! if defined, editor is in TESTING mode (== verbose mode + special painting)
#ifndef NDEBUG
#   define TESTING
#endif

#ifdef TESTING
//#   define TESTING_MOUSE_EVENTS
//#   define TESTING_ARROW_POINTS
#   define TESTING_STRING_PROCESSOR
//#   define TESTING_LEXER
#   define TESTING_PARSER
//#   define TESTING_PAINTING
#   define TESTING_SERIALIZERS
#   define TESTING_ADDING
#   define TESTING_AUTOMATA_CREATOR
#   define TESTING_DRAWING
#   define TESTING_AUTOMATA_INTERFACES
//#   define TESTING_USE_SMALLER_WINDOW
#   define TESTING_SIMULATION
#   define TESTING_SYNTAX_CHECKER
#   define TESTING_GRAPHVIZDRAWER
#endif

#ifdef TESTING_PAINTING
#   define TESTING_BOUNDING_RECT_PAINTING
#endif

#ifdef TESTING_SIMULATION
// if defined, every step of animation process is logged
//#   define TESTING_ANIMATIONS

// if defined, undo view is available while simulation is runnig (don't change undostack index !!!)
//#   define ALLOW_UNDO_VIEW_WHILE_SIMULATION_RUNNING
#endif

#include "dbglog.h"

#ifdef TESTING_AUTOMATA_INTERFACES
#   define DBGLOG_AI(x) DBGLOG_("IAUTOMATA", x)
#else
#   define DBGLOG_AI(x)
#endif

// #if defined, performance measurement is active
#define PERFORMANCE_MEASUREMENT

#ifdef PERFORMANCE_MEASUREMENT
//#   define MEASURE_CREATE_STROKES
//#   define MEASURE_TR_ADJUST
//#   define MEASURE_AUTOMATA_RECONGIZATION
#   define MEASURE_PARSER_RUN
#endif

#ifdef TESTING_STRING_PROCESSOR
// if defined, StringProcessorTestDialog will be showed on program start up
//#   define STRING_PROCESSOR_TEST
#endif

// debugging printouts turn on(==commented)/off
//#define QT_NO_DEBUG_OUTPUT

// warning printouts turn on(==commented)/off
//#define QT_NO_WARNING_OUTPUT

//! \name start settings
//! \{
#define SNAP_TO_GRID                false
#define SHOW_GRID                   true
#define SHOW_FRAME                  true
#define INIT_ANTIALIASING           false
//! \}

//! init action (Editor::EAction)
#define INIT_ACTION                 0 // == Editor::eSelection

//! default save suffix
#define DEFAULT_SUFFIX_VCG          false // if false, then "*.tex" is used

//! \name clipboards formats
//! \{
#define CLIPBOARD_FORMAT_STATE      "application/AutotmataEditor;type=State"
#define CLIPBOARD_FORMAT            "application/AutomataEditor;type=Selection"
//! \}

enum {LLX=0, LLY=0, URX=12, URY=10}; //!< default grid proportions

//! ZValues
enum {Z_STATE, Z_TRANSITION, Z_TR_LABEL};

//! \name areas bounds
//! used when creating click and selection areas using path stroker
//! \{
#define CLICK_BOUNDS                2
#define SELECTION_BOUNDS            4
//! \}

//! directions
enum {NORTH, SOUTH, EAST, WEST, NORTH_EAST, NORTH_WEST, SOUTH_EAST, SOUTH_WEST};

//! grid step
enum {GRID_STEP=40};

//! zooming divider
#define ZOOM_DIVIDER 600.0 //!< \note hold this in multiples of 120.0 according to Qt documentation of wheelEvent

//! normal state size proportions
enum {S_LX = -18, S_LY = -18, S_W = -2*S_LX, S_H = -2*S_LY};

//! radices of StateVar
enum {VAR_STATE_R_X = 20, VAR_STATE_R_Y = 50, VAR_STATE_R_X_DBL=25,
      VAR_STATE_WIDTH_ADDITION = 20};

//! \name arrow size
//! \{
#define ARROW_LEN                   10
#define ARROW_WIDTH                 6
//! \}

//! transition initial/final line length
#define TR_SE_LENGTH                40

//! \name transition loop parameters
//! \{
#define TR_LOOP_OPENING_ANGLE       30      //!< angles according to VCManual
#define TR_CLOOP_OPENING_ANGLE      22
#define TR_LOOPVAR_OPENING_ANGLE    28
#define TR_LOOP_MULTIPLICATOR       3.5f    //!< for loop construction - length of constructional line - empiric constant
//! \}

//! transition text distnace
#define TEXT_DISTANCE               5.f

//! \name view transformations
//! \{
#define TR_LINE_VIEW_COEF           2.f
#define STATE_LINE_VIEW_COEF        1.6f
#define STATE_DOUBLE_LINE_VIEW_COEF 1.4f
//! \}

//! undo and redo setting
enum {UNDO_LIMIT=0}; //!< \note for no limit set 0

//! gridRect's size limit
enum {MAX_RECT_VALUE = 500, MIN_RECT_VALUE = -MAX_RECT_VALUE};
//! scene border (only editor setting)
enum {SCENE_BORDER=100, MIN_BORDER_VALUE=10, MAX_BORDER_VALUE=500};

//! \name colors
//! \{
namespace CheckedColor { enum {r=255, g=100, b=100, a=255}; };
namespace SelectedColor { enum {r=100, g=100, b=100, a=200}; };
//! \}

//! default export format
#define NEW_FILENAME (DEFAULT_SUFFIX_VCG ? "untitled.vcg" : "untitled.tex")

//! number of side by side states and transitions in VauCanSon-G
enum {SBS_STATES = 3, SBS_TRAN = 2, SBS_IF = 4, SBS_LABELS = 3}; 

//! searching automata generation options
enum {EXACT_HSPACE = 2,
      HAMMING_HSPACE = 2, HAMMING_VSPACE= 2,
      LEVEN_HSPACE = 3, LEVEN_VSPACE = 3};

//! \name default values of transitions
//! \{
#define DEF_EDGE_LAB_POS            0.45f
#define DEF_ARC_LAB_POS             0.4f
#define DEF_LOOP_LAB_POS            0.25f
#define DEF_TR_S_DIR                WEST
#define DEF_TR_E_DIR                EAST
#define DEF_ARC_ANGLE               30
#define DEF_VCURV_ANGLE             0
#define DEF_VCURV_ANGLE_B           180
#define DEF_VCURVR_ANGLE_B          0       //!< probably bug in VauCanSon package, VCurveR has angleB default on 0
#define DEF_ARC_CURV                0.8f
#define DEF_VCURV_CURV              1.0f
//! \}

//! \name default style values
//! \{
#define DEF_LINE_STYLE              Qt::SolidLine
#define DEF_STATE_LINE_WIDTH        1.8f
#define DEF_EDGE_LINE_WIDTH         1.f
#define DEF_COLOR                   "black"
#define DEF_LABEL_SCALE             1.7f
#define DEF_FILL_STATUS             Qt::SolidPattern
#define DEF_FILL_COLOR              "white"
#define DEF_EDGE_LINE_DBL_STATUS    false

#define DEF_DIM_LINE_STYLE          Qt::SolidLine
#define DEF_DIM_COLOR               "gray"
#define DEF_DIM_STATE_LINE_COEF     1.0f
#define DEF_DIM_EDGE_LINE_COEF      1.2f
#define DEF_DIM_FILL_COLOR          "white"

#define DEF_STATE_LINE_DBL_COEF     0.6f
#define DEF_STATE_LINE_DBL_SEP      0.4f
#define DEF_EDGE_LINE_BORDER_COEF   2
#define DEF_EDGE_LINE_BORDER_COLOR  "white"

#define DEF_EDGE_LINE_DBL_COEF      0.5f
#define DEF_EDGE_LINE_DBL_SEP       0.6f

#define STATE_LABEL_SIZE            10
#define EDGE_LABEL_SIZE             10
//! \}

//! math custom constant
#define M_PI 3.1415926535

//! \name StringProcessor settings
//! \{
#define EPS_FONT_SIZE_MULTIPLIER    1.4f

#define SCRIPT_STYLE_MULT           0.75f
#define SCRIPT_SCRIPT_STYLE_MULT    0.7f

#ifdef USE_UNKNOWN_CONVENTION
#	define UNKNOWN_CHARACTER        '?'
#	define UNKNOWN_STRING           "\\unknown"
#endif
//! \}

//! Simulation settings
//! \{
#define SIMULATION_STEP_DEFAULT     1.0     //!< unit: seconds
#define SIMULATION_STEP_MIN         0.5
#define SIMULATION_STEP_MAX         10.0

#define USE_ANIMS_BY_DEFAULT        true
#define ANIM_SPEED_DEFAULT          500.0   //!< unit: miliseconds
#define ANIM_SPEED_MIN              100.0
#define ANIM_SPEED_MAX              10000.0
#define ANIMATION_FRAME_TIME        40.0f   //!< correspodns to 25fps

// if defined, undo stack is reset when simulation dialog is closed (to reduce stack size)
#define RESET_UNDO_STACK_AFTER_SIMULATION
//! \}

#endif
