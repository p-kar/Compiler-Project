#include "constants.h"

#include "stateVar.h"
#include "transforms.h"

#include <QtDebug>

StateVar::StateVar(const QPoint &position, Editor *parent, const QString l,
                   const QString n, bool dBorder, bool dim)
: State(position, parent, l, n, dBorder, dim)
{
    //! all other functionality is in State constructor
    updateMyPolygon();
}

QString StateVar::getTypeName() const
{
    return doubleBorder ? "FinalStateVar" : "StateVar";
}

void StateVar::updateMyPolygon()
{
    // it's posible to find exact point, but VauCanSon don't do it too, reason is when large state is added
    // loop than does not seem well
    
    QRectF ellipseRect(-getWidth()/2,-getHeight()/2,getWidth(),getHeight());
    float adjust;

    if (doubleBorder)
    {
        float doubleLineSep = m_lineWidth * stateLineDoubleSep / STATE_LINE_VIEW_COEF; // w/o correction
        float doubleLineWidth = m_lineWidth * stateLineDoubleCoef * STATE_DOUBLE_LINE_VIEW_COEF;
        adjust = doubleLineSep + doubleLineWidth*1.5;
    }
    else
    {
        adjust = m_lineWidth/2;
    }

    // exact polygon
    myPath = QPainterPath();
    myPath.addRoundedRect(ellipseRect.adjusted(-adjust,-adjust,
                                                adjust, adjust),
                                                (doubleBorder) ? VAR_STATE_R_X_DBL : VAR_STATE_R_X,
                                                VAR_STATE_R_Y);
    myPolygon = myPath.toFillPolygon();
}

void StateVar::setLabel(const QString &label)
{
    State::setLabel(label); // common functionality
    updateMyPolygon();
    adjustTransitions();
}

//<-- Export support functions -------------------------------------------------
/*
QString StateVar::getEPS() const
{
  QString s = "";
  int r, g, b;
  float rf, gf, bf;
  QColor lineC, labelC, fillC;
  Qt::PenStyle lineS;
  float lineWidth, lineSep = 0;
    
  if (dimmed){
    lineC = dimStateLineColor;
    labelC = dimStateLabelColor;
    lineS = dimStateLineStyle;
    fillC = dimStateFillColor;
    lineWidth = editor->stateLineWidth * dimStateLineCoef; // nasobi se jeste pres zmenu na stavu
  }
  else{
    lineC = stateLineColor;
    labelC = stateLabelColor;
    lineS = stateLineStyle;
    fillC = stateFillColor;
    lineWidth = editor->stateLineWidth * stateLineWidth;
  }
  
  // draw variable state
  // x y width height radius linewidth r g b rfill gfill bfill sBubble
  s += trLineStyle(lineS); // TODO: make "none" better
  if (doubleBorder){
    lineSep = lineWidth * stateLineDoubleSep;
    lineWidth *= stateLineDoubleCoef;    
  }

  QString tmp;
  lineC.getRgb(&r,&g,&b);
  rf = r / 255.; gf = g / 255.; bf = b / 255.;
  tmp += QString (" %1 %2 %3 %4")         
         .arg(lineWidth)
         .arg(rf).arg(gf).arg(bf);
  fillC.getRgb(&r,&g,&b);
  rf = r / 255.; gf = g / 255.; bf = b / 255.;  
  tmp += QString (" %1 %2 %3")
         .arg(rf).arg(gf).arg(bf);

  if (doubleBorder)
  {
      s += QString(" %1 %2 %3 %4 %5")
          .arg(x())
          .arg(scene()->height()-2 - y())
          .arg(getWidth() + lineSep*2)
          .arg(getHeight() + lineSep*2)
          .arg(18);
      s += tmp;
      s += " sBubble\n";  
  }

  s += QString(" %1 %2 %3 %4 %5")
          .arg(x())
          .arg(scene()->height()-2 - y())
          .arg(getWidth() - lineSep*2)
          .arg(getHeight() - lineSep*2)
          .arg(18);
      s += tmp;
      s += " sBubble\n";   
   
  if (label != "")
      s += stringProcessor->getEPS(QPointF(x() - getTextWidth()/2,
                                           scene()->height()-2 - y() - getTextDescent()));
  
  return s;
}
*/
//------------------------------------------------- Export support functions -->



//<-- QGraphicsItem functions --------------------------------------------------

QPainterPath StateVar::shape() const
{
    return myPath;
}

void StateVar::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    QColor lineC, labelC, fillC;
    Qt::PenStyle lineS;
    float doubleLineSep, doubleLineWidth;

    if (dimmed){
        lineC = dimStateLineColor;
        labelC = dimStateLabelColor;
        lineS = dimStateLineStyle;
        fillC = dimStateFillColor;
    }
    else{
        lineC = stateLineColor;
        labelC = stateLabelColor;
        lineS = stateLineStyle;
        fillC = stateFillColor;
    }

#ifdef TESTING_PAINTING
    fillC.setAlpha(100);
#endif
    
    doubleLineSep = m_lineWidth * stateLineDoubleSep / STATE_LINE_VIEW_COEF; // w/o correction
    doubleLineWidth = m_lineWidth * stateLineDoubleCoef * STATE_DOUBLE_LINE_VIEW_COEF;

    QRectF ellipseRect(-getWidth()/2, -getHeight()/2, getWidth(), getHeight());
    (doubleBorder) ? painter->setPen(QPen(lineC,doubleLineWidth,lineS)) :
                     painter->setPen(QPen(lineC,m_lineWidth,lineS));

    if (doubleBorder)
    {
        if (stateFillStatus != Qt::NoBrush)
        {
            painter->setBrush(QColor("white"));
        }
        else 
        {
            painter->setBrush(Qt::NoBrush);
        }
        // TODO: create right doubleLineSep!
        painter->drawRoundedRect(ellipseRect.adjusted(-doubleLineSep-doubleLineWidth,
                                                      -doubleLineSep-doubleLineWidth,
                                                       doubleLineSep+doubleLineWidth,
                                                       doubleLineSep+doubleLineWidth), 
                                                       VAR_STATE_R_X_DBL, VAR_STATE_R_Y);
    
    }

    if (stateFillStatus != Qt::SolidPattern) 
    { // only for better edge visibility TODO: maybe not necessary more
        fillC = "black";
        if (stateFillStatus != Qt::NoBrush)
        {
            painter->setBrush(QBrush("white",Qt::SolidPattern));
            if (doubleBorder)
            {
                painter->drawRoundedRect(ellipseRect.adjusted(doubleLineSep,doubleLineSep,-doubleLineSep,-doubleLineSep)
                                         , VAR_STATE_R_X, VAR_STATE_R_Y);
            }
            else
            {
                painter->drawRoundedRect(ellipseRect
                                         , VAR_STATE_R_X, VAR_STATE_R_Y);
            }
        }  
    }

    if (checked) 
    {
        painter->setBrush(checkedColor);  
    }
    else
    {
        painter->setBrush(QBrush(fillC,stateFillStatus));
    }

    if (doubleBorder) 
    {
        painter->drawRoundedRect(ellipseRect.adjusted(doubleLineSep,doubleLineSep,-doubleLineSep,-doubleLineSep),
                                 VAR_STATE_R_X, VAR_STATE_R_Y);
    }
    else
    {
        painter->drawRoundedRect(ellipseRect, VAR_STATE_R_X, VAR_STATE_R_Y);
    }  

    painter->setPen(labelC);
    if (stringProcessor->text() != "")
    {        
        QPointF point(-getTextWidth()/2, (getTextAscent() - getTextDescent())/2);
        stringProcessor->drawText(painter, point);
    }

    paintSelectionDecoration(painter);

#ifdef TESTING_PAINTING
#   ifdef TESTING_BOUNDING_RECT_PAINTING
    painter->setBrush(QBrush(QColor(50,255,0,80)));
    painter->fillRect(boundingRect(), painter->brush());
#   endif

    painter->setBrush(QBrush(QColor(0,0,255,50)));
    painter->fillPath(shape(), painter->brush());
#endif
}

//-------------------------------------------------- QGraphicsItem functions -->
