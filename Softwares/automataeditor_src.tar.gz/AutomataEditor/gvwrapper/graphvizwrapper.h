#ifndef GRAPHVIZWRAPPER_H_64684351348614
#define GRAPHVIZWRAPPER_H_64684351348614

#include "interfaces/igraphviz.h"

#include <QObject>

// GraphViz headers
#include "graphviz/gvc.h"

class GVEdge : public IGVEdge
{
public:
    GVEdge(Agraph_t *graph, Agedge_t *edge);
    ~GVEdge();

    QString getHeadName() const;
    QString getTailName() const;

    QString getLabel() const;
    QPoint  getLabelPos() const;

    QSharedPointer<IGVEdge> getNextOutEdge() const;

    TCPList getControlPoints() const;

private:
    Agraph_t    *m_graph;
    Agedge_t    *m_edge;
};



class GVNode : public IGVNode
{
public:
    GVNode(Agraph_t *graph, Agnode_t *node);
    ~GVNode();

    QString getName() const;
    QPoint  getPos() const;

    QSharedPointer<IGVNode> getPrevNode() const;
    QSharedPointer<IGVNode> getNextNode() const;

    QSharedPointer<IGVEdge> getFirstOutEdge() const;

private:
    Agraph_t    *m_graph;
    Agnode_t    *m_node;
};



class GVGraph : public IGVGraph
{
public:
    GVGraph();
    ~GVGraph();

    bool        addNode(const QString &name);
    int         getNodeCount() const;
    QSharedPointer<IGVNode> getNode(const QString &name) const;
    QSharedPointer<IGVNode> getFirstNode() const;
    QSharedPointer<IGVNode> getLastNode() const;

    bool        addEdge(const QString &s1, const QString &s2, const QString &l);
    int         getEdgeCount() const;

    void        layoutGraphUsingDot();
    void        renderToFile(const QString &fileName);

private:
    Agraph_t    *m_graph;
    GVC_t       *m_gvc;
    bool        m_layout;
};



class GraphVizWrapper : public QObject, public IGraphViz
{
    Q_OBJECT
    Q_INTERFACES(IGraphViz)
public:
    GraphVizWrapper();

    virtual ~GraphVizWrapper();

    QString     getVersion() const { return "2.0"; }
    QString     getGraphVizVersion() const;

    QSharedPointer<IGVGraph>    createGraph() const;
};

#endif //GRAPHVIZWRAPPER_H_64684351348614
