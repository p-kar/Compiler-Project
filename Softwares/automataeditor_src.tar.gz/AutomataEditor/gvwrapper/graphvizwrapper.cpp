#include "graphvizwrapper.h"
#include "utility/dbglog.h"

#include <QtPlugin>

#include <QPointF>
#include <QString>

#define DBGLOG_GV(x) DBGLOG_("GRAPHVIZ", x)
#define RELLOG_GV(x) RELLOG_("GRAPHVIZ", x)

//<-- GVEdge ----------------------------------------------------------

GVEdge::GVEdge(Agraph_t *graph, Agedge_t *edge)
: m_graph(graph), m_edge(edge)
{

}

GVEdge::~GVEdge()
{
    DBGLOG_GV("deleted");
}

QString GVEdge::getHeadName() const
{
    return m_edge->head->name;
}

QString GVEdge::getTailName() const
{
    return m_edge->tail->name;
}

QString GVEdge::getLabel() const
{
    return m_edge->u.label->text;
}

QPoint GVEdge::getLabelPos() const
{
    return
#ifdef WIN32
        QPointF(m_edge->u.label->pos.x, m_edge->u.label->pos.y).toPoint();
#else
        QPoint(m_edge->u.label->p.x, m_edge->u.label->p.y);
#endif
}

QSharedPointer<IGVEdge> GVEdge::getNextOutEdge() const
{
    Agedge_t *edge = agnxtout(m_graph, m_edge);
    return QSharedPointer<IGVEdge>(edge ? new GVEdge(m_graph, edge) : NULL);
}

IGVEdge::TCPList GVEdge::getControlPoints() const
{
    QVector<QPoint> result;

    const int count = m_edge->u.spl->list->size;
#ifdef WIN32
	pointf *pPoints = m_edge->u.spl->list->list;
#else
    point *pPoints = m_edge->u.spl->list->list;
#endif
    for (int i=0; i < count; ++i)
    {
#ifdef WIN32
		result << QPointF((pPoints+i)->x, (pPoints+i)->y).toPoint();
#else
        result << QPoint((pPoints+i)->x, (pPoints+i)->y);
#endif
    }

    return result;
}

//---------------------------------------------------------- GVEdge -->



//<-- GVNode ----------------------------------------------------------

GVNode::GVNode(Agraph_t *graph, Agnode_t *node)
:   m_graph(graph), m_node(node)
{

}

GVNode::~GVNode()
{
    DBGLOG_GV("deleted");
}

QString GVNode::getName() const
{
    return m_node->name;
}

QPoint GVNode::getPos() const
{
    return QPoint(m_node->u.coord.x, m_node->u.coord.y);
}

QSharedPointer<IGVNode> GVNode::getPrevNode() const
{
    Agnode_t *node = agprvnode(m_graph, m_node);
    return QSharedPointer<IGVNode>(node ? new GVNode(m_graph, node) : NULL);
}

QSharedPointer<IGVNode> GVNode::getNextNode() const
{
    Agnode_t *node = agnxtnode(m_graph, m_node);
    return QSharedPointer<IGVNode>(node ? new GVNode(m_graph, node) : NULL);
}

QSharedPointer<IGVEdge> GVNode::getFirstOutEdge() const
{
    Agedge_t *edge = agfstout(m_graph, m_node);
    return QSharedPointer<IGVEdge>(edge ? new GVEdge(m_graph, edge) : NULL);
}

//---------------------------------------------------------- GvNode -->



//<-- GVGraph ---------------------------------------------------------

GVGraph::GVGraph()
:   m_layout(false)
{
    m_gvc = gvContext();
    m_graph = agopen((char*)"G", AGDIGRAPH);
    agraphattr(m_graph, (char*)"rankdir", (char*)"LR");
    agraphattr(m_graph, (char*)"splines", (char*)"true");
    agedgeattr(m_graph, (char*)"label", (char*)"");
}

GVGraph::~GVGraph()
{
    DBGLOG_GV("deleted");
    if (m_layout)
        gvFreeLayout(m_gvc, m_graph);
    agclose(m_graph);
    gvFreeContext(m_gvc);
}

void GVGraph::layoutGraphUsingDot()
{
    if (m_layout)
    {
        gvFreeLayout(m_gvc, m_graph);
        m_layout = false;
    }
    gvLayout(m_gvc, m_graph, (char*)"dot");
    m_layout = true;
}

void GVGraph::renderToFile(const QString &fileName)
{
    if (!m_layout)
        layoutGraphUsingDot();
    gvRenderFilename(m_gvc, m_graph, (char*)"png", const_cast<char*>(fileName.toStdString().c_str()));
}

bool GVGraph::addNode(const QString &name)
{
    Agnode_t *n = agnode(m_graph, const_cast<char*>(name.toStdString().c_str()));
    if (n)
    {
        return true;
    }
    RELLOG_GV("Node couldn't be added!");
    return false;
}

int GVGraph::getNodeCount() const
{
    return agnnodes(m_graph);
}

QSharedPointer<IGVNode> GVGraph::getNode(const QString &name) const
{
    Agnode_t *node = agfindnode(m_graph, const_cast<char*>(name.toStdString().c_str()));
    return QSharedPointer<IGVNode>(node ? new GVNode(m_graph, node) : NULL);
}

QSharedPointer<IGVNode> GVGraph::getFirstNode() const
{
    Agnode_t *node = agfstnode(m_graph);
    return QSharedPointer<IGVNode>(node ? new GVNode(m_graph, node) : NULL);
}

QSharedPointer<IGVNode> GVGraph::getLastNode() const
{
    Agnode_t *node = aglstnode(m_graph);
    return QSharedPointer<IGVNode>(node ? new GVNode(m_graph, node) : NULL);
}

bool GVGraph::addEdge(const QString &s1, const QString &s2, const QString &l)
{
    Agnode_t *n1 = agfindnode(m_graph, const_cast<char*>(s1.toStdString().c_str()));
    Agnode_t *n2 = agfindnode(m_graph, const_cast<char*>(s2.toStdString().c_str()));
    if (!n1 || !n2)
    {
        RELLOG_GV("Some node don't exist when adding edge, couldn't be added!");
        return false;
    }
    Agedge_t *e = agedge(m_graph, n1, n2);
    if (e)
    {
        agset(e, (char*)"label", const_cast<char*>(l.toStdString().c_str()));
        return true;
    }
    RELLOG("Edge couldn't be added;!");
    return false;
}

int GVGraph::getEdgeCount() const
{
    return agnedges(m_graph);
}

//--------------------------------------------------------- GVGraph -->



//<-- GraphVizWrapper -------------------------------------------------

GraphVizWrapper::GraphVizWrapper()

{

}

GraphVizWrapper::~GraphVizWrapper()
{
    DBGLOG_GV("deleted");
}

QSharedPointer<IGVGraph> GraphVizWrapper::createGraph() const
{
    return QSharedPointer<IGVGraph>(new GVGraph());
}

QString GraphVizWrapper::getGraphVizVersion() const
{
    GVC_t *gvc = gvContext();
    QString versionStr = gvcVersion(gvc);
    gvFreeContext(gvc);
    return versionStr;
}

//------------------------------------------------- GraphVizWrapper -->

Q_EXPORT_PLUGIN2(gvwrapper, GraphVizWrapper)
