#ifndef _ALGORITHMS_H_11656963715131_
#define _ALGORITHMS_H_11656963715131_

#include <QObject>
#include "interfaces/ialgorithm.h"

#ifndef QT_STATICPLUGIN
#   define QT_STATICPLUGIN
#endif

class IAutomataCreator;

class BasicAlgorithm : public IAlgorithm
{
public:
    BasicAlgorithm();

    virtual ~BasicAlgorithm() {}

    bool requireCreator() const { return true; }

    void setAutomataCreator(const QSharedPointer<IAutomataCreator> &creator);

    bool hasSettingsDialog() const { return false; }
    void runSettingsDialog(QWidget *) {}

    bool run(const IAutomaton::TAutomataList &input, QSharedPointer<IAutomaton> &result,
             QString *report = 0) const;

protected:
    //! each basic algorithm has to implements this method
    virtual bool runInternal(const IAutomaton::TAutomataList &input,
                             QSharedPointer<IAutomaton> &result) const = 0;

    virtual bool removeMultipleInitials(QSharedPointer<IAutomaton> &automaton) const;
    virtual bool removeEpsilonTransitions(QSharedPointer<IAutomaton> &automaton) const;
    virtual bool determinize(QSharedPointer<IAutomaton> &automaton) const;

    void makeSureNameUnique(const QSharedPointer<IAutomaton> &automaton,
                            QString &name) const;

    void makeSureNamesUnique(const QSharedPointer<IAutomaton> &automaton1,
                             const QSharedPointer<IAutomaton> &automaton2) const;

    //! const because doesn't change algorithm, however changes report member
    virtual void addReport(const QString &text) const;

    IState::TIStateNameSet getEpsilonClosure(const QSharedPointer<IAutomaton> &automaton,
                                             const QSharedPointer<IState> &state) const;    
    
    bool tryMergeAlphabet(const ITransition::TCharSet &alphabet1,
                          const ITransition::TCharSet &alphabet2,
                          ITransition::TCharSet &alphabet) const;

    QSharedPointer<IAutomataCreator>    m_creator;
    
private:
    mutable QString     m_report;
};



class BasicAlgorithmWithSettings : public BasicAlgorithm
{
public:
    BasicAlgorithmWithSettings(bool preserveNames = false, bool preserveLabels = false);

    bool hasSettingsDialog() const { return true; }
    void runSettingsDialog(QWidget *parent);
    
    //! \name algorithm's settings
    //! \{
    bool preserveNames() const { return m_preserveNames; }
    bool preserveLabels() const { return m_preserveLabels; }
    void setPreserveNames(bool preserve) { m_preserveNames = preserve; }
    void setPreserveLabels(bool preserve) { m_preserveLabels = preserve; }
    //! \}

protected:    
    QString chooseStateName(QSharedPointer<IAutomaton> &automaton,
                            const QStringList &nameList, int num) const;
    QString chooseStateLabel(const QStringList &labelList, int num) const;
    
private:
    bool    m_preserveNames;
    bool    m_preserveLabels;
};



/*!
 * Jan Holub, X36JPR-03/23, 2008/2009
 */
class RemoveEpsilonAlgorithm : public BasicAlgorithm
{
public:
    ~RemoveEpsilonAlgorithm();

    QString getName() const;
    
    int getInputCount() const { return 1; }

protected:
    bool runInternal(const IAutomaton::TAutomataList &input,
                     QSharedPointer<IAutomaton> &result) const;    
};



/*!
 * Jan Holub, X36JPR-03/14, 2008/2009
 */
class RemoveInaccessibleAlgorithm: public BasicAlgorithm
{
public:
    ~RemoveInaccessibleAlgorithm();

    QString getName() const;

    int getInputCount() const { return 1; }

protected:
    bool runInternal(const IAutomaton::TAutomataList &input,
                     QSharedPointer<IAutomaton> &result) const;
};



/*!
 * Jan Holub, X36JPR-03/17, 2008/2009
 */
class RemoveUselessAlgorithm: public BasicAlgorithm
{
public:
    ~RemoveUselessAlgorithm();

    QString getName() const;

    int getInputCount() const { return 1; }

protected:
    bool runInternal(const IAutomaton::TAutomataList &input,
                     QSharedPointer<IAutomaton> &result) const;
};



/*!
 * Jan Holub, X36JPR-03/17, 2008/2009
 */
class RemoveMultipleInitialsAlgorithm: public BasicAlgorithm
{
public:
    ~RemoveMultipleInitialsAlgorithm();
    
    QString getName() const;

    int getInputCount() const { return 1; }

protected:
    bool runInternal(const IAutomaton::TAutomataList &input,
                     QSharedPointer<IAutomaton> &result) const;
};



/*!
 * Jan Holub, X36JPR-03/33, 2008/2009
 */
class DeterminizeAlgorithm: public BasicAlgorithmWithSettings
{
public:
    DeterminizeAlgorithm();
    ~DeterminizeAlgorithm();
    
    QString getName() const;
    
    int getInputCount() const { return 1; }
    
protected:
    bool runInternal(const IAutomaton::TAutomataList &input,
                     QSharedPointer<IAutomaton> &result) const;    
};


/*!
 * VSB Ostrava, TI, http://www.elearn.vsb.cz/archivcd/FEI/UTI/, Minimalizace KA
 */
class MinimalizeAlgorithm : public BasicAlgorithm
{
public:
    ~MinimalizeAlgorithm();

    QString getName() const;

    int getInputCount() const
    {
        return 1;
    }

protected:
    bool runInternal(const IAutomaton::TAutomataList &input,
                     QSharedPointer<IAutomaton> &result) const;    
};



/*!
 * X36PJP, Algorithm 2.71 - Jazyky a preklady, prof. Ing. Borivoj Melichar, DrSc. 2003
 */
class UniteParallelAlgorithm : public BasicAlgorithmWithSettings
{
public:
    UniteParallelAlgorithm();
    ~UniteParallelAlgorithm();
    
    QString getName() const;
    
    int getInputCount() const { return 2; }

protected:
    bool runInternal(const IAutomaton::TAutomataList &input,
                     QSharedPointer<IAutomaton> &result) const;
};



/*!
 * X36PJP, Algorithm 2.75 - Jazyky a preklady, prof. Ing. Borivoj Melichar, DrSc. 2003
 */
class IntersectionParallelAlgorithm : public BasicAlgorithmWithSettings
{
public:
    IntersectionParallelAlgorithm();
    ~IntersectionParallelAlgorithm();
    
    QString getName() const;
    
    int getInputCount() const { return 2; }

protected:
    bool runInternal(const IAutomaton::TAutomataList &input,
                     QSharedPointer<IAutomaton> &result) const;
};


class AlgorithmHolder : public QObject, public IAlgorithmHolder
{
    Q_OBJECT
    Q_INTERFACES(IAlgorithmHolder)
public:
    AlgorithmHolder();
    ~AlgorithmHolder();

    IAlgorithm::TAlgorithmList getAlgorithms() const;

    QString getVersion() const { return "2.0"; }

    QString getPluginName() const { return "Basic automata algorthms"; }

protected:

};

#endif // _ALGORITHMS_H_11656963715131_
